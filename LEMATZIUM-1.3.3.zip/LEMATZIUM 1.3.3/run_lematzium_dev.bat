@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "LOG_FILE=%TEMP%\lematzium_dev_launcher.log"
set "PY_CMD="

if exist ".venv\Scripts\python.exe" set "PY_CMD=.venv\Scripts\python.exe"
if not defined PY_CMD if exist "venv\Scripts\python.exe" set "PY_CMD=venv\Scripts\python.exe"

if not defined PY_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
    where py >nul 2>&1
    if not errorlevel 1 set "PY_CMD=py"
)

if not defined PY_CMD (
    > "%LOG_FILE%" echo No se encontro un interprete de Python utilizable.
    >>"%LOG_FILE%" echo Prueba creando un entorno virtual .venv o instala Python y agregalo al PATH.
    echo No se encontro un interprete de Python utilizable.
    echo Revisa el log: %LOG_FILE%
    pause
    exit /b 1
)

> "%LOG_FILE%" echo Usando interprete: %PY_CMD%
"%PY_CMD%" "launcher\lematzium_suite_launcher.py" 1>>"%LOG_FILE%" 2>&1

set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
    echo LEMATZIUM se cerro con error %EXIT_CODE%.
    echo Revisa el log: %LOG_FILE%
    pause
)
exit /b %EXIT_CODE%
