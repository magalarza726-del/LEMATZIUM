from lematzium_minijuego_retro.app import main

if __name__ == "__main__":
    main()
