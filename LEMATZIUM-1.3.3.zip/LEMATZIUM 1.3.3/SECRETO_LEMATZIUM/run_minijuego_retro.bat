@echo off
cd /d "%~dp0"
python launch_minijuego_retro.py
pause
