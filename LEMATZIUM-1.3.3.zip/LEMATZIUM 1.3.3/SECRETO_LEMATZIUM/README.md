# LEMATZIUM · Minijuego retro V6

Rediseño aplicado sobre el prototipo Python/Tkinter. Esta edición mantiene la esencia retro duotono/procedural y suma música, tutorial, guardado persistente, Time-space multi-teleport, pasivas automáticas, Jetpack real y entradas secretas señalizadas.

## Ejecutar

```bash
python launch_minijuego_retro.py
```

o en Windows:

```bat
run_minijuego_retro.bat
```


## Cambios V3: música, tutorial, memoria persistente y rutas secretas

- **Menú Música**: botón propio en el menú principal. Permite asignar 1 pista al menú principal y hasta 5 pistas por modo; el juego elige al azar al entrar en cada sección. La configuración se guarda de forma persistente.
- **Tutorial independiente**: botón propio en menú principal. Es un nivel fijo sin semilla, con equipo/árboles al máximo, enemigos controlados, textos en pantalla y secciones para practicar X Buster, Z Saber, Jetpack, Telequinesis, Shield, Nova y Time-space.
- **Memoria persistente por modo**: Clásico, Carrera, Multijugador, Arena y Desafío guardan semilla, nivel, XP, armas, árboles, vida, checkpoint y posición. El tutorial no sobreescribe progreso. El guardado usa esquema versionado y tolera cambios de árbol entre versiones.
- **X Buster seguimiento**: nueva rama de 5 mejoras. El disparo sigue enemigos durante 1s de base y hasta 2s con la rama completa.
- **Pasadizos secretos reales**: se generan salas secretas con entradas que exigen varios disparos de X Buster, cortes de Z Saber, Nova Dash o bomba de Jetpack. La generación vertical se amplió para rutas altas y salas intencionales.
- **Time-space corregido**: congela correctamente enemigos/proyectiles enemigos y la pantalla invierte colores mientras dura el efecto.
- **Enemigos más activos**: mayor rango de patrulla, IA con lectura del jugador y +10% de cadencia de disparo.
- **Cadencia de armas revisada**: los multiplicadores de árbol se aplican al cooldown real de disparo/uso.
- **Z Saber ajustado**: conserva su rango inicial, pero el rango máximo por mejoras queda reducido a la mitad.

## Catálogo final

### Armas

Todas las armas cuestan 6 XP para desbloquear, excepto X Buster que es inicial. Las ramas del árbol ahora están fraccionadas en **5 partes por nivel de rama**: por ejemplo, una rama que antes sumaba +2 en dos compras ahora entrega +0.4 por cada una de sus cinco partes. El jugador puede elegir libremente qué rama mejorar, respetando requisitos internos de esa rama. Las mejoras pequeñas cuestan 1 XP para que la granularidad no rompa la progresión.

- **X Buster**: arma inicial. Árbol de ataque, rango, velocidad de ataque, cantidad de balas 3/5, crítico + perforación.
- **Z Saber**: ataque, rango, velocidad, boomerang con carga de 2 segundos y mini-boomerang cada 3 ataques.
- **C Jetpack**: vuelo con mantenimiento de altura, tiempo de vuelo en 5 partes, disparos dobles hacia abajo y bombas cada 2 segundos de vuelo.
- **Telequinesis**: pasiva automática; al desbloquearse permite arrastrar cajas con el mouse durante 2s base, con mejoras de tiempo y daño de impacto.
- **B Shield**: escudo base de 2s, cooldown 5s; mejoras de defensa, duración y sombra que replica movimientos/ataques durante cooldown.

### Habilidades

Cada una cuesta 18 XP.

- **Parry**: pasiva automática; saltar sobre enemigos causa daño, rebota y abre una ventana breve de desvío. Ahora tiene árbol de 5 partes para daño, ventana y rebote.
- **Nova**: pasiva automática; el dash atraviesa enemigos sin daño de contacto y causa daño; invierte colores durante el dash. Ahora tiene árbol de 5 partes para daño/duración y el especial **LEMON DASH**: disparar durante Nova Dash causa crítico asegurado.
- **Time-space**: ralentiza el tiempo y permite teleports repetidos dentro de la pantalla visible hasta agotar duración, con cooldown interno reducido. Ahora tiene árbol de 5 partes para duración, daño radial de ruptura al teletransportar y recarga.
- **Cuarto salto**: pasiva automática que habilita hasta cuatro saltos permanentes.

## Modos de juego

- **Clásico**: modo de niveles normal/campaña con generación larga completa, jefes, pozos, checkpoints y rutas del mapa original.
- **Carrera**: antes de iniciar se configuran las sombras rivales activas: 4s, 3s, 2s y 1s. Ya no hay jefe final: se cruza la bandera **META** para avanzar al siguiente nivel. Cada sombra replica movimiento, disparos y habilidades del jugador con su retraso respectivo. Sus ataques solo dañan al jugador, pero las sombras sí pueden recibir daño de enemigos y reaparecen tras 3 segundos.
- **Multijugador**: P2 local con controles propios; fuego amigo configurable desde el menú. En pausa se muestran controles separados y J1 no usa WASD para evitar doble control.
- **Arena**: estadio estable **todos contra todos** con 15 IAs + jugador repartidos por todo el mapa. Ya no inicia con armas/árboles al máximo: todos arrancan con X Buster y el jugador con 6XP. Matar a un jugador/IA da 6XP al jugador y puntos individuales. Hay respawn tras 3 segundos, contador visible de 5 minutos, orbes de puntos y tabla final de posiciones. La cámara sigue al jugador/acción y los bots tienen antiatasco real.
- **Desafío**: sala compacta con 8 sombras permanentes del lado del jugador, sin sombras espejo: delays 4/3/2/1/5/6/7/8. Este modo inicia con armas, habilidades y árboles al máximo. Al otro extremo aparece el jefe exclusivo **Shadow Warp**, con el doble de vida y teletransporte global cada 30 segundos.

En el modo de niveles, enemigos y jefes aumentan vida y ataque +10% por cada nuevo nivel. Además, los jefes tienen **vida duplicada**, atacan con **cadencia 2.5x** respecto a la base y agregan patrones secundarios variados, manteniendo su movilidad original.

## Cambios V2.5: reparación de Arena, Desafío sin espejo y LEMON DASH

- **Arena reparada**: reemplaza la sala procedural por un estadio estable, sin pozos ni paredes que encajonen a las IAs.
- **Cámara de Arena**: sigue al jugador cuando está vivo y a la acción durante el respawn.
- **Contador visible**: el reloj de 5:00 aparece grande en el HUD.
- **IAs antiatasco**: saltan, cambian de dirección y se recolocan si quedan bloqueadas.
- **Desafío sin espejo**: 8 sombras del lado del jugador con delays 4/3/2/1/5/6/7/8.
- **Desafío al máximo**: todas las armas, habilidades y ramas del árbol empiezan completas en este modo.
- **Daño fijo de sombras**: todo ataque/contacto de sombra quita exactamente 7 de vida.
- **LEMON DASH**: especial de Nova; si disparas durante Nova Dash, el disparo causa crítico asegurado.

## Cambios V2.4: Carrera con meta, Arena FFA y sombras dañables

- **Carrera sin jefe**: el objetivo es llegar a la bandera META; al cruzarla se pasa al siguiente nivel.
- **Arena FFA 5:00**: 15 IAs + jugador, todos contra todos, distribuidos por todo el mapa.
- **Arena sin loadout máximo**: el jugador inicia con 6XP y el X Buster; debe comprar mejoras durante la partida.
- **Puntos + XP**: matar en Arena da 6XP al jugador y suma puntos; también existen orbes de puntos.
- **Respawn 3s**: jugador, IAs y sombras enemigas reaparecen tras 3 segundos.
- **Tabla final**: al terminar los 5 minutos aparece el ranking completo.
- **Multijugador claro**: la pausa muestra controles de J1 y J2; J1 usa flechas, no WASD, para evitar doble control.
- **Jefes ajustados**: la agresividad baja a la mitad del parche anterior; la cadencia queda en 2.5x manteniendo movilidad.
- **Sombras dañables por enemigos**: proyectiles y contacto enemigo pueden destruir sombras, que reaparecen luego.

## Cambios V2.3: jefes y árboles finos

- **Jefes 2.5x más agresivos**: su movimiento se mantiene igual, pero la cadencia de ataques queda a la mitad del parche 5x.
- **Ataques más variados**: cada jefe conserva su patrón principal y añade presión secundaria con abanicos, columnas, bombas, minions o disparos radiales.
- **Vida de jefes duplicada**: todos los jefes estándar tienen x2 vida; Shadow Warp mantiene su identidad de jefe especial y queda todavía más resistente.
- **Árboles en 5 partes**: cada rama se subdivide en cinco compras pequeñas. Una mejora total de +2 se reparte como +0.4 x 5.
- **Habilidades mejorables**: Parry, Nova y Time-space ahora tienen ramas propias de daño/duración/recarga según corresponda.

## Cambios V2 de preservación de esencia

- **Sombras ofensivas**: Carrera y Desafío respetan delays reales, replican ataques/habilidades del jugador y sus ataques quitan siempre 7 de vida fijo.
- **Configuración de Carrera**: selector pre-partida para activar/desactivar sombras de 4s, 3s, 2s y 1s.
- **Desafío sin espejo**: 8 sombras del lado del jugador con delays 4/3/2/1/5/6/7/8, armas al máximo y jefe exclusivo con doble vida/teletransporte.
- **Ritmo de nivel**: se redujo saturación de enemigos/trampas/pozos, pero se conservaron mundos largos, biomas, jefes y dificultad retro.
- **Taller más claro**: la pausa muestra ramas del árbol y permite comprar varios nodos disponibles por arma, no solo un botón lineal.
- **HUD más legible**: información permanente separada en vida/XP/tanques/Z/slots; cooldowns se muestran solo cuando importan.
- **Feedback visual**: cajas telequinéticas, pickups y enemigos tienen siluetas/pulsos más claros manteniendo el duotono.
- **Arena IA 15**: incorpora 15 CPUs con estilos buster, saber, sniper, charger, dasher, shield, bomber, tank, assassin, etc., ahora en free-for-all.
- **Limpieza**: documentación y manifest actualizados para eliminar referencias contradictorias a versiones anteriores, pared difícil desactivada.





## Cambios V7: Ninja, Cazador y N-Resurrection

- **Nuevo enemigo Ninja**: enemigo rápido que presiona distancia, lanza estrellas ninja y usa espada cuando entra en cuerpo a cuerpo.
- **Nuevo enemigo Cazador**: enemigo tipo escopeta que dispara **dos balas** con cadencia equivalente al X Buster inicial del jugador.
- **Nueva habilidad N-Resurrection**: revive el último enemigo asesinado por el jugador como aliado temporal de combate.
- **Rama de cantidad**: 4 mejoras; empieza con 1 enemigo revivido y llega hasta **5 aliados**.
- **Rama de vida**: 5 mejoras de **+10% de vida** para enemigos revividos.
- **Rama de ataque**: 5 mejoras de **+10% de ataque** para enemigos revividos.
- **IA aliada**: los enemigos revividos buscan enemigos hostiles, atacan con patrones según su tipo y pueden recibir daño de proyectiles enemigos.
- **Tutorial ampliado**: agrega secciones para practicar Parry, reconocer Ninja/Cazador y usar N-Resurrection después de matar un enemigo.

## Cambios V6: teleport Time-space más rápido

- **Cooldown de teleport reducido 70%**: el cooldown interno entre teleports de Time-space baja de **1.2s** a **0.36s**.
- **Multi-teleport conservado**: se siguen permitiendo teleports repetidos hasta que se agote Time-space, pero con una espera mucho menor entre clicks.

## Cambios V5: pasivas automáticas, Jetpack real y señales secretas

- **Pasivas al final del taller**: Nova, Parry, Cuarto salto y Telequinesis aparecen después de las habilidades activas.
- **Sin slots 1-3 para pasivas**: esas habilidades ya no se pueden configurar en Z ni en botones rápidos; funcionan automáticamente desde que se desbloquean.
- **Cuarto salto**: la antigua mejora de triple salto ahora permite hasta cuatro saltos permanentes.
- **Telequinesis automática**: al desbloquearla, basta con hacer click y arrastrar cajas; no requiere seleccionar V ni ocupar un slot.
- **Jetpack de vuelo**: al mantener C/Jetpack se mantiene la altura sin sumar gravedad normal; Up/W asciende y Down/S desciende suavemente.
- **Entradas secretas señalizadas**: los muros secretos muestran símbolo de requisito (`X`, `Z`, `NOVA`, `BOMB`) y contador de golpes cuando aplica.

## Cambios V4: Time-space multi-teleport y clon de Shield

- **Time-space multi-teleport**: mientras Time-space siga activo, el jugador puede hacer click para teletransportarse varias veces.
- **Cooldown reducido por teleport**: después de cada teleport aparece un cooldown interno de 0.36s antes del siguiente teleport; el HUD lo muestra como `TP`.
- **Fin seguro del efecto**: cuando Time-space termina, se limpia el estado pendiente de teleport y su cooldown interno.
- **Shield: rama Clon**: nueva rama de 5 mejoras. El clon empieza en 2s y llega a 7s al completar la rama.
- **Compatibilidad de guardado**: la rama usa nodos normales del árbol (`clone_1` a `clone_5`), por lo que se guarda con la memoria persistente existente por modo.

## Controles

### P1

- Movimiento: Flechas o WASD en modo individual. En multijugador, J1 solo usa flechas para evitar doble control.
- Saltar: Arriba / W en modo individual; solo Arriba en multijugador.
- Dash: Espacio o Enter.
- X Buster: X para disparar/cargar.
- Z: usar habilidad secundaria seleccionada.
- 1-3: seleccionar slots rápidos solo de habilidades activas. Nova, Parry, Cuarto salto y Telequinesis son automáticas.
- C: mantener Jetpack si está desbloqueado; mantiene altura, Up/W sube y Down/S baja.
- Telequinesis: al desbloquearla, arrastra cajas con el mouse; no ocupa V ni slots 1-3.
- B: activar Shield si está desbloqueado.
- Time-space: asígnala a un slot 1-3 y pulsa Z; luego haz click dentro de la pantalla para teletransportarte varias veces hasta que se agote el tiempo. Cada teleport tiene cooldown interno reducido 70% mostrado como `TP`.
- 0: tanque de curación.
- ESC: pausa/taller.
- N: si N-Resurrection está desbloqueada, la selecciona/activa; si no, genera nueva semilla manual.

### P2 local

- J/L: mover.
- I: saltar.
- K: dash.
- U: disparar X Buster.
- O: usar Z Saber.

## Archivos modificados

- `lematzium_minijuego_retro/content.py`: catálogo final de armas/habilidades, enemigos Ninja/Cazador, orden activo/pasivo y árboles de mejora incluida N-Resurrection.
- `lematzium_minijuego_retro/game.py`: lógica de modos, sombras ofensivas/configurables, Arena 15 IA, Desafío sin espejo + jefe Shadow Warp, ritmo de generación, HUD, taller de árboles libres, pasivas automáticas, señales secretas, telequinesis, Time-space, Shield, Jetpack, Nova, Parry, N-Resurrection, aliados revividos y escalado +10%.
- `lematzium_minijuego_retro/models.py`: añade `ArenaBot` para las IAs de Arena y conserva compatibilidad con el rediseño.


## V8 - Tutorial descongelado y verificación de modos

- El tutorial entra jugable de inmediato, sin intro larga que pueda sentirse como bloqueo.
- Los enemigos del tutorial ahora patrullan y atacan dentro de rangos seguros; ya no quedan casi estáticos.
- El tutorial no genera peligros ambientales aleatorios encima de las secciones guiadas.
- Se añadió un failsafe para limpiar estados temporales de Time-space/intro al iniciar tutorial.
- Se verificó por simulación que clásico, carrera, multijugador, arena, desafío y tutorial avanzan sin detener el bucle.


## V9 - Seguimiento corregido y Arena vertical

- **X Buster sin seguimiento prematuro**: las balas normales ya no buscan objetivos si la rama Seguimiento no está desbloqueada.
- **Seguimiento 1/5** activa seguimiento por **1.0s**; al completar **Seguimiento 5/5** llega a **2.0s**.
- **Arena más aérea**: el estadio ahora genera muchas más plataformas en varias alturas para combates verticales.
- **IA de Arena vertical**: los bots usan waypoints de plataformas, saltan para alcanzar alturas y bajan de plataforma cuando el objetivo está por debajo.
- **Color uniforme de bots**: todas las IAs de Arena usan el mismo color naranja, distinto al jugador, para que el jugador destaque mejor.
