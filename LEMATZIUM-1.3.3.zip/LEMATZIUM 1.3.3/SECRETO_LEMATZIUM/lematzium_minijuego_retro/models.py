from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    name: str
    base: str
    ink: str


@dataclass(frozen=True)
class CharacterSpec:
    key: str
    name: str
    desc: str
    primary: str
    secondary: str
    jumps: int




@dataclass(frozen=True)
class BiomeSpec:
    key: str
    name: str
    desc: str
    sky: str
    shadow: str
    mid: str
    ground: str
    accent: str
    glow: str
    hazard: str
    gravity_mult: float = 1.0
    speed_mult: float = 1.0
    width_mult: float = 1.0
    height_mult: float = 1.0
    pit_mult: float = 1.0

@dataclass
class RetroPlayer:
    x: float = 94.0
    y: float = 0.0
    w: float = 26.0
    h: float = 34.0
    vx: float = 0.0
    vy: float = 0.0
    facing: int = 1
    on_ground: bool = False
    jumps_used: int = 0
    wall_side: int = 0
    walk_phase: float = 0.0
    dash_timer: float = 0.0
    dash_cooldown: float = 0.0
    attack_timer: float = 0.0
    attack_cooldown: float = 0.0
    shoot_cooldown: float = 0.0
    hurt_timer: float = 0.0
    hp: int | float = 30
    max_hp: int | float = 30
    flight_left: float = 3.0
    flight_cooldown: float = 0.0
    flight_bob: float = 0.0
    crouching: bool = False
    base_h: float = 34.0
    crouch_h: float = 22.0
    perfect_dash_timer: float = 0.0
    damage_bonus_timer: float = 0.0
    attack_speed_bonus_timer: float = 0.0


@dataclass
class ArenaBot:
    player: RetroPlayer
    name: str
    style: str
    team: int
    index: int
    alive: bool = True
    respawn_timer: float = 0.0
    think_timer: float = 0.0
    action_timer: float = 0.0
    shield_timer: float = 0.0
    special_timer: float = 0.0
    target_kind: str = ""
    target_index: int = -1


@dataclass
class RetroProjectile:
    x: float
    y: float
    vx: float
    vy: float = 0.0
    life: float = 1.4
    damage: int | float = 1
    kind: str = "normal"
    level: int = 0
    owner: str = "player"
    origin_x: float = 0.0
    origin_y: float = 0.0
    max_distance: float = 420.0
    returning: bool = False
    hit_ids: set[int] | None = None
    radius: float = 0.0
    gravity: float = 0.0
    stuck: bool = False
    target_id: int | None = None
    bounces: int = 0
    ability: str = ""
    homing_time: float = 0.0


@dataclass(frozen=True)
class RetroRect:
    x: float
    y: float
    w: float
    h: float
    kind: str = "platform"


@dataclass(frozen=True)
class RetroPit:
    x: float
    w: float


@dataclass
class RetroEnemy:
    x: float
    y: float
    w: float
    h: float
    vx: float
    kind: str
    hp: int | float
    max_hp: int | float
    attack: int | float
    patrol_left: float
    patrol_right: float
    phase: float = 0.0
    alive: bool = True
    hurt_flash: float = 0.0
    home_y: float = 0.0
    shoot_timer: float = 0.0
    pattern_timer: float = 0.0
    status_effects: dict[str, float] | None = None
    armor: float = 0.0
    weakness: str = ""
    resistance: str = ""
    elite_mod: str = ""


@dataclass
class RetroPickup:
    x: float
    y: float
    kind: str
    collected: bool = False


@dataclass
class RetroBox:
    x: float
    y: float
    w: float = 30.0
    h: float = 28.0
    vx: float = 0.0
    vy: float = 0.0
    grabbed: bool = False


@dataclass
class RetroCheckpoint:
    x: float
    y: float
    label: str
    activated: bool = False


@dataclass
class SecretGate:
    rect: RetroRect
    ability: str
    label: str
    opened: bool = False
    hits_left: int = 1
    max_hits: int = 1


@dataclass
class RetroEffect:
    x: float
    y: float
    radius: float
    life: float
    kind: str = "boom"
