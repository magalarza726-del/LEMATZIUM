from __future__ import annotations

# Punto de entrada de compatibilidad: el código grande vive en game.py
# para que el proyecto pueda crecer por módulos.
from .game import RetroMinigame, main

__all__ = ["RetroMinigame", "main"]


if __name__ == "__main__":
    main()
