"""Minijuego retro LEMATZIUM como módulo independiente."""

from .app import main
from .game import RetroMinigame

__all__ = ["RetroMinigame", "main"]
