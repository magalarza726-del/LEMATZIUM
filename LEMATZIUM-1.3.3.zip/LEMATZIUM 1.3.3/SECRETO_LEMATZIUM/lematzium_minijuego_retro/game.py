from __future__ import annotations

import json
import math
import os
from pathlib import Path
import random
import time
import tkinter as tk
from tkinter import filedialog

from .content import (
    ABILITY_INFO,
    ABILITY_ORDER,
    APP_TITLE,
    BIOME_RULES,
    BOSS_ORDER,
    BOSS_SPECS,
    BIOMES,
    CHARACTERS,
    DASH_MAX_SPEED,
    ENEMY_BEHAVIOR_SPECS,
    ENEMY_STATS,
    ENEMY_XP,
    FRAME_MS,
    FLIGHT_COOLDOWN,
    FLIGHT_DURATION,
    HARD_CHASER_SPEED,
    LEVEL_MODIFIER_ORDER,
    LEVEL_MODIFIERS,
    PALETTES,
    STARTING_PLAYER_HP,
    TILE,
    UPGRADE_COST,
    WEAPON_UPGRADE_TREES,
)
from .models import (
    BiomeSpec,
    CharacterSpec,
    ArenaBot,
    RetroBox,
    RetroCheckpoint,
    RetroEffect,
    RetroEnemy,
    RetroPickup,
    RetroPit,
    RetroPlayer,
    RetroProjectile,
    RetroRect,
    SecretGate,
 )


ARENA_AI_STYLES: tuple[str, ...] = (
    "buster", "saber", "charger", "sniper", "jumper",
    "dasher", "shield", "telekinetic", "nova", "bomber",
    "hunter", "coward", "flanker", "tank", "assassin",
)

SHADOW_DELAY_PRESETS: tuple[float, ...] = (4.0, 3.0, 2.0, 1.0)
CHALLENGE_SHADOW_DELAYS: tuple[float, ...] = (3.0, 3.5, 4.0, 4.75, 5.5, 6.25, 7.0, 8.0)
CHALLENGE_SHADOW_SPAWN_GRACE = 3.0
CHALLENGE_SAFE_INTRO = 3.0
ARENA_ATTACK_PREFERENCE = 0.50
ARENA_BOT_JUMP_COOLDOWN = 0.82
SHADOW_FIXED_DAMAGE = 7
ARENA_MATCH_SECONDS = 300.0
ARENA_KILL_XP = 6
ARENA_BOT_COUNT = 15
ARENA_POINT_ORB_TARGET = 36
MUSIC_TARGETS: tuple[tuple[str, str], ...] = (
    ("main", "Pantalla principal"),
    ("classic", "Clásico"),
    ("race", "Carrera"),
    ("multiplayer", "Multijugador"),
    ("arena", "Arena"),
    ("challenge", "Desafío"),
    ("tutorial", "Tutorial"),
)
SAVE_SCHEMA_VERSION = 7
ENEMY_FIRE_COOLDOWN_MULT = 0.90
CAMPAIGN_MODES: set[str] = {"campaign_day", "campaign_night"}
TUTORIAL_MODES: set[str] = {"tutorial", "tutorial_night", "tutorial_free", "tutorial_free_night"}

# Estas habilidades son automáticas desde que se desbloquean: no ocupan Z ni slots 1-3.
PASSIVE_AUTO_ABILITIES: set[str] = {"nova", "parry", "triple_jump", "telekinesis", "flashlight"}
DEFAULT_QUICK_SLOTS: dict[str, str] = {"1": "sword", "2": "flight", "3": "shield"}
SECRET_GATE_SYMBOLS: dict[str, str] = {
    "gun": "X",
    "sword": "Z",
    "nova": "NOVA",
    "bomb": "BOMB",
    "flight": "JP",
}


class RetroMinigame:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("960x560")
        self.root.minsize(760, 440)

        self.palette_index = 0
        self.palette = PALETTES[self.palette_index]
        self.retro_seed = random.SystemRandom().randrange(1, 2_147_483_647)
        self.boss_route_seed = self.retro_seed
        self.game_state = "select"
        self.selected_character: CharacterSpec | None = CHARACTERS[0]
        self.selected_mode = "campaign_day"
        self.friendly_fire = False
        self.arena_vs_cpu = True
        self.level_number = 1
        self.current_biome: BiomeSpec = BIOMES[0]
        self.character_cards: list[tuple[float, float, float, float, CharacterSpec]] = []
        self.mode_buttons: list[tuple[float, float, float, float, str]] = []
        self.achievement_buttons: dict[str, tuple[float, float, float, float]] = {}
        self.start_choice_buttons: dict[str, tuple[float, float, float, float]] = {}
        self._pending_start_spec: CharacterSpec | None = None
        self.race_shadow_buttons: list[tuple[float, float, float, float, float]] = []
        self.pause_buttons: dict[str, tuple[float, float, float, float]] = {}
        self.race_shadow_delays: list[float] = list(SHADOW_DELAY_PRESETS)
        self.shadow_action_history: list[tuple[int, float, str, dict[str, object]]] = []
        self.shadow_action_cursors: dict[int, int] = {}
        self._shadow_next_action_id = 1
        self.arena_bots: list[ArenaBot] = []
        self.arena_player_team = -1
        self.arena_scores: dict[int, int] = {-1: 0}
        self.arena_match_timer = ARENA_MATCH_SECONDS
        self.arena_match_over = False
        self.arena_player_respawn_timer = 0.0
        self._arena_last_player_attacker: int | None = None
        self.arena_orb_spawn_timer = 0.0
        self.race_finish_x = 0.0
        self.race_finish_reached = False

        self.retro_player = RetroPlayer()
        self.retro_projectiles: list[RetroProjectile] = []
        self.retro_obstacles: list[RetroRect] = []
        self.retro_pits: list[RetroPit] = []
        self.retro_enemies: list[RetroEnemy] = []
        self.retro_pickups: list[RetroPickup] = []
        self.retro_boxes: list[RetroBox] = []
        self.dragged_box_index: int | None = None
        self._last_mouse_world: tuple[float, float] | None = None
        self.retro_checkpoints: list[RetroCheckpoint] = []
        self.active_checkpoint_index = -1
        self.secret_gates: list[SecretGate] = []
        self.retro_effects: list[RetroEffect] = []
        self.retro_world_size: tuple[int, int, int, int, int] | None = None
        self.retro_world_width = 0
        self.retro_world_height = 0
        self.boss_room_entry_x = 0.0
        self.boss_room_stop_x = 0.0
        self.retro_camera_x = 0.0
        self.retro_camera_y = 0.0
        self.xp_count = 0
        self.hp_upgrade = 0
        self.active_primary_slot = "gun"
        self.active_secondary_slot = "none"
        # Slots rápidos reasignables: teclas 1-3 solo apuntan a habilidades activas.
        self.quick_slots: dict[str, str] = dict(DEFAULT_QUICK_SLOTS)
        self.owned_abilities: dict[str, bool] = {ability: False for ability in ABILITY_ORDER}
        self.owned_abilities["gun"] = True
        self.owned_abilities["flashlight"] = True
        self.ability_levels: dict[str, int] = {ability: 0 for ability in ("gun", *ABILITY_ORDER)}
        self.weapon_tree_nodes_owned: dict[str, set[str]] = {ability: set() for ability in ("gun", *ABILITY_ORDER)}
        self.pause_page = 0
        self.status_notice_timer = 0.0
        self.status_notice_text = ""
        self.combo_count = 0
        self.combo_timer = 0.0
        self.perfect_dash_timer = 0.0
        self.parry_timer = 0.0
        self.quantum_anchor: tuple[float, float] | None = None
        self.orbit_blades_timer = 0.0
        self.level_modifier_key = "storm"
        self.level_spec: dict[str, object] = {}
        self.heal_tanks = 1
        self.clone_timer = 0.0
        self.clone_history: list[tuple[float, float, float, int, bool, int]] = []
        self.shield_timer = 0.0
        self.shield_cooldown = 0.0
        self.slow_time_timer = 0.0
        self.slow_time_cooldown = 0.0
        self._time_space_pending_teleport = False
        self._time_space_teleport_cooldown = 0.0
        self._last_resurrection_blueprint: dict[str, object] | None = None
        self.sword_attack_count = 0
        self._flight_downshot_timer = 0.0
        self._flight_bomb_timer = 0.0
        self.shadow_chaser_history: list[tuple[float, float, float, int, bool, int]] = []
        self.shadow_damage_cooldown = 0.0
        self.shadow_chaser_hp: dict[int, float] = {}
        self.shadow_chaser_max_hp: dict[int, float] = {}
        self.shadow_chaser_hurt: dict[int, float] = {}
        self.shadow_chaser_respawn: dict[int, float] = {}
        self.shadow_action_history = []
        self.shadow_action_cursors = {}
        self._shadow_next_action_id = 1
        self.arena_bots = []
        self.arena_scores = {-1: 0}
        self.arena_match_timer = ARENA_MATCH_SECONDS
        self.arena_match_over = False
        self.arena_player_respawn_timer = 0.0
        self._arena_last_player_attacker = None
        self.arena_orb_spawn_timer = 0.0
        self.race_finish_x = 0.0
        self.race_finish_reached = False
        self.telekinesis_grab_started = 0.0
        self.p2_player = RetroPlayer(x=154.0)
        self.p2_enabled = False
        self.p2_is_cpu = False
        self.p2_score = 0
        self.p1_score = 0
        self.challenge_timer = 22.0
        self.challenge_safe_timer = 0.0
        self._p2_last_jump_pressed = False
        self._p2_last_dash_pressed = False
        self._p2_last_primary_pressed = False
        self._p2_last_secondary_pressed = False
        self._z_sword_charge_active = False
        self._z_sword_charge_started = 0.0
        self._pending_level_advance = 0.0
        self.hard_spike_wall_x = -760.0
        self.hard_spike_wall_width = 64.0
        self.win_banner_timer = 0.0
        self.level_intro_timer = 0.0

        self.pressed_keys: set[str] = set()
        self._last_jump_pressed = False
        self._last_dash_pressed = False
        self._last_primary_pressed = False
        self._last_secondary_pressed = False
        self._x_charge_active = False
        self._x_charge_started = 0.0
        self.anim_phase = 0.0
        self._last_frame_time = time.perf_counter()
        self._color_button_bbox = (12, 12, 74, 32)
        self._pause_button_bbox = (82, 12, 156, 32)
        self._music_button_bbox = (166, 12, 250, 32)
        self.music_buttons: dict[str, tuple[float, float, float, float]] = {}
        self.music_target = "main"
        self.music_selected_index = -1
        self.music_tracks: dict[str, list[str]] = {key: [] for key, _label in MUSIC_TARGETS}
        self._music_backend_checked = False
        self._music_backend = None
        self._music_context = ""
        self._music_current_path = ""
        self._save_path = Path(os.environ.get("LEMATZIUM_SAVE_FILE", Path.home() / ".lematzium_retro_save_v3.json"))
        self._save_cache: dict[str, object] = {"schema_version": SAVE_SCHEMA_VERSION, "modes": {}, "music": self.music_tracks, "achievements": {}}
        self.tutorial_messages: list[tuple[float, float, str]] = []
        self._pending_restore_after_world: dict[str, object] | None = None
        self.flashlight_on = False
        self.flashlight_energy = 10.0
        self.flashlight_recharge = 0.0
        self.flashlight_recharge_total = 0.0
        self._flashlight_session_used = 0.0
        self._load_persistent_data()

        self.canvas = tk.Canvas(root, highlightthickness=0, bd=0, takefocus=True)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Button-1>", self._on_canvas_click)
        self.canvas.bind("<B1-Motion>", self._on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_canvas_release)
        # Teclado solo en root: antes canvas + root procesaban la misma tecla dos veces.
        # Eso hacía que F encendiera y apagara la linterna en el mismo fotograma.
        self.canvas.bind("<FocusOut>", self._on_focus_out)
        self.root.bind("<KeyPress>", self._on_key_press, add="+")
        self.root.bind("<KeyRelease>", self._on_key_release, add="+")
        self.root.after(100, self.canvas.focus_set)

        self.level_intro_timer = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 7.0
        self._reset_retro_world(max(360, self.canvas.winfo_width()), max(220, self.canvas.winfo_height()), keep_player_ratio=False)
        self._apply_palette_to_window()
        self._set_music_context("main")
        self.canvas.focus_set()
        self._schedule_animation()

    def _load_persistent_data(self) -> None:
        try:
            if self._save_path.exists():
                data = json.loads(self._save_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self._save_cache = data
        except Exception:
            self._save_cache = {"schema_version": SAVE_SCHEMA_VERSION, "modes": {}, "music": {}}
        self._save_cache.setdefault("schema_version", SAVE_SCHEMA_VERSION)
        self._save_cache.setdefault("modes", {})
        self._save_cache.setdefault("achievements", {})
        music = self._save_cache.setdefault("music", {})
        if not isinstance(music, dict):
            music = {}
            self._save_cache["music"] = music
        for key, _label in MUSIC_TARGETS:
            raw = music.get(key, [])
            if not isinstance(raw, list):
                raw = []
            clean: list[str] = []
            for path in raw:
                if isinstance(path, str) and path and path not in clean:
                    clean.append(path)
            limit = 1 if key == "main" else 5
            self.music_tracks[key] = clean[:limit]
        self._save_cache["music"] = self.music_tracks

    def _write_persistent_data(self) -> None:
        self._save_cache["schema_version"] = SAVE_SCHEMA_VERSION
        self._save_cache["music"] = self.music_tracks
        self._save_cache.setdefault("modes", {})
        self._save_cache.setdefault("achievements", {})
        try:
            self._save_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._save_path.with_suffix(self._save_path.suffix + ".tmp")
            tmp.write_text(json.dumps(self._save_cache, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self._save_path)
        except Exception:
            # El juego no debe romperse si la carpeta del usuario es de solo lectura.
            pass

    def _persistent_mode_key(self) -> str | None:
        if self._is_tutorial_mode():
            return None
        return self.selected_mode

    def _serialize_mode_progress(self) -> dict[str, object]:
        player = self.retro_player
        return {
            "schema_version": SAVE_SCHEMA_VERSION,
            "mode": self.selected_mode,
            "level_number": int(self.level_number),
            "retro_seed": int(self.retro_seed),
            "boss_route_seed": int(self.boss_route_seed),
            "xp_count": int(self.xp_count),
            "hp_upgrade": int(self.hp_upgrade),
            "heal_tanks": int(self.heal_tanks),
            "player": {"x": float(player.x), "y": float(player.y), "hp": float(player.hp), "max_hp": float(player.max_hp)},
            "active_checkpoint_index": int(self.active_checkpoint_index),
            "active_secondary_slot": self.active_secondary_slot,
            "quick_slots": dict(self.quick_slots),
            "owned_abilities": dict(self.owned_abilities),
            "ability_levels": dict(self.ability_levels),
            "weapon_tree_nodes_owned": {ability: sorted(list(nodes)) for ability, nodes in self.weapon_tree_nodes_owned.items()},
            "last_resurrection_blueprint": dict(self._last_resurrection_blueprint or {}),
        }

    def _save_mode_progress(self) -> None:
        mode_key = self._persistent_mode_key()
        if not mode_key:
            return
        modes = self._save_cache.setdefault("modes", {})
        if isinstance(modes, dict):
            modes[mode_key] = self._serialize_mode_progress()
            self._write_persistent_data()

    def _restore_mode_progress(self, mode: str) -> bool:
        modes = self._save_cache.get("modes", {})
        if not isinstance(modes, dict):
            return False
        data = modes.get(mode)
        if not isinstance(data, dict):
            return False
        try:
            self.level_number = max(1, int(data.get("level_number", 1)))
            self.retro_seed = max(1, int(data.get("retro_seed", self.retro_seed)))
            self.boss_route_seed = max(1, int(data.get("boss_route_seed", self.retro_seed)))
            self.xp_count = max(0, int(data.get("xp_count", self.xp_count)))
            self.hp_upgrade = max(0, int(data.get("hp_upgrade", self.hp_upgrade)))
            self.heal_tanks = max(0, int(data.get("heal_tanks", self.heal_tanks)))
            self.active_secondary_slot = str(data.get("active_secondary_slot", self.active_secondary_slot))
            raw_slots = data.get("quick_slots", {})
            if isinstance(raw_slots, dict):
                self.quick_slots.update({str(k): str(v) for k, v in raw_slots.items() if str(k) in {"1", "2", "3"}})
            raw_owned = data.get("owned_abilities", {})
            if isinstance(raw_owned, dict):
                for ability in ABILITY_ORDER:
                    self.owned_abilities[ability] = bool(raw_owned.get(ability, self.owned_abilities.get(ability, False)))
                self.owned_abilities["gun"] = True
                self.owned_abilities["flashlight"] = True
            raw_levels = data.get("ability_levels", {})
            if isinstance(raw_levels, dict):
                for ability in ("gun", *ABILITY_ORDER):
                    self.ability_levels[ability] = max(0, int(raw_levels.get(ability, self.ability_levels.get(ability, 0))))
            raw_nodes = data.get("weapon_tree_nodes_owned", {})
            if isinstance(raw_nodes, dict):
                for ability in ("gun", *ABILITY_ORDER):
                    nodes = raw_nodes.get(ability, [])
                    if isinstance(nodes, (list, tuple, set)):
                        valid = {str(n.get("id", "")) for n in self._iter_tree_nodes(ability)}
                        self.weapon_tree_nodes_owned[ability] = {str(node) for node in nodes if str(node) in valid}
                        self._sync_ability_level_from_tree(ability)
            raw_blueprint = data.get("last_resurrection_blueprint", {})
            self._last_resurrection_blueprint = dict(raw_blueprint) if isinstance(raw_blueprint, dict) else None
            self._ensure_quick_slots()
            self._sanitize_active_secondary_slot()
            player_data = data.get("player", {})
            if isinstance(player_data, dict):
                self._pending_restore_after_world = {
                    "x": float(player_data.get("x", 94.0)),
                    "y": float(player_data.get("y", 0.0)),
                    "hp": float(player_data.get("hp", STARTING_PLAYER_HP)),
                    "max_hp": float(player_data.get("max_hp", STARTING_PLAYER_HP + self.hp_upgrade * 5)),
                    "checkpoint": int(data.get("active_checkpoint_index", -1)),
                }
            return True
        except Exception:
            self._pending_restore_after_world = None
            return False

    def _apply_pending_restore_after_world(self) -> None:
        data = getattr(self, "_pending_restore_after_world", None)
        if not isinstance(data, dict):
            return
        player = self.retro_player
        ground = self._retro_ground_y()
        player.max_hp = max(1.0, float(data.get("max_hp", STARTING_PLAYER_HP + self.hp_upgrade * 5)))
        player.hp = max(1.0, min(player.max_hp, float(data.get("hp", player.max_hp))))
        player.x = max(8.0, min(self.retro_world_width - player.w - 8.0, float(data.get("x", 94.0))))
        player.y = max(8.0, min(float(ground - player.h), float(data.get("y", ground - player.h))))
        self.active_checkpoint_index = max(-1, min(len(self.retro_checkpoints) - 1, int(data.get("checkpoint", -1))))
        if self.selected_mode == "challenge":
            self._place_challenge_boss_opposite_player()
            self.challenge_safe_timer = max(getattr(self, "challenge_safe_timer", 0.0), CHALLENGE_SAFE_INTRO)
            self.shadow_chaser_history.clear()
            self.shadow_action_cursors.clear()
        self._retro_update_camera(max(360, self.canvas.winfo_width()), max(220, self.canvas.winfo_height()), instant=True)
        self._pending_restore_after_world = None

    def _music_label(self, target: str) -> str:
        return dict(MUSIC_TARGETS).get(target, target)

    def _get_music_backend(self):
        if self._music_backend_checked:
            return self._music_backend
        self._music_backend_checked = True
        try:
            import pygame  # type: ignore
            pygame.mixer.init()
            self._music_backend = pygame
        except Exception:
            self._music_backend = None
        return self._music_backend

    def _set_music_context(self, target: str) -> None:
        target = target if target in self.music_tracks else "main"
        if self._music_context == target:
            return
        self._music_context = target
        tracks = [path for path in self.music_tracks.get(target, []) if isinstance(path, str) and Path(path).exists()]
        if not tracks:
            if self._music_current_path:
                backend = self._get_music_backend()
                if backend is not None:
                    try:
                        backend.mixer.music.stop()
                    except Exception:
                        pass
            self._music_current_path = ""
            return
        backend = self._get_music_backend()
        if backend is None:
            return
        path = random.choice(tracks)
        if path == self._music_current_path:
            return
        try:
            backend.mixer.music.load(path)
            backend.mixer.music.play(-1)
            self._music_current_path = path
        except Exception:
            self._music_current_path = ""

    def _add_music_track(self) -> None:
        target = self.music_target if self.music_target in self.music_tracks else "main"
        limit = 1 if target == "main" else 5
        if len(self.music_tracks.get(target, [])) >= limit:
            self.status_notice_text = "LÍMITE: 1 MÚSICA EN MENÚ" if target == "main" else "LÍMITE: 5 MÚSICAS POR MODO"
            self.status_notice_timer = 2.2
            return
        path = filedialog.askopenfilename(
            title=f"Agregar música a {self._music_label(target)}",
            filetypes=(('Audio', '*.mp3 *.ogg *.wav *.flac *.mid *.midi'), ('Todos los archivos', '*.*')),
        )
        if not path:
            return
        tracks = self.music_tracks.setdefault(target, [])
        if path not in tracks:
            tracks.append(path)
            self.music_tracks[target] = tracks[:limit]
            self._write_persistent_data()
            self._music_context = ""
            self._set_music_context(target if self.game_state != "playing" else self.selected_mode)

    def _remove_music_track(self, target: str, index: int) -> None:
        tracks = self.music_tracks.get(target, [])
        if 0 <= index < len(tracks):
            removed = tracks.pop(index)
            self._write_persistent_data()
            if removed == self._music_current_path:
                backend = self._get_music_backend()
                if backend is not None:
                    try:
                        backend.mixer.music.stop()
                    except Exception:
                        pass
                self._music_current_path = ""
                self._music_context = ""

    def _apply_palette_to_window(self) -> None:
        # En juego, el duotono depende del bioma y si es día/noche.
        # En menú se conserva el botón Color original.
        base, _ink = self._retro_duotone()
        self.root.configure(bg=base)
        self.canvas.configure(bg=base)
        if self.game_state == "select":
            subtitle = f"{self.palette.name} · modo {self.selected_mode.upper()}"
        else:
            char_name = self.selected_character.name if self.selected_character else "?"
            subtitle = f"{char_name} · Nivel {self._display_level_label()} · {self._level_biome_label()} · {self.selected_mode.upper()}"
        self.root.title(f"{APP_TITLE} · {subtitle}")

    def _cycle_palette(self) -> None:
        self.palette_index = (self.palette_index + 1) % len(PALETTES)
        self.palette = PALETTES[self.palette_index]
        self._apply_palette_to_window()
        self.canvas.focus_set()
        self._draw()

    def _schedule_animation(self) -> None:
        try:
            if not self.root.winfo_exists():
                return
            now = time.perf_counter()
            dt = max(0.010, min(0.075, now - self._last_frame_time))
            self._last_frame_time = now
            self.anim_phase += 0.09
            if self.game_state == "playing":
                self._update_retro_game(dt)
            self._draw()
            self.root.after(FRAME_MS, self._schedule_animation)
        except tk.TclError:
            return

    def _draw(self) -> None:
        width = max(360, self.canvas.winfo_width())
        height = max(220, self.canvas.winfo_height())
        self.canvas.delete("all")
        if self.game_state == "select":
            self._draw_character_select(self.canvas, width, height)
        elif self.game_state == "music":
            self._draw_music_menu(self.canvas, width, height)
        elif self.game_state == "achievements":
            self._draw_achievements_menu(self.canvas, width, height)
        elif self.game_state == "start_choice":
            self._draw_start_choice(self.canvas, width, height)
        else:
            self._draw_retro_scene(self.canvas, width, height)

    def _is_campaign_mode(self) -> bool:
        return self.selected_mode in CAMPAIGN_MODES

    def _is_tutorial_mode(self) -> bool:
        return self.selected_mode in TUTORIAL_MODES

    def _is_tutorial_guided(self) -> bool:
        return self.selected_mode in {"tutorial", "tutorial_night"}

    def _is_tutorial_free(self) -> bool:
        return self.selected_mode in {"tutorial_free", "tutorial_free_night"}

    def _is_mode_night(self) -> bool:
        return self.selected_mode in {"campaign_night", "tutorial_night", "tutorial_free_night"}

    def _achievement_store(self) -> dict[str, object]:
        achievements = self._save_cache.setdefault("achievements", {})
        if not isinstance(achievements, dict):
            achievements = {}
            self._save_cache["achievements"] = achievements
        return achievements

    def _day_campaign_completed(self) -> bool:
        return bool(self._achievement_store().get("yo_mi_peor_enemigo", False))

    def _has_saved_progress(self, mode: str) -> bool:
        modes = self._save_cache.get("modes", {})
        return isinstance(modes, dict) and isinstance(modes.get(mode), dict)

    def _campaign_enemy_quantity_mult(self) -> float:
        if not self._is_campaign_mode():
            return 1.0
        return {1: 1.0, 2: 1.5, 4: 2.0, 5: 2.5}.get(int(self.level_number), 1.0)

    def _campaign_enemy_stat_mult(self, kind: str) -> float:
        if not self._is_campaign_mode():
            return 1.0
        if kind == "attack":
            return {1: 1.0, 2: 1.2, 4: 1.5, 5: 2.0}.get(int(self.level_number), 1.0)
        return {1: 1.0, 2: 1.2, 4: 1.5, 5: 2.0}.get(int(self.level_number), 1.0)

    def _campaign_boss_count(self) -> int | None:
        if not self._is_campaign_mode():
            return None
        return {1: 1, 2: 2, 4: 3, 5: 0}.get(int(self.level_number), 1)

    def _campaign_is_arena_stage(self) -> bool:
        return self._is_campaign_mode() and int(self.level_number) in {3, 6}

    def _campaign_has_spike_wall(self) -> bool:
        return self._is_campaign_mode() and int(self.level_number) in {1, 2, 4, 5}

    def _campaign_has_finish_goal(self) -> bool:
        return self._is_campaign_mode() and int(self.level_number) == 5

    def _campaign_shadow_objective_clear(self) -> bool:
        specs = self._shadow_specs()
        if not specs:
            return True
        self._ensure_shadow_chaser_health()
        return all(self.shadow_chaser_hp.get(index, 0.0) <= 0.0 for index in range(len(specs)))

    def _campaign_final_boss_clear(self) -> bool:
        return not any(enemy.alive and enemy.kind.startswith("boss") for enemy in self.retro_enemies)

    def _maybe_complete_campaign_arena_objective(self) -> None:
        if not self._campaign_is_arena_stage() or self.level_intro_timer > 0 or self._pending_level_advance > 0:
            return
        if int(self.level_number) == 3 and self._campaign_shadow_objective_clear():
            self.win_banner_timer = 1.25
            self._pending_level_advance = 1.25
        elif int(self.level_number) == 6 and self._campaign_shadow_objective_clear() and self._campaign_final_boss_clear():
            self.win_banner_timer = 1.25
            self._pending_level_advance = 1.25

    def _complete_campaign_if_needed(self) -> bool:
        if not self._is_campaign_mode() or int(self.level_number) < 6:
            return False
        if self.selected_mode == "campaign_day":
            achievements = self._achievement_store()
            if not achievements.get("yo_mi_peor_enemigo", False):
                achievements["yo_mi_peor_enemigo"] = True
                self.status_notice_text = "LOGRO CONSEGUIDO: YO, MI PEOR ENEMIGO"
                self.status_notice_timer = 8.0
                self._write_persistent_data()
        self.game_state = "achievements"
        self._set_music_context("main")
        self._apply_palette_to_window()
        self._draw()
        return True

    def _mode_label(self, mode: str | None = None) -> str:
        mode = self.selected_mode if mode is None else mode
        return {
            "campaign_day": "Campaña día",
            "campaign_night": "Campaña noche",
            "tutorial": "Tutorial nivel 0 · guiado día",
            "tutorial_night": "Tutorial nivel 0 · guiado noche",
            "tutorial_free": "Tutorial nivel 0.5 · práctica libre día",
            "tutorial_free_night": "Tutorial nivel 0.5 · práctica libre noche",
            "classic": "Clásico", "race": "Carrera", "arena": "Arena", "challenge": "Desafío", "multiplayer": "Multijugador",
        }.get(mode, str(mode))

    def _menu_family(self, mode: str | None = None) -> str:
        mode = self.selected_mode if mode is None else mode
        return "tutorial" if mode in TUTORIAL_MODES else "campaign"

    def _mode_for_family_and_light(self, family: str, night: bool) -> str:
        if family == "tutorial":
            return "tutorial_night" if night else "tutorial"
        return "campaign_night" if night else "campaign_day"

    def _display_level_label(self) -> str:
        if self._is_tutorial_guided():
            return "0"
        if self._is_tutorial_free():
            return "0.5"
        return str(self.level_number)

    def _reset_flashlight_state(self) -> None:
        self.flashlight_energy = self._flashlight_battery_max()
        self.flashlight_recharge = 0.0
        self.flashlight_recharge_total = 0.0
        self._flashlight_session_used = 0.0
        # En noche la linterna arranca encendida para que el jugador vea de inmediato
        # que él mismo ilumina el camino. F la sigue alternando.
        self.flashlight_on = self._is_mode_night()

    def _flashlight_range_factor(self) -> float:
        # El rango base se conserva en 1.5 tiles, pero el máximo de la linterna
        # baja 30%: 4.5 -> 3.15 tiles. Las cinco mejoras siguen aportando rango.
        return min(3.15, (0.5 + self._tree_effect_sum("flashlight", "light_range")) * 3.0)

    def _flashlight_battery_max(self) -> float:
        return min(15.0, 10.0 + self._tree_effect_sum("flashlight", "light_battery"))

    def _entity_luminosity_factor(self) -> float:
        # Luminicidad inicial x3: 0.1 -> 0.3 tiles para jugador/enemigos/sombras.
        return min(1.5, (0.1 + self._tree_effect_sum("flashlight", "entity_light")) * 3.0)

    def _toggle_flashlight(self) -> None:
        if not self._is_mode_night():
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
            return
        if self.flashlight_on:
            # Apagarla manualmente no debe dejarla "bugueada" ni forzar recarga.
            self.flashlight_on = False
            self._flashlight_session_used = 0.0
            self._draw()
            return
        if self.flashlight_recharge > 0.0:
            # Si se vació por completo, todavía está recargando.
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "cooldown"))
            self._draw()
            return
        if self.flashlight_energy <= 0.0:
            self.flashlight_energy = max(1.2, self._flashlight_battery_max() * 0.30)
        self.flashlight_on = True
        self._flashlight_session_used = 0.0
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y + self.retro_player.h * 0.5, 34.0, 0.40, "flashlight"))
        self._draw()

    def _is_night_level(self) -> bool:
        if self._is_campaign_mode() or self._is_tutorial_mode():
            return self._is_mode_night()
        return ((self.retro_seed // 13) + self.level_number) % 2 == 1

    def _level_biome_label(self) -> str:
        suffix = "nocturno" if self._is_night_level() else "diurno"
        mod_name = str(self.level_spec.get("modifier_name", "")) if getattr(self, "level_spec", None) else ""
        if mod_name:
            return f"{self.current_biome.name} · {mod_name} · {suffix}"
        return f"{self.current_biome.name} {suffix}"

    def _retro_duotone(self) -> tuple[str, str]:
        if self.game_state in {"select", "music", "achievements", "start_choice"}:
            return self.palette.base, self.palette.ink
        day = not self._is_night_level()
        if self._is_campaign_mode():
            # La noche ya no es negro puro: queda como penumbra azul/verdosa tipo Hollow Knight.
            return (("#FFFFFF", self.palette.ink) if day else ("#06131C", "#43D7FF"))
        if self._is_tutorial_mode() and self._is_mode_night():
            return "#06131C", "#43D7FF"
        # Cada bioma mantiene diseño duotono: solo base + tinta.
        tones = {
            "water": (("#E7F9FF", "#0077A8"), ("#03121D", "#47D7FF")),
            "lava": (("#FFF0D8", "#C23800"), ("#170606", "#FF5A1F")),
            "forest": (("#EAFBEA", "#148A37"), ("#06140C", "#7CFF8D")),
            "lunar": (("#F4F7FF", "#5E6FB8"), ("#090A18", "#D7E2FF")),
            "city": (("#EDF8FF", "#0066CC"), ("#060B18", "#00E5FF")),
            "village": (("#FFF4E2", "#AD651C"), ("#120D08", "#FFB86B")),
            "mountain": (("#F0FBFF", "#527C96"), ("#080D13", "#C7F0FF")),
            "valley": (("#EBFFF7", "#108565"), ("#07110F", "#52FFB8")),
        }
        day_tone, night_tone = tones.get(self.current_biome.key, ((self.palette.base, self.palette.ink), (self.palette.base, self.palette.ink)))
        base, ink = day_tone if day else night_tone
        if getattr(self, "slow_time_timer", 0.0) > 0:
            return ink, base
        return base, ink

    def _current_biome_for_seed(self) -> BiomeSpec:
        return BIOMES[(self.retro_seed // 97 + self.retro_seed // 1009) % len(BIOMES)]

    def _get_level_spec(self, width: int = 960, height: int = 560) -> dict[str, object]:
        biome = self._current_biome_for_seed()
        mod_key = LEVEL_MODIFIER_ORDER[(self.level_number - 1 + (self.retro_seed // 17)) % max(1, len(LEVEL_MODIFIER_ORDER))]
        modifier = LEVEL_MODIFIERS.get(mod_key, {})
        rhythm_options = ("exploración", "combate", "verticalidad", "persecución", "puzzle", "arena", "mixto")
        rhythm = rhythm_options[(self.level_number + self.retro_seed // 211) % len(rhythm_options)]
        if mod_key == "ascent":
            rhythm = "verticalidad"
        elif mod_key == "arena":
            rhythm = "arena"
        elif mod_key == "chase":
            rhythm = "persecución"
        rules = BIOME_RULES.get(biome.key, {})
        # Dificultad progresiva sin saturar la pantalla: se conserva la tensión retro,
        # pero se alternan mejor combate, lectura y respiro entre secciones.
        difficulty = 1.0 + max(0, self.level_number - 1) * 0.16
        return {
            "level": self.level_number,
            "biome": biome.key,
            "biome_name": biome.name,
            "modifier": mod_key,
            "modifier_name": str(modifier.get("name", mod_key)),
            "difficulty": difficulty,
            "rhythm": rhythm,
            "objective": str(modifier.get("goal", "derrota al jefe")),
            "enemy_density": float(modifier.get("enemy_density", 1.0)) * (1.0 + min(0.55, self.level_number * 0.035)) * 1.08,
            "platform_density": float(modifier.get("platform_density", 1.0)) * 0.96,
            "trap_density": 1.15,
            "aerial_density": 1.18,
            "aerial_hazard_density": 1.05,
            "hazard": str(modifier.get("hazard", "none")),
            "reward": float(modifier.get("reward", 1.0)),
            "preferred_enemies": tuple(rules.get("preferred_enemies", ())),
            "biome_hazards": tuple(rules.get("hazards", ())),
        }

    def _boss_kind_for_level(self, offset: int = 0) -> str:
        # Una partida usa una ruta de 14 jefes barajada por la semilla inicial.
        # Así no se repite jefe dentro del mismo ciclo, pero cada partida/semilla se siente distinta.
        block = max(0, (self.level_number - 1) // max(1, len(BOSS_ORDER)))
        index = max(0, (self.level_number - 1 + offset) % max(1, len(BOSS_ORDER)))
        order = list(BOSS_ORDER)
        rng = random.Random(self.boss_route_seed + block * 104729)
        rng.shuffle(order)
        return order[index]

    def _ability_name(self, ability: str) -> str:
        if ability == "none":
            return "NINGUNA"
        return str(ABILITY_INFO.get(ability, {}).get("name", ability)).upper()

    def _ability_owned(self, ability: str) -> bool:
        return ability == "gun" or bool(self.owned_abilities.get(ability, False))

    def _is_passive_auto_ability(self, ability: str) -> bool:
        return ability in PASSIVE_AUTO_ABILITIES

    def _default_active_secondary(self) -> str:
        for ability in DEFAULT_QUICK_SLOTS.values():
            if ability != "none" and self._ability_owned(ability):
                return ability
        for ability in ABILITY_ORDER:
            if not self._is_passive_auto_ability(ability) and self._ability_owned(ability):
                return ability
        return "none"

    def _sanitize_active_secondary_slot(self) -> None:
        if self.active_secondary_slot != "none" and (self._is_passive_auto_ability(self.active_secondary_slot) or not self._ability_owned(self.active_secondary_slot)):
            self.active_secondary_slot = self._default_active_secondary()

    def _ensure_quick_slots(self) -> None:
        if not hasattr(self, "quick_slots") or not isinstance(self.quick_slots, dict):
            self.quick_slots = dict(DEFAULT_QUICK_SLOTS)
        for digit, default in DEFAULT_QUICK_SLOTS.items():
            ability = str(self.quick_slots.get(digit, default))
            if ability in PASSIVE_AUTO_ABILITIES:
                ability = default if default not in PASSIVE_AUTO_ABILITIES else "none"
            if ability != "none" and not self._ability_owned(ability):
                # Mantiene compatibilidad con partidas antiguas: no borra una habilidad activa bloqueada
                # por compra futura, pero sí evita que una pasiva quede asignada al slot.
                ability = default if default not in PASSIVE_AUTO_ABILITIES else "none"
            self.quick_slots[digit] = ability
        self._sanitize_active_secondary_slot()

    def _quick_slot_label(self, ability: str) -> str:
        if self._is_passive_auto_ability(ability):
            return "AUTO"
        self._ensure_quick_slots()
        slots = [digit for digit, assigned in self.quick_slots.items() if assigned == ability]
        return "/".join(slots) if slots else "·"

    def _assign_quick_slot(self, digit: str, ability: str) -> None:
        digit = digit.replace("KP_", "")
        if digit not in {"1", "2", "3"}:
            return
        if self._is_passive_auto_ability(ability):
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
            return
        if ability != "none" and not self._ability_owned(ability):
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
            return
        self._ensure_quick_slots()
        self.quick_slots[digit] = ability
        if ability != "none":
            self.active_secondary_slot = ability
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "select"))

    def _tree_nodes(self, ability: str) -> set[str]:
        if not hasattr(self, "weapon_tree_nodes_owned"):
            self.weapon_tree_nodes_owned = {key: set() for key in ("gun", *ABILITY_ORDER)}
        return self.weapon_tree_nodes_owned.setdefault(ability, set())

    def _iter_tree_nodes(self, ability: str) -> list[dict[str, object]]:
        tree = WEAPON_UPGRADE_TREES.get(ability, {})
        nodes: list[dict[str, object]] = []
        for branch_nodes in tree.values():
            nodes.extend(branch_nodes)
        return nodes

    def _node_owned(self, ability: str, node_id: str) -> bool:
        return node_id in self._tree_nodes(ability)

    def _node_available(self, ability: str, node: dict[str, object]) -> bool:
        if self._node_owned(ability, str(node.get("id", ""))):
            return False
        requires = tuple(node.get("requires", ()))
        return all(str(req) in self._tree_nodes(ability) for req in requires)

    def _next_upgrade_node(self, ability: str) -> dict[str, object] | None:
        branch_order = ("damage", "range", "speed", "tracking", "bullets", "duration", "defense", "clone", "mobility", "crit", "reload", "count", "life", "attack", "special")
        tree = WEAPON_UPGRADE_TREES.get(ability, {})
        for branch in branch_order:
            for node in tree.get(branch, []):
                if self._node_available(ability, node):
                    return node
        return None

    def _sync_ability_level_from_tree(self, ability: str) -> None:
        # Nivel derivado solo para UI/compatibilidad; los efectos reales salen del árbol.
        owned = self._tree_nodes(ability)
        self.ability_levels[ability] = max(self.ability_levels.get(ability, 0), len(owned))

    def _max_out_weapon_tree(self, ability: str) -> None:
        self.owned_abilities[ability] = True
        owned = self._tree_nodes(ability)
        for node in self._iter_tree_nodes(ability):
            node_id = str(node.get("id", ""))
            if node_id:
                owned.add(node_id)
        self._sync_ability_level_from_tree(ability)

    def _max_out_challenge_loadout(self) -> None:
        # Desafío es el modo de presión máxima: todas las armas/habilidades empiezan al máximo.
        for ability in ("gun", *ABILITY_ORDER):
            self._max_out_weapon_tree(ability)
        self.quick_slots = dict(DEFAULT_QUICK_SLOTS)
        self.active_secondary_slot = self._default_active_secondary()
        self.heal_tanks = max(self.heal_tanks, 2)

    def _tree_effect_sum(self, ability: str, key: str) -> float:
        total = 0.0
        for node in self._iter_tree_nodes(ability):
            node_id = str(node.get("id", ""))
            if node_id not in self._tree_nodes(ability):
                continue
            effects = node.get("effects", {})
            if isinstance(effects, dict):
                total += float(effects.get(key, 0.0))
        return total

    def _ability_attack_bonus(self, ability: str) -> float:
        return self._tree_effect_sum(ability, "damage")

    def _ability_range_bonus(self, ability: str) -> int:
        return int(self._tree_effect_sum(ability, "range"))

    def _sword_range_bonus(self) -> float:
        # El rango inicial del Z Saber se mantiene, pero la mejora total llega solo
        # a la mitad del máximo anterior.
        return self._tree_effect_sum("sword", "range") * 0.5

    def _gun_homing_duration(self) -> float:
        # Sin la rama Seguimiento desbloqueada, las balas NO persiguen objetivos.
        # Seguimiento I activa 1.0s; Seguimiento V llega a 2.0s.
        return max(0.0, self._tree_effect_sum("gun", "homing_time"))

    def _ability_speed_mult(self, ability: str) -> float:
        mult = 1.0
        for node in self._iter_tree_nodes(ability):
            node_id = str(node.get("id", ""))
            if node_id in self._tree_nodes(ability):
                effects = node.get("effects", {})
                if isinstance(effects, dict) and "speed" in effects:
                    mult *= float(effects["speed"])
        return max(0.35, mult)

    def _gun_reload_reduction(self, charge_level: int) -> float:
        return 0.0

    def _gun_shot_cooldown(self, charge_level: int) -> float:
        # Cargas más altas golpean más fuerte, así que tienen un enfriamiento base mayor.
        # La rama Recarga resta 0.4s por nodo, máximo 2 veces por nivel de carga.
        base_by_charge = {0: 0.62, 1: 1.10, 2: 1.55, 3: 2.05}
        base = base_by_charge.get(int(charge_level), 0.62)
        return max(0.08, (base - self._gun_reload_reduction(charge_level)) * self._ability_speed_mult("gun"))

    def _ability_crit_chance(self, ability: str) -> float:
        return max(0.0, min(0.75, self._tree_effect_sum(ability, "crit")))

    def _has_weapon_special(self, ability: str, special_id: str = "unique") -> bool:
        for node in self._iter_tree_nodes(ability):
            node_id = str(node.get("id", ""))
            if node_id not in self._tree_nodes(ability):
                continue
            effects = node.get("effects", {})
            if not isinstance(effects, dict):
                continue
            value = str(effects.get("special", ""))
            if special_id == "unique" and value:
                return True
            if value == special_id:
                return True
        return False

    def _tree_effect_max(self, ability: str, key: str, default: float = 0.0) -> float:
        value = default
        for node in self._iter_tree_nodes(ability):
            node_id = str(node.get("id", ""))
            if node_id not in self._tree_nodes(ability):
                continue
            effects = node.get("effects", {})
            if isinstance(effects, dict) and key in effects:
                value = max(value, float(effects[key]))
        return value

    def _flight_max_duration(self) -> float:
        return FLIGHT_DURATION + self._tree_effect_sum("flight", "flight_time")

    def _telekinesis_grab_duration(self) -> float:
        return 2.0 + self._tree_effect_sum("telekinesis", "grab_time")

    def _shield_duration(self) -> float:
        return 2.0 + self._tree_effect_sum("shield", "shield_time")

    def _shield_block_amount(self) -> float:
        return 1.0 + self._tree_effect_sum("shield", "shield_defense")

    def _shield_clone_duration(self) -> float:
        # Base del clon: 2s. Rama completa de 5 mejoras: 7s.
        return 2.0 + self._tree_effect_sum("shield", "clone_time")

    def _gun_bullet_count(self) -> int:
        return int(max(1.0, self._tree_effect_max("gun", "bullets", 1.0)))

    def _parry_damage(self) -> float:
        return 1.0 + self._tree_effect_sum("parry", "damage")

    def _parry_window(self) -> float:
        return 0.18 + self._tree_effect_sum("parry", "parry_window")

    def _parry_bounce_velocity(self) -> float:
        return 231.0 + self._tree_effect_sum("parry", "parry_bounce")

    def _nova_damage(self) -> float:
        return 1.0 + self._tree_effect_sum("nova", "damage")

    def _nova_duration_bonus(self) -> float:
        return self._tree_effect_sum("nova", "nova_time")

    def _time_space_duration(self) -> float:
        return 4.0 + self._tree_effect_sum("time_space", "time_duration")

    def _time_space_cooldown(self) -> float:
        return max(3.0, 8.0 + self._tree_effect_sum("time_space", "time_cooldown"))

    def _time_space_blast_damage(self) -> float:
        return self._tree_effect_sum("time_space", "time_blast_damage")

    def _time_space_teleport_recast(self) -> float:
        # Cooldown interno reducido 70% respecto a V5: 1.20s -> 0.36s.
        # Mantiene límite mínimo entre teleports sin romper el flujo de Time-space.
        return 0.36

    def _available_tree_nodes(self, ability: str) -> list[tuple[str, dict[str, object]]]:
        tree = WEAPON_UPGRADE_TREES.get(ability, {})
        available: list[tuple[str, dict[str, object]]] = []
        branch_order = ("damage", "range", "speed", "tracking", "bullets", "duration", "defense", "clone", "mobility", "crit", "reload", "count", "life", "attack", "special")
        seen = set()
        for branch in (*branch_order, *tree.keys()):
            if branch in seen:
                continue
            seen.add(branch)
            for node in tree.get(branch, []):
                if self._node_available(ability, node):
                    available.append((branch, node))
                    break
        return available

    def _tree_branch_summary(self, ability: str) -> str:
        tree = WEAPON_UPGRADE_TREES.get(ability, {})
        if not tree:
            return "sin árbol"
        owned = self._tree_nodes(ability)
        labels = {
            "damage": "ATQ", "range": "RNG", "speed": "VEL", "tracking": "SEG", "bullets": "BAL",
            "duration": "DUR", "defense": "DEF", "clone": "CLON", "crit": "CRT", "reload": "REC", "mobility": "MOV", "count": "ALI", "life": "VID", "attack": "ATK", "special": "ESP",
        }
        parts: list[str] = []
        for branch, nodes in tree.items():
            total = max(1, len(nodes))
            count = sum(1 for node in nodes if str(node.get("id", "")) in owned)
            parts.append(f"{labels.get(branch, branch[:3].upper())} {count}/{total}")
        return " · ".join(parts)

    @staticmethod
    def _retro_world_span(viewport_width: int) -> int:
        return max(14800, int(max(360, viewport_width) * 15.5))

    @staticmethod
    def _retro_world_vertical(viewport_height: int) -> int:
        return max(1180, int(max(260, viewport_height) * 2.65))

    def _retro_ground_y(self) -> int:
        return max(220, self.retro_world_height - 72)

    @staticmethod
    def _retro_intersects(x: float, y: float, w: float, h: float, rect: RetroRect | RetroEnemy | RetroPickup | RetroBox) -> bool:
        return x < rect.x + rect.w and x + w > rect.x and y < rect.y + rect.h and y + h > rect.y

    def _level_enemy_scale(self) -> float:
        # Escalado solicitado: enemigos y jefes suben vida/ataque 10% por cada nuevo nivel.
        return 1.10 ** max(0, self.level_number - 1)

    def _scaled_enemy_hp(self, base_hp: int | float) -> int:
        return max(1, int(math.ceil(float(base_hp) * self._level_enemy_scale() * self._campaign_enemy_stat_mult("hp"))))

    def _scaled_enemy_attack(self, base_attack: int | float) -> float:
        return max(0.1, round(float(base_attack) * self._level_enemy_scale() * self._campaign_enemy_stat_mult("attack"), 2))

    def _scaled_enemy_stats(self, hp: int | float, attack: int | float) -> tuple[int, float]:
        return self._scaled_enemy_hp(hp), self._scaled_enemy_attack(attack)

    def _enemy_fire_cooldown(self, seconds: float) -> float:
        return max(0.12, float(seconds) * ENEMY_FIRE_COOLDOWN_MULT)

    def _alive_boss_count(self) -> int:
        return sum(1 for enemy in self.retro_enemies if enemy.alive and enemy.kind.startswith("boss"))

    @staticmethod
    def _retro_rects_overlap(a: RetroRect, b: RetroRect) -> bool:
        return a.x < b.x + b.w and a.x + a.w > b.x and a.y < b.y + b.h and a.y + a.h > b.y

    @staticmethod
    def _retro_point_in_rect(x: float, y: float, rect: RetroRect) -> bool:
        return rect.x <= x <= rect.x + rect.w and rect.y <= y <= rect.y + rect.h

    def _screen_x(self, world_x: float) -> float:
        return world_x - self.retro_camera_x

    def _screen_y(self, world_y: float) -> float:
        return world_y - self.retro_camera_y

    def _closed_gate_rects(self) -> list[RetroRect]:
        return [gate.rect for gate in self.secret_gates if not gate.opened]

    def _solid_rects(self) -> list[RetroRect]:
        # Las trampas se pisan, no son paredes/plataformas sólidas.
        return [r for r in self.retro_obstacles if r.kind != "spike_trap"] + self._closed_gate_rects()

    def _trap_rects(self) -> list[RetroRect]:
        return [r for r in self.retro_obstacles if r.kind == "spike_trap"]

    def _box_solid_rects(self) -> list[RetroRect]:
        return [RetroRect(box.x, box.y, box.w, box.h, "box") for box in self.retro_boxes]

    def _solid_rects_with_boxes(self) -> list[RetroRect]:
        return self._solid_rects() + self._box_solid_rects()

    def _carve_boss_room_entry_corridors(
        self,
        *,
        arena_x: float,
        arena_y: float,
        arena_w: float,
        arena_h: float,
        ground: float,
        roof_gap_x: float,
        roof_gap_w: float,
    ) -> None:
        # La sala de jefe se crea después de la generación procedural. Este tallado
        # reserva únicamente la entrada superior: el hueco del techo. Cualquier
        # plataforma, caja, pickup, enemigo normal o compuerta secreta que caiga
        # en esa columna se elimina para que nunca interrumpa el acceso. Las
        # piezas estructurales de la sala se conservan.
        player_w = self.retro_player.w
        player_h = self.retro_player.h
        gap_pad_x = max(20.0, player_w * 0.75)
        gap_air_above = max(150.0, player_h * 4.0)
        gap_drop_depth = max(arena_h + 64.0, ground - arena_y + 96.0)
        reserved_zones = [
            # Columna completa del hueco del techo, desde bastante antes del techo
            # hasta dentro de la arena. Un objeto horizontal que cruce el hueco se
            # borra aunque solo invada unos píxeles.
            RetroRect(
                roof_gap_x - gap_pad_x,
                max(0.0, arena_y - gap_air_above),
                roof_gap_w + gap_pad_x * 2.0,
                gap_drop_depth + gap_air_above,
                "boss_roof_gap_reserved",
            ),
        ]
        protected_obstacle_kinds = {
            "boss_floor",
            "boss_room_ceiling",
            "boss_room_wall",
            "boss_room_floor",
        }

        def overlaps_reserved_rect(x: float, y: float, w: float, h: float) -> bool:
            test_rect = RetroRect(x, y, w, h, "test")
            return any(self._retro_rects_overlap(test_rect, zone) for zone in reserved_zones)

        def point_in_reserved_area(x: float, y: float) -> bool:
            return any(self._retro_point_in_rect(x, y, zone) for zone in reserved_zones)

        self.retro_obstacles = [
            rect for rect in self.retro_obstacles
            if rect.kind in protected_obstacle_kinds or not overlaps_reserved_rect(rect.x, rect.y, rect.w, rect.h)
        ]
        self.secret_gates = [
            gate for gate in self.secret_gates
            if not overlaps_reserved_rect(gate.rect.x, gate.rect.y, gate.rect.w, gate.rect.h)
        ]
        self.retro_pickups = [
            pickup for pickup in self.retro_pickups
            if not point_in_reserved_area(pickup.x, pickup.y)
        ]
        self.retro_boxes = [
            box for box in self.retro_boxes
            if not overlaps_reserved_rect(box.x, box.y, box.w, box.h)
        ]
        self.retro_enemies = [
            enemy for enemy in self.retro_enemies
            if enemy.kind.startswith("boss") or not overlaps_reserved_rect(enemy.x, enemy.y, enemy.w, enemy.h)
        ]
        self.retro_projectiles = [
            projectile for projectile in self.retro_projectiles
            if not point_in_reserved_area(projectile.x, projectile.y)
        ]
        self.retro_pits = [
            pit for pit in self.retro_pits
            if not overlaps_reserved_rect(pit.x, ground - 12.0, pit.w, 96.0)
        ]

    def _retro_in_pit(self, x: float, w: float = 0.0) -> bool:
        center = x + w * 0.5
        return any(pit.x + 6 <= center <= pit.x + pit.w - 6 for pit in self.retro_pits)

    def _draw_character_select(self, canvas: tk.Canvas, width: int, height: int) -> None:
        base, ink = self._retro_duotone()
        self.character_cards.clear()
        self.mode_buttons.clear()
        self.race_shadow_buttons.clear()
        self.achievement_buttons.clear()
        canvas.create_rectangle(0, 0, width, height, fill=base, outline=ink, width=2)
        self._draw_color_button(canvas, base, ink)
        mx0, my0, mx1, my1 = self._music_button_bbox
        canvas.create_rectangle(mx0, my0, mx1, my1, fill=base, outline=ink, width=2)
        canvas.create_text((mx0 + mx1) / 2, (my0 + my1) / 2, text="MÚSICA", fill=ink, font=("Courier New", 7, "bold"))
        ax0, ay0, ax1, ay1 = width - 132, 12, width - 18, 34
        self.achievement_buttons["open"] = (ax0, ay0, ax1, ay1)
        canvas.create_rectangle(ax0, ay0, ax1, ay1, fill=base, outline=ink, width=2)
        canvas.create_text((ax0 + ax1) / 2, (ay0 + ay1) / 2, text="LOGROS", fill=ink, font=("Courier New", 7, "bold"))

        phase = int(self.anim_phase * 3) % 18
        for y in range(44, height, 28):
            canvas.create_line(0, y + phase % 5, width, y + phase % 5, fill=ink, width=1)
        for i in range(18):
            x = int((i * 137 - self.anim_phase * 13) % max(1, width))
            y = 58 + (i * 29) % max(30, height - 96)
            canvas.create_rectangle(x, y, x + 3, y + 3, fill=ink, outline="")

        canvas.create_text(width / 2, 52, text="LEMATZIUM", fill=ink, font=("Courier New", 22, "bold"))
        unlocked_night = self._day_campaign_completed()
        subtitle = "Campaña noche desbloqueada" if unlocked_night else "Campaña noche bloqueada hasta completar campaña día"
        canvas.create_text(width / 2, 80, text=f"Elige Tutorial o Campaña · luego Día/Noche · {subtitle}", fill=ink, font=("Courier New", 9, "bold"))

        family = self._menu_family()
        cat_w = min(245, max(170, (width - 110) / 2))
        cat_h = 58
        cat_y = 106
        cat_defs = (("category_tutorial", "TUTORIAL", "Nivel 0 guiado → 0.5 libre"), ("category_campaign", "CAMPAÑA", "6 niveles + jefes"))
        total_w = 2 * cat_w + 18
        for idx, (mode, label, desc) in enumerate(cat_defs):
            x0 = width / 2 - total_w / 2 + idx * (cat_w + 18)
            x1 = x0 + cat_w
            y0m = cat_y
            y1 = y0m + cat_h
            selected = (family == "tutorial" and mode == "category_tutorial") or (family == "campaign" and mode == "category_campaign")
            self.mode_buttons.append((x0, y0m, x1, y1, mode))
            canvas.create_rectangle(x0, y0m, x1, y1, fill=ink if selected else base, outline=ink, width=3)
            canvas.create_rectangle(x0 + 5, y0m + 5, x1 - 5, y1 - 5, fill=base if selected else ink, outline="")
            text_col = ink if selected else base
            canvas.create_text((x0 + x1) / 2, y0m + 20, text=label, fill=text_col, font=("Courier New", 14, "bold"))
            canvas.create_text((x0 + x1) / 2, y0m + 40, text=desc, fill=text_col, font=("Courier New", 6, "bold"))

        selector_y = 178
        day_mode = self._mode_for_family_and_light(family, False)
        night_mode = self._mode_for_family_and_light(family, True)
        day_label = "DÍA"
        night_label = "NOCHE" if family == "tutorial" or unlocked_night else "NOCHE BLOQUEADA"
        light_defs = ((day_mode, day_label, "visible"), (night_mode, night_label, "linterna + brillo" if family == "tutorial" or unlocked_night else "completa campaña día"))
        sel_w = min(212, max(140, (width - 100) / 2))
        sel_h = 42
        total_w = 2 * sel_w + 14
        for idx, (mode, label, desc) in enumerate(light_defs):
            x0 = width / 2 - total_w / 2 + idx * (sel_w + 14)
            y0m = selector_y
            x1 = x0 + sel_w
            y1 = y0m + sel_h
            locked = mode == "campaign_night" and not unlocked_night
            self.mode_buttons.append((x0, y0m, x1, y1, mode))
            selected = self.selected_mode == mode
            canvas.create_rectangle(x0, y0m, x1, y1, fill=ink if selected and not locked else base, outline=ink, width=3)
            canvas.create_rectangle(x0 + 4, y0m + 4, x1 - 4, y1 - 4, fill=base if selected and not locked else ink, outline="")
            text_col = ink if selected and not locked else base
            canvas.create_text((x0 + x1) / 2, y0m + 14, text=label, fill=text_col, font=("Courier New", 9, "bold"))
            canvas.create_text((x0 + x1) / 2, y0m + 29, text=desc, fill=text_col, font=("Courier New", 5, "bold"))

        spec = CHARACTERS[0]
        card_w = min(610, max(360, width - 180))
        y0 = 244
        card_h = min(258, max(180, height - y0 - 48))
        x0 = (width - card_w) / 2
        x1 = x0 + card_w
        y1 = y0 + card_h
        self.character_cards.append((x0, y0, x1, y1, spec))
        canvas.create_rectangle(x0, y0, x1, y1, fill=ink, outline=ink, width=3)
        canvas.create_rectangle(x0 + 5, y0 + 5, x1 - 5, y1 - 5, fill=base, outline="")
        canvas.create_rectangle(x0 + 11, y0 + 11, x1 - 11, y0 + 50, fill=ink, outline="")
        canvas.create_text(x0 + 20, y0 + 22, text=f"INICIAR: {self._mode_label().upper()}", anchor="nw", fill=base, font=("Courier New", 13, "bold"))
        self._draw_select_avatar(canvas, spec.key, x0 + 82, y0 + 104, base, ink)
        if family == "tutorial":
            lines = [
                "Tutorial: nivel 0 guiado. Al tocar la bandera final pasa a 0.5 práctica libre.",
                "En noche el jugador y los enemigos brillan; F alterna la linterna.",
                "La práctica libre mantiene el equipo al máximo para probar habilidades.",
            ]
        else:
            lines = [
                "Campaña día: 6 niveles estructurados con sombras, pinchos y jefes.",
                "Campaña noche: mismo recorrido con penumbra, luces y linterna.",
                "Antes de campaña guardada podrás continuar o iniciar una nueva partida.",
                "Logro: Yo, mi peor enemigo · completa campaña de día por primera vez.",
            ]
        ty = y0 + 67
        for line in lines:
            for wrapped in self._wrap_text(line, max(34, int((card_w - 170) / 8))):
                canvas.create_text(x0 + 145, ty, text=wrapped, anchor="nw", fill=ink, font=("Courier New", 8, "bold"))
                ty += 17
        canvas.create_rectangle(x0 + card_w - 190, y1 - 58, x0 + card_w - 20, y1 - 18, fill=ink, outline=ink, width=2)
        canvas.create_rectangle(x0 + card_w - 186, y1 - 54, x0 + card_w - 24, y1 - 22, fill=base, outline="")
        canvas.create_text(x0 + card_w - 105, y1 - 38, text="JUGAR", fill=ink, font=("Courier New", 12, "bold"))

        if self.status_notice_timer > 0 and self.status_notice_text:
            canvas.create_text(width / 2, y0 - 18, text=self.status_notice_text, fill=ink, font=("Courier New", 9, "bold"))
        canvas.create_text(width / 2, height - 24, text="Solo hay dos rutas: Tutorial y Campaña · Día/Noche se elige debajo · F alterna linterna en noche", fill=ink, font=("Courier New", 8, "bold"))


    def _draw_achievements_menu(self, canvas: tk.Canvas, width: int, height: int) -> None:
        base, ink = self._retro_duotone()
        self.achievement_buttons.clear()
        canvas.create_rectangle(0, 0, width, height, fill=base, outline=ink, width=2)
        canvas.create_text(width / 2, 54, text="LOGROS", fill=ink, font=("Courier New", 22, "bold"))
        achieved = self._day_campaign_completed()
        panel_w = min(720, width - 60)
        x0 = (width - panel_w) / 2
        y0 = 110
        y1 = min(height - 86, y0 + 210)
        canvas.create_rectangle(x0, y0, x0 + panel_w, y1, fill=base, outline=ink, width=3)
        status = "CONSEGUIDO" if achieved else "PENDIENTE"
        canvas.create_text(x0 + 24, y0 + 24, anchor="nw", text=f"[{status}] Yo, mi peor enemigo", fill=ink, font=("Courier New", 13, "bold"))
        desc = "Completa el modo campaña por primera vez durante el día. Desbloquea campaña noche."
        for i, line in enumerate(self._wrap_text(desc, 68)):
            canvas.create_text(x0 + 24, y0 + 62 + i * 18, anchor="nw", text=line, fill=ink, font=("Courier New", 9, "bold"))
        night = "DISPONIBLE" if achieved else "BLOQUEADA"
        canvas.create_text(x0 + 24, y0 + 132, anchor="nw", text=f"Campaña noche: {night}", fill=ink, font=("Courier New", 9, "bold"))
        bx0, by0, bx1, by1 = width / 2 - 82, height - 62, width / 2 + 82, height - 28
        self.achievement_buttons["back"] = (bx0, by0, bx1, by1)
        canvas.create_rectangle(bx0, by0, bx1, by1, fill=ink, outline=ink, width=2)
        canvas.create_rectangle(bx0 + 4, by0 + 4, bx1 - 4, by1 - 4, fill=base, outline="")
        canvas.create_text((bx0 + bx1) / 2, (by0 + by1) / 2, text="VOLVER", fill=ink, font=("Courier New", 10, "bold"))
        if self.status_notice_timer > 0 and self.status_notice_text:
            canvas.create_text(width / 2, height - 92, text=self.status_notice_text, fill=ink, font=("Courier New", 9, "bold"))

    def _draw_start_choice(self, canvas: tk.Canvas, width: int, height: int) -> None:
        base, ink = self._retro_duotone()
        self.start_choice_buttons.clear()
        canvas.create_rectangle(0, 0, width, height, fill=base, outline=ink, width=2)
        canvas.create_text(width / 2, 62, text="PARTIDA GUARDADA", fill=ink, font=("Courier New", 21, "bold"))
        canvas.create_text(width / 2, 92, text=f"{self._mode_label().upper()} tiene progreso guardado. ¿Continuar partida o iniciar una nueva?", fill=ink, font=("Courier New", 9, "bold"))
        bw, bh = 230, 48
        y = height / 2 - 18
        specs = (("continue", "CONTINUAR PARTIDA"), ("new", "INICIAR NUEVA"), ("back", "VOLVER"))
        total = len(specs) * bw + (len(specs) - 1) * 18
        x = width / 2 - total / 2
        for key, label in specs:
            self.start_choice_buttons[key] = (x, y, x + bw, y + bh)
            canvas.create_rectangle(x, y, x + bw, y + bh, fill=ink, outline=ink, width=3)
            canvas.create_rectangle(x + 5, y + 5, x + bw - 5, y + bh - 5, fill=base, outline="")
            canvas.create_text(x + bw / 2, y + bh / 2, text=label, fill=ink, font=("Courier New", 10, "bold"))
            x += bw + 18

    def _draw_music_menu(self, canvas: tk.Canvas, width: int, height: int) -> None:
        base, ink = self._retro_duotone()
        self.music_buttons.clear()
        canvas.create_rectangle(0, 0, width, height, fill=base, outline=ink, width=2)
        self._draw_color_button(canvas, base, ink)
        canvas.create_text(width / 2, 48, text="MÚSICA POR SECCIÓN", fill=ink, font=("Courier New", 20, "bold"))
        canvas.create_text(width / 2, 76, text="Agrega música para pantalla principal o hasta 5 pistas por modo. Se reproducen al azar.", fill=ink, font=("Courier New", 8, "bold"))

        def button(name: str, x: float, y: float, w: float, h: float, title: str, selected: bool = False) -> None:
            self.music_buttons[name] = (x, y, x + w, y + h)
            canvas.create_rectangle(x, y, x + w, y + h, fill=ink if selected else base, outline=ink, width=2)
            canvas.create_text(x + w / 2, y + h / 2, text=title, fill=base if selected else ink, font=("Courier New", 7, "bold"))

        target_w = min(156, max(116, (width - 96) / 4))
        start_y = 108
        for idx, (target, label) in enumerate(MUSIC_TARGETS):
            col = idx % 4
            row = idx // 4
            x = width / 2 - (4 * target_w + 3 * 10) / 2 + col * (target_w + 10)
            y = start_y + row * 36
            count = len(self.music_tracks.get(target, []))
            limit = 1 if target == "main" else 5
            button(f"target_{target}", x, y, target_w, 28, f"{label[:12]} {count}/{limit}", self.music_target == target)

        panel_w = min(760, width - 48)
        x0 = (width - panel_w) / 2
        y0 = 190
        y1 = min(height - 68, y0 + 250)
        canvas.create_rectangle(x0, y0, x0 + panel_w, y1, fill=base, outline=ink, width=3)
        canvas.create_text(x0 + 16, y0 + 14, anchor="nw", text=f"SECCIÓN: {self._music_label(self.music_target).upper()}", fill=ink, font=("Courier New", 10, "bold"))
        tracks = self.music_tracks.get(self.music_target, [])
        if not tracks:
            canvas.create_text(x0 + 22, y0 + 58, anchor="nw", text="Sin música agregada en esta sección.", fill=ink, font=("Courier New", 9, "bold"))
        for idx, path in enumerate(tracks[:5]):
            row_y = y0 + 48 + idx * 34
            name = Path(path).name
            exists = "OK" if Path(path).exists() else "NO ENCONTRADA"
            canvas.create_text(x0 + 22, row_y + 6, anchor="nw", text=f"{idx + 1}. {name[:54]} · {exists}", fill=ink, font=("Courier New", 8, "bold"))
            button(f"remove_{self.music_target}_{idx}", x0 + panel_w - 110, row_y, 84, 24, "QUITAR")

        current_limit = 1 if self.music_target == "main" else 5
        button("add", x0 + 20, y1 + 18, 150, 30, "AGREGAR MÚSICA", len(tracks) < current_limit)
        button("back", x0 + panel_w - 140, y1 + 18, 120, 30, "VOLVER")
        if self.status_notice_timer > 0 and self.status_notice_text:
            canvas.create_text(width / 2, min(height - 44, y1 + 56), text=self.status_notice_text, fill=ink, font=("Courier New", 8, "bold"))
        backend = "pygame" if self._get_music_backend() is not None else "sin reproductor pygame"
        canvas.create_text(width / 2, height - 24, text=f"Archivos guardados en configuración persistente · backend: {backend}", fill=ink, font=("Courier New", 7, "bold"))



    @staticmethod
    def _wrap_text(text: str, max_chars: int) -> list[str]:
        words = text.split()
        lines: list[str] = []
        current = ""
        for word in words:
            candidate = word if not current else f"{current} {word}"
            if len(candidate) <= max_chars:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines

    def _draw_select_avatar(self, canvas: tk.Canvas, key: str, cx: float, cy: float, base: str, ink: str) -> None:
        # Avatar de menú con la misma silueta original; solo ampliado 2x para verse mejor.
        x = cx - 26
        y = cy - 34
        scale = 2
        def rect(x0: float, y0: float, x1: float, y1: float, fill: str, outline: str = "") -> None:
            canvas.create_rectangle(x + x0 * scale, y + y0 * scale, x + x1 * scale, y + y1 * scale, fill=fill, outline=outline)
        rect(4, 24, 10, 34, ink)
        rect(16, 24, 22, 34, ink)
        rect(3, 14, 23, 26, base, ink)
        rect(8, 18, 18, 25, ink)
        rect(5, 5, 21, 18, base, ink)
        rect(4, 1, 22, 9, ink)
        rect(12, 10, 21, 14, ink)
        rect(15, 11, 18, 13, base)
        rect(26, 19, 33, 24, ink)

    def _select_character(self, spec: CharacterSpec, continue_saved: bool = True) -> None:
        self.selected_character = spec
        self.game_state = "playing"
        self.hp_upgrade = 0
        self.xp_count = 3
        self.level_number = 1
        self.active_primary_slot = "gun"
        self.active_secondary_slot = "none"
        self.quick_slots = dict(DEFAULT_QUICK_SLOTS)
        self.status_notice_timer = 0.0
        self.status_notice_text = ""
        self.owned_abilities = {ability: False for ability in ABILITY_ORDER}
        self.owned_abilities["gun"] = True
        self.owned_abilities["flashlight"] = True
        self.ability_levels = {ability: 0 for ability in ("gun", *ABILITY_ORDER)}
        self.weapon_tree_nodes_owned = {ability: set() for ability in ("gun", *ABILITY_ORDER)}
        self.pause_page = 0
        self.combo_count = 0
        self.combo_timer = 0.0
        self.perfect_dash_timer = 0.0
        self.parry_timer = 0.0
        self.quantum_anchor = None
        self.orbit_blades_timer = 0.0
        self.heal_tanks = 1
        self.clone_timer = 0.0
        self.clone_history.clear()
        self.shield_timer = 0.0
        self.shield_cooldown = 0.0
        self.slow_time_timer = 0.0
        self.slow_time_cooldown = 0.0
        self._time_space_pending_teleport = False
        self._time_space_teleport_cooldown = 0.0
        self._last_resurrection_blueprint: dict[str, object] | None = None
        self.sword_attack_count = 0
        self._flight_downshot_timer = 0.0
        self._flight_bomb_timer = 0.0
        self.shadow_chaser_history: list[tuple[float, float, float, int, bool, int]] = []
        self.shadow_damage_cooldown = 0.0
        self.shadow_chaser_hp: dict[int, float] = {}
        self.shadow_chaser_max_hp: dict[int, float] = {}
        self.shadow_chaser_hurt: dict[int, float] = {}
        self.shadow_chaser_respawn: dict[int, float] = {}
        self.shadow_action_history = []
        self.shadow_action_cursors = {}
        self._shadow_next_action_id = 1
        self.arena_bots = []
        self.arena_scores = {-1: 0}
        self.arena_match_timer = ARENA_MATCH_SECONDS
        self.arena_match_over = False
        self.arena_player_respawn_timer = 0.0
        self._arena_last_player_attacker = None
        self.arena_orb_spawn_timer = 0.0
        self.race_finish_x = 0.0
        self.race_finish_reached = False
        self.telekinesis_grab_started = 0.0
        self.p2_player = RetroPlayer(x=154.0)
        self.p2_enabled = self.selected_mode == "multiplayer"
        self.p2_is_cpu = False
        self.p2_score = 0
        self.p1_score = 0
        self.challenge_timer = 22.0
        self.challenge_safe_timer = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 0.0
        self._p2_last_jump_pressed = False
        self._p2_last_dash_pressed = False
        self._p2_last_primary_pressed = False
        self._p2_last_secondary_pressed = False
        self._z_sword_charge_active = False
        self._z_sword_charge_started = 0.0
        self._pending_level_advance = 0.0
        self.level_intro_timer = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 7.0
        self.hard_spike_wall_x = -760.0
        self.retro_player.max_hp = STARTING_PLAYER_HP
        self.retro_player.hp = STARTING_PLAYER_HP
        self.retro_seed = random.SystemRandom().randrange(1, 2_147_483_647)
        if self._is_tutorial_mode():
            self.retro_seed = 7351337
        self.boss_route_seed = self.retro_seed
        if not self._is_tutorial_mode() and continue_saved:
            self._restore_mode_progress(self.selected_mode)
        elif self._is_campaign_mode() and not continue_saved:
            modes = self._save_cache.setdefault("modes", {})
            if isinstance(modes, dict):
                modes.pop(self.selected_mode, None)
                self._write_persistent_data()
        self.current_biome = self._current_biome_for_seed()
        self._apply_mode_loadout()
        if self.selected_mode == "arena":
            self._reset_arena_match()
        self._reset_retro_world(max(360, self.canvas.winfo_width()), max(220, self.canvas.winfo_height()), keep_player_ratio=False)
        if self._is_tutorial_mode():
            # El tutorial debe entrar jugable de inmediato. En V7 el intro largo,
            # combinado con enemigos de práctica casi quietos, podía percibirse como
            # un nivel congelado aunque el bucle siguiera vivo.
            self.level_intro_timer = 0.0
            self.slow_time_timer = 0.0
            self.slow_time_cooldown = 0.0
            self._time_space_pending_teleport = False
            self._time_space_teleport_cooldown = 0.0
        if self.selected_mode == "arena":
            self.xp_count = max(self.xp_count, ARENA_KILL_XP)
        elif self._is_tutorial_mode():
            self.xp_count = max(self.xp_count, 99)
        else:
            self.xp_count = max(self.xp_count, 3)
        self._apply_pending_restore_after_world()
        self._reset_flashlight_state()
        self._apply_palette_to_window()
        self._set_music_context("classic" if self._is_campaign_mode() else self.selected_mode)
        self.canvas.focus_set()

    def _apply_mode_loadout(self) -> None:
        self.p2_enabled = self.selected_mode == "multiplayer"
        self.p2_is_cpu = False
        if self.selected_mode == "arena":
            # Arena ya no empieza con armas al máximo: todos arrancan desde X Buster
            # y 6XP para comprar una primera decisión en el taller.
            self.active_secondary_slot = "none"
        elif self.selected_mode == "challenge" or self._is_tutorial_mode():
            self._max_out_challenge_loadout()
            if self._is_tutorial_mode():
                # El tutorial puede jugarse de día o de noche, pero la linterna
                # debe partir sin mejoras para enseñar su batería/rango base.
                self.weapon_tree_nodes_owned["flashlight"] = set()
                self._sync_ability_level_from_tree("flashlight")
                self.heal_tanks = max(self.heal_tanks, 5)

    def _retro_generate_level(self, width: int, height: int) -> None:
        width = max(360, width)
        height = max(220, height)
        self.current_biome = self._current_biome_for_seed()
        self.level_spec = self._get_level_spec(width, height)
        self.level_modifier_key = str(self.level_spec.get("modifier", "storm"))
        biome = self.current_biome
        spec_platform_mult = float(self.level_spec.get("platform_density", 1.0))
        world_w = int(self._retro_world_span(width) * biome.width_mult * (1.04 if self.level_spec.get("rhythm") == "exploración" else 1.0))
        world_h = int(self._retro_world_vertical(height) * biome.height_mult * (1.10 if self.level_spec.get("modifier") == "ascent" else 1.0) * 1.16)
        # Solo Arena y Desafío usan sala compacta. Clásico, Carrera y Multijugador
        # mantienen la generación larga de niveles/campaña.
        compact_mode = self.selected_mode in {"arena", "challenge"}
        if self.selected_mode == "arena":
            # Estadio amplio y estable: la Arena no usa el laberinto procedural completo,
            # porque los bots se quedaban enganchados entre paredes, techos y pozos.
            world_w = max(2200, int(width * 2.35))
            world_h = max(height + 260, 780)
        elif self.selected_mode == "challenge":
            world_w = max(1700, int(world_w * 0.26))
            world_h = max(height + 220, int(world_h * 0.72))
        elif self._is_tutorial_guided():
            world_w = max(5600, int(width * 5.8))
            world_h = max(920, height + 360)
        elif self._campaign_is_arena_stage():
            world_w = max(2100, int(width * 2.2))
            world_h = max(height + 260, 760)
        self.retro_world_width = world_w
        self.retro_world_height = world_h
        ground = self._retro_ground_y()
        rng = random.Random(self.retro_seed + width * 31 + height * 17)

        self.retro_obstacles = []
        self.retro_pits = []
        self.retro_enemies = []
        self.retro_pickups = []
        self.retro_boxes = []
        self.dragged_box_index = None
        self._last_mouse_world = None
        self.telekinesis_grab_started = 0.0
        self.retro_checkpoints = []
        self.active_checkpoint_index = -1
        self.secret_gates = []
        self.retro_effects = []
        self.tutorial_messages = []
        if self._is_tutorial_guided():
            self._build_tutorial_level(world_w, ground)
            return
        if self._campaign_is_arena_stage():
            self._build_campaign_arena_level(world_w, ground)
            return

        # Zonas de descanso iniciales y arena final.
        self.retro_obstacles.extend(
            [
                RetroRect(40.0, float(ground - 60), 250.0, 14.0, "start_bridge"),
                RetroRect(float(world_w - 1050), float(ground - 92), 250.0, 14.0, "arena"),
                RetroRect(float(world_w - 750), float(ground - 150), 260.0, 14.0, "arena"),
                RetroRect(float(world_w - 430), float(ground - 210), 300.0, 14.0, "arena"),
            ]
        )

        # Pits largos y puentes exigentes, con zona inicial segura para enseñar movimiento.
        x = 860
        while x < world_w - 1080:
            pit_w = int(rng.choice((112, 136, 164, 196, 224, 252, 286)) * biome.pit_mult)
            self.retro_pits.append(RetroPit(float(x), float(pit_w)))
            if rng.random() < 0.78:
                self.retro_obstacles.append(
                    RetroRect(
                        float(x + rng.randint(-35, 70)),
                        float(ground - rng.choice((92, 126, 160, 198, 238))),
                        float(rng.randint(78, 176)),
                        14.0,
                        "bridge",
                    )
                )
            if rng.random() < 0.45:
                self.retro_obstacles.append(
                    RetroRect(
                        float(x + pit_w + rng.randint(25, 90)),
                        float(ground - rng.choice((82, 126, 172))),
                        30.0,
                        float(rng.choice((84, 120, 158))),
                        "wall",
                    )
                )
            x += rng.randint(390, 570)

        # Trampas: suficientes para mantener lectura retro, no tantas como para tapar la silueta.
        trap_density = float(self.level_spec.get("trap_density", 1.0))
        trap_count = min(24, max(6, int((world_w / 2200) * trap_density)))
        for _ in range(trap_count):
            tx = rng.uniform(980, world_w - 1160)
            near_pit = [pit for pit in self.retro_pits if abs((pit.x + pit.w * 0.5) - tx) < 240]
            if near_pit and rng.random() < 0.65:
                pit = rng.choice(near_pit)
                tx = pit.x + rng.choice((-42.0, pit.w + 18.0))
            tw = float(rng.choice((26, 34, 42, 50)))
            self.retro_obstacles.append(RetroRect(float(tx), float(ground - 12), tw, 12.0, "spike_trap"))
        # Amenazas aéreas puntuales: señalizan riesgo sin llenar todas las rutas altas.
        air_trap_count = min(22, max(4, int(trap_count * float(self.level_spec.get("aerial_hazard_density", 1.0)))))
        for _ in range(air_trap_count):
            tx = rng.uniform(1040, world_w - 1040)
            ty = float(max(78.0, ground - rng.choice((138, 190, 250, 320, 395, 470))))
            tw = float(rng.choice((22, 30, 38, 46)))
            self.retro_obstacles.append(RetroRect(float(tx), ty, tw, 12.0, "spike_trap"))

        # Red de plataformas: rutas bajas, medias y altas para que el nivel sea vertical y con múltiples caminos.
        section = 340
        if biome.key == "mountain":
            bands = [ground - 70, ground - 160, ground - 270, ground - 410, ground - 570, ground - 740, ground - 930]
        elif biome.key == "lunar":
            bands = [ground - 88, ground - 220, ground - 365, ground - 520, ground - 690, ground - 870]
        elif biome.key == "village":
            bands = [ground - 62, ground - 118, ground - 178, ground - 255, ground - 345, ground - 455]
        elif biome.key == "water":
            bands = [ground - 92, ground - 195, ground - 300, ground - 420, ground - 560, ground - 710]
        else:
            bands = [ground - 74, ground - 145, ground - 220, ground - 310, ground - 410, ground - 525, ground - 650]
        while section < world_w - 540:
            chosen = rng.sample(bands, k=rng.randint(2, 4))
            for band in chosen:
                y_level = max(80.0, float(band + rng.randint(-24, 24)))
                self.retro_obstacles.append(
                    RetroRect(
                        float(section + rng.randint(-65, 110)),
                        y_level,
                        float(rng.randint(74, 210)),
                        float(rng.choice((12, 14, 16))),
                        "platform",
                    )
                )
            if rng.random() < 0.58:
                wall_h = rng.choice((74, 112, 150, 205, 260))
                self.retro_obstacles.append(
                    RetroRect(
                        float(section + rng.randint(170, 360)),
                        float(ground - wall_h),
                        float(rng.choice((26, 32, 38))),
                        float(wall_h),
                        "wall",
                    )
                )
            if rng.random() < 0.55:
                base_x = section + rng.randint(45, 260)
                step_count = rng.randint(3, 7)
                for step in range(step_count):
                    self.retro_obstacles.append(
                        RetroRect(
                            float(base_x + step * rng.choice((48, 56, 64))),
                            float(ground - 38 - step * rng.choice((22, 28, 34))),
                            float(rng.choice((42, 52, 62))),
                            12.0,
                            "step",
                        )
                    )
            if rng.random() < 0.36:
                self.retro_obstacles.append(
                    RetroRect(
                        float(section + rng.randint(70, 290)),
                        float(ground - rng.choice((32, 52, 76))),
                        float(rng.randint(58, 105)),
                        float(rng.choice((28, 38, 52))),
                        "block",
                    )
                )
            section += max(150, int(rng.randint(245, 410) / max(0.70, spec_platform_mult)))

        # Set pieces intencionales tipo Mega Man X/Sonic: cada tercio tiene una ruta baja de velocidad,
        # una ruta alta de riesgo/recompensa y una ruta vertical que favorece habilidades concretas.
        for zone_idx, zone_x in enumerate((world_w * 0.18, world_w * 0.42, world_w * 0.68)):
            zone_x = float(zone_x + rng.randint(-120, 120))
            if biome.key in {"city", "village"}:
                # Techos y callejones: Wilson limpia rutas cortas, Yariel abre paredes, Mafer evita emboscadas.
                self.retro_obstacles.append(RetroRect(zone_x, ground - 118, 260.0, 14.0, "speed_lane"))
                self.retro_obstacles.append(RetroRect(zone_x + 310, ground - 190, 230.0, 14.0, "rooftop"))
                self.retro_obstacles.append(RetroRect(zone_x + 585, ground - 262, 190.0, 14.0, "rooftop"))
                self.retro_obstacles.append(RetroRect(zone_x + 760, ground - 330, 36.0, 250.0, "wall"))
            elif biome.key in {"forest", "valley"}:
                # Ramas / rampas: lectura de momentum estilo Sonic con salidas altas.
                for step in range(6):
                    self.retro_obstacles.append(RetroRect(zone_x + step * 92, ground - 72 - step * 34, 118.0, 13.0, "canopy"))
                self.retro_obstacles.append(RetroRect(zone_x + 620, ground - 330, 250.0, 13.0, "canopy"))
                self.retro_obstacles.append(RetroRect(zone_x + 930, ground - 96, 320.0, 12.0, "speed_lane"))
            elif biome.key in {"mountain", "lunar"}:
                # Ascensos verticales y saltos largos: Mafer destaca, Yariel controla enemigos desde lejos.
                shaft_x = zone_x + 120
                for step in range(8):
                    self.retro_obstacles.append(RetroRect(shaft_x + (step % 2) * 168, ground - 82 - step * 72, 132.0, 13.0, "climb_node"))
                self.retro_obstacles.append(RetroRect(shaft_x + 400, max(90.0, ground - 710), 260.0, 14.0, "high_route"))
            elif biome.key == "water":
                # Túneles inundados: rutas horizontales con respiraderos/burbujas.
                for step in range(5):
                    self.retro_obstacles.append(RetroRect(zone_x + step * 172, ground - 128 - (step % 2) * 82, 142.0, 13.0, "bubble_path"))
                self.retro_obstacles.append(RetroRect(zone_x + 870, ground - 430, 230.0, 14.0, "high_route"))
            elif biome.key == "lava":
                # Forja: rutas superiores para esquivar daño y salas de presión.
                self.retro_obstacles.append(RetroRect(zone_x, ground - 210, 190.0, 14.0, "heat_bridge"))
                self.retro_obstacles.append(RetroRect(zone_x + 250, ground - 292, 170.0, 14.0, "heat_bridge"))
                self.retro_obstacles.append(RetroRect(zone_x + 500, ground - 374, 190.0, 14.0, "heat_bridge"))
                self.retro_obstacles.append(RetroRect(zone_x + 760, ground - 92, 340.0, 13.0, "speed_lane"))

        # Pasadizos secretos funcionales: cada uno lleva a una sala real con recompensa.
        # Hay entradas por X Buster, Z Saber, Nova y bomba de Jetpack repartidas en altura.
        gate_positions = [
            (world_w * 0.22, ground - 250, "gun", "X BUSTER x3", 3),
            (world_w * 0.39, ground - 430, "sword", "Z SABER x2", 2),
            (world_w * 0.56, ground - 600, "nova", "NOVA", 1),
            (world_w * 0.72, ground - 520, "bomb", "BOMBA JETPACK", 1),
            (world_w * 0.82, ground - 720, "flight", "SOLO VOLAR", 1),
        ]
        for gx, gy, ability, label, hits in gate_positions:
            gx = float(gx + rng.randint(-120, 120))
            gy = float(max(92, gy + rng.randint(-35, 35)))
            self._add_secret_room(gx, gy, ability, label, rng, ground, hits=hits)

        # Progresión: no hay monedas. La XP se gana al derrotar enemigos;
        # solo permanecen 2 curaciones fijas que cargan tanques de +5 y drops aleatorios de vida.
        platform_candidates = [r for r in self.retro_obstacles if r.h <= 16 and r.x > 320 and r.x < world_w - 450]
        rng.shuffle(platform_candidates)

        # Techo del nivel: se coloca exactamente a la altura de la plataforma más alta
        # generada por la semilla, dejando una barrera sólida horizontal sobre todo el mapa.
        seed_platforms = [r for r in self.retro_obstacles if r.h <= 16 and r.kind not in {"boss_floor", "boss_room_ceiling", "boss_room_floor"}]
        if seed_platforms:
            ceiling_y = min(r.y for r in seed_platforms)
            self.retro_obstacles.append(RetroRect(0.0, max(0.0, ceiling_y - 18.0), float(world_w), 18.0, "level_ceiling"))

        # Curaciones: exactamente 2 por nivel; se guardan como tanques de +5.
        heal_candidates = platform_candidates[7:]
        for rect in heal_candidates[:2]:
            self.retro_pickups.append(RetroPickup(rect.x + rect.w * 0.5, rect.y - 28, "heal"))
        while len([p for p in self.retro_pickups if p.kind == "heal"]) < 2:
            self.retro_pickups.append(RetroPickup(rng.uniform(900, world_w - 900), rng.uniform(150, ground - 120), "heal"))

        # Cajitas manipulables con mouse: no atacan, pero empujan enemigos.
        box_count = max(10, int(world_w / 1350))
        box_spots = [r for r in platform_candidates if r.w >= 72 and 480 < r.x < world_w - 780]
        rng.shuffle(box_spots)
        for rect in box_spots[:box_count]:
            self.retro_boxes.append(RetroBox(rect.x + rect.w * 0.5 - 15.0, rect.y - 28.0, 30.0, 28.0))
        while len(self.retro_boxes) < box_count:
            self.retro_boxes.append(RetroBox(rng.uniform(640, world_w - 940), float(ground - 28), 30.0, 28.0))

        # Enemigos base: mezcla por bioma/modificador, con apertura segura antes del primer combate.
        enemy_id = 0
        x = 760
        enemy_kinds = list(ENEMY_STATS.keys())
        preferred = set(self.level_spec.get("preferred_enemies", ()))
        hazard = str(self.level_spec.get("hazard", ""))

        def weight_for(kind: str) -> float:
            spec = ENEMY_BEHAVIOR_SPECS.get(kind, {})
            weight = 10.0
            if kind in preferred or biome.key in set(spec.get("biome_affinity", ())):
                weight += 18.0
            if kind == "elite" and hazard != "elite":
                weight = 1.1 + self.level_number * 0.15
            if hazard == "hunters" and kind in {"sprinter", "leech", "kamikaze"}:
                weight += 18.0
            if hazard == "elite" and kind == "elite":
                weight += 26.0
            if kind in {"flyer", "ghost"}:
                weight *= float(self.level_spec.get("aerial_density", 2.0))
            if kind in {"sniper", "turret"}:
                weight += 8.0 * float(self.level_spec.get("aerial_density", 2.0))
            if self.level_number < 2 and kind in {"sniper", "summoner", "mirror", "ghost", "elite"}:
                weight *= 0.35
            return max(0.4, weight)

        weights = [weight_for(kind) for kind in enemy_kinds]
        # Separación por frases de combate: sigue siendo difícil, pero deja respirar y leer patrones.
        spawn_step_min = max(138, int(235 / max(0.75, float(self.level_spec.get("enemy_density", 1.0)))))
        spawn_step_max = max(spawn_step_min + 70, int(390 / max(0.75, float(self.level_spec.get("enemy_density", 1.0)))))

        def place_enemy(kind: str, raw_x: float | None = None) -> None:
            nonlocal enemy_id
            ew, eh, hp, attack, base_speed = ENEMY_STATS[kind]
            if kind == "elite":
                hp = int(hp * (1.0 + self.level_number * 0.08))
                attack = int(attack + max(0, self.level_number // 3))
            hp, attack_scaled = self._scaled_enemy_stats(hp, attack)
            if kind in {"flyer", "ghost"}:
                hp = int(max(1, hp * 1.35))
                base_speed *= 1.22
            ex = float((raw_x if raw_x is not None else rng.uniform(820, world_w - 980)) + rng.randint(-70, 135))
            if ex < 700.0:
                ex = 700.0 + rng.random() * 120.0
            platform = None
            nearby = [r for r in platform_candidates if abs((r.x + r.w * 0.5) - ex) < 280]
            if nearby and rng.random() < (0.70 if kind in {"ghost", "flyer", "burrower"} else 0.88):
                platform = rng.choice(nearby)
                ex = min(platform.x + platform.w - ew - 6, max(platform.x + 6, ex))
                ey = platform.y - eh
            else:
                ey = float(ground - eh)
            if kind in {"flyer", "ghost"}:
                ey = float(max(90, ey - rng.choice((120, 180, 250, 320))))
            if kind in {"turret", "sniper"} and platform is None and platform_candidates:
                platform = min(platform_candidates, key=lambda r: abs((r.x + r.w * 0.5) - ex))
                ex = min(platform.x + platform.w - ew - 6, max(platform.x + 6, ex))
                ey = platform.y - eh
            speed = rng.choice((-1.0, 1.0)) * base_speed * 1.08
            patrol = int(rng.randint(95, 250) * 1.35)
            enemy = RetroEnemy(
                x=ex, y=ey, w=ew, h=eh, vx=speed, kind=kind, hp=hp, max_hp=hp, attack=attack_scaled,
                patrol_left=max(42.0, ex - patrol), patrol_right=min(float(world_w - 90), ex + patrol),
                phase=float(enemy_id) * 0.37, home_y=ey, shoot_timer=rng.uniform(0.6, 2.3) * ENEMY_FIRE_COOLDOWN_MULT,
                status_effects={}, armor=1.0 if kind in {"major", "shield", "mirror", "elite"} else 0.0,
                weakness=rng.choice(("fire", "ice", "lightning", "sonic", "acid", "slash")) if kind == "elite" else "",
                resistance="physical" if kind in {"shield", "major", "mirror"} else "",
                elite_mod=rng.choice(("rápido", "duro", "veneno", "crítico")) if kind == "elite" else "",
            )
            self.retro_enemies.append(enemy)
            enemy_id += 1

        while x < world_w - 720:
            if rng.random() < 0.86:
                kind = rng.choices(enemy_kinds, weights=weights, k=1)[0]
                place_enemy(kind, float(x))
            x += rng.randint(spawn_step_min, spawn_step_max)

        # Escalado por progreso: más presión por nivel, sin convertir cada pantalla en enjambre.
        enemy_multiplier = min(3.2, 1.0 + max(0, self.level_number - 1) * 0.28) * float(self.level_spec.get("enemy_density", 1.0)) * self._campaign_enemy_quantity_mult()
        base_nonboss = [e for e in self.retro_enemies if not e.kind.startswith("boss")]
        extra_count = max(0, int(len(base_nonboss) * (enemy_multiplier - 1.0)))
        extra_count = min(extra_count, 70)
        for _ in range(extra_count):
            kind = rng.choices(enemy_kinds, weights=weights, k=1)[0]
            place_enemy(kind)

        # Amenazas aéreas extra: sirven como acento, no como ruido permanente.
        aerial_extra = min(36, max(6, int((world_w / 1550) * float(self.level_spec.get("aerial_density", 1.0)))))
        for _ in range(aerial_extra):
            place_enemy(rng.choice(("flyer", "flyer", "ghost", "sniper", "turret")))

        # Límite de rendimiento: mantiene la dificultad alta sin bloquear entradas en niveles 2+.
        max_nonboss = int((155 + self.level_number * 22) * max(1.0, self._campaign_enemy_quantity_mult()))
        base_nonboss = [e for e in self.retro_enemies if not e.kind.startswith("boss")]
        if len(base_nonboss) > max_nonboss:
            keep_ids = {id(e) for e in rng.sample(base_nonboss, max_nonboss)}
            self.retro_enemies = [e for e in self.retro_enemies if e.kind.startswith("boss") or id(e) in keep_ids]

        if hazard == "waves":
            for wave_x in (world_w * 0.36, world_w * 0.54, world_w * 0.72):
                for offset in (-70, 0, 70):
                    place_enemy(rng.choice(("minor", "sprinter", "hopper", "shield")), wave_x + offset)
        # Jefes por nivel: cada nivel agrega un jefe adicional en la sala, hasta 5 acumulados.
        final_boss_x = float(world_w - 650 + rng.randint(-90, 70))
        boss_y = float(ground - 78)

        # Sala del jefe final: arena cerrada con techo, pared trasera y entrada estrecha.
        # El checkpoint extra queda justo antes de la puerta.
        if final_boss_x <= 0:
            final_boss_x = world_w - 650
        arena_x = max(520.0, final_boss_x - 360.0)
        arena_y = max(70.0, ground - 420.0)
        arena_w = min(860.0, world_w - arena_x - 80.0)
        arena_h = float(ground - arena_y + 36.0)
        self.boss_room_stop_x = max(0.0, arena_x - self.hard_spike_wall_width - 32.0)
        # Techo con hueco garantizado: siempre deja una abertura pequeña
        # de al menos el doble del ancho del personaje para entrar desde arriba.
        roof_gap_w = max(72.0, self.retro_player.w * 2.2)
        roof_gap_x = min(arena_x + arena_w - roof_gap_w - 72.0, max(arena_x + 72.0, arena_x + arena_w * 0.18))
        ceiling_segments: list[RetroRect] = []
        left_ceiling_w = roof_gap_x - arena_x
        right_ceiling_x = roof_gap_x + roof_gap_w
        right_ceiling_w = arena_x + arena_w - right_ceiling_x
        if left_ceiling_w > 10.0:
            ceiling_segments.append(RetroRect(arena_x, arena_y, left_ceiling_w, 18.0, "boss_room_ceiling"))
        if right_ceiling_w > 10.0:
            ceiling_segments.append(RetroRect(right_ceiling_x, arena_y, right_ceiling_w, 18.0, "boss_room_ceiling"))
        self.retro_obstacles.extend(
            [
                *ceiling_segments,
                RetroRect(arena_x + arena_w - 18.0, arena_y, 18.0, arena_h, "boss_room_wall"),
                RetroRect(arena_x, arena_y, 18.0, arena_h, "boss_room_wall"),
                RetroRect(arena_x, ground + 16.0, arena_w, 18.0, "boss_room_floor"),
                RetroRect(arena_x + 42.0, boss_y + 78 + 12, max(260.0, arena_w - 84.0), 16.0, "boss_floor"),
            ]
        )
        boss_count = self._campaign_boss_count() if self._campaign_boss_count() is not None else min(5, max(1, self.level_number))
        boss_offsets = [0.50, 0.30, 0.70, 0.42, 0.58]
        for boss_index in range(boss_count):
            boss_kind = self._boss_kind_for_level(boss_index)
            bx = arena_x + arena_w * boss_offsets[boss_index] - 34.0
            boss_spec = BOSS_SPECS.get(boss_kind, {})
            boss_hp, boss_attack = self._scaled_enemy_stats(50 * float(boss_spec.get("hp_mult", 1.0)), 3 * float(boss_spec.get("attack_mult", 1.0)))
            boss_hp *= 2
            self.retro_enemies.append(RetroEnemy(
                x=bx, y=boss_y, w=68.0, h=78.0, vx=36.0 if boss_index % 2 == 0 else -36.0,
                kind=boss_kind, hp=boss_hp, max_hp=boss_hp, attack=boss_attack,
                patrol_left=max(arena_x + 36.0, bx - 170.0), patrol_right=min(arena_x + arena_w - 36.0, bx + 238.0),
                phase=float(boss_index) * 0.73, home_y=boss_y, shoot_timer=1.15 + boss_index * 0.18, pattern_timer=0.0,
                status_effects={}, weakness=str(boss_spec.get("weakness", "")), resistance="physical" if boss_kind in {"boss_colossus", "boss_rock"} else ""
            ))
        # La única entrada a la sala de jefe es el hueco en el techo.
        self.boss_room_entry_x = roof_gap_x + roof_gap_w * 0.5
        self._carve_boss_room_entry_corridors(
            arena_x=arena_x,
            arena_y=arena_y,
            arena_w=arena_w,
            arena_h=arena_h,
            ground=float(ground),
            roof_gap_x=roof_gap_x,
            roof_gap_w=roof_gap_w,
        )
        platform_candidates = [r for r in self.retro_obstacles if r.h <= 16 and r.x > 320 and r.x < world_w - 450]

        # Checkpoints: 33%, 66% y uno adicional justo antes del jefe final.
        checkpoint_specs = [
            (world_w * 0.33, "CHECKPOINT 33%"),
            (world_w * 0.66, "CHECKPOINT 66%"),
            (self.boss_room_entry_x, "ANTES DEL JEFE"),
        ]
        for raw_x, label in checkpoint_specs:
            cx = float(max(160.0, min(world_w - 220.0, raw_x)))
            # Regla nueva: los checkpoints siempre quedan al nivel del suelo y nunca encerrados.
            # Se limpia un corredor amplio alrededor para evitar paredes, pinchos o cajas bloqueantes.
            cp_x = cx
            cp_y = float(ground - 36.0)
            clear_x0 = cp_x - 95.0
            clear_x1 = cp_x + 95.0
            self.retro_obstacles = [r for r in self.retro_obstacles if not (r.x < clear_x1 and r.x + r.w > clear_x0 and r.y > ground - 150.0 and r.kind not in {"level_ceiling", "boss_room_wall", "boss_room_ceiling"})]
            self.retro_pits = [pit for pit in self.retro_pits if not (pit.x < clear_x1 and pit.x + pit.w > clear_x0)]
            self.retro_checkpoints.append(RetroCheckpoint(cp_x, cp_y, label))

        if self.selected_mode == "race" or self._campaign_has_finish_goal():
            # Carrera y nivel 4 de campaña no tienen jefe: la meta reemplaza la sala final.
            self.retro_enemies = [enemy for enemy in self.retro_enemies if not enemy.kind.startswith("boss")]
            self.retro_obstacles = [
                rect for rect in self.retro_obstacles
                if rect.kind not in {"boss_room_wall", "boss_room_ceiling", "boss_room_floor", "boss_floor"}
            ]
            self.boss_room_stop_x = 0.0
            self.boss_room_entry_x = 0.0
            self.race_finish_x = float(max(520.0, world_w - 180.0))
            self.race_finish_reached = False
            self.retro_checkpoints = [cp for cp in self.retro_checkpoints if cp.label != "ANTES DEL JEFE"]
            self.retro_checkpoints.append(RetroCheckpoint(self.race_finish_x - 72.0, float(ground - 36.0), "META"))
        else:
            self.race_finish_x = 0.0
            self.race_finish_reached = False

        if compact_mode:
            # Estos modos son salas compactas: se eliminan jefes, oleadas y pozos para que
            # el foco sea PVP/CPU en Arena y sombras acumuladas en Desafío.
            if self.selected_mode == "arena":
                self._build_arena_stadium(world_w, ground)
                self.boss_room_entry_x = 0.0
                self.boss_room_stop_x = 0.0
            else:
                self.retro_enemies.clear()
                self.retro_pickups.clear()
                self.retro_pits.clear()
                self.secret_gates.clear()
                self.retro_obstacles = [
                    rect for rect in self.retro_obstacles
                    if rect.kind not in {"spike_trap", "boss_room_wall", "boss_room_ceiling", "boss_room_floor", "boss_floor"}
                ]
                self.retro_checkpoints = [RetroCheckpoint(94.0, float(ground - 36.0), "INICIO")]
            if self.selected_mode == "challenge":
                boss_hp, boss_attack = self._scaled_enemy_stats(100, 5)
                boss_hp *= 4
                bx = max(420.0, self.retro_world_width - 210.0)
                by = float(ground - 88.0)
                self.retro_enemies.append(RetroEnemy(
                    x=bx, y=by, w=72.0, h=88.0, vx=-36.0, kind="boss_shadow_warp",
                    hp=boss_hp, max_hp=boss_hp, attack=boss_attack,
                    patrol_left=40.0, patrol_right=float(self.retro_world_width - 32.0),
                    phase=0.0, home_y=by, shoot_timer=CHALLENGE_SAFE_INTRO + 0.8, pattern_timer=0.0,
                    status_effects={}, weakness="lightning", resistance="physical"
                ))
                self.retro_checkpoints.append(RetroCheckpoint(max(220.0, self.retro_world_width - 280.0), float(ground - 36.0), "JEFE ESPEJO"))

        if self._is_tutorial_free():
            # Práctica libre: nivel 0.5 con todo al máximo y la mitad de enemigos iniciales del nivel 1.
            normal = [enemy for enemy in self.retro_enemies if not enemy.kind.startswith("boss")]
            rng.shuffle(normal)
            keep = {id(e) for e in normal[:max(1, len(normal) // 2)]}
            self.retro_enemies = [enemy for enemy in self.retro_enemies if enemy.kind.startswith("boss") or id(enemy) in keep]
            self.level_spec["level"] = "0.5"
            self.level_spec["modifier_name"] = "Práctica libre 0.5"
            self.level_spec["objective"] = "prueba libre con equipo máximo"

        # En modo difícil ya no se genera jefe perseguidor; se usa una pared de pinchos
        # sistémica que avanza desde atrás del jugador.


    def _add_secret_room(self, gx: float, gy: float, ability: str, label: str, rng: random.Random, ground: int, *, hits: int = 1) -> None:
        gate_h = 116.0
        gate_w = 42.0
        gy = max(72.0, min(float(ground - gate_h - 28), gy))
        gate = SecretGate(RetroRect(float(gx), float(gy), gate_w, gate_h, "secret_gate"), ability, label, False, max(1, hits), max(1, hits))
        self.secret_gates.append(gate)
        room_x = gx + gate_w + 20.0
        room_y = max(68.0, gy - 24.0)
        # Sala real: piso, techo, pared posterior y dos plataformas internas.
        self.retro_obstacles.extend([
            RetroRect(room_x, room_y + gate_h + 14.0, 420.0, 16.0, "secret_room_floor"),
            RetroRect(room_x, room_y - 8.0, 420.0, 16.0, "secret_room_roof"),
            RetroRect(room_x + 404.0, room_y - 8.0, 16.0, gate_h + 38.0, "secret_room_wall"),
            RetroRect(room_x + 82.0, room_y + 74.0, 126.0, 14.0, "secret_path"),
            RetroRect(room_x + 246.0, room_y + 36.0, 118.0, 14.0, "secret_path"),
        ])
        self.retro_pickups.append(RetroPickup(room_x + 118.0, room_y + 42.0, "heal"))
        self.retro_pickups.append(RetroPickup(room_x + 302.0, room_y + 6.0, "xp_orb"))
        self.retro_pickups.append(RetroPickup(room_x + 338.0, room_y + 6.0, "xp_orb"))
        if rng.random() < 0.75:
            ew, eh, hp, attack, speed = ENEMY_STATS["minor"]
            hp, attack = self._scaled_enemy_stats(hp, attack)
            ex = room_x + 215.0
            ey = room_y + gate_h + 14.0 - eh
            self.retro_enemies.append(RetroEnemy(ex, ey, ew, eh, speed, "minor", hp, hp, attack, ex - 70.0, ex + 96.0, home_y=ey, status_effects={}))

    def _build_tutorial_level(self, world_w: int, ground: int) -> None:
        rng = random.Random(7351337)
        self.current_biome = next((b for b in BIOMES if b.key == "city"), BIOMES[0])
        self.level_spec = {
            "level": 0,
            "biome": self.current_biome.key,
            "biome_name": self.current_biome.name,
            "modifier": "tutorial",
            "modifier_name": "Tutorial guiado",
            "difficulty": 1.0,
            "rhythm": "tutorial",
            "objective": "practica habilidades con equipo al máximo",
            "enemy_density": 0.0,
            "platform_density": 1.0,
            "hazard": "tutorial",
            "reward": 1.0,
        }
        self.level_modifier_key = "tutorial"
        self.boss_room_entry_x = 0.0
        self.boss_room_stop_x = 0.0
        self.race_finish_x = 5350.0
        self.race_finish_reached = False
        self.retro_obstacles.extend([
            RetroRect(40.0, float(ground - 60), 340.0, 14.0, "tutorial_start"),
            RetroRect(430.0, float(ground - 118), 180.0, 14.0, "tutorial_step"),
            RetroRect(650.0, float(ground - 178), 160.0, 14.0, "tutorial_step"),
            RetroRect(900.0, float(ground - 86), 250.0, 14.0, "tutorial_lane"),
            RetroRect(1260.0, float(ground - 155), 180.0, 14.0, "tutorial_platform"),
            RetroRect(1510.0, float(ground - 235), 180.0, 14.0, "tutorial_platform"),
            RetroRect(1780.0, float(ground - 320), 170.0, 14.0, "tutorial_platform"),
            RetroRect(2140.0, float(ground - 90), 290.0, 14.0, "tutorial_lane"),
            RetroRect(2470.0, float(ground - 172), 210.0, 14.0, "tutorial_platform"),
            RetroRect(2830.0, float(ground - 118), 250.0, 14.0, "tutorial_lane"),
            RetroRect(3200.0, float(ground - 210), 230.0, 14.0, "tutorial_platform"),
            RetroRect(3600.0, float(ground - 128), 300.0, 14.0, "tutorial_lane"),
            RetroRect(4020.0, float(ground - 96), 320.0, 14.0, "tutorial_parry"),
            RetroRect(4420.0, float(ground - 168), 230.0, 14.0, "tutorial_platform"),
            RetroRect(4760.0, float(ground - 96), 330.0, 14.0, "tutorial_resurrection"),
            RetroRect(5200.0, float(ground - 128), 300.0, 14.0, "tutorial_finish"),
            RetroRect(0.0, 44.0, float(world_w), 18.0, "level_ceiling"),
        ])
        self.retro_pits.extend([RetroPit(1180.0, 140.0), RetroPit(1960.0, 170.0), RetroPit(3090.0, 120.0), RetroPit(4345.0, 120.0)])
        self.retro_checkpoints = [
            RetroCheckpoint(94.0, float(ground - 36.0), "INICIO"),
            RetroCheckpoint(1500.0, float(ground - 36.0), "JETPACK"),
            RetroCheckpoint(2860.0, float(ground - 36.0), "PASADIZOS"),
            RetroCheckpoint(4050.0, float(ground - 36.0), "PARRY"),
            RetroCheckpoint(4760.0, float(ground - 36.0), "N-RES"),
            RetroCheckpoint(self.race_finish_x - 72.0, float(ground - 36.0), "META"),
        ]
        self.active_checkpoint_index = -1
        # Enemigos controlados, pero activos: en V7 varios quedaban casi inmóviles
        # hasta que el jugador se acercaba mucho. Ahora todos patrullan/atacan dentro
        # de rangos seguros para que el tutorial no se sienta congelado.
        specs = [
            # x, y_base, tipo, dirección, multiplicador_velocidad, patrulla_izq, patrulla_der, delay_disparo
            (960.0, ground - 20.0, "minor", 1, 0.72, 130.0, 170.0, 0.60),
            (1320.0, ground - 155.0 - 20.0, "turret", 1, 0.0, 0.0, 0.0, 1.10),
            (2210.0, ground - 90.0 - 20.0, "shield", -1, 0.55, 150.0, 160.0, 0.80),
            (2520.0, ground - 172.0 - 20.0, "flyer", 1, 0.70, 180.0, 190.0, 0.75),
            (3660.0, ground - 128.0 - 20.0, "sniper", -1, 0.18, 120.0, 140.0, 1.00),
            (4070.0, ground - 96.0 - 20.0, "hopper", 1, 0.62, 120.0, 130.0, 0.70),
            (4285.0, ground - 96.0 - 20.0, "ninja", -1, 0.95, 150.0, 180.0, 0.55),
            (4510.0, ground - 168.0 - 20.0, "hunter", -1, 0.58, 120.0, 150.0, 0.62),
            (4820.0, ground - 96.0 - 20.0, "minor", 1, 0.65, 130.0, 150.0, 0.60),
            (5050.0, ground - 96.0 - 20.0, "major", -1, 0.50, 130.0, 160.0, 0.75),
        ]
        for ex, ey, kind, direction, speed_mult, patrol_l, patrol_r, shoot_delay in specs:
            ew, eh, hp, attack, speed = ENEMY_STATS[kind]
            hp, attack = self._scaled_enemy_stats(max(2, hp // 2), max(1, attack))
            ey = float(max(78.0, ey - eh + 20.0))
            vx = float(direction) * speed * float(speed_mult)
            self.retro_enemies.append(RetroEnemy(
                ex, ey, ew, eh, vx, kind, hp, hp, attack,
                max(24.0, ex - float(patrol_l)), min(float(world_w - 24.0), ex + float(patrol_r)),
                home_y=ey, shoot_timer=float(shoot_delay), status_effects={}
            ))
        self.retro_boxes.append(RetroBox(2320.0, float(ground - 118.0), 30.0, 28.0))
        self.retro_pickups.extend([
            RetroPickup(520.0, float(ground - 150.0), "heal"),
            RetroPickup(1100.0, float(ground - 118.0), "xp_orb"),
            RetroPickup(1540.0, float(ground - 267.0), "heal"),
            RetroPickup(3820.0, float(ground - 160.0), "xp_orb"),
            RetroPickup(4330.0, float(ground - 130.0), "heal"),
            RetroPickup(4920.0, float(ground - 130.0), "xp_orb"),
        ])
        self._add_secret_room(2500.0, float(ground - 232.0), "gun", "X BUSTER x3", rng, ground, hits=3)
        self._add_secret_room(3000.0, float(ground - 300.0), "sword", "Z SABER", rng, ground, hits=2)
        self._add_secret_room(3450.0, float(ground - 250.0), "nova", "NOVA DASH", rng, ground, hits=1)
        self._add_secret_room(3830.0, float(ground - 340.0), "bomb", "BOMBA JETPACK", rng, ground, hits=1)
        self.tutorial_messages = [
            (100.0, ground - 150.0, "TUTORIAL: todo está al máximo. X dispara; mantén X para cargar."),
            (470.0, ground - 225.0, "Salta por plataformas. Shift corre; Espacio/Enter hace dash."),
            (900.0, ground - 155.0, "Practica combate controlado: X Buster con seguimiento y Z Saber."),
            (1260.0, ground - 230.0, "C usa Jetpack en el aire. Hay tiempo máximo, pero aquí está mejorado."),
            (2110.0, ground - 165.0, "Telequinesis es pasiva: haz click y arrastra cajas para probar."),
            (2450.0, ground - 250.0, "B activa Shield. 1-3 seleccionan habilidades rápidas; Z usa la seleccionada."),
            (2700.0, ground - 320.0, "Pasadizos: algunos muros abren con varios disparos X, otros con Z, Nova o bombas."),
            (3200.0, ground - 280.0, "Time-space invierte la pantalla, congela enemigos y permite teleports con click hasta agotar tiempo; cada teleport tiene CD reducido 70%."),
            (4020.0, ground - 185.0, "PARRY: salta sobre enemigos para rebotar, causar daño y abrir una ventana breve de desvío."),
            (4280.0, ground - 185.0, "Nuevo enemigo: NINJA. Es rápido, lanza estrellas y usa espada si se acerca."),
            (4510.0, ground - 245.0, "Nuevo enemigo: CAZADOR. Dispara escopeta de 2 balas con cadencia igual al X Buster inicial."),
            (4800.0, ground - 180.0, "N-RESURRECTION: mata un enemigo y usa Z con la habilidad seleccionada, o pulsa N, para revivirlo como aliado."),
            (5060.0, ground - 185.0, "Con mejoras, N-Resurrection mantiene hasta 5 aliados y aumenta vida/ataque de revividos."),
        ]



    def _build_campaign_arena_level(self, world_w: int, ground: int) -> None:
        self.current_biome = next((b for b in BIOMES if b.key == "city"), BIOMES[0])
        self.level_spec = {
            "level": self.level_number,
            "biome": self.current_biome.key,
            "biome_name": self.current_biome.name,
            "modifier": "campaign_arena",
            "modifier_name": "Arena espejo" if int(self.level_number) == 3 else "Arena final",
            "difficulty": 1.0 + self.level_number * 0.25,
            "rhythm": "arena",
            "objective": "vence a tu sombra" if int(self.level_number) == 3 else "vence al jefe final y sobrevive al ninja",
            "enemy_density": 0.0,
            "platform_density": 1.0,
            "hazard": "mirror_shadow",
            "reward": 1.0,
        }
        self.level_modifier_key = "campaign_arena"
        self.boss_room_entry_x = 0.0
        self.boss_room_stop_x = 0.0
        self.race_finish_x = 0.0
        self.race_finish_reached = False
        self.retro_pits.clear()
        self.retro_pickups.clear()
        self.secret_gates.clear()
        self.retro_boxes.clear()
        self.retro_obstacles.extend([
            RetroRect(34.0, float(ground - 54), float(world_w - 68), 16.0, "arena_floor"),
            RetroRect(0.0, 42.0, float(world_w), 18.0, "level_ceiling"),
            RetroRect(18.0, 42.0, 18.0, float(ground - 42), "arena_wall"),
            RetroRect(float(world_w - 36), 42.0, 18.0, float(ground - 42), "arena_wall"),
            RetroRect(float(world_w * 0.22), float(ground - 150), 250.0, 14.0, "arena_platform"),
            RetroRect(float(world_w * 0.58), float(ground - 210), 310.0, 14.0, "arena_platform"),
            RetroRect(float(world_w * 0.40), float(ground - 315), 260.0, 14.0, "arena_platform"),
        ])
        self.retro_checkpoints = [RetroCheckpoint(94.0, float(ground - 36.0), "INICIO")]
        self.active_checkpoint_index = -1
        if int(self.level_number) == 6:
            boss_kind = "boss_clone"
            boss_hp, boss_attack = self._scaled_enemy_stats(150, 6)
            boss_attack = round(boss_attack * 1.25, 2)
            bx = float(world_w * 0.62)
            by = float(ground - 88.0)
            self.retro_enemies.append(RetroEnemy(
                x=bx, y=by, w=72.0, h=88.0, vx=-62.0, kind=boss_kind,
                hp=boss_hp, max_hp=boss_hp, attack=boss_attack,
                patrol_left=80.0, patrol_right=float(world_w - 80.0),
                phase=0.0, home_y=by, shoot_timer=0.75, pattern_timer=0.0,
                status_effects={}, weakness="lightning", resistance="physical", elite_mod="final_boss_aggressive"
            ))
            ew, eh, hp, attack, speed = ENEMY_STATS["ninja"]
            hp, attack = self._scaled_enemy_stats(hp * 5, attack)
            nx = float(world_w * 0.82)
            ny = float(ground - eh)
            self.retro_enemies.append(RetroEnemy(
                x=nx, y=ny, w=ew, h=eh, vx=-abs(speed), kind="ninja",
                hp=hp, max_hp=hp, attack=attack,
                patrol_left=80.0, patrol_right=float(world_w - 80.0),
                phase=1.0, home_y=ny, shoot_timer=1.0, pattern_timer=0.0,
                status_effects={}, elite_mod="immortal_final_ninja"
            ))

    def _place_challenge_boss_opposite_player(self) -> None:
        if self.selected_mode != "challenge":
            return
        player = self.retro_player
        ground = self._retro_ground_y()
        player_center = player.x + player.w * 0.5
        place_right = player_center <= self.retro_world_width * 0.5
        for enemy in self.retro_enemies:
            if enemy.kind != "boss_shadow_warp":
                continue
            if place_right:
                target_x = max(player.x + max(420.0, self.retro_world_width * 0.30), self.retro_world_width - enemy.w - 190.0)
            else:
                target_x = min(player.x - max(420.0, self.retro_world_width * 0.30) - enemy.w, 190.0)
            enemy.x = max(48.0, min(float(self.retro_world_width - enemy.w - 48.0), target_x))
            enemy.y = float(ground - enemy.h)
            enemy.home_y = enemy.y
            enemy.vx = -abs(enemy.vx or 36.0) if enemy.x > player.x else abs(enemy.vx or 36.0)
            enemy.pattern_timer = 0.0
            enemy.shoot_timer = max(enemy.shoot_timer, CHALLENGE_SAFE_INTRO + 0.8)

    def _build_arena_stadium(self, world_w: int, ground: int) -> None:
        self.retro_obstacles.clear()
        self.retro_pits.clear()
        self.retro_enemies.clear()
        self.retro_boxes.clear()
        self.secret_gates.clear()
        self.retro_pickups.clear()
        self.retro_checkpoints = [RetroCheckpoint(94.0, float(ground - 36.0), "INICIO")]
        # Estadio más respirable: menos plataformas por nivel y separación vertical amplia.
        margin = 118.0
        span = max(900.0, float(world_w) - margin * 2.0)
        platforms: list[RetroRect] = []
        layers = (
            (ground - 104.0, 285.0, 5, 0.00),
            (ground - 226.0, 265.0, 4, 0.38),
            (ground - 354.0, 245.0, 4, 0.08),
            (ground - 492.0, 225.0, 3, 0.54),
        )
        for y, width, count, offset in layers:
            if count <= 1:
                xs = [world_w * 0.5 - width * 0.5]
            else:
                step = span / (count - 1)
                xs = [margin + (i + (offset if i % 2 else 0.0)) * step - width * 0.5 for i in range(count)]
            for x in xs:
                x = max(86.0, min(float(world_w) - width - 86.0, x))
                platforms.append(RetroRect(float(x), float(y), float(width), 14.0, "arena_platform"))
        # Cruces centrales grandes, separados para que no formen una escalera apretada.
        platforms.extend([
            RetroRect(world_w * 0.5 - 210.0, float(ground - 164), 420.0, 14.0, "arena_platform"),
            RetroRect(world_w * 0.5 - 235.0, float(ground - 424), 470.0, 14.0, "arena_platform"),
            RetroRect(170.0, float(ground - 500), 250.0, 14.0, "arena_platform"),
            RetroRect(max(170.0, world_w - 420.0), float(ground - 500), 250.0, 14.0, "arena_platform"),
        ])
        # Eliminar duplicados/solapes y dejar carriles de lectura limpia.
        compact: list[RetroRect] = []
        for rect in sorted(platforms, key=lambda r: (r.y, r.x)):
            if any(abs(rect.y - other.y) < 10 and abs((rect.x + rect.w * 0.5) - (other.x + other.w * 0.5)) < 145 for other in compact):
                continue
            compact.append(rect)
        self.retro_obstacles.extend(compact)
        self._reseed_arena_point_orbs(force=True)

    def _arena_point_spawn_candidates(self) -> list[tuple[float, float]]:
        ground = self._retro_ground_y()
        spots: list[tuple[float, float]] = []
        for rect in self.retro_obstacles:
            if rect.h <= 18 and rect.w >= 70 and rect.kind.startswith("arena"):
                for frac in (0.25, 0.50, 0.75):
                    spots.append((rect.x + rect.w * frac, rect.y - 28.0))
        for i in range(18):
            frac = (i + 1) / 19
            spots.append((80.0 + (self.retro_world_width - 160.0) * frac, float(ground - 32.0)))
        return spots

    def _reseed_arena_point_orbs(self, *, force: bool = False) -> None:
        if self.selected_mode != "arena":
            return
        active = [p for p in self.retro_pickups if p.kind == "point_orb" and not p.collected]
        if not force and len(active) >= ARENA_POINT_ORB_TARGET:
            return
        if force:
            self.retro_pickups = [p for p in self.retro_pickups if p.kind != "point_orb"]
            active = []
        spots = self._arena_point_spawn_candidates()
        if not spots:
            return
        rng = random.Random(self.retro_seed + int(time.perf_counter() * 10))
        rng.shuffle(spots)
        needed = max(0, ARENA_POINT_ORB_TARGET - len(active))
        for px, py in spots[:needed]:
            self.retro_pickups.append(RetroPickup(px, py, "point_orb"))


    def _advance_to_next_level(self, width: int, height: int) -> None:
        if self._is_tutorial_guided():
            was_night = self._is_mode_night()
            self.selected_mode = "tutorial_free_night" if was_night else "tutorial_free"
            self.level_number = 1
            self.retro_seed = random.SystemRandom().randrange(1, 2_147_483_647)
            self.current_biome = self._current_biome_for_seed()
            self._apply_mode_loadout()
            self._pending_level_advance = 0.0
            self.win_banner_timer = 0.0
            self.level_intro_timer = 0.0
            self.status_notice_text = "TUTORIAL 0 COMPLETO · ENTRANDO A 0.5 PRÁCTICA LIBRE"
            self.status_notice_timer = 4.0
            self._reset_retro_world(width, height, keep_player_ratio=False)
            self._reset_flashlight_state()
            self._apply_palette_to_window()
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 24, 46.0, 0.9, "level_up"))
            return
        if self._complete_campaign_if_needed():
            return
        # Conserva XP, habilidades, tanques y mejoras; genera una semilla nueva y escala la dificultad.
        saved_xp = self.xp_count
        saved_tanks = self.heal_tanks
        saved_hp = max(1, self.retro_player.hp)
        self.level_number += 1
        self.retro_seed = random.SystemRandom().randrange(1, 2_147_483_647)
        self.current_biome = self._current_biome_for_seed()
        self._x_charge_active = False
        self._z_sword_charge_active = False
        self.slow_time_timer = 0.0
        self.slow_time_cooldown = 0.0
        self._pending_level_advance = 0.0
        self.win_banner_timer = 0.0
        self.level_intro_timer = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 7.0
        self.challenge_timer = 18.0 + min(22.0, self.level_number * 3.0)
        self.challenge_safe_timer = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 0.0
        self.shadow_chaser_history.clear()
        self.shadow_chaser_hp.clear()
        self.shadow_chaser_max_hp.clear()
        self.shadow_chaser_hurt.clear()
        self.shadow_chaser_respawn.clear()
        self.pressed_keys.clear()
        self._last_jump_pressed = False
        self._last_dash_pressed = False
        self._last_primary_pressed = False
        self._last_secondary_pressed = False
        self._reset_retro_world(width, height, keep_player_ratio=False)
        self.xp_count = saved_xp
        self.heal_tanks = saved_tanks
        self.retro_player.hp = min(self.retro_player.max_hp, saved_hp)
        self._apply_palette_to_window()
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 24, 36.0, 0.85, "level_up"))
        self._save_mode_progress()

    def _reset_retro_world(self, width: int, height: int, *, keep_player_ratio: bool = True) -> None:
        width = max(360, width)
        height = max(220, height)
        previous = self.retro_world_size
        old_world_w = previous[2] if previous else 0
        old_world_h = previous[3] if previous else 0
        self._retro_generate_level(width, height)
        ground = self._retro_ground_y()
        player = self.retro_player

        if previous is None or not keep_player_ratio:
            player.x = 94.0
            player.y = float(ground - player.h)
            self.retro_camera_x = 0.0
            self.retro_camera_y = max(0.0, ground - height + 96)
            player.max_hp = STARTING_PLAYER_HP + self.hp_upgrade * 5
            player.hp = player.max_hp
            player.flight_left = self._flight_max_duration()
            player.flight_cooldown = 0.0
            if not getattr(self, "_pending_restore_after_world", None):
                self.xp_count = 0
        else:
            ratio_x = self.retro_world_width / max(1, old_world_w)
            ratio_y = self.retro_world_height / max(1, old_world_h)
            player.x = max(8.0, min(self.retro_world_width - player.w - 8.0, player.x * ratio_x))
            player.y = max(8.0, min(ground - player.h, player.y * ratio_y))
            self.retro_camera_x = max(0.0, min(float(max(0, self.retro_world_width - width)), self.retro_camera_x * ratio_x))
            self.retro_camera_y = max(0.0, min(float(max(0, self.retro_world_height - height)), self.retro_camera_y * ratio_y))

        self._reset_hard_spike_wall_behind_player()

        player.h = player.base_h
        player.crouching = False
        player.vx = 0.0
        player.vy = 0.0
        player.on_ground = True
        player.jumps_used = 0
        player.wall_side = 0
        player.dash_timer = 0.0
        player.dash_cooldown = 0.0
        player.attack_timer = 0.0
        player.attack_cooldown = 0.0
        player.shoot_cooldown = 0.0
        player.hurt_timer = 0.0
        if self.selected_mode == "challenge":
            self.challenge_safe_timer = CHALLENGE_SAFE_INTRO if previous is None or not keep_player_ratio else max(getattr(self, "challenge_safe_timer", 0.0), 1.0)
            self._place_challenge_boss_opposite_player()
        self._place_p2_for_mode(reset_hp=previous is None or not keep_player_ratio)
        if self.selected_mode == "arena":
            self._setup_arena_bots()
            self._retro_update_camera(width, height, instant=True)
        else:
            self.arena_bots.clear()
        self.retro_projectiles.clear()
        if not keep_player_ratio:
            self.shadow_chaser_history.clear()
            self.shadow_chaser_hp.clear()
            self.shadow_chaser_max_hp.clear()
            self.shadow_chaser_hurt.clear()
            self.shadow_chaser_respawn.clear()
            self.shadow_action_history.clear()
            self.shadow_action_cursors.clear()
            self._shadow_next_action_id = 1
        self.retro_world_size = (width, height, self.retro_world_width, self.retro_world_height, self.retro_seed, self.selected_mode)

    def _ensure_retro_world(self, width: int, height: int) -> None:
        width = max(360, width)
        height = max(220, height)
        # Fijado: el tamaño esperado debe incluir los modificadores de LevelSpec.
        # Antes, niveles con ritmo "exploración" o modificador "ascenso" se regeneraban
        # en cada frame, lo que se sentía como congelamiento y anulaba saltos/inputs.
        biome = self._current_biome_for_seed()
        spec = self._get_level_spec(width, height)
        expected_w = int(self._retro_world_span(width) * biome.width_mult * (1.04 if spec.get("rhythm") == "exploración" else 1.0))
        expected_h = int(self._retro_world_vertical(height) * biome.height_mult * (1.10 if spec.get("modifier") == "ascent" else 1.0) * 1.16)
        # La clave incluye el modo para que volver a Clásico nunca reutilice una sala
        # compacta de Arena/Desafío ni una generación previa de otro modo.
        if self.selected_mode == "arena":
            expected_w = max(2200, int(width * 2.35))
            expected_h = max(height + 260, 780)
        elif self.selected_mode == "challenge":
            expected_w = max(1700, int(expected_w * 0.26))
            expected_h = max(height + 220, int(expected_h * 0.72))
        elif self._is_tutorial_guided():
            # Debe coincidir EXACTAMENTE con _retro_generate_level(). En V7 estaba
            # en 4300/4.6 mientras la generación real usaba 5600/5.8, por eso
            # _ensure_retro_world regeneraba el tutorial cada frame y parecía congelado.
            expected_w = max(5600, int(width * 5.8))
            expected_h = max(920, height + 360)
        elif self._campaign_is_arena_stage():
            expected_w = max(2100, int(width * 2.2))
            expected_h = max(height + 260, 760)
        size_key = (width, height, expected_w, expected_h, self.retro_seed, self.selected_mode)
        if self.retro_world_size != size_key:
            self._reset_retro_world(width, height)

    def _checkpoint_spawn_point(self) -> tuple[float, float]:
        player = self.retro_player
        ground = self._retro_ground_y()
        if 0 <= self.active_checkpoint_index < len(self.retro_checkpoints):
            checkpoint = self.retro_checkpoints[self.active_checkpoint_index]
            return (
                max(94.0, min(self.retro_world_width - player.w - 8.0, checkpoint.x - player.w * 0.5)),
                max(8.0, min(float(ground - player.h), checkpoint.y - player.h)),
            )
        return 94.0, float(ground - player.h)

    def _respawn_player_at_checkpoint(self) -> None:
        player = self.retro_player
        player.h = player.base_h
        player.crouching = False
        player.x, player.y = self._checkpoint_spawn_point()
        player.vx = 0.0
        player.vy = 0.0
        player.on_ground = True
        player.jumps_used = 0
        player.wall_side = 0
        player.dash_timer = 0.0
        player.dash_cooldown = 0.0
        player.attack_timer = 0.0
        player.shoot_cooldown = 0.0
        player.flight_left = self._flight_max_duration()
        player.flight_cooldown = 0.0
        self._reset_hard_spike_wall_behind_player()
        if self.selected_mode == "challenge":
            self._place_challenge_boss_opposite_player()
            self.challenge_safe_timer = max(getattr(self, "challenge_safe_timer", 0.0), CHALLENGE_SAFE_INTRO)
            self.shadow_damage_cooldown = max(getattr(self, "shadow_damage_cooldown", 0.0), CHALLENGE_SAFE_INTRO)
            self.shadow_chaser_history.clear()
            self.shadow_action_cursors.clear()
        self.retro_projectiles = [p for p in self.retro_projectiles if p.owner in {"enemy"}]

    def _retro_respawn(self, width: int, height: int, damage: int = 1) -> None:
        player = self.retro_player
        self._damage_player(damage, player.x, allow_if_hurt=True)
        self._respawn_player_at_checkpoint()
        player.hurt_timer = 0.7
        self._retro_update_camera(width, height, instant=True)

    def _retro_touching_wall(self, player: RetroPlayer, obstacles: list[RetroRect]) -> int:
        eps = 4.0
        if player.x <= 8.0 + eps:
            return -1
        if player.x + player.w >= self.retro_world_width - 8.0 - eps:
            return 1
        for rect in obstacles:
            vertical_overlap = player.y + player.h > rect.y + 3 and player.y < rect.y + rect.h - 3
            if not vertical_overlap:
                continue
            if abs((player.x + player.w) - rect.x) <= eps:
                return 1
            if abs(player.x - (rect.x + rect.w)) <= eps:
                return -1
        return 0

    def _retro_update_camera(self, viewport_width: int, viewport_height: int, *, instant: bool = False) -> None:
        player = self.retro_player
        limit_x = max(0.0, float(self.retro_world_width - viewport_width))
        limit_y = max(0.0, float(self.retro_world_height - viewport_height))
        focus_x = player.x + player.w * 0.5
        focus_y = player.y + player.h * 0.5
        if self.selected_mode == "arena" and (self.arena_player_respawn_timer > 0.0 or player.x < -1000):
            alive = [bot for bot in self.arena_bots if bot.alive]
            if alive:
                leader = max(alive, key=lambda b: self.arena_scores.get(b.index, 0))
                focus_x = leader.player.x + leader.player.w * 0.5
                focus_y = leader.player.y + leader.player.h * 0.5
            else:
                focus_x = self.retro_world_width * 0.5
                focus_y = self._retro_ground_y() - 120.0
        desired_x = focus_x - (viewport_width * (0.50 if self.selected_mode == "arena" else 0.40))
        desired_y = focus_y - viewport_height * 0.54
        desired_x = max(0.0, min(limit_x, desired_x))
        desired_y = max(0.0, min(limit_y, desired_y))
        if instant:
            self.retro_camera_x = desired_x
            self.retro_camera_y = desired_y
        else:
            cam_lerp_x = 0.30 if self.selected_mode == "arena" else 0.18
            cam_lerp_y = 0.24 if self.selected_mode == "arena" else 0.16
            self.retro_camera_x += (desired_x - self.retro_camera_x) * cam_lerp_x
            self.retro_camera_y += (desired_y - self.retro_camera_y) * cam_lerp_y

    def _reset_hard_spike_wall_behind_player(self) -> None:
        if self.selected_mode != "race_hard_disabled" and not self._campaign_has_spike_wall():
            return
        player = self.retro_player
        self.hard_spike_wall_x = max(-760.0, player.x - 760.0)

    def _update_hard_spike_wall(self, dt: float, viewport_width: int, viewport_height: int) -> None:
        if not self._campaign_has_spike_wall():
            return
        player = self.retro_player
        # Avanza a 1/3 de la velocidad normal al caminar, y si el jugador se aleja
        # demasiado, se mantiene detrás sin teletransportarse encima.
        target_far_back = player.x - 900.0
        next_x = max(self.hard_spike_wall_x + HARD_CHASER_SPEED * dt, min(self.hard_spike_wall_x + HARD_CHASER_SPEED * dt, target_far_back))
        if self.boss_room_stop_x > 0.0:
            next_x = min(next_x, self.boss_room_stop_x)
        self.hard_spike_wall_x = next_x
        if player.x < self.hard_spike_wall_x + self.hard_spike_wall_width:
            self._retro_respawn(viewport_width, viewport_height, damage=3)

    def _retro_key_pressed(self, *names: str) -> bool:
        return any(name in self.pressed_keys for name in names)

    def _primary_pressed(self) -> bool:
        return self._retro_key_pressed("x", "X")

    def _secondary_pressed(self) -> bool:
        return self._retro_key_pressed("z", "Z")

    def _dash_pressed(self) -> bool:
        return self._retro_key_pressed("space", "Return", "KP_Enter")

    def _mouse_world_pos(self, event: tk.Event) -> tuple[float, float]:
        return float(event.x + self.retro_camera_x), float(event.y + self.retro_camera_y)

    def _try_start_box_drag(self, event: tk.Event) -> bool:
        if self.game_state != "playing" or not self._ability_owned("telekinesis"):
            return False
        wx, wy = self._mouse_world_pos(event)
        for idx in range(len(self.retro_boxes) - 1, -1, -1):
            box = self.retro_boxes[idx]
            if box.x <= wx <= box.x + box.w and box.y <= wy <= box.y + box.h:
                self.dragged_box_index = idx
                self._last_mouse_world = (wx, wy)
                box.grabbed = True
                self.telekinesis_grab_started = time.perf_counter()
                box.vx = 0.0
                box.vy = 0.0
                self.canvas.focus_set()
                return True
        return False

    def _on_canvas_drag(self, event: tk.Event) -> None:
        if self.game_state != "playing" or self.dragged_box_index is None:
            return
        if not (0 <= self.dragged_box_index < len(self.retro_boxes)):
            self.dragged_box_index = None
            return
        if self.telekinesis_grab_started and time.perf_counter() - self.telekinesis_grab_started > self._telekinesis_grab_duration():
            self._on_canvas_release(event)
            return
        wx, wy = self._mouse_world_pos(event)
        last_x, last_y = self._last_mouse_world or (wx, wy)
        dx = wx - last_x
        dy = wy - last_y
        box = self.retro_boxes[self.dragged_box_index]
        box.x = max(8.0, min(self.retro_world_width - box.w - 8.0, box.x + dx))
        box.y = max(8.0, min(self.retro_world_height - box.h - 8.0, box.y + dy))
        box.vx = dx * 12.0
        box.vy = dy * 12.0
        self._push_enemies_with_box(box, dx, dy)
        self._last_mouse_world = (wx, wy)
        self._draw()

    def _on_canvas_release(self, _event: tk.Event) -> None:
        if self.dragged_box_index is not None and 0 <= self.dragged_box_index < len(self.retro_boxes):
            self.retro_boxes[self.dragged_box_index].grabbed = False
        self.dragged_box_index = None
        self._last_mouse_world = None
        self.telekinesis_grab_started = 0.0

    def _push_enemies_with_box(self, box: RetroBox, dx: float, dy: float = 0.0) -> None:
        if abs(dx) < 0.01 and abs(dy) < 0.01:
            return
        for enemy in self.retro_enemies:
            if not enemy.alive:
                continue
            if not self._retro_intersects(box.x, box.y, box.w, box.h, enemy):
                continue
            if enemy.hurt_flash <= 0:
                self._retro_damage_enemy(enemy, 1 + self._ability_attack_bonus("telekinesis"), 0, ability="telekinesis")
                if not enemy.alive:
                    continue
            if abs(dx) >= abs(dy):
                push = dx if abs(dx) > 0.5 else (1.0 if box.x + box.w * 0.5 < enemy.x + enemy.w * 0.5 else -1.0)
                enemy.x += max(-18.0, min(18.0, push * 1.25))
            else:
                enemy.y += max(-12.0, min(12.0, dy * 0.65))
            enemy.x = max(enemy.patrol_left, min(enemy.patrol_right - enemy.w, enemy.x))
            enemy.y = max(24.0, min(float(self._retro_ground_y() - enemy.h), enemy.y))

    def _on_canvas_click(self, event: tk.Event) -> None:
        x0, y0, x1, y1 = self._color_button_bbox
        if x0 <= event.x <= x1 and y0 <= event.y <= y1:
            self._cycle_palette()
            return
        if self.game_state == "select":
            mx0, my0, mx1, my1 = self._music_button_bbox
            if mx0 <= event.x <= mx1 and my0 <= event.y <= my1:
                self.game_state = "music"
                self.music_target = "main"
                self._set_music_context("main")
                self._draw()
                return
            for ax0, ay0, ax1, ay1 in self.achievement_buttons.values():
                if ax0 <= event.x <= ax1 and ay0 <= event.y <= ay1:
                    self.game_state = "achievements"
                    self._draw()
                    return
            for mx0, my0, mx1, my1, mode in self.mode_buttons:
                if mx0 <= event.x <= mx1 and my0 <= event.y <= my1:
                    if mode == "category_tutorial":
                        self.selected_mode = self._mode_for_family_and_light("tutorial", self._is_mode_night())
                    elif mode == "category_campaign":
                        wants_night = self._is_mode_night() and self._day_campaign_completed()
                        self.selected_mode = self._mode_for_family_and_light("campaign", wants_night)
                    else:
                        if mode == "campaign_night" and not self._day_campaign_completed():
                            self.status_notice_text = "Completa campaña de día para desbloquear noche"
                            self.status_notice_timer = 2.5
                            self._draw()
                            return
                        self.selected_mode = mode
                    self._apply_palette_to_window()
                    self._draw()
                    return
            for bx0, by0, bx1, by1, delay in self.race_shadow_buttons:
                if bx0 <= event.x <= bx1 and by0 <= event.y <= by1:
                    self._toggle_race_shadow_delay(delay)
                    self._draw()
                    return
            for cx0, cy0, cx1, cy1, spec in self.character_cards:
                if cx0 <= event.x <= cx1 and cy0 <= event.y <= cy1:
                    if self.selected_mode == "campaign_night" and not self._day_campaign_completed():
                        self.status_notice_text = "Campaña noche bloqueada"
                        self.status_notice_timer = 2.5
                        self._draw()
                        return
                    if self._is_campaign_mode() and self._has_saved_progress(self.selected_mode):
                        self._pending_start_spec = spec
                        self.game_state = "start_choice"
                        self._draw()
                    else:
                        self._select_character(spec, continue_saved=True)
                    return
        elif self.game_state == "music":
            for action, (bx0, by0, bx1, by1) in self.music_buttons.items():
                if bx0 <= event.x <= bx1 and by0 <= event.y <= by1:
                    if action == "back":
                        self.game_state = "select"
                        self._apply_palette_to_window()
                    elif action == "add":
                        self._add_music_track()
                    elif action.startswith("target_"):
                        self.music_target = action.removeprefix("target_")
                    elif action.startswith("remove_"):
                        payload = action.removeprefix("remove_")
                        target, idx = payload.rsplit("_", 1)
                        self._remove_music_track(target, int(idx))
                    self.canvas.focus_set()
                    self._draw()
                    return
        elif self.game_state == "achievements":
            for action, (bx0, by0, bx1, by1) in self.achievement_buttons.items():
                if bx0 <= event.x <= bx1 and by0 <= event.y <= by1:
                    self.game_state = "select"
                    self._apply_palette_to_window()
                    self._draw()
                    return
        elif self.game_state == "start_choice":
            for action, (bx0, by0, bx1, by1) in self.start_choice_buttons.items():
                if bx0 <= event.x <= bx1 and by0 <= event.y <= by1:
                    if action == "back":
                        self.game_state = "select"
                    else:
                        spec = self._pending_start_spec or CHARACTERS[0]
                        self._pending_start_spec = None
                        self._select_character(spec, continue_saved=(action == "continue"))
                    self._draw()
                    return
        elif self.game_state == "playing":
            px0, py0, px1, py1 = self._pause_button_bbox
            if px0 <= event.x <= px1 and py0 <= event.y <= py1:
                self._toggle_pause()
                return
            if self._try_time_space_teleport(event):
                return
            if self._try_start_box_drag(event):
                return
        elif self.game_state == "paused":
            for action, (bx0, by0, bx1, by1) in self.pause_buttons.items():
                if bx0 <= event.x <= bx1 and by0 <= event.y <= by1:
                    if action == "resume":
                        self._toggle_pause()
                    elif action == "menu":
                        self._return_to_menu()
                    elif action == "page_prev":
                        self.pause_page = max(0, self.pause_page - 1)
                    elif action == "page_next":
                        max_page = max(0, (len(("gun", *ABILITY_ORDER)) - 1) // 8)
                        self.pause_page = min(max_page, self.pause_page + 1)
                    elif action.startswith("buy_"):
                        self._buy_ability(action.removeprefix("buy_"))
                    elif action.startswith("upnode_"):
                        self._buy_upgrade(action.removeprefix("upnode_"))
                    elif action.startswith("upgrade_"):
                        self._buy_upgrade(action.removeprefix("upgrade_"))
                    elif action.startswith("slot_"):
                        _, digit, ability = action.split("_", 2)
                        self._assign_quick_slot(digit, ability)
                    elif action.startswith("setz_"):
                        ability = action.removeprefix("setz_")
                        if ability != "none" and self._is_passive_auto_ability(ability):
                            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
                        elif ability == "none" or self._ability_owned(ability):
                            self.active_secondary_slot = ability
                    self.canvas.focus_set()
                    self._draw()
                    return
        self.canvas.focus_set()

    def _toggle_race_shadow_delay(self, delay: float) -> None:
        delay = float(delay)
        if delay in self.race_shadow_delays:
            if len(self.race_shadow_delays) <= 1:
                self.retro_effects.append(RetroEffect(self.retro_player.x + 10.0, self.retro_player.y, 18.0, 0.35, "locked"))
                return
            self.race_shadow_delays = [d for d in self.race_shadow_delays if d != delay]
        else:
            self.race_shadow_delays.append(delay)
        self.race_shadow_delays = [d for d in SHADOW_DELAY_PRESETS if d in set(self.race_shadow_delays)]

    def _toggle_pause(self) -> None:
        if self.game_state == "playing":
            self.game_state = "paused"
            self.pressed_keys.clear()
        elif self.game_state == "paused":
            self.game_state = "playing"
        self._apply_palette_to_window()
        self._draw()

    def _return_to_menu(self) -> None:
        self._save_mode_progress()
        self.pressed_keys.clear()
        self.game_state = "select"
        self._set_music_context("main")
        self._apply_palette_to_window()
        self._draw()

    def _buy_ability(self, ability: str) -> None:
        if ability not in ABILITY_ORDER or self._ability_owned(ability):
            return
        cost = int(ABILITY_INFO[ability].get("cost", 0))
        if self.xp_count < cost:
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 16, 18.0, 0.45, "no_xp"))
            return
        self.xp_count -= cost
        self.owned_abilities[ability] = True
        if self.active_secondary_slot == "none" and not self._is_passive_auto_ability(ability):
            self.active_secondary_slot = ability
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y, 24.0, 0.55, "upgrade1"))
        self._save_mode_progress()
        self._draw()

    def _buy_upgrade(self, kind: str) -> None:
        player = self.retro_player
        if kind == "life":
            if self.xp_count < UPGRADE_COST:
                self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y - 16, 18.0, 0.45, "no_xp"))
                return
            self.xp_count -= UPGRADE_COST
            self.hp_upgrade += 1
            player.max_hp += 5
            player.hp = min(player.max_hp, player.hp + 5)
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y, 28.0, 0.65, "heal"))
            self._save_mode_progress()
            self._draw()
            return

        ability, node_id = (kind.split("|", 1) + [""])[:2] if "|" in kind else (kind, "")
        if ability not in ("gun", *ABILITY_ORDER) or not self._ability_owned(ability):
            return
        if not bool(ABILITY_INFO.get(ability, {}).get("upgradeable", False)):
            return
        if not node_id:
            node = self._next_upgrade_node(ability)
        else:
            node = next((n for n in self._iter_tree_nodes(ability) if str(n.get("id", "")) == node_id), None)
        if node is None or not self._node_available(ability, node):
            return
        cost = int(node.get("cost", UPGRADE_COST))
        if self.xp_count < cost:
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y - 16, 18.0, 0.45, "no_xp"))
            return
        self.xp_count -= cost
        self._tree_nodes(ability).add(str(node.get("id", "")))
        self._sync_ability_level_from_tree(ability)
        self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y, 24.0, 0.55, "upgrade1"))
        self._save_mode_progress()
        self._draw()

    def _select_ability_by_number(self, key: str) -> None:
        digit = key.replace("KP_", "")
        if digit not in {"1", "2", "3"}:
            return
        self._ensure_quick_slots()
        ability = self.quick_slots.get(digit, "none")
        if ability == "none" or self._is_passive_auto_ability(ability):
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
        elif self._ability_owned(ability):
            self.active_secondary_slot = ability
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "select"))
        else:
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
        self._draw()

    def _use_heal_tank(self) -> None:
        player = self.retro_player
        if self.heal_tanks <= 0 or player.hp >= player.max_hp:
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y - 14, 18.0, 0.35, "no_heal"))
            return
        self.heal_tanks -= 1
        player.hp = min(player.max_hp, player.hp + 5)
        self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y, 28.0, 0.55, "heal"))
        self._draw()

    def _on_key_press(self, event: tk.Event) -> None:
        key = getattr(event, "keysym", "")
        if not key:
            return
        self.pressed_keys.add(key)
        if self.game_state == "select":
            modes = ["tutorial", "tutorial_night", "campaign_day"]
            if self._day_campaign_completed():
                modes.append("campaign_night")
            if key in {"t", "T", "Tab"}:
                current = self.selected_mode if self.selected_mode in modes else modes[0]
                self.selected_mode = modes[(modes.index(current) + 1) % len(modes)]
                self._draw()
                return
            if key in {"f", "F"}:
                self.friendly_fire = not self.friendly_fire
                self._draw()
                return
            if key in {"1", "KP_1", "2", "KP_2", "3", "KP_3", "4", "KP_4"} and self.selected_mode == "race":
                digit = key.replace("KP_", "")
                mapping = {"1": 4.0, "2": 3.0, "3": 2.0, "4": 1.0}
                self._toggle_race_shadow_delay(mapping.get(digit, 4.0))
                self._draw()
                return
            if key in {"m", "M"}:
                self.arena_vs_cpu = not self.arena_vs_cpu
                self._draw()
                return
            if key in {"u", "U"}:
                self.game_state = "music"
                self.music_target = "main"
                self._draw()
                return
            if key in {"Return", "KP_Enter", "space"}:
                if self.selected_mode == "campaign_night" and not self._day_campaign_completed():
                    self.status_notice_text = "Campaña noche bloqueada"
                    self.status_notice_timer = 2.5
                    self._draw()
                    return
                if self._is_campaign_mode() and self._has_saved_progress(self.selected_mode):
                    self._pending_start_spec = CHARACTERS[0]
                    self.game_state = "start_choice"
                    self._draw()
                else:
                    self._select_character(CHARACTERS[0], continue_saved=True)
                return
            return
        if self.game_state == "music":
            if key in {"Escape", "m", "M"}:
                self.game_state = "select"
                self._apply_palette_to_window()
                self._draw()
            return
        if self.game_state == "achievements":
            if key in {"Escape", "m", "M", "Return", "KP_Enter", "space"}:
                self.game_state = "select"
                self._apply_palette_to_window()
                self._draw()
            return
        if self.game_state == "start_choice":
            if key in {"Escape"}:
                self.game_state = "select"
                self._draw()
            elif key in {"Return", "KP_Enter", "space", "c", "C"}:
                self._select_character(self._pending_start_spec or CHARACTERS[0], continue_saved=True)
            elif key in {"n", "N"}:
                self._select_character(self._pending_start_spec or CHARACTERS[0], continue_saved=False)
            return
        if self.game_state == "paused":
            if key in {"Escape"}:
                self._toggle_pause()
            elif key in {"m", "M"}:
                self._return_to_menu()
            return
        if key in {"0", "KP_0"}:
            self._use_heal_tank()
            return
        if key in {"v", "V"}:
            if self._ability_owned("telekinesis"):
                self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "select"))
            return
        if key in {"c", "C"}:
            if self._ability_owned("flight"):
                self.active_secondary_slot = "flight"
            return
        if key in {"b", "B"}:
            if self._ability_owned("shield"):
                self._activate_shield()
            return
        if key in {"f", "F"}:
            self._toggle_flashlight()
            return
        if key in {"1", "KP_1", "2", "KP_2", "3", "KP_3"}:
            self._select_ability_by_number(key)
            return
        if key in {"Escape"}:
            self._toggle_pause()
            return
        if key in {"n", "N"}:
            if self._ability_owned("n_resurrection"):
                self.active_secondary_slot = "n_resurrection"
                self._activate_n_resurrection()
                return
            self.retro_seed = random.SystemRandom().randrange(1, 2_147_483_647)
            self.current_biome = self._current_biome_for_seed()
            self.level_intro_timer = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 7.0
            self._reset_retro_world(max(360, self.canvas.winfo_width()), max(220, self.canvas.winfo_height()), keep_player_ratio=False)
            self._apply_palette_to_window()
            return
        if (key in {"Up"}) or (self.selected_mode != "multiplayer" and key in {"w", "W"}):
            if not self._last_jump_pressed:
                self._retro_jump()
            self._last_jump_pressed = True
        elif key in {"space", "Return", "KP_Enter"}:
            if not self._last_dash_pressed:
                self._retro_dash()
            self._last_dash_pressed = True
        elif key in {"x", "X"}:
            if not self._last_primary_pressed:
                self._handle_primary_press()
            self._last_primary_pressed = True
        elif key in {"z", "Z"}:
            if not self._last_secondary_pressed:
                self._handle_secondary_press()
            self._last_secondary_pressed = True
        elif self.p2_enabled and not self.p2_is_cpu and key in {"i", "I"}:
            if not self._p2_last_jump_pressed:
                self._p2_jump()
            self._p2_last_jump_pressed = True
        elif self.p2_enabled and not self.p2_is_cpu and key in {"k", "K"}:
            if not self._p2_last_dash_pressed:
                self._p2_dash()
            self._p2_last_dash_pressed = True
        elif self.p2_enabled and not self.p2_is_cpu and key in {"u", "U"}:
            if not self._p2_last_primary_pressed:
                self._p2_shoot()
            self._p2_last_primary_pressed = True
        elif self.p2_enabled and not self.p2_is_cpu and key in {"o", "O"}:
            if not self._p2_last_secondary_pressed:
                self._p2_sword()
            self._p2_last_secondary_pressed = True

    def _on_key_release(self, event: tk.Event) -> None:
        key = getattr(event, "keysym", "")
        if not key:
            return
        self.pressed_keys.discard(key)
        if key in {"Up", "w", "W"}:
            self._last_jump_pressed = self._retro_key_pressed("Up") if self.selected_mode == "multiplayer" else self._retro_key_pressed("Up", "w", "W")
        elif key in {"space", "Return", "KP_Enter"}:
            self._last_dash_pressed = self._dash_pressed()
        elif key in {"x", "X"}:
            if self._x_charge_active:
                self._retro_release_charge()
            self._last_primary_pressed = self._primary_pressed()
        elif key in {"z", "Z"}:
            if self._z_sword_charge_active:
                held = max(0.0, time.perf_counter() - self._z_sword_charge_started)
                self._z_sword_charge_active = False
                self._z_sword_charge_started = 0.0
                if held >= 2.0 and self._ability_owned("sword") and self._has_weapon_special("sword", "boomerang"):
                    self._retro_shoot_boomerang("sword")
                    self._record_shadow_action("boomerang")
                    self._clone_attack("boomerang")
            self._last_secondary_pressed = self._secondary_pressed()
        elif key in {"i", "I"}:
            self._p2_last_jump_pressed = self._retro_key_pressed("i", "I")
        elif key in {"k", "K"}:
            self._p2_last_dash_pressed = self._retro_key_pressed("k", "K")
        elif key in {"u", "U"}:
            self._p2_last_primary_pressed = self._retro_key_pressed("u", "U")
        elif key in {"o", "O"}:
            self._p2_last_secondary_pressed = self._retro_key_pressed("o", "O")

    def _on_focus_out(self, _event: tk.Event) -> None:
        self.pressed_keys.clear()
        self._last_jump_pressed = False
        self._last_dash_pressed = False
        self._last_primary_pressed = False
        self._last_secondary_pressed = False
        self._p2_last_jump_pressed = False
        self._p2_last_dash_pressed = False
        self._p2_last_primary_pressed = False
        self._p2_last_secondary_pressed = False
        if self._x_charge_active:
            self._retro_release_charge()
        self._z_sword_charge_active = False
        self._z_sword_charge_started = 0.0

    def _handle_primary_press(self) -> None:
        # X siempre dispara al pulsar, aunque también deja cargando para un tiro potente al soltar.
        # Así el arma inicial responde de inmediato y no depende del menú ni de números.
        self._retro_shoot_charged(0)
        self._record_shadow_action("gun", level=0)
        self._clone_attack("gun", charge_level=0)
        if not self._x_charge_active:
            self._x_charge_active = True
            self._x_charge_started = time.perf_counter()

    def _handle_secondary_press(self) -> None:
        ability = self.active_secondary_slot
        self._activate_ability(ability, source="secondary")
        if ability != "none" and self._ability_owned(ability) and ability not in {"shield", "time_space"}:
            self._record_shadow_action(ability if ability in {"sword", "flight", "parry", "nova", "triple_jump", "telekinesis"} else "gun", ability=ability)

    def _activate_ability(self, ability: str, *, source: str) -> None:
        if ability == "none":
            return
        if not self._ability_owned(ability):
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "locked"))
            return
        self._weapon_attack_fx(ability, scale=1.0)
        if ability == "gun":
            # X se gestiona en _handle_primary_press para que dispare al instante.
            # Si la pistola se invoca como secundaria/eco, dispara un tiro simple.
            if source != "primary":
                self._retro_shoot_charged(0)
                self._clone_attack("gun", charge_level=0)
        elif ability == "sword":
            if source == "secondary" and self._has_weapon_special("sword", "boomerang") and not self._z_sword_charge_active:
                self._z_sword_charge_active = True
                self._z_sword_charge_started = time.perf_counter()
            self._retro_sword()
            self._clone_attack("sword")
        elif ability == "flight":
            self._try_open_secret_gates("flight")
        elif ability == "shield":
            self._activate_shield()
        elif ability == "time_space":
            self._activate_slow_time()
        elif ability == "n_resurrection":
            self._activate_n_resurrection()
        elif ability in PASSIVE_AUTO_ABILITIES:
            # Pasivas: no se activan con Z ni ocupan slots. Funcionan automáticamente al estar desbloqueadas.
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "select"))
        else:
            self._activate_expanded_ability(ability)
            self._clone_attack(ability)

    def _weapon_attack_fx(self, ability: str, *, scale: float = 1.0) -> None:
        # Animaciones de ataque comunes: cada arma genera un flash duotono distinto
        # usando RetroEffect; _draw_pickups_and_effects convierte el kind en texto/ondas.
        player = self.retro_player
        direction = 1 if player.facing >= 0 else -1
        cx = player.x + player.w * 0.5 + direction * 24.0
        cy = player.y + player.h * 0.48
        radius = max(14.0, 22.0 * scale + self._ability_range_bonus(ability) * 4.0)
        fx_kind = f"atk_{ability}"
        self.retro_effects.append(RetroEffect(cx, cy, radius, 0.22 + min(0.18, scale * 0.05), fx_kind))
        # Armas grandes reciben un segundo eco para que el ataque sea más legible.
        if ability in {"rail_shot", "laser_beam", "meteor_call", "plasma_burst", "pulse_wave", "sonic_dash", "chain_lightning"}:
            self.retro_effects.append(RetroEffect(cx + direction * 34.0, cy, radius * 1.45, 0.28, f"atk2_{ability}"))

    def _ability_projectile_damage(self, ability: str, base: int = 2) -> int:
        return max(1, base + self._ability_attack_bonus(ability))

    def _ability_projectile_range(self, ability: str, base_tiles: float = 2.4) -> float:
        return TILE * (base_tiles + self._ability_range_bonus(ability) * 0.85)

    def _enemy_center(self, enemy: RetroEnemy) -> tuple[float, float]:
        return enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.5

    @staticmethod
    def _enemy_is_ally(enemy: RetroEnemy) -> bool:
        return str(getattr(enemy, "elite_mod", "")).startswith("ally")

    def _revived_allies(self) -> list[RetroEnemy]:
        return [e for e in self.retro_enemies if e.alive and self._enemy_is_ally(e)]

    def _resurrection_limit(self) -> int:
        return max(1, min(5, 1 + int(round(self._tree_effect_sum("n_resurrection", "revive_slots")))))

    def _resurrection_hp_mult(self) -> float:
        return 1.0 + max(0.0, self._tree_effect_sum("n_resurrection", "revive_hp_mult"))

    def _resurrection_attack_mult(self) -> float:
        return 1.0 + max(0.0, self._tree_effect_sum("n_resurrection", "revive_attack_mult"))

    def _remember_resurrection_blueprint(self, enemy: RetroEnemy) -> None:
        if self._enemy_is_ally(enemy) or enemy.kind.startswith("boss") or enemy.kind not in ENEMY_STATS:
            return
        self._last_resurrection_blueprint = {
            "kind": enemy.kind,
            "max_hp": float(max(1.0, enemy.max_hp)),
            "attack": float(max(0.1, enemy.attack)),
        }

    def _find_nearest_enemy(self, x: float, y: float, max_dist: float = 520.0) -> RetroEnemy | None:
        candidates = [e for e in self.retro_enemies if e.alive and not self._enemy_is_ally(e) and math.hypot((e.x + e.w * 0.5) - x, (e.y + e.h * 0.5) - y) <= max_dist]
        if not candidates:
            return None
        return min(candidates, key=lambda e: math.hypot((e.x + e.w * 0.5) - x, (e.y + e.h * 0.5) - y))

    def _find_nearest_projectile_target(self, x: float, y: float, max_dist: float = 620.0) -> tuple[float, float] | None:
        candidates: list[tuple[float, float, float]] = []
        for enemy in self.retro_enemies:
            if enemy.alive and not self._enemy_is_ally(enemy):
                ex, ey = self._enemy_center(enemy)
                dist = math.hypot(ex - x, ey - y)
                if dist <= max_dist:
                    candidates.append((dist, ex, ey))
        if self.selected_mode == "arena":
            for bot in self.arena_bots:
                if bot.alive:
                    bx, by = self._arena_bot_center(bot)
                    dist = math.hypot(bx - x, by - y)
                    if dist <= max_dist:
                        candidates.append((dist, bx, by))
        if not candidates:
            return None
        _dist, tx, ty = min(candidates, key=lambda item: item[0])
        return tx, ty

    def _damage_area(self, x: float, y: float, radius: float, damage: int, ability: str, *, push: float = 0.0, status: str = "") -> int:
        hits = 0
        for enemy in self.retro_enemies:
            if not enemy.alive or self._enemy_is_ally(enemy):
                continue
            ex, ey = self._enemy_center(enemy)
            dist = math.hypot(ex - x, ey - y)
            if dist > radius:
                continue
            hits += 1
            direction = 1 if ex >= x else -1
            self._retro_damage_enemy(enemy, damage, direction, ability=ability)
            if push:
                enemy.x += direction * push * max(0.2, 1.0 - dist / max(1.0, radius))
            if status:
                self._apply_status(enemy, status, 2.0 + self._ability_range_bonus(ability) * 0.5)
        shadow_hits = self._damage_shadow_area(x, y, radius, damage, ability)
        hits += shadow_hits
        if self.selected_mode == "arena":
            hits += self._damage_arena_bots_area(x, y, radius, damage, attacker_team=self.arena_player_team, ability=ability)
        if hits:
            self.retro_effects.append(RetroEffect(x, y, radius, 0.42, ability))
        return hits

    def _apply_status(self, enemy: RetroEnemy, status: str, duration: float) -> None:
        if enemy.status_effects is None:
            enemy.status_effects = {}
        enemy.status_effects[status] = max(duration, enemy.status_effects.get(status, 0.0))

    def _activate_n_resurrection(self) -> None:
        player = self.retro_player
        if player.shoot_cooldown > 0:
            return
        blueprint = self._last_resurrection_blueprint if isinstance(getattr(self, "_last_resurrection_blueprint", None), dict) else None
        if not blueprint:
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y - 18, 20.0, 0.45, "locked"))
            return
        if len(self._revived_allies()) >= self._resurrection_limit():
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y - 18, 20.0, 0.45, "locked"))
            return
        kind = str(blueprint.get("kind", "minor"))
        if kind not in ENEMY_STATS or kind.startswith("boss"):
            kind = "minor"
        ew, eh, base_hp, base_attack, base_speed = ENEMY_STATS[kind]
        hp_seed = float(blueprint.get("max_hp", base_hp))
        atk_seed = float(blueprint.get("attack", base_attack))
        hp = max(1, int(math.ceil(hp_seed * self._resurrection_hp_mult())))
        attack = max(0.1, round(atk_seed * self._resurrection_attack_mult(), 2))
        direction = 1 if player.facing >= 0 else -1
        sx = max(34.0, min(self.retro_world_width - ew - 34.0, player.x - direction * (ew + 28.0)))
        sy = max(60.0, min(float(self._retro_ground_y() - eh), player.y + player.h - eh))
        patrol = 260.0
        ally = RetroEnemy(
            sx, sy, ew, eh, direction * max(28.0, base_speed), kind, hp, hp, attack,
            max(24.0, sx - patrol), min(float(self.retro_world_width - 24.0), sx + patrol),
            phase=random.random() * 2.0, home_y=sy, shoot_timer=0.15, pattern_timer=0.0,
            status_effects={}, armor=0.35 if kind in {"major", "shield", "mirror", "elite", "hunter"} else 0.0,
            elite_mod=f"ally:{kind}",
        )
        self.retro_enemies.append(ally)
        self.retro_effects.append(RetroEffect(sx + ew * 0.5, sy + eh * 0.5, 52.0, 0.75, "resurrection"))
        player.shoot_cooldown = 1.05 * self._ability_speed_mult("n_resurrection")
        self._save_mode_progress()

    def _activate_expanded_ability(self, ability: str) -> None:
        player = self.retro_player
        if player.shoot_cooldown > 0 and ability not in {"sonic_dash", "blink_strike", "quantum_swap"}:
            return
        direction = 1 if player.facing >= 0 else -1
        cx = player.x + player.w * 0.5
        cy = player.y + player.h * 0.5
        dmg = self._ability_projectile_damage(ability, 2)
        rng_px = self._ability_projectile_range(ability, 2.6)
        self._weapon_attack_fx(ability, scale=1.05)

        if ability == "chain_lightning":
            first = self._find_nearest_enemy(cx, cy, rng_px)
            if first:
                current = first
                already: set[int] = set()
                for _ in range(3 + self._ability_range_bonus(ability)):
                    if current is None or id(current) in already:
                        break
                    already.add(id(current))
                    ex, ey = self._enemy_center(current)
                    self._retro_damage_enemy(current, dmg, direction, ability=ability)
                    self.retro_effects.append(RetroEffect(ex, ey, 28.0, 0.32, "lightning"))
                    nearby = [e for e in self.retro_enemies if e.alive and id(e) not in already and math.hypot((e.x+e.w*.5)-ex, (e.y+e.h*.5)-ey) < TILE * 2.2]
                    current = min(nearby, key=lambda e: math.hypot((e.x+e.w*.5)-ex, (e.y+e.h*.5)-ey)) if nearby else None
            player.shoot_cooldown = 0.62 * self._ability_speed_mult(ability)
        elif ability == "pulse_wave":
            self._damage_area(cx, cy, TILE * (1.1 + self._ability_range_bonus(ability) * 0.55), dmg, ability, push=58.0, status="stun")
            for proj in self.retro_projectiles:
                if proj.owner == "enemy" and math.hypot(proj.x - cx, proj.y - cy) < TILE * 1.4:
                    proj.vx *= -1.0; proj.vy *= -1.0; proj.owner = "player"; proj.kind = "reflected"
            player.shoot_cooldown = 0.75 * self._ability_speed_mult(ability)
        elif ability == "shadow_clone":
            self._activate_clone(5.0 + self._ability_range_bonus(ability))
            player.shoot_cooldown = 0.9 * self._ability_speed_mult(ability)
        elif ability == "meteor_call":
            for i in range(3 + self._ability_range_bonus(ability)):
                tx = player.x + direction * (140 + i * 72)
                self.retro_projectiles.append(RetroProjectile(tx, max(36.0, player.y - 420.0 - i * 12), 0.0, 520.0, 2.2, dmg + 1, "meteor", 1, "player", tx, player.y - 420.0, 900.0, radius=40.0, ability=ability))
                self.retro_effects.append(RetroEffect(tx, player.y, 34.0, 0.45, "telegraph"))
            player.shoot_cooldown = 1.15 * self._ability_speed_mult(ability)
        elif ability == "thorn_trap":
            tx = cx + direction * TILE * 1.2
            ty = self._retro_ground_y() - 24.0
            self.retro_projectiles.append(RetroProjectile(tx, ty, 0.0, 0.0, 3.5, dmg, "thorn_trap", 0, "player", tx, ty, rng_px, radius=TILE * 0.85, ability=ability))
            player.shoot_cooldown = 0.70 * self._ability_speed_mult(ability)
        elif ability == "laser_beam":
            self.retro_projectiles.append(RetroProjectile(cx + direction * 30, cy, direction * 960.0, 0.0, 0.32, dmg, "laser_beam", 3, "player", cx, cy, rng_px + TILE * 2, radius=18.0, ability=ability))
            player.shoot_cooldown = 0.48 * self._ability_speed_mult(ability)
        elif ability == "blink_strike":
            target = self._find_nearest_enemy(cx + direction * 130, cy, TILE * 3.5)
            if target:
                player.x = max(8.0, min(self.retro_world_width - player.w - 8.0, target.x - direction * (player.w + 8)))
                player.y = max(8.0, min(float(self._retro_ground_y() - player.h), target.y + target.h - player.h))
                self._retro_damage_enemy(target, dmg + 2, direction, ability=ability)
                self.retro_effects.append(RetroEffect(player.x, player.y, 36.0, 0.4, "blink"))
            player.shoot_cooldown = 0.72 * self._ability_speed_mult(ability)
        elif ability == "plasma_burst":
            self._damage_area(cx, cy, TILE * (0.9 + self._ability_range_bonus(ability) * 0.45), dmg + 2, ability, push=24.0, status="shock")
            player.shoot_cooldown = 0.82 * self._ability_speed_mult(ability)
        elif ability == "orbit_blades":
            self.orbit_blades_timer = max(self.orbit_blades_timer, 5.0 + self._ability_range_bonus(ability))
            player.shoot_cooldown = 0.65 * self._ability_speed_mult(ability)
        elif ability == "sonic_dash":
            player.facing = direction
            player.vx = direction * (DASH_MAX_SPEED + 120.0)
            player.dash_timer = 0.25
            self._damage_area(cx + direction * 38, cy, TILE * 0.75, dmg + 1, ability, push=80.0, status="rupture")
            player.shoot_cooldown = 0.62 * self._ability_speed_mult(ability)
        elif ability == "frost_field":
            self._damage_area(cx, cy, TILE * (1.25 + self._ability_range_bonus(ability) * 0.6), dmg, ability, status="slow")
            player.shoot_cooldown = 0.92 * self._ability_speed_mult(ability)
        elif ability == "magnet_shield":
            self.shield_timer = max(self.shield_timer, 1.8 + self._ability_range_bonus(ability) * 0.4)
            self.parry_timer = max(self.parry_timer, 1.4)
            for proj in self.retro_projectiles:
                if proj.owner == "enemy" and math.hypot(proj.x - cx, proj.y - cy) < TILE * 1.8:
                    proj.owner = "player"; proj.kind = "reflected"; proj.vx = -proj.vx * 1.15; proj.vy = -proj.vy * 1.15
            player.shoot_cooldown = 0.75 * self._ability_speed_mult(ability)
        elif ability == "crystal_wall":
            wall_x = player.x + (player.w + 18 if direction > 0 else -34)
            self.retro_obstacles.append(RetroRect(wall_x, max(36.0, player.y - 4), 26.0, 76.0, "crystal_wall"))
            crystal_walls = [r for r in self.retro_obstacles if r.kind == "crystal_wall"]
            if len(crystal_walls) > 3:
                oldest = crystal_walls[0]
                self.retro_obstacles = [r for r in self.retro_obstacles if r is not oldest]
            self.retro_effects.append(RetroEffect(wall_x + 13, player.y + 30, 34.0, 0.55, "crystal"))
            player.shoot_cooldown = 0.85 * self._ability_speed_mult(ability)
        elif ability == "vampiric_slash":
            before = player.hp
            self._retro_apply_sword_damage_at(player.x, player.y, player.w, player.h, direction, dmg + 2, ability)
            if player.hp > before:
                self.retro_effects.append(RetroEffect(cx, cy, 24.0, 0.4, "heal"))
            player.shoot_cooldown = 0.55 * self._ability_speed_mult(ability)
        elif ability == "quantum_swap":
            if self.quantum_anchor is None:
                self.quantum_anchor = (player.x, player.y)
                self.retro_effects.append(RetroEffect(cx, cy, 30.0, 1.0, "quantum"))
            else:
                old = (player.x, player.y)
                player.x, player.y = self.quantum_anchor
                self.quantum_anchor = old
                self._damage_area(player.x + player.w * 0.5, player.y + player.h * 0.5, TILE * 0.9, dmg, ability, status="mark")
            player.shoot_cooldown = 0.55 * self._ability_speed_mult(ability)
        else:
            # Habilidades basadas en proyectil con comportamiento especial en _update_projectiles.
            kind_map = {
                "ice_lance": ("ice_lance", 760.0, 0.0, 1.1, 1, "slow"),
                "acid_orb": ("acid_orb", 260.0, -20.0, 2.4, 0, "poison"),
                "gravity_hook": ("gravity_hook", 680.0, 0.0, 0.9, 0, "pull"),
                "mine_layer": ("mine", direction * 30.0, -80.0, 6.0, 0, ""),
                "ricochet_disc": ("ricochet_disc", 560.0, -40.0, 2.5, 1, ""),
                "toxic_cloud": ("toxic_cloud", 170.0, -25.0, 3.2, 0, "poison"),
                "boomerang_plus": ("boomerang", 575.0, 0.0, 2.35, 1, "mark"),
                "rail_shot": ("rail_shot", 1080.0, 0.0, 0.72, 3, "rupture"),
                "fire_wheel": ("fire_wheel", 390.0, 0.0, 2.2, 1, "burn"),
                "seeker_missile": ("seeker_missile", 340.0, -40.0, 2.6, 1, ""),
            }
            kind, speed, vy, life, level, status = kind_map.get(ability, (ability, 520.0, 0.0, 1.2, 0, ""))
            self._retro_spawn_projectile(kind=kind, vx=direction * speed, vy=vy, life=life, damage=dmg, level=level, max_distance=rng_px, gravity=900.0 if kind in {"mine", "fire_wheel"} else 0.0, radius=42.0 if kind in {"mine", "acid_orb", "toxic_cloud"} else 0.0)
            if self.retro_projectiles:
                self.retro_projectiles[-1].ability = ability
            if ability == "rail_shot":
                player.vx -= direction * 180.0
            player.shoot_cooldown = 0.54 * self._ability_speed_mult(ability)

    def _flight_pressed(self) -> bool:
        return self._ability_owned("flight") and (self._retro_key_pressed("c", "C") or (self.active_secondary_slot == "flight" and self._secondary_pressed()))

    def _clone_snapshot(self) -> tuple[float, float, int, bool, int] | None:
        if self.clone_timer <= 0 or not self.clone_history:
            return None
        target_time = time.perf_counter() - 0.25
        _, x, y, facing, on_ground, jumps_used = min(self.clone_history, key=lambda item: abs(item[0] - target_time))
        return x, y, facing, on_ground, jumps_used

    def _clone_attack(self, ability: str, *, charge_level: int = 0) -> None:
        snapshot = self._clone_snapshot()
        if snapshot is None:
            return
        x, y, facing, _on_ground, _jumps_used = snapshot
        # El clon copia ataques con 0.25 s de delay y sus proyectiles no dañan al jugador.
        if ability == "gun":
            self._spawn_gun_projectile(charge_level, source_x=x, source_y=y, source_facing=facing, owner="clone")
        elif ability == "sword":
            self._retro_apply_sword_damage_at(x, y, self.retro_player.w, self.retro_player.h, facing, 4 + self._ability_attack_bonus("sword"), "sword")
        elif ability == "boomerang":
            direction = 1 if facing >= 0 else -1
            self._retro_spawn_projectile(kind="boomerang", vx=direction * 560.0, life=2.0, damage=2 + self._ability_attack_bonus("sword"), level=1, max_distance=TILE * (4 + self._sword_range_bonus()), owner="clone", source_x=x, source_y=y, source_facing=facing)
        elif ability == "bomb":
            direction = 1 if facing >= 0 else -1
            self._retro_spawn_projectile(kind="bomb", vx=direction * 55.0, vy=-90.0, life=2.5, damage=4 + self._ability_attack_bonus("flamethrower"), max_distance=9999, owner="clone", gravity=1040.0, radius=TILE * (1 + self._ability_range_bonus("flamethrower")), source_x=x, source_y=y, source_facing=facing)
        elif ability == "triple":
            direction = 1 if facing >= 0 else -1
            spreads = (-250.0, -125.0, 0.0, 125.0, 250.0) if self.ability_levels.get("triple", 0) >= 5 else (-185.0, 0.0, 185.0)
            for vy in spreads:
                self._retro_spawn_projectile(kind="vshot", vx=direction * 600.0, vy=vy, life=0.95, damage=1 + self._ability_attack_bonus("triple"), level=0, max_distance=TILE * (1.15 + self._ability_range_bonus("triple")), owner="clone", source_x=x, source_y=y, source_facing=facing)
        elif ability == "flamethrower":
            direction = 1 if facing >= 0 else -1
            self._retro_spawn_projectile(kind="flame", vx=direction * 460.0, life=0.26, damage=2, level=0, max_distance=TILE * (1 + self._ability_range_bonus("flamethrower")), radius=18.0, owner="clone", source_x=x, source_y=y, source_facing=facing)

    def _activate_clone(self, duration: float = 10.0) -> None:
        if self.clone_timer > 0:
            return
        self.clone_timer = duration
        self.clone_history.clear()
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y, 30.0, 0.55, "clone"))

    def _activate_shield(self) -> None:
        if self.shield_cooldown > 0:
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "cooldown"))
            return
        self.shield_timer = self._shield_duration()
        self._record_shadow_action("shield")
        self.parry_timer = 0.28
        self.shield_cooldown = 5.0
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y, 34.0, 0.55, "shield"))

    def _time_slow_factor(self) -> float:
        # No afecta al jugador ni a sus proyectiles; congela enemigos, peligros y cajitas.
        return 0.0 if self.slow_time_timer > 0 else 1.0

    def _activate_slow_time(self) -> None:
        if self.slow_time_cooldown > 0:
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 18, 18.0, 0.35, "cooldown"))
            return
        self.slow_time_timer = self._time_space_duration()
        self._record_shadow_action("time_space")
        self.slow_time_cooldown = self._time_space_cooldown()
        self._time_space_pending_teleport = True
        self._time_space_teleport_cooldown = 0.0
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y, 36.0, 0.65, "time_space"))

    def _try_time_space_teleport(self, event: tk.Event) -> bool:
        if not self._ability_owned("time_space") or not self._time_space_pending_teleport or self.slow_time_timer <= 0:
            return False
        player = self.retro_player
        if getattr(self, "_time_space_teleport_cooldown", 0.0) > 0:
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y - 18, 18.0, 0.25, "cooldown"))
            return True
        wx = max(8.0, min(self.retro_world_width - player.w - 8.0, event.x + self.retro_camera_x - player.w * 0.5))
        wy = max(8.0, min(self.retro_world_height - player.h - 8.0, event.y + self.retro_camera_y - player.h * 0.5))
        test = RetroRect(wx, wy, player.w, player.h, "teleport")
        if any(self._retro_intersects(test.x, test.y, test.w, test.h, rect) for rect in self._solid_rects_with_boxes()):
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y, 18.0, 0.35, "locked"))
            return True
        player.x, player.y = wx, wy
        player.vx *= 0.25
        player.vy = min(player.vy, 0.0)
        self._time_space_teleport_cooldown = self._time_space_teleport_recast()
        blast_damage = self._time_space_blast_damage()
        if blast_damage > 0:
            self._damage_area(player.x + player.w * 0.5, player.y + player.h * 0.5, 64.0 + 10.0 * blast_damage, blast_damage, "time_space", push=70.0, status="stun")
        self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h * 0.5, 48.0, 0.55, "time_space"))
        return True

    def _retro_jump(self) -> None:
        player = self.retro_player
        # Permite saltar estando agachado. No exige levantarse antes del impulso,
        # para que funcione también en túneles bajos. Si no mantienes Abajo/S,
        # la hitbox volverá a tamaño normal en el siguiente update cuando haya espacio.
        if getattr(player, "crouching", False) and player.on_ground:
            player.vy = min(player.vy, 0.0)
        max_jumps = self.selected_character.jumps if self.selected_character else 2
        if self._ability_owned("triple_jump"):
            max_jumps = max(max_jumps, 3)
            if self._has_weapon_special("triple_jump", "fourth_jump"):
                max_jumps = max(max_jumps, 4)
        if player.wall_side and not player.on_ground:
            player.vy = -430.0
            player.vx = -player.wall_side * 285.0
            player.facing = -player.wall_side
            player.jumps_used = 1
            return
        if player.on_ground:
            player.vy = -462.0
            player.on_ground = False
            player.jumps_used = 1
            return
        if player.jumps_used < max_jumps:
            player.vy = -408.0 if player.jumps_used == 1 else -368.0
            player.jumps_used += 1

    def _retro_dash(self) -> None:
        player = self.retro_player
        if player.dash_cooldown > 0:
            return
        direction = 1 if player.facing >= 0 else -1
        if self._retro_key_pressed("Left", "a", "A") and not self._retro_key_pressed("Right", "d", "D"):
            direction = -1
        elif self._retro_key_pressed("Right", "d", "D") and not self._retro_key_pressed("Left", "a", "A"):
            direction = 1
        player.facing = direction
        player.vx = direction * 680.0
        player.vy = min(player.vy, 20.0)
        player.dash_timer = 0.18 + (self._nova_duration_bonus() if self._ability_owned("nova") else 0.0)
        player.dash_cooldown = 0.52
        self.perfect_dash_timer = 0.24

    def _retro_sword(self) -> None:
        player = self.retro_player
        if player.attack_cooldown > 0:
            return
        player.attack_timer = 0.22
        self._weapon_attack_fx("sword", scale=1.2)
        player.attack_cooldown = 0.34 * self._ability_speed_mult("sword")
        self.sword_attack_count += 1
        self._retro_apply_sword_damage()
        if self._has_weapon_special("sword", "mini_boomerang") and self.sword_attack_count % 3 == 0:
            self._retro_shoot_boomerang("sword", small=True)

    def _retro_apply_sword_damage(self) -> None:
        player = self.retro_player
        self._retro_apply_sword_damage_at(player.x, player.y, player.w, player.h, player.facing, 4 + self._ability_attack_bonus("sword"), "sword")

    def _retro_apply_sword_damage_at(self, x: float, y: float, w: float, h: float, facing: int, damage: int, ability: str) -> None:
        reach = TILE * (0.5 + self._sword_range_bonus())
        sx = x + (w if facing > 0 else -reach)
        sy = y + 3.0
        for enemy in self.retro_enemies:
            if not enemy.alive or enemy.hurt_flash > 0 or self._enemy_is_ally(enemy):
                continue
            if sx < enemy.x + enemy.w and sx + reach > enemy.x and sy < enemy.y + enemy.h and sy + h > enemy.y:
                self._retro_damage_enemy(enemy, damage, facing, ability=ability)
        if self.selected_mode == "arena":
            self._damage_arena_bots_rect(sx, sy, reach, h + 4.0, damage, attacker_team=self.arena_player_team, ability=ability)
        self._damage_shadow_rect(sx, sy, reach, h + 4.0, damage, ability, facing)
        self._try_open_secret_gates(ability, area=(sx, sy, reach, h + 4.0))

    def _retro_release_charge(self) -> None:
        held = max(0.0, time.perf_counter() - self._x_charge_started)
        self._x_charge_active = False
        self._x_charge_started = 0.0
        level = 0
        if held >= 5.0:
            level = 3
        elif held >= 3.0:
            level = 2
        elif held >= 1.0:
            level = 1
        self._retro_shoot_charged(level)
        self._record_shadow_action("gun", level=level)
        self._clone_attack("gun", charge_level=level)

    def _retro_spawn_projectile(
        self,
        *,
        kind: str,
        vx: float,
        vy: float = 0.0,
        life: float = 1.4,
        damage: int = 1,
        level: int = 0,
        max_distance: float = 420.0,
        owner: str = "player",
        gravity: float = 0.0,
        radius: float = 0.0,
        source_x: float | None = None,
        source_y: float | None = None,
        source_facing: int | None = None,
        ability: str = "",
        homing_time: float = 0.0,
    ) -> None:
        player = self.retro_player
        direction = 1 if (player.facing if source_facing is None else source_facing) >= 0 else -1
        shooter_x = player.x if source_x is None else source_x
        shooter_y = player.y if source_y is None else source_y
        shooter_w = player.w
        shooter_h = player.h
        x = shooter_x + (shooter_w if direction > 0 else -7)
        y = shooter_y + shooter_h * 0.44
        self.retro_projectiles.append(
            RetroProjectile(
                x=x,
                y=y,
                vx=vx,
                vy=vy,
                life=life,
                damage=damage,
                kind=kind,
                level=level,
                owner=owner,
                origin_x=x,
                origin_y=y,
                max_distance=max_distance,
                hit_ids=set(),
                gravity=gravity,
                radius=radius,
                ability=ability,
                homing_time=homing_time,
            )
        )

    def _spawn_gun_projectile(self, level: int, *, source_x: float | None = None, source_y: float | None = None, source_facing: int | None = None, owner: str = "player") -> None:
        facing = self.retro_player.facing if source_facing is None else source_facing
        direction = 1 if facing >= 0 else -1
        damage_by_level = {0: 1, 1: 2, 2: 4, 3: 6}
        damage_bonus = self._ability_attack_bonus("gun")
        lemon_dash = (owner == "player" and self._ability_owned("nova") and self.retro_player.dash_timer > 0 and (self._has_weapon_special("nova", "lemon_dash") or self._node_owned("nova", "special_5")))
        # Nivel 0 inicial reducido a la mitad: antes 620 px/s, ahora 310 px/s.
        speed = 310.0 if level == 0 else 620.0 + level * 120.0
        range_px = TILE * (3 + self._ability_range_bonus("gun")) + level * 18
        count = self._gun_bullet_count() if level == 0 else 1
        spreads = {1: (0.0,), 3: (-95.0, 0.0, 95.0), 5: (-160.0, -80.0, 0.0, 80.0, 160.0)}.get(count, (0.0,))
        if lemon_dash:
            self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y + self.retro_player.h * 0.45, 28.0, 0.30, "crit"))
        for vy in spreads:
            self._retro_spawn_projectile(
                kind="charged",
                vx=direction * speed,
                vy=vy,
                life=1.2 + level * 0.18,
                damage=(damage_by_level[level] + damage_bonus) * (2 if lemon_dash else 1),
                level=level,
                max_distance=range_px,
                owner=owner,
                source_x=source_x,
                source_y=source_y,
                source_facing=source_facing,
                ability="lemon_dash" if lemon_dash else "gun",
                homing_time=self._gun_homing_duration() if owner in {"player", "clone", "p2"} else 0.0,
            )

    def _retro_shoot_charged(self, level: int) -> None:
        player = self.retro_player
        if player.shoot_cooldown > 0:
            return
        self._weapon_attack_fx("gun", scale=1.0 + level * 0.35)
        self._spawn_gun_projectile(level)
        player.shoot_cooldown = self._gun_shot_cooldown(level)

    def _retro_shoot_boomerang(self, ability: str = "sword", *, small: bool = False) -> None:
        kind = "mini_boomerang" if small else "boomerang"
        if not small and any(p.kind == "boomerang" and p.owner == "player" for p in self.retro_projectiles):
            return
        player = self.retro_player
        direction = 1 if player.facing >= 0 else -1
        damage = (4 + self._ability_attack_bonus(ability)) * 2
        self._retro_spawn_projectile(kind=kind, vx=direction * (610.0 if small else 560.0), life=1.55 if small else 2.25, damage=damage, level=0 if small else 1, max_distance=TILE * ((2.2 if small else 4.0) + (self._sword_range_bonus() if ability == "sword" else self._ability_range_bonus(ability))), ability=ability)
        player.shoot_cooldown = 0.22 * self._ability_speed_mult(ability)

    def _try_open_secret_gates(self, ability: str, area: tuple[float, float, float, float] | None = None) -> None:
        player = self.retro_player
        if area is None:
            area = (player.x - 12, player.y - 12, player.w + 24, player.h + 24)
        ax, ay, aw, ah = area
        for gate in self.secret_gates:
            if gate.opened or gate.ability != ability:
                continue
            r = gate.rect
            if ax < r.x + r.w and ax + aw > r.x and ay < r.y + r.h and ay + ah > r.y:
                now = time.perf_counter()
                last_hit = float(getattr(gate, "_last_hit_time", 0.0))
                if now - last_hit < 0.18:
                    continue
                setattr(gate, "_last_hit_time", now)
                gate.hits_left = max(0, int(getattr(gate, "hits_left", 1)) - 1)
                self.retro_effects.append(RetroEffect(r.x + r.w * 0.5, r.y + r.h * 0.5, 36.0, 0.32, "secret"))
                if gate.hits_left <= 0:
                    gate.opened = True
                    self.retro_effects.append(RetroEffect(r.x + r.w * 0.5, r.y + r.h * 0.5, 70.0, 0.7, "secret"))

    def _retro_damage_enemy(self, enemy: RetroEnemy, amount: int | float, attack_dir: int = 0, *, ability: str = "") -> None:
        if not enemy.alive:
            return
        tags = set(ABILITY_INFO.get(ability, {}).get("tags", ())) if ability else set()
        tag_key = next(iter(tags), ability) if tags else ability
        if enemy.kind == "shield" and attack_dir and math.copysign(1, enemy.vx or 1) != attack_dir and "sonic" not in tags:
            amount = max(1, amount - 2)
        if enemy.kind == "mirror" and ability in {"gun", "triple", "rail_shot"} and random.random() < 0.28:
            # Refleja disparos simples como amenaza; no refleja ataques de área.
            self._spawn_enemy_bullet(enemy, speed=360.0, damage=max(1, amount * 0.6))
            self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.5, 22.0, 0.25, "reflect"))
            return
        if enemy.resistance and (enemy.resistance == tag_key or enemy.resistance in tags):
            amount *= 0.72
        if enemy.weakness and (enemy.weakness == tag_key or enemy.weakness in tags or enemy.weakness in ability):
            amount *= 1.35
            self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y, 16.0, 0.25, "weak"))
        if enemy.armor:
            amount = max(1, amount - enemy.armor * 0.35)
        if ability == "lemon_dash":
            self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.2, 22.0, 0.35, "crit"))
        elif ability and random.random() < self._ability_crit_chance(ability):
            amount *= 2
            self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.2, 18.0, 0.35, "crit"))
        enemy.hp -= amount
        enemy.hurt_flash = 0.17
        if ability in {"ice_lance", "frost_field"}:
            self._apply_status(enemy, "slow", 2.2)
        elif ability in {"acid_orb", "toxic_cloud"}:
            self._apply_status(enemy, "poison", 2.8)
        elif ability in {"flamethrower", "fire_wheel", "meteor_call"}:
            self._apply_status(enemy, "burn", 2.0)
        elif ability in {"boomerang_plus", "quantum_swap"}:
            self._apply_status(enemy, "mark", 4.0)
        if enemy.hp <= 0 and str(getattr(enemy, "elite_mod", "")) == "immortal_final_ninja":
            enemy.hp = max(1.0, enemy.max_hp * 0.25)
            enemy.hurt_flash = 0.45
            self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y, 22.0, 0.35, "locked"))
            return
        if enemy.hp <= 0:
            self._remember_resurrection_blueprint(enemy)
            enemy.alive = False
            center_x = enemy.x + enemy.w * 0.5
            center_y = enemy.y + enemy.h * 0.5
            self.retro_effects.append(RetroEffect(center_x, center_y, max(enemy.w, enemy.h), 0.55, "defeat"))
            if self._enemy_is_ally(enemy):
                return

            if enemy.kind == "splitter":
                for dx in (-22.0, 22.0):
                    ew, eh, hp, attack, speed = ENEMY_STATS["minor"]
                    hp, attack = self._scaled_enemy_stats(max(2, hp // 2), attack)
                    sx = max(30.0, min(self.retro_world_width - 60.0, center_x + dx))
                    sy = max(30.0, min(float(self._retro_ground_y() - eh), center_y))
                    self.retro_enemies.append(RetroEnemy(sx, sy, ew, eh, math.copysign(speed, dx), "minor", hp, hp, attack, sx - 90, sx + 90, home_y=sy, status_effects={}))

            if ability == "vampiric_slash" or (enemy.hp <= -2 and ability and self._has_weapon_special(ability)):
                self.retro_player.hp = min(self.retro_player.max_hp, self.retro_player.hp + 1)

            self.combo_count = min(99, getattr(self, "combo_count", 0) + 1)
            self.combo_timer = 4.0
            combo_bonus = 1 if self.combo_count >= 8 and self.combo_count % 4 == 0 else 0

            # Enemigos normales sueltan XP; los jefes entregan XP directo.
            if enemy.kind.startswith("boss"):
                reward = int(ENEMY_XP.get(enemy.kind, 10) * float(getattr(self, "level_spec", {}).get("reward", 1.0)))
                self.xp_count += max(8, reward) + combo_bonus
                self.retro_effects.append(RetroEffect(center_x, center_y - 22.0, 32.0, 0.75, "boss_xp"))
                if self._pending_level_advance <= 0:
                    if self._campaign_is_arena_stage() and int(self.level_number) == 6:
                        self._maybe_complete_campaign_arena_objective()
                    elif self._alive_boss_count() <= 0:
                        self.win_banner_timer = 1.25
                        self._pending_level_advance = 1.25
            else:
                xp_value = max(1, ENEMY_XP.get(enemy.kind, 1)) + combo_bonus
                if enemy.kind == "elite":
                    xp_value += 1
                drop_rng = random.Random(int(enemy.x * 17 + enemy.y * 31 + self.retro_seed + self.level_number * 101))
                # Tiradas independientes solicitadas: 50% XP y 10% vida.
                # Pueden caer ambos, solo uno o ninguno.
                if drop_rng.random() < 0.50:
                    for i in range(min(xp_value, 10)):
                        self.retro_pickups.append(RetroPickup(center_x + (i - xp_value / 2) * 12.0, center_y - 20.0 - (i % 3) * 10.0, "xp_orb"))
                if drop_rng.random() < 0.10:
                    self.retro_pickups.append(RetroPickup(center_x, center_y - 44.0, "heal"))

    def _damage_player(self, amount: int | float, source_x: float, *, allow_if_hurt: bool = False) -> None:
        player = self.retro_player
        if getattr(self, "perfect_dash_timer", 0.0) > 0 and player.dash_timer > 0:
            self.perfect_dash_timer = 0.0
            player.hurt_timer = max(player.hurt_timer, 0.42)
            cx = player.x + player.w * 0.5
            cy = player.y + player.h * 0.5
            self._damage_area(cx, cy, TILE * 0.95, 3, "perfect_dash", push=70.0, status="stun")
            self.retro_effects.append(RetroEffect(cx, cy, 54.0, 0.45, "perfect_dash"))
            return
        if self.shield_timer > 0:
            self.parry_timer = max(getattr(self, "parry_timer", 0.0), 0.18)
            blocked = self._shield_block_amount()
            amount = max(0.0, float(amount) - blocked)
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h * 0.5, 22.0 + blocked * 2.0, 0.25, "shield"))
            if amount <= 0:
                return
        if player.hurt_timer > 0 and not allow_if_hurt:
            return
        player.hp -= amount
        if player.hp <= 0:
            if self.selected_mode == "arena":
                self._award_arena_score(self._arena_last_player_attacker, victim_id=self.arena_player_team)
                self.arena_player_respawn_timer = 3.0
                player.hp = 0
                player.x = -5000.0
                player.y = -5000.0
                player.vx = player.vy = 0.0
                player.hurt_timer = 3.0
                self.retro_effects.append(RetroEffect(max(0.0, min(self.retro_world_width, source_x)), self._retro_ground_y() - 40.0, 44.0, 0.7, "defeat"))
                return
            player.hp = player.max_hp
            self._respawn_player_at_checkpoint()
        else:
            player.vx = -math.copysign(285.0, source_x - (player.x + player.w * 0.5))
            player.vy = -245.0
            player.on_ground = False
        player.hurt_timer = 0.68

    def _reset_arena_match(self) -> None:
        self.arena_player_team = -1
        self.arena_scores = {-1: 0}
        for idx in range(ARENA_BOT_COUNT):
            self.arena_scores[idx] = 0
        self.arena_match_timer = ARENA_MATCH_SECONDS
        self.arena_match_over = False
        self.arena_player_respawn_timer = 0.0
        self._arena_last_player_attacker = None
        self.arena_orb_spawn_timer = 0.0
        self.p1_score = 0
        self.p2_score = 0

    def _arena_spawn_point(self, slot: int, total: int = 16) -> tuple[float, float, int]:
        ground = self._retro_ground_y()
        # Reparto estable por todo el estadio: alterna suelo y plataformas.
        total = max(1, total)
        frac = (slot + 0.5) / total
        ground_x = 70.0 + (self.retro_world_width - 140.0) * frac
        platforms = [r for r in self.retro_obstacles if r.h <= 18 and r.w >= 90 and r.kind.startswith("arena")]
        platforms = sorted(platforms, key=lambda r: r.x + r.w * 0.5)
        if platforms and slot % 3 == 1:
            rect = platforms[(slot // 3) % len(platforms)]
            x = rect.x + rect.w * (0.25 + 0.5 * ((slot * 41) % 100) / 100.0)
            y = rect.y - self.retro_player.base_h
        else:
            x = ground_x
            y = float(ground - self.retro_player.base_h)
        x = max(24.0, min(self.retro_world_width - self.retro_player.w - 24.0, x))
        y = max(24.0, min(float(ground - self.retro_player.base_h), y))
        facing = 1 if x < self.retro_world_width * 0.5 else -1
        return x, y, facing

    def _award_arena_score(self, killer_id: int | None, *, victim_id: int | None = None) -> None:
        if self.selected_mode != "arena" or self.arena_match_over:
            return
        if killer_id is None or killer_id == victim_id:
            return
        self.arena_scores[killer_id] = self.arena_scores.get(killer_id, 0) + 1
        if killer_id == self.arena_player_team:
            self.xp_count += ARENA_KILL_XP
            self.p1_score = self.arena_scores[killer_id]
        else:
            self.p2_score = max(self.arena_scores.get(i, 0) for i in self.arena_scores if i != self.arena_player_team)

    def _arena_rankings(self) -> list[tuple[int, str, int]]:
        rows: list[tuple[int, str, int]] = [(self.arena_player_team, "JUGADOR", self.arena_scores.get(self.arena_player_team, 0))]
        for bot in self.arena_bots:
            rows.append((bot.index, f"{bot.name} {bot.style[:3].upper()}", self.arena_scores.get(bot.index, 0)))
        return sorted(rows, key=lambda row: (-row[2], row[1]))

    def _finish_arena_match(self) -> None:
        if self.arena_match_over:
            return
        self.arena_match_over = True
        ranking = self._arena_rankings()
        winner = ranking[0][1] if ranking else "?"
        self.status_notice_text = f"ARENA FINALIZADA · GANA {winner}"
        self.status_notice_timer = 6.0

    def _update_arena_match(self, dt: float) -> None:
        if self.selected_mode != "arena":
            return
        if self.arena_match_over:
            return
        self.arena_match_timer = max(0.0, self.arena_match_timer - dt)
        if self.arena_player_respawn_timer > 0.0:
            self.arena_player_respawn_timer = max(0.0, self.arena_player_respawn_timer - dt)
            if self.arena_player_respawn_timer <= 0.0:
                self._respawn_arena_player()
        self.arena_orb_spawn_timer = max(0.0, getattr(self, "arena_orb_spawn_timer", 0.0) - dt)
        if self.arena_orb_spawn_timer <= 0.0:
            self.arena_orb_spawn_timer = 2.0
            self._reseed_arena_point_orbs()
        if self.arena_match_timer <= 0.0:
            self._finish_arena_match()

    def _update_race_finish(self, viewport_width: int, viewport_height: int) -> None:
        has_finish = self.selected_mode == "race" or self._campaign_has_finish_goal() or self._is_tutorial_guided()
        if not has_finish or self.race_finish_x <= 0.0 or self.race_finish_reached:
            return
        player = self.retro_player
        if player.x + player.w * 0.5 >= self.race_finish_x:
            self.race_finish_reached = True
            self.win_banner_timer = 1.15
            self._pending_level_advance = 1.15
            self.retro_effects.append(RetroEffect(self.race_finish_x, self._retro_ground_y() - 70.0, 64.0, 0.8, "finish"))

    def _setup_arena_bots(self) -> None:
        if self.selected_mode != "arena":
            self.arena_bots.clear()
            return
        ground = self._retro_ground_y()
        if len(self.arena_bots) != ARENA_BOT_COUNT:
            self.arena_bots = []
            for i, style in enumerate(ARENA_AI_STYLES[:ARENA_BOT_COUNT]):
                bot = ArenaBot(
                    player=RetroPlayer(w=self.retro_player.w, h=self.retro_player.base_h, base_h=self.retro_player.base_h, crouch_h=self.retro_player.crouch_h),
                    name=f"IA-{i + 1:02d}", style=style, team=i, index=i,
                    think_timer=random.random() * 0.4, action_timer=random.random() * 0.5,
                )
                bot.player.max_hp = 38 if style == "tank" else 26 if style in {"sniper", "coward"} else 30
                bot.player.hp = bot.player.max_hp
                bot.personality = ("duelista" if style in {"saber", "assassin"} else "tirador" if style in {"buster", "sniper", "charger"} else "evasivo" if style in {"coward", "shield"} else "aéreo" if style in {"jumper", "flanker"} else "cazador")
                bot.intent_attack = (i % 2 == 0)
                bot.intent_timer = 0.35 + random.random() * 1.0
                bot.jump_cooldown = 0.45 + random.random() * 1.0
                bot.nav_timer = 0.0
                self.arena_bots.append(bot)
            if not getattr(self, "arena_scores", None) or len(self.arena_scores) < 16:
                self._reset_arena_match()
        total = len(self.arena_bots) + 1
        for i, bot in enumerate(self.arena_bots):
            p = bot.player
            p.x, p.y, p.facing = self._arena_spawn_point(i, total)
            p.vx = p.vy = 0.0
            p.on_ground = True
            p.jumps_used = 0
            p.hp = p.max_hp
            p.hurt_timer = 0.0
            p.dash_cooldown = p.attack_cooldown = p.shoot_cooldown = 0.0
            bot.alive = True
            bot.respawn_timer = 0.0
            bot.team = bot.index  # todos contra todos: cada IA es su propio bando lógico
            bot.last_x = p.x
            bot.stuck_timer = 0.0
            bot.roam_timer = random.random() * 1.0
            bot.intent_attack = (i % 2 == 0)
            bot.intent_timer = 0.35 + random.random() * 1.0
            bot.jump_cooldown = 0.45 + random.random() * 1.0
            bot.nav_timer = 0.0
        player = self.retro_player
        player.x, player.y, player.facing = self._arena_spawn_point(total - 1, total)
        player.hp = player.max_hp
        player.vx = player.vy = 0.0
        player.on_ground = True
        player.hurt_timer = 0.0
        self.arena_player_team = -1
        self.arena_scores.setdefault(self.arena_player_team, 0)

    def _respawn_arena_player(self) -> None:
        player = self.retro_player
        player.hp = player.max_hp
        slot = random.randint(0, ARENA_BOT_COUNT)
        player.x, player.y, player.facing = self._arena_spawn_point(slot, len(self.arena_bots) + 1)
        player.vx = player.vy = 0.0
        player.on_ground = True
        player.jumps_used = 0
        player.hurt_timer = 0.9
        self._arena_last_player_attacker = None
        self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y, 44.0, 0.7, "arena"))

    def _arena_owner_team(self, owner: str) -> int | None:
        if owner in {"player", "clone"}:
            return self.arena_player_team
        if owner.startswith("bot:"):
            try:
                idx = int(owner.split(":", 1)[1])
            except ValueError:
                return None
            for bot in self.arena_bots:
                if bot.index == idx:
                    return bot.team
        return None

    def _arena_bot_center(self, bot: ArenaBot) -> tuple[float, float]:
        p = bot.player
        return p.x + p.w * 0.5, p.y + p.h * 0.5

    def _arena_target_for_bot(self, bot: ArenaBot) -> tuple[str, int, RetroPlayer] | None:
        candidates: list[tuple[float, str, int, RetroPlayer]] = []
        bp = bot.player
        bx, by = bp.x + bp.w * 0.5, bp.y + bp.h * 0.5
        if self.retro_player.hp > 0 and self.arena_player_respawn_timer <= 0.0:
            pp = self.retro_player
            candidates.append((math.hypot((pp.x + pp.w * 0.5) - bx, (pp.y + pp.h * 0.5) - by), "player", -1, pp))
        for other in self.arena_bots:
            if other is bot or not other.alive:
                continue
            op = other.player
            candidates.append((math.hypot((op.x + op.w * 0.5) - bx, (op.y + op.h * 0.5) - by), "bot", other.index, op))
        if not candidates:
            return None
        _dist, kind, index, player = min(candidates, key=lambda item: item[0])
        return kind, index, player

    def _damage_arena_bot(self, index: int, amount: int | float, source_x: float, *, attacker_team: int | None = None, ability: str = "") -> bool:
        if self.selected_mode != "arena":
            return False
        bot = next((b for b in self.arena_bots if b.index == index), None)
        if bot is None or not bot.alive:
            return False
        if attacker_team is not None and attacker_team == bot.team:
            return False
        p = bot.player
        if p.hurt_timer > 0:
            return False
        if bot.style == "shield" and bot.shield_timer > 0:
            amount = max(0.0, float(amount) - 2.5)
            self.retro_effects.append(RetroEffect(p.x + p.w * 0.5, p.y + p.h * 0.5, 22.0, 0.25, "shield"))
            if amount <= 0:
                return False
        p.hp -= amount
        p.hurt_timer = 0.35
        p.vx = -math.copysign(210.0, source_x - (p.x + p.w * 0.5))
        p.vy = min(p.vy, -170.0)
        if p.hp <= 0:
            bot.alive = False
            bot.respawn_timer = 3.0
            self._award_arena_score(attacker_team, victim_id=bot.index)
            self.retro_effects.append(RetroEffect(p.x + p.w * 0.5, p.y + p.h * 0.5, 34.0, 0.55, "defeat"))
        return True

    def _damage_arena_bots_rect(self, x: float, y: float, w: float, h: float, damage: int | float, *, attacker_team: int | None, ability: str = "") -> int:
        hits = 0
        if self.selected_mode != "arena":
            return 0
        for bot in self.arena_bots:
            if not bot.alive or (attacker_team is not None and bot.team == attacker_team):
                continue
            p = bot.player
            if self._retro_intersects(p.x, p.y, p.w, p.h, RetroRect(x, y, w, h, "arena_hit")):
                if self._damage_arena_bot(bot.index, damage, x + w * 0.5, attacker_team=attacker_team, ability=ability):
                    hits += 1
        return hits

    def _damage_arena_bots_area(self, x: float, y: float, radius: float, damage: int | float, *, attacker_team: int | None, ability: str = "") -> int:
        hits = 0
        if self.selected_mode != "arena":
            return 0
        for bot in self.arena_bots:
            if not bot.alive or (attacker_team is not None and bot.team == attacker_team):
                continue
            bx, by = self._arena_bot_center(bot)
            if math.hypot(bx - x, by - y) <= radius:
                if self._damage_arena_bot(bot.index, damage, x, attacker_team=attacker_team, ability=ability):
                    hits += 1
        return hits

    def _arena_bot_shoot(self, bot: ArenaBot, target: RetroPlayer, *, charged: bool = False) -> None:
        p = bot.player
        if p.shoot_cooldown > 0:
            return
        tx = target.x + target.w * 0.5
        ty = target.y + target.h * 0.5
        sx = p.x + p.w * 0.5
        sy = p.y + p.h * 0.45
        dx, dy = tx - sx, ty - sy
        length = max(1.0, math.hypot(dx, dy))
        speed = 460.0 if charged else 360.0
        p.facing = 1 if dx >= 0 else -1
        self.retro_projectiles.append(RetroProjectile(sx, sy, dx / length * speed, dy / length * speed, 1.35, 2 if charged else 1, "arena_bot_shot", 1 if charged else 0, f"bot:{bot.index}", sx, sy, 720.0, ability=bot.style))
        p.shoot_cooldown = 0.72 if bot.style in {"sniper", "charger"} else 0.44
        self.retro_effects.append(RetroEffect(sx, sy, 14.0, 0.22, "bot_shot"))

    def _arena_bot_sword(self, bot: ArenaBot) -> None:
        p = bot.player
        if p.attack_cooldown > 0:
            return
        reach = TILE * (1.0 if bot.style != "assassin" else 1.25)
        sx = p.x + (p.w if p.facing > 0 else -reach)
        sy = p.y + 3.0
        damage = 4 if bot.style in {"saber", "assassin"} else 3
        if self.arena_player_respawn_timer <= 0.0 and self._retro_intersects(self.retro_player.x, self.retro_player.y, self.retro_player.w, self.retro_player.h, RetroRect(sx, sy, reach, p.h + 4.0)):
            self._arena_last_player_attacker = bot.index
            self._damage_player(damage, sx, allow_if_hurt=True)
        self._damage_arena_bots_rect(sx, sy, reach, p.h + 4.0, damage, attacker_team=bot.team, ability=bot.style)
        p.attack_timer = 0.20
        p.attack_cooldown = 0.42 if bot.style != "assassin" else 0.28
        self.retro_effects.append(RetroEffect(sx + reach * 0.5, sy + 14.0, 24.0, 0.18, "bot_sword"))

    def _unstick_arena_bot(self, bot: ArenaBot, dt: float, target_info: tuple[str, int, RetroPlayer] | None) -> None:
        p = bot.player
        moved = abs(p.x - float(getattr(bot, "last_x", p.x)))
        if moved < 2.0 and (target_info is not None or abs(p.vx) > 22.0):
            bot.stuck_timer = float(getattr(bot, "stuck_timer", 0.0)) + dt
        else:
            bot.stuck_timer = max(0.0, float(getattr(bot, "stuck_timer", 0.0)) - dt * 1.8)
        bot.last_x = p.x
        if bot.stuck_timer > 0.70 and p.on_ground and float(getattr(bot, "jump_cooldown", 0.0)) <= 0.0:
            p.vy = -405.0
            p.on_ground = False
            p.jumps_used = 1
            p.vx = (1 if random.random() < 0.5 else -1) * (210.0 + random.random() * 115.0)
            p.facing = 1 if p.vx > 0 else -1
            bot.jump_cooldown = 1.15 + random.random() * 0.55
        if bot.stuck_timer > 1.85:
            p.x, p.y, p.facing = self._arena_spawn_point(random.randint(0, ARENA_BOT_COUNT), ARENA_BOT_COUNT + 1)
            p.vx = p.vy = 0.0
            p.on_ground = True
            p.jumps_used = 0
            bot.stuck_timer = 0.0
            bot.jump_cooldown = 0.75
            self.retro_effects.append(RetroEffect(p.x + p.w * 0.5, p.y, 26.0, 0.35, "arena"))

    def _update_arena_bots(self, dt: float, viewport_width: int, viewport_height: int) -> None:
        if self.selected_mode != "arena":
            return
        if len(self.arena_bots) != ARENA_BOT_COUNT:
            self._setup_arena_bots()
        ground = self._retro_ground_y()
        obstacles = self._solid_rects_with_boxes()
        arena_platforms = [r for r in obstacles if r.kind.startswith("arena") and r.h <= 18]

        close_styles = {"saber", "assassin", "dasher", "tank"}
        ranged_styles = {"sniper", "charger", "coward"}
        aerial_styles = {"jumper", "flanker", "hunter"}

        for bot in self.arena_bots:
            p = bot.player
            if not bot.alive:
                bot.respawn_timer = max(0.0, bot.respawn_timer - dt)
                if bot.respawn_timer <= 0.0:
                    bot.alive = True
                    p.hp = p.max_hp
                    p.x, p.y, p.facing = self._arena_spawn_point(random.randint(0, ARENA_BOT_COUNT), len(self.arena_bots) + 1)
                    p.vx = p.vy = 0.0
                    p.hurt_timer = 0.4
                    bot.jump_cooldown = 0.75 + random.random() * 0.5
                    bot.intent_timer = 0.35 + random.random() * 0.7
                continue

            p.dash_cooldown = max(0.0, p.dash_cooldown - dt)
            p.attack_cooldown = max(0.0, p.attack_cooldown - dt)
            p.attack_timer = max(0.0, p.attack_timer - dt)
            p.shoot_cooldown = max(0.0, p.shoot_cooldown - dt)
            p.hurt_timer = max(0.0, p.hurt_timer - dt)
            bot.shield_timer = max(0.0, bot.shield_timer - dt)
            bot.action_timer = max(0.0, bot.action_timer - dt)
            bot.jump_cooldown = max(0.0, float(getattr(bot, "jump_cooldown", 0.0)) - dt)
            bot.nav_timer = max(0.0, float(getattr(bot, "nav_timer", 0.0)) - dt)
            bot.intent_timer = max(0.0, float(getattr(bot, "intent_timer", 0.0)) - dt)
            if bot.intent_timer <= 0.0:
                # Decisión limpia 50/50: atacar o reposicionarse. La personalidad cambia cómo ejecuta la decisión.
                bot.intent_attack = random.random() < ARENA_ATTACK_PREFERENCE
                bot.intent_timer = 0.95 + random.random() * 1.35

            intent_attack = bool(getattr(bot, "intent_attack", True))
            target_info = self._arena_target_for_bot(bot)
            left = right = False
            px = p.x + p.w * 0.5
            py = p.y + p.h * 0.5
            nav_x: float | None = None
            nav_y: float | None = None

            desired_gap = 70.0 if bot.style in close_styles else 240.0 if bot.style in ranged_styles else 142.0
            if bot.style == "bomber":
                desired_gap = 178.0
            elif bot.style == "shield":
                desired_gap = 118.0
            elif bot.style == "telekinetic":
                desired_gap = 165.0
            jump_chance = 0.20
            if bot.style in aerial_styles:
                jump_chance = 0.42
            elif bot.style in close_styles:
                jump_chance = 0.28
            elif bot.style in ranged_styles:
                jump_chance = 0.12

            def choose_nav_point(prefer_far_from: RetroPlayer | None = None) -> None:
                nonlocal nav_x, nav_y
                if not arena_platforms:
                    return
                platforms = arena_platforms
                if prefer_far_from is not None:
                    tcx = prefer_far_from.x + prefer_far_from.w * 0.5
                    candidates = [r for r in platforms if abs((r.x + r.w * 0.5) - tcx) > desired_gap * 0.85]
                    if candidates:
                        platforms = candidates
                platform = random.choice(platforms)
                bot.nav_x = platform.x + platform.w * random.uniform(0.22, 0.78)
                bot.nav_y = platform.y
                bot.nav_timer = 1.35 + random.random() * 1.65
                nav_x = float(bot.nav_x)
                nav_y = float(bot.nav_y)

            def try_jump(power: float = -438.0, cooldown: float = ARENA_BOT_JUMP_COOLDOWN) -> bool:
                if not p.on_ground or float(getattr(bot, "jump_cooldown", 0.0)) > 0.0:
                    return False
                p.vy = power
                p.on_ground = False
                p.jumps_used = 1
                bot.jump_cooldown = cooldown + random.random() * 0.55
                return True

            bot.roam_timer = max(0.0, float(getattr(bot, "roam_timer", 0.0)) - dt)
            if bot.roam_timer <= 0.0:
                bot.roam_timer = 1.35 + random.random() * 1.9
                bot.roam_dir = random.choice((-1, 1))
                if random.random() < 0.48:
                    choose_nav_point()

            if target_info:
                _kind, _idx, target = target_info
                tx = target.x + target.w * 0.5
                ty = target.y + target.h * 0.5
                distance = tx - px
                vertical_gap = ty - py

                if intent_attack:
                    # Ataque: acercarse al rango de su personalidad; solo saltar si de verdad hay altura que ganar.
                    if arena_platforms and abs(vertical_gap) > 92.0:
                        candidates = [r for r in arena_platforms if abs((r.x + r.w * 0.5) - tx) < 470.0]
                        if candidates:
                            platform = min(candidates, key=lambda r: abs((r.x + r.w * 0.5) - tx) + abs(r.y - target.y) * 0.9)
                            nav_x = platform.x + platform.w * 0.5
                            nav_y = platform.y
                    if nav_x is None:
                        left = distance < -desired_gap
                        right = distance > desired_gap
                    else:
                        nav_distance = nav_x - px
                        left = nav_distance < -42.0
                        right = nav_distance > 42.0
                    if p.on_ground and float(getattr(bot, "jump_cooldown", 0.0)) <= 0.0 and random.random() < jump_chance:
                        if target.y < p.y - 74.0 or (nav_y is not None and nav_y < p.y - 62.0):
                            try_jump(-438.0 if bot.style != "jumper" else -472.0, 0.95)
                    if p.on_ground and nav_y is not None and nav_y > p.y + 44 and abs((nav_x or tx) - px) > 110:
                        left = (nav_x or tx) < px
                        right = (nav_x or tx) > px

                    if bot.action_timer <= 0.0:
                        bot.action_timer = 0.30 + random.random() * 0.32
                        if bot.style in {"dasher", "assassin", "nova"} and abs(distance) > 118 and p.dash_cooldown <= 0 and random.random() < 0.55:
                            p.facing = 1 if distance > 0 else -1
                            p.vx = p.facing * (620.0 if bot.style != "tank" else 500.0)
                            p.dash_timer = 0.14
                            p.dash_cooldown = 0.92
                            if bot.style == "nova" and target_info[0] == "player" and abs(distance) < 150:
                                self._arena_last_player_attacker = bot.index
                                self._damage_player(2, p.x, allow_if_hurt=True)
                        elif bot.style == "shield" and bot.shield_timer <= 0 and random.random() < 0.22:
                            bot.shield_timer = 1.35
                            self.retro_effects.append(RetroEffect(p.x + p.w * 0.5, p.y + p.h * 0.5, 34.0, 0.45, "shield"))
                        elif abs(distance) < 84 and abs(target.y - p.y) < 60 and bot.style in {"saber", "assassin", "tank", "dasher"}:
                            p.facing = 1 if distance >= 0 else -1
                            self._arena_bot_sword(bot)
                        elif bot.style == "bomber" and p.shoot_cooldown <= 0:
                            self.retro_projectiles.append(RetroProjectile(p.x + p.w * 0.5, p.y + p.h * 0.35, math.copysign(72.0, distance or p.facing), -155.0, 2.2, 3, "bomb", 0, f"bot:{bot.index}", p.x, p.y, 900.0, gravity=1040.0, radius=46.0, ability="arena_bomb"))
                            p.shoot_cooldown = 1.25
                        elif abs(distance) < 780 or bot.style in {"sniper", "charger"}:
                            self._arena_bot_shoot(bot, target, charged=bot.style in {"charger", "sniper"})
                else:
                    # Reposición: separar, buscar otra plataforma/orbe y solo disparar ocasionalmente.
                    if bot.nav_timer <= 0.0 or not hasattr(bot, "nav_x"):
                        choose_nav_point(target)
                    nav_x = float(getattr(bot, "nav_x", px + getattr(bot, "roam_dir", 1) * 160.0))
                    nav_y = float(getattr(bot, "nav_y", p.y))
                    if abs(distance) < desired_gap * 0.95:
                        left = distance > 0
                        right = distance < 0
                    else:
                        left = nav_x < px - 40.0
                        right = nav_x > px + 40.0
                    if p.on_ground and nav_y < p.y - 86.0 and random.random() < jump_chance * 0.6:
                        try_jump(-416.0, 1.15)
                    if bot.action_timer <= 0.0:
                        bot.action_timer = 0.45 + random.random() * 0.45
                        if abs(distance) < 430 and abs(vertical_gap) < 140 and p.shoot_cooldown <= 0 and random.random() < 0.18:
                            self._arena_bot_shoot(bot, target, charged=False)
            else:
                if bot.nav_timer <= 0.0 or not hasattr(bot, "nav_x"):
                    choose_nav_point()
                nav_x = float(getattr(bot, "nav_x", px + getattr(bot, "roam_dir", 1) * 120.0))
                nav_y = float(getattr(bot, "nav_y", p.y))
                left = nav_x < px - 40.0
                right = nav_x > px + 40.0
                if p.on_ground and nav_y < p.y - 92.0 and random.random() < jump_chance * 0.55:
                    try_jump(-410.0, 1.2)

            speed = (128.0 if bot.style == "tank" else 216.0 if bot.style in {"assassin", "dasher"} else 162.0) * self.current_biome.speed_mult
            if not intent_attack:
                speed *= 0.92
            if p.dash_timer > 0:
                p.dash_timer = max(0.0, p.dash_timer - dt)
                p.vx = p.facing * (620.0 if bot.style != "tank" else 500.0)
            else:
                target_vx = (-speed if left and not right else speed if right and not left else 0.0)
                if target_vx:
                    p.facing = 1 if target_vx > 0 else -1
                    p.vx += (target_vx - p.vx) * min(1.0, 11.5 * dt)
                else:
                    p.vx += (0.0 - p.vx) * min(1.0, 10.0 * dt)
                    if abs(p.vx) < 5:
                        p.vx = 0.0

            gravity = 1060.0 * self.current_biome.gravity_mult
            p.vy += (gravity * 0.25 if p.dash_timer > 0 else gravity) * dt
            old_x = p.x
            old_vx = p.vx
            p.x += p.vx * dt
            p.x = max(8.0, min(self.retro_world_width - p.w - 8.0, p.x))
            hit_wall = False
            for rect in obstacles:
                if self._retro_intersects(p.x, p.y, p.w, p.h, rect):
                    if old_x + p.w <= rect.x:
                        p.x = rect.x - p.w
                        hit_wall = True
                    elif old_x >= rect.x + rect.w:
                        p.x = rect.x + rect.w
                        hit_wall = True
                    p.vx = 0.0
            if hit_wall and p.on_ground and abs(old_vx) > 25.0:
                try_jump(-388.0, 1.05)

            # Saltos de borde/plataforma solo con cooldown y probabilidad: evita el pogo permanente.
            if p.on_ground and target_info and float(getattr(bot, "jump_cooldown", 0.0)) <= 0.0:
                probe_x = p.x + (p.w + 12.0 if p.facing > 0 else -12.0)
                should_jump = self._retro_in_pit(probe_x, p.w)
                if not should_jump and intent_attack:
                    ahead_x = px + p.facing * 104.0
                    for rect in arena_platforms:
                        if rect.x - 12 <= ahead_x <= rect.x + rect.w + 12 and p.y - 210.0 <= rect.y <= p.y - 60.0:
                            should_jump = random.random() < jump_chance
                            break
                if should_jump:
                    try_jump(-426.0, 1.0)

            old_y = p.y
            p.y += p.vy * dt
            p.on_ground = False
            if not self._retro_in_pit(p.x, p.w) and p.y + p.h >= ground:
                p.y = float(ground - p.h)
                p.vy = 0.0
                p.on_ground = True
                p.jumps_used = 0
            for rect in obstacles:
                if self._retro_intersects(p.x, p.y, p.w, p.h, rect):
                    if old_y + p.h <= rect.y:
                        p.y = rect.y - p.h
                        p.vy = 0.0
                        p.on_ground = True
                        p.jumps_used = 0
                    elif old_y >= rect.y + rect.h:
                        p.y = rect.y + rect.h
                        p.vy = 0.0
            if p.y > ground + 240:
                self._damage_arena_bot(bot.index, 4, p.x, attacker_team=None, ability="fall")
            self._unstick_arena_bot(bot, dt, target_info)
            for pickup in self.retro_pickups:
                if pickup.collected or pickup.kind != "point_orb":
                    continue
                if pickup.x - 9 < p.x + p.w and pickup.x + 9 > p.x and pickup.y - 9 < p.y + p.h and pickup.y + 9 > p.y:
                    pickup.collected = True
                    self.arena_scores[bot.index] = self.arena_scores.get(bot.index, 0) + 1
                    self.retro_effects.append(RetroEffect(pickup.x, pickup.y, 22.0, 0.35, "point_orb"))
            if abs(p.vx) > 10 or not p.on_ground:
                p.walk_phase += dt * 10.0

    def _draw_arena_bots(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        if self.selected_mode != "arena":
            return
        for bot in self.arena_bots:
            if not bot.alive:
                continue
            p = bot.player
            x = self._screen_x(p.x)
            y = self._screen_y(p.y)
            if x + p.w < -80 or x > canvas.winfo_width() + 80 or y + p.h < -90 or y > canvas.winfo_height() + 90:
                continue
            # Todas las IAs de Arena usan el mismo color, siempre distinto del jugador.
            sprite_base, sprite_ink = "#ff8c1a", "#2a1200"
            self._draw_player_sprite(canvas, x, y, sprite_base, sprite_ink, facing=p.facing, on_ground=p.on_ground, jumps_used=p.jumps_used, walk_phase=p.walk_phase, hurt_timer=p.hurt_timer)
            self._draw_health_bar(canvas, x - 2, y - 12, p.w + 4, p.hp, p.max_hp, base, ink)
            label = f"{bot.name} {bot.style[:3].upper()} {self.arena_scores.get(bot.index, 0)}"
            canvas.create_text(x + p.w * 0.5, y - 19, text=label, fill="#ff8c1a", font=("Courier New", 5, "bold"))
            if bot.shield_timer > 0:
                canvas.create_rectangle(x - 6, y - 6, x + p.w + 6, y + p.h + 6, outline=ink, width=1)

    def _place_p2_for_mode(self, *, reset_hp: bool = False) -> None:
        self.p2_enabled = self.selected_mode == "multiplayer"
        self.p2_is_cpu = False
        if not self.p2_enabled:
            return
        p2 = self.p2_player
        ground = self._retro_ground_y()
        p2.max_hp = STARTING_PLAYER_HP + (self.hp_upgrade * 5 if self.selected_mode == "multiplayer" else 0)
        if reset_hp or p2.hp <= 0:
            p2.hp = p2.max_hp
        if self.selected_mode == "arena":
            p2.x = max(180.0, self.retro_world_width - 190.0)
            p2.facing = -1
        else:
            p2.x = 154.0
            p2.facing = 1
        p2.y = float(ground - p2.h)
        p2.h = p2.base_h
        p2.crouching = False
        p2.vx = 0.0
        p2.vy = 0.0
        p2.on_ground = True
        p2.jumps_used = 0
        p2.wall_side = 0
        p2.dash_timer = 0.0
        p2.dash_cooldown = 0.0
        p2.attack_timer = 0.0
        p2.attack_cooldown = 0.0
        p2.shoot_cooldown = 0.0
        p2.hurt_timer = 0.0
        p2.flight_left = self._flight_max_duration()
        p2.flight_cooldown = 0.0

    def _reset_arena_round(self, *, winner: str = "") -> None:
        self.retro_player.hp = self.retro_player.max_hp
        self._respawn_player_at_checkpoint()
        self._place_p2_for_mode(reset_hp=True)
        self.retro_projectiles.clear()
        self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 28, 42.0, 0.9, "arena"))
        if winner:
            self.status_notice_text = f"{winner} gana la ronda · {self.p1_score}-{self.p2_score}"
            self.status_notice_timer = 1.8
        if self.p1_score >= 2 or self.p2_score >= 2:
            champ = "P1" if self.p1_score > self.p2_score else ("CPU" if self.p2_is_cpu else "P2")
            self.status_notice_text = f"{champ} gana la arena 2 de 3"
            self.status_notice_timer = 3.0
            self.p1_score = 0
            self.p2_score = 0

    def _p2_key_pressed(self, *names: str) -> bool:
        return any(name in self.pressed_keys for name in names)

    def _p2_jump(self) -> None:
        if not self.p2_enabled:
            return
        p = self.p2_player
        max_jumps = self.selected_character.jumps if self.selected_character else 2
        if self._ability_owned("triple_jump"):
            max_jumps = max(max_jumps, 3)
            if self._has_weapon_special("triple_jump", "fourth_jump"):
                max_jumps = max(max_jumps, 4)
        if p.wall_side and not p.on_ground:
            p.vy = -430.0
            p.vx = -p.wall_side * 285.0
            p.facing = -p.wall_side
            p.jumps_used = 1
        elif p.on_ground:
            p.vy = -462.0
            p.on_ground = False
            p.jumps_used = 1
        elif p.jumps_used < max_jumps:
            p.vy = -408.0 if p.jumps_used == 1 else -368.0
            p.jumps_used += 1

    def _p2_dash(self) -> None:
        if not self.p2_enabled:
            return
        p = self.p2_player
        if p.dash_cooldown > 0:
            return
        direction = 1 if p.facing >= 0 else -1
        if not self.p2_is_cpu:
            if self._p2_key_pressed("j", "J") and not self._p2_key_pressed("l", "L"):
                direction = -1
            elif self._p2_key_pressed("l", "L") and not self._p2_key_pressed("j", "J"):
                direction = 1
        p.facing = direction
        p.vx = direction * 680.0
        p.vy = min(p.vy, 20.0)
        p.dash_timer = 0.18
        p.dash_cooldown = 0.52

    def _p2_shoot(self) -> None:
        if not self.p2_enabled:
            return
        p = self.p2_player
        if p.shoot_cooldown > 0:
            return
        self._spawn_gun_projectile(0, source_x=p.x, source_y=p.y, source_facing=p.facing, owner="p2")
        p.shoot_cooldown = self._gun_shot_cooldown(0)
        self.retro_effects.append(RetroEffect(p.x + p.w * 0.5, p.y + p.h * 0.45, 16.0, 0.25, "p2_shot"))

    def _p2_sword(self) -> None:
        if not self.p2_enabled or not self._ability_owned("sword"):
            return
        p = self.p2_player
        if p.attack_cooldown > 0:
            return
        p.attack_timer = 0.22
        p.attack_cooldown = 0.34 * self._ability_speed_mult("sword")
        self._retro_apply_sword_damage_at(p.x, p.y, p.w, p.h, p.facing, 4 + self._ability_attack_bonus("sword"), "sword")
        if self.friendly_fire and self._retro_intersects(p.x + (p.w if p.facing > 0 else -TILE), p.y + 4, TILE, p.h, RetroRect(self.retro_player.x, self.retro_player.y, self.retro_player.w, self.retro_player.h)):
            self._damage_player(2, p.x)

    def _damage_p2(self, amount: int | float, source_x: float, *, allow_if_hurt: bool = False) -> None:
        if not self.p2_enabled:
            return
        p = self.p2_player
        if p.hurt_timer > 0 and not allow_if_hurt:
            return
        p.hp -= amount
        if p.hp <= 0:
            if self.selected_mode == "arena":
                self.p1_score += 1
                self._reset_arena_round(winner="P1")
                return
            self._place_p2_for_mode(reset_hp=True)
        else:
            p.vx = -math.copysign(285.0, source_x - (p.x + p.w * 0.5))
            p.vy = -245.0
            p.on_ground = False
        p.hurt_timer = 0.68

    def _update_p2_player(self, dt: float, viewport_width: int, viewport_height: int) -> None:
        if not self.p2_enabled:
            return
        p = self.p2_player
        p.dash_cooldown = max(0.0, p.dash_cooldown - dt)
        p.attack_cooldown = max(0.0, p.attack_cooldown - dt)
        p.shoot_cooldown = max(0.0, p.shoot_cooldown - dt)
        p.hurt_timer = max(0.0, p.hurt_timer - dt)
        if p.attack_timer > 0:
            p.attack_timer = max(0.0, p.attack_timer - dt)
            self._retro_apply_sword_damage_at(p.x, p.y, p.w, p.h, p.facing, 4 + self._ability_attack_bonus("sword"), "sword")
        obstacles = self._solid_rects_with_boxes()
        ground = self._retro_ground_y()
        cpu = self.p2_is_cpu
        if cpu:
            target = self.retro_player
            left = target.x + target.w * 0.5 < p.x + p.w * 0.5 - 36
            right = target.x + target.w * 0.5 > p.x + p.w * 0.5 + 36
            if p.on_ground and (target.y < p.y - 40 or random.random() < 0.008):
                self._p2_jump()
            if abs(target.x - p.x) > 210 and p.dash_cooldown <= 0 and random.random() < 0.018:
                p.facing = 1 if target.x > p.x else -1
                self._p2_dash()
            if abs(target.x - p.x) < 95 and abs(target.y - p.y) < 45 and self._ability_owned("sword"):
                self._p2_sword()
            elif p.shoot_cooldown <= 0 and abs(target.y - p.y) < 115:
                p.facing = 1 if target.x > p.x else -1
                self._p2_shoot()
        else:
            left = self._p2_key_pressed("j", "J")
            right = self._p2_key_pressed("l", "L")
        speed = 178.0 * self.current_biome.speed_mult
        if p.dash_timer > 0:
            p.dash_timer = max(0.0, p.dash_timer - dt)
            p.vx = p.facing * 680.0
        else:
            target_vx = 0.0
            if left and not right:
                target_vx = -speed
                p.facing = -1
            elif right and not left:
                target_vx = speed
                p.facing = 1
            if target_vx:
                p.vx += (target_vx - p.vx) * min(1.0, 14.0 * dt)
            else:
                p.vx += (0.0 - p.vx) * min(1.0, 12.0 * dt)
                if abs(p.vx) < 4:
                    p.vx = 0.0
        p.wall_side = self._retro_touching_wall(p, obstacles)
        gravity = 1060.0 * self.current_biome.gravity_mult
        if p.wall_side and not p.on_ground and p.vy > 88:
            p.vy = min(p.vy, 120.0)
        else:
            p.vy += (gravity * 0.22 if p.dash_timer > 0 else gravity) * dt
        old_x = p.x
        p.x += p.vx * dt
        if p.x < 8.0:
            p.x = 8.0
            p.vx = max(0.0, p.vx)
        if p.x + p.w > self.retro_world_width - 8.0:
            p.x = self.retro_world_width - 8.0 - p.w
            p.vx = min(0.0, p.vx)
        for rect in obstacles:
            if not self._retro_intersects(p.x, p.y, p.w, p.h, rect):
                continue
            if p.vx > 0 or (p.vx == 0 and old_x + p.w <= rect.x):
                p.x = rect.x - p.w
                p.wall_side = 1
            elif p.vx < 0 or (p.vx == 0 and old_x >= rect.x + rect.w):
                p.x = rect.x + rect.w
                p.wall_side = -1
            p.vx = 0.0
        old_y = p.y
        p.y += p.vy * dt
        p.on_ground = False
        if not self._retro_in_pit(p.x, p.w) and p.y + p.h >= ground:
            p.y = float(ground - p.h)
            p.vy = 0.0
            p.on_ground = True
            p.jumps_used = 0
        for rect in obstacles:
            if not self._retro_intersects(p.x, p.y, p.w, p.h, rect):
                continue
            if p.vy > 0 or (p.vy == 0 and old_y + p.h <= rect.y):
                p.y = rect.y - p.h
                p.vy = 0.0
                p.on_ground = True
                p.jumps_used = 0
            elif p.vy < 0 or (p.vy == 0 and old_y >= rect.y + rect.h):
                p.y = rect.y + rect.h
                p.vy = 0.0
        if p.y > ground + 220:
            self._damage_p2(2, p.x, allow_if_hurt=True)
            self._place_p2_for_mode(reset_hp=False)
        if p.on_ground:
            p.wall_side = 0
        if abs(p.vx) > 12 or not p.on_ground:
            p.walk_phase += dt * 10.0
        for enemy in self.retro_enemies:
            if not enemy.alive:
                continue
            if not self._retro_intersects(p.x, p.y, p.w, p.h, RetroRect(enemy.x, enemy.y, enemy.w, enemy.h)):
                continue
            falling_on_enemy = p.vy > 0 and p.y + p.h - 8 < enemy.y + enemy.h * 0.55
            if self._ability_owned("parry") and falling_on_enemy:
                self._retro_damage_enemy(enemy, self._parry_damage(), p.facing, ability="parry")
                self.parry_timer = max(getattr(self, "parry_timer", 0.0), self._parry_window())
                p.vy = -self._parry_bounce_velocity()
                p.on_ground = False
                p.jumps_used = max(1, p.jumps_used)
                continue
            if self._ability_owned("nova") and p.dash_timer > 0:
                if enemy.hurt_flash <= 0:
                    self._retro_damage_enemy(enemy, self._nova_damage(), p.facing, ability="nova")
                continue
            if p.hurt_timer <= 0:
                self._damage_p2(enemy.attack, enemy.x + enemy.w * 0.5)

    def _update_retro_game(self, dt: float) -> None:
        viewport_width = max(360, self.canvas.winfo_width())
        viewport_height = max(220, self.canvas.winfo_height())
        self._ensure_retro_world(viewport_width, viewport_height)
        if self._is_tutorial_mode() and self.level_intro_timer > 0.0:
            # Failsafe: el tutorial nunca debe quedarse esperando una intro o un
            # estado temporal heredado; debe responder desde el primer frame.
            self.level_intro_timer = 0.0
        player = self.retro_player
        ground = self._retro_ground_y()
        obstacles = self._solid_rects_with_boxes()

        if self.selected_mode == "multiplayer":
            # En multijugador J1 no tiene doble control: solo flechas.
            left = self._retro_key_pressed("Left")
            right = self._retro_key_pressed("Right")
            climb = self._retro_key_pressed("Up")
            crouch = self._retro_key_pressed("Down")
        else:
            left = self._retro_key_pressed("Left", "a", "A")
            right = self._retro_key_pressed("Right", "d", "D")
            climb = self._retro_key_pressed("Up", "w", "W")
            crouch = self._retro_key_pressed("Down", "s", "S")
        running = self._retro_key_pressed("Shift_L", "Shift_R")
        speed = (292.0 if running else 178.0) * self.current_biome.speed_mult
        if crouch and player.on_ground:
            speed *= 0.46
        # Agacharse: baja hitbox real y permite entrar en huecos bajos.
        # Ahora también puede mantenerse en el aire: así el salto desde agachado responde al instante
        # y no fuerza al jugador a levantarse bajo techos bajos.
        desired_h = player.crouch_h if crouch and player.dash_timer <= 0 else player.base_h
        if desired_h < player.h:
            delta = player.h - desired_h
            player.y += delta
            player.h = desired_h
            player.crouching = True
        elif desired_h > player.h:
            delta = desired_h - player.h
            test_rect = RetroRect(player.x, player.y - delta, player.w, desired_h, "stand_test")
            can_stand = not any(self._retro_intersects(test_rect.x, test_rect.y, test_rect.w, test_rect.h, rect) for rect in obstacles)
            if can_stand:
                player.y -= delta
                player.h = desired_h
                player.crouching = False
            else:
                player.crouching = True
        acceleration = 18.0 if player.on_ground else 10.0
        friction = 16.0 if player.on_ground else 3.8

        self.perfect_dash_timer = max(0.0, getattr(self, "perfect_dash_timer", 0.0) - dt)
        self.parry_timer = max(0.0, getattr(self, "parry_timer", 0.0) - dt)
        self.status_notice_timer = max(0.0, getattr(self, "status_notice_timer", 0.0) - dt)
        self.challenge_safe_timer = max(0.0, getattr(self, "challenge_safe_timer", 0.0) - dt)
        self.combo_timer = max(0.0, getattr(self, "combo_timer", 0.0) - dt)
        if self.combo_timer <= 0:
            self.combo_count = 0
        self.orbit_blades_timer = max(0.0, getattr(self, "orbit_blades_timer", 0.0) - dt)
        player.dash_cooldown = max(0.0, player.dash_cooldown - dt)
        player.attack_cooldown = max(0.0, player.attack_cooldown - dt)
        player.shoot_cooldown = max(0.0, player.shoot_cooldown - dt)
        player.hurt_timer = max(0.0, player.hurt_timer - dt)
        if self._is_mode_night():
            max_battery = self._flashlight_battery_max()
            if self.flashlight_on:
                self.flashlight_energy = max(0.0, min(max_battery, self.flashlight_energy) - dt)
                self._flashlight_session_used = min(max_battery, getattr(self, "_flashlight_session_used", 0.0) + dt)
                if self.flashlight_energy <= 0.0:
                    self.flashlight_on = False
                    self.flashlight_recharge = max_battery
                    self.flashlight_recharge_total = max_battery
                    self._flashlight_session_used = 0.0
            elif self.flashlight_recharge > 0.0:
                self.flashlight_recharge = max(0.0, self.flashlight_recharge - dt)
                if self.flashlight_recharge <= 0.0:
                    self.flashlight_energy = max_battery
                    self.flashlight_recharge_total = 0.0
            elif self.flashlight_energy < max_battery:
                # Apagada manualmente: recupera algo de energía sin bloquear F.
                self.flashlight_energy = min(max_battery, self.flashlight_energy + dt * 1.35)
        else:
            self.flashlight_on = False
        shield_was_active = self.shield_timer > 0
        self.shield_timer = max(0.0, self.shield_timer - dt)
        if shield_was_active and self.shield_timer <= 0 and self._ability_owned("shield") and self._has_weapon_special("shield", "cooldown_shadow"):
            self._activate_clone(self._shield_clone_duration())
        self.shield_cooldown = max(0.0, self.shield_cooldown - dt)
        self.slow_time_timer = max(0.0, self.slow_time_timer - dt)
        self.slow_time_cooldown = max(0.0, self.slow_time_cooldown - dt)
        self._time_space_teleport_cooldown = max(0.0, getattr(self, "_time_space_teleport_cooldown", 0.0) - dt)
        if self.slow_time_timer <= 0.0:
            self._time_space_pending_teleport = False
            self._time_space_teleport_cooldown = 0.0
        slow_dt = dt * self._time_slow_factor()
        if self.clone_timer > 0:
            self.clone_timer = max(0.0, self.clone_timer - dt)
            self.clone_history.append((time.perf_counter(), player.x, player.y, player.facing, player.on_ground, player.jumps_used))
            cutoff = time.perf_counter() - 0.75
            self.clone_history = [snapshot for snapshot in self.clone_history if snapshot[0] >= cutoff]
        else:
            self.clone_history.clear()
        if player.attack_timer > 0:
            player.attack_timer = max(0.0, player.attack_timer - dt)
            self._retro_apply_sword_damage()
        player.flight_cooldown = max(0.0, player.flight_cooldown - dt)
        if player.flight_cooldown <= 0.0 and player.flight_left <= 0.0:
            player.flight_left = self._flight_max_duration()
        if player.on_ground and player.flight_cooldown <= 0.0:
            player.flight_left = self._flight_max_duration()

        if self.selected_mode == "arena" and self.arena_match_over:
            self.retro_effects = [RetroEffect(e.x, e.y, e.radius + 24.0 * dt, e.life - dt, e.kind) for e in self.retro_effects if e.life > dt]
            return

        if self.selected_mode == "arena" and self.arena_player_respawn_timer > 0.0:
            # Mientras J1 espera respawn, se congelan sus inputs pero la simulación de IA/proyectiles sigue.
            player.vx = player.vy = 0.0
            player.hurt_timer = max(player.hurt_timer, 0.15)
            player.x = -5000.0
            self._update_arena_bots(dt, viewport_width, viewport_height)
            self._update_projectiles(dt, viewport_width, viewport_height)
            self._update_arena_match(dt)
            self.retro_effects = [RetroEffect(e.x, e.y, e.radius + 24.0 * dt, e.life - dt, e.kind) for e in self.retro_effects if e.life > dt]
            self._retro_update_camera(viewport_width, viewport_height)
            return

        dashing = player.dash_timer > 0
        if dashing:
            player.dash_timer = max(0.0, player.dash_timer - dt)
            player.vx = player.facing * 680.0
        else:
            target_vx = 0.0
            if left and not right:
                target_vx = -speed
                player.facing = -1
            elif right and not left:
                target_vx = speed
                player.facing = 1
            if target_vx:
                player.vx += (target_vx - player.vx) * min(1.0, acceleration * dt)
            else:
                player.vx += (0.0 - player.vx) * min(1.0, friction * dt)
                if abs(player.vx) < 4:
                    player.vx = 0.0

        player.wall_side = self._retro_touching_wall(player, obstacles)
        gravity = 1060.0 * self.current_biome.gravity_mult
        using_flight = self._flight_pressed() and player.flight_left > 0 and player.flight_cooldown <= 0.0 and not player.on_ground
        if using_flight:
            player.flight_left = max(0.0, player.flight_left - dt)
            if player.flight_left <= 0.0:
                player.flight_cooldown = FLIGHT_COOLDOWN
            player.flight_bob += dt * 11.0
            # Jetpack real: mantiene altura; Up/W asciende y Down/S desciende con control fino.
            hover_vy = math.sin(player.flight_bob) * 8.0
            if climb and not crouch:
                hover_vy = -155.0
            elif crouch and not climb:
                hover_vy = 145.0
            player.vy += (hover_vy - player.vy) * min(1.0, 18.0 * dt)
            self._try_open_secret_gates("flight")
            if self._has_weapon_special("flight", "down_shots"):
                self._flight_downshot_timer -= dt
                if self._flight_downshot_timer <= 0:
                    self._flight_downshot_timer = self._gun_shot_cooldown(0)
                    cx = player.x + player.w * 0.5
                    cy = player.y + player.h + 4.0
                    for ox, vx in ((-8.0, -65.0), (8.0, 65.0)):
                        self.retro_projectiles.append(RetroProjectile(cx + ox, cy, vx, 540.0, 0.9, 1 + self._ability_attack_bonus("gun"), "charged", 0, "player", cx + ox, cy, 560.0, ability="gun"))
            if self._has_weapon_special("flight", "flight_bombs"):
                self._flight_bomb_timer += dt
                if self._flight_bomb_timer >= 1.0:
                    self._flight_bomb_timer = 0.0
                    self.retro_projectiles.append(RetroProjectile(player.x + player.w * 0.5, player.y + player.h, 0.0, 150.0, 4.0, 3 + self._ability_attack_bonus("flight"), "bomb", 0, "player", player.x, player.y, 9999.0, gravity=1040.0, radius=54.0, ability="flight"))
        else:
            self._flight_downshot_timer = 0.0
            self._flight_bomb_timer = 0.0
        if using_flight:
            # Sin gravedad normal durante vuelo: el Jetpack mantiene la altura en vez de planear.
            pass
        elif player.wall_side and not player.on_ground and climb:
            player.vy = min(player.vy, -120.0 if not crouch else 145.0)
            player.vy -= 280.0 * dt
        elif player.wall_side and not player.on_ground and player.vy > 88:
            player.vy = min(player.vy, 120.0)
        else:
            player.vy += (gravity * 0.22 if dashing else gravity) * dt

        # Mecánicas por bioma: corrientes, viento, baja gravedad, lava peligrosa y autopistas urbanas.
        if self.current_biome.key == "water" and not player.on_ground:
            player.vx += math.sin(self.anim_phase * 0.7 + player.y * 0.01) * 34.0 * dt
            player.vy *= 0.992
        elif self.current_biome.key == "valley":
            player.vx += math.sin(self.anim_phase * 0.9 + player.x * 0.004) * 72.0 * dt
        elif self.current_biome.key == "city" and player.on_ground:
            player.vx += math.sin(player.x * 0.006) * 28.0 * dt
        elif self.current_biome.key == "mountain" and not player.on_ground:
            player.vx += math.sin(self.anim_phase * 1.3) * 36.0 * dt

        old_x = player.x
        player.x += player.vx * dt
        if player.x < 8.0:
            player.x = 8.0
            if player.vx < 0:
                player.vx = 0.0
        if player.x + player.w > self.retro_world_width - 8.0:
            player.x = self.retro_world_width - 8.0 - player.w
            if player.vx > 0:
                player.vx = 0.0
        if self._ability_owned("nova") and player.dash_timer > 0:
            self._try_open_secret_gates("nova", area=(player.x, player.y, player.w, player.h))
            obstacles = self._solid_rects_with_boxes()
        for rect in obstacles:
            if not self._retro_intersects(player.x, player.y, player.w, player.h, rect):
                continue
            if player.vx > 0 or (player.vx == 0 and old_x + player.w <= rect.x):
                player.x = rect.x - player.w
                player.wall_side = 1
            elif player.vx < 0 or (player.vx == 0 and old_x >= rect.x + rect.w):
                player.x = rect.x + rect.w
                player.wall_side = -1
            player.vx = 0.0

        old_y = player.y
        player.y += player.vy * dt
        player.on_ground = False
        has_ground = not self._retro_in_pit(player.x, player.w)
        if has_ground and player.y + player.h >= ground:
            player.y = float(ground - player.h)
            player.vy = 0.0
            player.on_ground = True
            player.jumps_used = 0
        for rect in obstacles:
            if not self._retro_intersects(player.x, player.y, player.w, player.h, rect):
                continue
            if player.vy > 0 or (player.vy == 0 and old_y + player.h <= rect.y):
                player.y = rect.y - player.h
                player.vy = 0.0
                player.on_ground = True
                player.jumps_used = 0
            elif player.vy < 0 or (player.vy == 0 and old_y >= rect.y + rect.h):
                player.y = rect.y + rect.h
                player.vy = 0.0
        if player.y < 8.0:
            player.y = 8.0
            player.vy = max(0.0, player.vy)
        if self.current_biome.key == "lava" and self._retro_in_pit(player.x, player.w) and player.y + player.h > ground + 10:
            self._retro_respawn(viewport_width, viewport_height, damage=2)
        elif self.current_biome.key == "water" and self._retro_in_pit(player.x, player.w) and player.y + player.h > ground + 120:
            self._retro_respawn(viewport_width, viewport_height, damage=1)
        elif player.y > ground + 220:
            self._retro_respawn(viewport_width, viewport_height, damage=1)
        elif player.hurt_timer <= 0 and any(self._retro_intersects(player.x + 3, player.y + player.h - 12, player.w - 6, 10, trap) for trap in self._trap_rects()):
            self._damage_player(1, player.x + player.w * 0.5, allow_if_hurt=True)
            player.vy = -260.0
            player.on_ground = False
            self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h, 22.0, 0.36, "trap"))

        self._update_hard_spike_wall(slow_dt, viewport_width, viewport_height)
        self._update_p2_player(dt, viewport_width, viewport_height)
        self._update_arena_bots(dt, viewport_width, viewport_height)
        self._update_shadow_chasers(dt)
        self._update_boxes(slow_dt)

        player.wall_side = self._retro_touching_wall(player, obstacles)
        if player.on_ground:
            player.wall_side = 0
        if abs(player.vx) > 12 or not player.on_ground:
            player.walk_phase += dt * (9.0 if not running else 15.0)

        self._update_level_hazards(dt, viewport_width, viewport_height)
        self._update_enemies(slow_dt, viewport_width, viewport_height)
        self._update_projectiles(dt, viewport_width, viewport_height)
        self._update_pickups()
        self._update_checkpoints()
        self._update_race_finish(viewport_width, viewport_height)
        self._update_arena_match(dt)
        self.retro_effects = [RetroEffect(e.x, e.y, e.radius + (70.0 * dt if e.kind in {"boom", "secret"} else 24.0 * dt), e.life - dt, e.kind) for e in self.retro_effects if e.life > dt]
        if self.win_banner_timer > 0:
            self.win_banner_timer = max(0.0, self.win_banner_timer - dt)
        if self.level_intro_timer > 0:
            self.level_intro_timer = max(0.0, self.level_intro_timer - dt)
        if self.selected_mode == "challenge" and self.level_intro_timer <= 0 and self._pending_level_advance <= 0:
            # El Desafío ya no termina por reloj: las 8 sombras presionan hasta
            # derrotar al jefe exclusivo del otro lado del mapa.
            self.challenge_timer = max(0.0, self.challenge_timer - dt)
        if self._pending_level_advance > 0:
            self._pending_level_advance = max(0.0, self._pending_level_advance - dt)
            if self._pending_level_advance <= 0:
                self._advance_to_next_level(viewport_width, viewport_height)
                return
        self._retro_update_camera(viewport_width, viewport_height)

    def _update_level_hazards(self, dt: float, viewport_width: int, viewport_height: int) -> None:
        if self.selected_mode in {"arena", "challenge"} or self._is_tutorial_mode():
            return
        if not hasattr(self, "_level_hazard_timer"):
            self._level_hazard_timer = 0.0
        self._level_hazard_timer -= dt
        if self._level_hazard_timer > 0:
            return
        hazard = str(getattr(self, "level_spec", {}).get("hazard", ""))
        player = self.retro_player
        aerial_pressure = float(getattr(self, "level_spec", {}).get("aerial_hazard_density", 2.0))
        if hazard not in {"storm", "vertical", "unstable", "elite"}:
            self._level_hazard_timer = max(0.90, 2.2 / max(0.5, aerial_pressure))
        if hazard == "storm":
            self._level_hazard_timer = max(0.75, 1.8 / aerial_pressure)
            x = player.x + random.choice((-420, -220, 220, 420))
            y = max(40.0, player.y - random.randint(80, 260))
            self.retro_projectiles.append(RetroProjectile(x, y, math.copysign(210.0, player.x - x), 55.0, 4.0, 1, "enemy_storm", 0, "enemy", x, y, 900.0))
            self.retro_effects.append(RetroEffect(x, y, 20.0, 0.4, "storm"))
        elif hazard == "vertical":
            self._level_hazard_timer = 2.2
            self.retro_effects.append(RetroEffect(player.x, player.y - 40.0, 28.0, 0.35, "wind"))
        elif hazard == "unstable":
            self._level_hazard_timer = 3.0
            # Marca visual: algunas plataformas parpadean; no se borran para evitar bloquear rutas.
            self.retro_effects.append(RetroEffect(player.x + player.w * .5, player.y - 40.0, 32.0, 0.45, "unstable"))
        elif hazard == "elite":
            self._level_hazard_timer = 8.0
            if random.random() < 0.35 and sum(1 for e in self.retro_enemies if e.alive and e.kind == "elite") < 3:
                ew, eh, hp, attack, speed = ENEMY_STATS["elite"]
                hp, attack = self._scaled_enemy_stats(hp, attack)
                sx = min(self.retro_world_width - 120.0, max(260.0, player.x + random.choice((-360, 360))))
                sy = float(self._retro_ground_y() - eh)
                self.retro_enemies.append(RetroEnemy(sx, sy, ew, eh, math.copysign(speed, player.x - sx), "elite", hp, hp, attack, sx - 220, sx + 220, home_y=sy, status_effects={}, armor=1.0, weakness=random.choice(("fire", "ice", "lightning", "sonic")), elite_mod=random.choice(("rápido", "duro", "veneno"))))
        # Presión aérea universal v39: aunque el modificador no sea tormenta, el aire nunca queda vacío.
        if random.random() < 0.35:
            x = player.x + random.choice((-360, 360, 520))
            y = max(50.0, player.y - random.randint(120, 360))
            vx = math.copysign(190.0 + random.random() * 80.0, player.x - x)
            self.retro_projectiles.append(RetroProjectile(x, y, vx, random.uniform(18.0, 70.0), 3.2, 1, "enemy_air", 0, "enemy", x, y, 760.0))
            self.retro_effects.append(RetroEffect(x, y, 16.0, 0.25, "air_warning"))

    def _update_boxes(self, dt: float) -> None:
        ground = self._retro_ground_y()
        obstacles = self._solid_rects()
        player = self.retro_player
        for box in self.retro_boxes:
            if box.grabbed:
                continue
            old_x = box.x
            old_y = box.y
            player_was_on_box = (
                player.vy >= -20.0
                and player.x + player.w > old_x + 2.0
                and player.x < old_x + box.w - 2.0
                and abs((player.y + player.h) - old_y) <= 6.0
            )
            box.vy += 1040.0 * dt
            box.x += box.vx * dt
            box.y += box.vy * dt
            box.vx *= max(0.0, 1.0 - 5.0 * dt)
            moved_dx = box.x - old_x
            moved_dy = box.y - old_y
            if box.x < 8.0:
                box.x = 8.0
                box.vx = 0.0
            if box.x + box.w > self.retro_world_width - 8.0:
                box.x = self.retro_world_width - box.w - 8.0
                box.vx = 0.0
            for rect in obstacles:
                if not self._retro_intersects(box.x, box.y, box.w, box.h, rect):
                    continue
                if old_y + box.h <= rect.y + 2 and box.vy >= 0:
                    box.y = rect.y - box.h
                    box.vy = 0.0
                elif old_y >= rect.y + rect.h - 2 and box.vy < 0:
                    box.y = rect.y + rect.h
                    box.vy = 0.0
                elif old_x + box.w <= rect.x + 2:
                    box.x = rect.x - box.w
                    box.vx = 0.0
                elif old_x >= rect.x + rect.w - 2:
                    box.x = rect.x + rect.w
                    box.vx = 0.0
            if not self._retro_in_pit(box.x, box.w) and box.y + box.h >= ground:
                box.y = float(ground - box.h)
                box.vy = 0.0
            if box.y > ground + 260:
                box.y = float(ground - box.h)
                box.vy = 0.0
            if player_was_on_box:
                player.x = max(8.0, min(self.retro_world_width - player.w - 8.0, player.x + moved_dx))
                player.y = box.y - player.h
                player.vy = min(player.vy, 0.0)
                player.on_ground = True
                player.jumps_used = 0
            elif self._retro_intersects(player.x, player.y, player.w, player.h, box):
                if moved_dx > 0:
                    player.x = min(self.retro_world_width - player.w - 8.0, box.x + box.w)
                elif moved_dx < 0:
                    player.x = max(8.0, box.x - player.w)
            if abs(moved_dx) > 0.01 or abs(moved_dy) > 0.01:
                self._push_enemies_with_box(box, moved_dx, moved_dy)

    def _update_pickups(self) -> None:
        player = self.retro_player
        for pickup in self.retro_pickups:
            if pickup.collected:
                continue
            if pickup.x - 8 < player.x + player.w and pickup.x + 8 > player.x and pickup.y - 8 < player.y + player.h and pickup.y + 8 > player.y:
                pickup.collected = True
                if pickup.kind == "xp_orb":
                    self.xp_count += 1
                    self.retro_effects.append(RetroEffect(pickup.x, pickup.y, 20.0, 0.35, "xp_orb"))
                elif pickup.kind == "point_orb":
                    self.xp_count += 1
                    self.arena_scores[self.arena_player_team] = self.arena_scores.get(self.arena_player_team, 0) + 1
                    self.p1_score = self.arena_scores[self.arena_player_team]
                    self.retro_effects.append(RetroEffect(pickup.x, pickup.y, 22.0, 0.35, "point_orb"))
                elif pickup.kind == "heal":
                    self.heal_tanks += 1
                    self.retro_effects.append(RetroEffect(pickup.x, pickup.y, 26.0, 0.45, "tank"))

    def _update_checkpoints(self) -> None:
        player = self.retro_player
        for index, checkpoint in enumerate(self.retro_checkpoints):
            if abs((player.x + player.w * 0.5) - checkpoint.x) <= 36 and abs((player.y + player.h * 0.5) - checkpoint.y) <= 62:
                if not checkpoint.activated:
                    checkpoint.activated = True
                    self.retro_effects.append(RetroEffect(checkpoint.x, checkpoint.y, 42.0, 0.65, "checkpoint"))
                if index > self.active_checkpoint_index:
                    self.active_checkpoint_index = index
                    self._save_mode_progress()

    def _find_nearest_hostile_enemy(self, x: float, y: float, max_dist: float = 900.0) -> RetroEnemy | None:
        candidates = [e for e in self.retro_enemies if e.alive and not self._enemy_is_ally(e) and math.hypot((e.x + e.w * 0.5) - x, (e.y + e.h * 0.5) - y) <= max_dist]
        if not candidates:
            return None
        return min(candidates, key=lambda e: math.hypot((e.x + e.w * 0.5) - x, (e.y + e.h * 0.5) - y))

    def _spawn_ally_projectile(self, ally: RetroEnemy, target: RetroEnemy, *, speed: float = 360.0, damage: int | float = 1, spread: float = 0.0, kind: str = "ally_bullet") -> None:
        ax, ay = self._enemy_center(ally)
        tx, ty = self._enemy_center(target)
        angle = math.atan2(ty - ay, tx - ax) + spread
        vx = math.cos(angle) * speed
        vy = math.sin(angle) * speed
        self.retro_projectiles.append(RetroProjectile(ax, ay, vx, vy, 2.2, damage, kind, 0, "ally", ax, ay, 820.0, ability="n_resurrection"))

    def _damage_resurrected_ally(self, ally: RetroEnemy, amount: int | float, source_x: float = 0.0) -> None:
        if not ally.alive:
            return
        ally.hp -= max(0.1, float(amount))
        ally.hurt_flash = 0.18
        if ally.hp <= 0:
            ally.alive = False
            self.retro_effects.append(RetroEffect(ally.x + ally.w * 0.5, ally.y + ally.h * 0.5, max(ally.w, ally.h), 0.55, "defeat"))

    def _update_resurrected_ally(self, ally: RetroEnemy, dt: float, speed_factor: float, ground: int) -> None:
        player = self.retro_player
        ax, ay = self._enemy_center(ally)
        target = self._find_nearest_hostile_enemy(ax, ay, 940.0)
        base_speed = ENEMY_STATS.get(ally.kind, ENEMY_STATS["minor"])[4]
        if target is None:
            desired_x = player.x - player.facing * 72.0
            dx = desired_x - ally.x
            ally.vx = math.copysign(max(24.0, min(base_speed, abs(dx) * 1.8)), dx) if abs(dx) > 18 else 0.0
            ally.x += ally.vx * dt * speed_factor
            if ally.kind in {"flyer", "ghost"}:
                ally.y += (player.y - 40.0 - ally.y) * min(1.0, 2.5 * dt)
            else:
                ally.y = min(float(ground - ally.h), ally.y + 180.0 * dt)
            return
        tx, ty = self._enemy_center(target)
        dx = tx - ax
        dy = ty - ay
        dist = max(1.0, math.hypot(dx, dy))
        ally.vx = math.copysign(max(32.0, base_speed * (1.18 if ally.kind == "ninja" else 0.86)), dx)
        if abs(dx) > 44:
            ally.x += ally.vx * dt * speed_factor
        if ally.kind in {"flyer", "ghost"}:
            ally.y += (ty - ally.h * 0.5 - ally.y) * min(1.0, 3.0 * dt)
            ally.y += math.sin(ally.phase * 3.0) * 18.0 * dt
        else:
            ally.y = min(float(ground - ally.h), max(40.0, ally.y + (60.0 if ally.y < ground - ally.h else 0.0) * dt))
        ally.shoot_timer -= dt * speed_factor
        attack_damage = max(1.0, ally.attack)
        if ally.kind == "hunter":
            if ally.shoot_timer <= 0 and dist < 720.0:
                ally.shoot_timer = 0.62
                self._spawn_ally_projectile(ally, target, speed=440.0, damage=attack_damage, spread=-0.12, kind="ally_shotgun")
                self._spawn_ally_projectile(ally, target, speed=440.0, damage=attack_damage, spread=0.12, kind="ally_shotgun")
        elif ally.kind == "ninja":
            if dist < 52.0 and ally.shoot_timer <= 0:
                ally.shoot_timer = 0.45
                self._retro_damage_enemy(target, attack_damage + 0.65, 1 if dx >= 0 else -1, ability="n_resurrection")
                self.retro_effects.append(RetroEffect(tx, ty, 22.0, 0.22, "slash"))
            elif ally.shoot_timer <= 0 and dist < 760.0:
                ally.shoot_timer = 0.92
                self._spawn_ally_projectile(ally, target, speed=520.0, damage=attack_damage, kind="ally_star")
        elif ally.kind in {"turret", "sniper", "bomber", "flyer", "ghost", "elite"}:
            if ally.shoot_timer <= 0 and dist < 760.0:
                ally.shoot_timer = 1.05 if ally.kind != "sniper" else 1.45
                self._spawn_ally_projectile(ally, target, speed=460.0 if ally.kind != "sniper" else 600.0, damage=attack_damage)
        elif dist < 46.0 and ally.shoot_timer <= 0:
            ally.shoot_timer = 0.75
            self._retro_damage_enemy(target, attack_damage, 1 if dx >= 0 else -1, ability="n_resurrection")
            self.retro_effects.append(RetroEffect(tx, ty, 20.0, 0.22, "resurrection_hit"))
        else:
            if ally.shoot_timer <= 0 and dist < 520.0:
                ally.shoot_timer = 1.25
                self._spawn_ally_projectile(ally, target, speed=360.0, damage=max(1.0, attack_damage * 0.8))

    def _update_enemies(self, dt: float, viewport_width: int, viewport_height: int) -> None:
        player = self.retro_player
        ground = self._retro_ground_y()
        for enemy in list(self.retro_enemies):
            if not enemy.alive:
                continue
            enemy.phase += dt
            enemy.pattern_timer += dt
            enemy.hurt_flash = max(0.0, enemy.hurt_flash - dt)

            # Estados elementales: slow, stun/root, poison/burn, mark, rupture.
            speed_factor = 1.0
            if enemy.status_effects:
                for key in list(enemy.status_effects.keys()):
                    enemy.status_effects[key] -= dt
                    if enemy.status_effects[key] <= 0:
                        del enemy.status_effects[key]
                if "slow" in enemy.status_effects:
                    speed_factor *= 0.46
                if "root" in enemy.status_effects or "stun" in enemy.status_effects:
                    speed_factor *= 0.05
                if "poison" in enemy.status_effects and int(enemy.phase * 5) != int((enemy.phase - dt) * 5):
                    self._retro_damage_enemy(enemy, 0.35, 0, ability="poison")
                    if not enemy.alive:
                        continue
                if "burn" in enemy.status_effects and int(enemy.phase * 6) != int((enemy.phase - dt) * 6):
                    self._retro_damage_enemy(enemy, 0.45, 0, ability="fire")
                    if not enemy.alive:
                        continue

            if self._enemy_is_ally(enemy):
                self._update_resurrected_ally(enemy, dt, speed_factor, ground)
                continue

            # IA mejorada: los enemigos no jefe amplían su lectura de jugador y ajustan
            # dirección dentro de su patrulla en lugar de caminar siempre como metrónomo.
            if not enemy.kind.startswith("boss") and enemy.kind not in {"turret", "sniper"}:
                dx_to_player = (player.x + player.w * 0.5) - (enemy.x + enemy.w * 0.5)
                if abs(dx_to_player) < 560 and abs(player.y - enemy.y) < 260:
                    base_speed = ENEMY_STATS.get(enemy.kind, ENEMY_STATS["minor"])[4]
                    enemy.vx = math.copysign(max(abs(enemy.vx), base_speed * 0.72), dx_to_player)
                    enemy.patrol_left = max(24.0, min(enemy.patrol_left, enemy.x - 48.0))
                    enemy.patrol_right = min(float(self.retro_world_width - 24.0), max(enemy.patrol_right, enemy.x + enemy.w + 48.0))

            if self.selected_mode == "challenge" and enemy.kind == "boss_shadow_warp" and getattr(self, "challenge_safe_timer", 0.0) > 0.0:
                enemy.shoot_timer = max(enemy.shoot_timer, getattr(self, "challenge_safe_timer", 0.0) + 0.65)
                enemy.pattern_timer = 0.0
                continue

            if enemy.kind.startswith("boss"):
                self._update_boss(enemy, dt * speed_factor, player)
            elif enemy.kind == "flyer":
                enemy.y = enemy.home_y + math.sin(enemy.phase * 2.6) * 34.0
                enemy.x += enemy.vx * dt * speed_factor
            elif enemy.kind == "hopper":
                enemy.y = enemy.home_y - abs(math.sin(enemy.phase * 2.4)) * 42.0
                enemy.x += enemy.vx * dt * speed_factor
            elif enemy.kind == "turret":
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0 and abs(enemy.x - player.x) < 850 and abs(enemy.y - player.y) < 480:
                    enemy.shoot_timer = self._enemy_fire_cooldown(2.1)
                    self._spawn_enemy_bullet(enemy, speed=330.0, damage=enemy.attack)
            elif enemy.kind == "sniper":
                enemy.shoot_timer -= dt * speed_factor
                enemy.x += enemy.vx * 0.28 * dt * speed_factor
                if enemy.shoot_timer <= 0 and abs(enemy.x - player.x) < 1000 and abs(enemy.y - player.y) < 420:
                    enemy.shoot_timer = self._enemy_fire_cooldown(3.0)
                    self._spawn_enemy_bullet(enemy, speed=520.0, damage=enemy.attack + 0.75)
            elif enemy.kind == "ninja":
                dx_to_player = (player.x + player.w * 0.5) - (enemy.x + enemy.w * 0.5)
                if abs(dx_to_player) < 620:
                    enemy.vx = math.copysign(max(abs(enemy.vx), 132.0), dx_to_player)
                enemy.x += enemy.vx * 1.05 * dt * speed_factor
                if enemy.pattern_timer > 1.55 and abs(dx_to_player) < 260:
                    enemy.pattern_timer = 0.0
                    enemy.vx = math.copysign(190.0, dx_to_player)
                    self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.5, 28.0, 0.22, "dash"))
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0 and abs(dx_to_player) < 720 and abs(enemy.y - player.y) < 360:
                    enemy.shoot_timer = self._enemy_fire_cooldown(1.05)
                    self._spawn_enemy_bullet(enemy, speed=520.0, damage=enemy.attack, kind="ninja_star")
                if abs(dx_to_player) < 42 and abs(enemy.y - player.y) < 48 and player.hurt_timer <= 0:
                    self._damage_player(enemy.attack + 0.5, enemy.x + enemy.w * 0.5)
                    self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h * 0.5, 18.0, 0.22, "slash"))
            elif enemy.kind == "hunter":
                dx_to_player = (player.x + player.w * 0.5) - (enemy.x + enemy.w * 0.5)
                enemy.x += enemy.vx * 0.48 * dt * speed_factor
                if abs(dx_to_player) < 540:
                    enemy.vx = math.copysign(max(28.0, abs(enemy.vx)), dx_to_player)
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0 and abs(dx_to_player) < 680 and abs(enemy.y - player.y) < 360:
                    enemy.shoot_timer = 0.62
                    self._spawn_enemy_bullet(enemy, speed=430.0, damage=enemy.attack, spread=-0.14, kind="hunter_shell")
                    self._spawn_enemy_bullet(enemy, speed=430.0, damage=enemy.attack, spread=0.14, kind="hunter_shell")
            elif enemy.kind == "bomber":
                enemy.x += enemy.vx * 0.55 * dt * speed_factor
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0 and abs(enemy.x - player.x) < 620:
                    enemy.shoot_timer = self._enemy_fire_cooldown(2.45)
                    direction = 1 if player.x > enemy.x else -1
                    ex, ey = self._enemy_center(enemy)
                    self.retro_projectiles.append(RetroProjectile(ex, ey, direction * 190.0, -270.0, 2.2, enemy.attack + 0.5, "enemy_bomb", 0, "enemy", ex, ey, 860.0, gravity=760.0, radius=50.0))
            elif enemy.kind == "burrower":
                if enemy.pattern_timer > 2.4:
                    enemy.pattern_timer = 0.0
                    enemy.x = max(enemy.patrol_left, min(enemy.patrol_right - enemy.w, player.x + random.choice((-140, 140))))
                    enemy.y = min(float(ground - enemy.h), player.y + 8)
                    self.retro_effects.append(RetroEffect(enemy.x + enemy.w * .5, enemy.y + enemy.h, 24.0, 0.32, "burrow"))
                else:
                    enemy.x += enemy.vx * 0.4 * dt * speed_factor
            elif enemy.kind == "healer":
                enemy.x += enemy.vx * 0.45 * dt * speed_factor
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0:
                    enemy.shoot_timer = self._enemy_fire_cooldown(2.0)
                    for ally in self.retro_enemies:
                        if ally.alive and ally is not enemy and math.hypot((ally.x- enemy.x), (ally.y- enemy.y)) < 260:
                            ally.hp = min(ally.max_hp, ally.hp + 1)
                    self.retro_effects.append(RetroEffect(enemy.x + enemy.w * .5, enemy.y + enemy.h * .5, 40.0, 0.35, "heal"))
            elif enemy.kind == "leech":
                enemy.vx = math.copysign(max(abs(enemy.vx), 64.0), player.x - enemy.x)
                enemy.x += enemy.vx * dt * speed_factor
            elif enemy.kind == "kamikaze":
                if abs(enemy.x - player.x) < 430:
                    enemy.vx = math.copysign(145.0, player.x - enemy.x)
                enemy.x += enemy.vx * dt * speed_factor
                if math.hypot((enemy.x + enemy.w*.5) - (player.x + player.w*.5), (enemy.y + enemy.h*.5) - (player.y + player.h*.5)) < 38:
                    self._damage_area(enemy.x + enemy.w*.5, enemy.y + enemy.h*.5, 70.0, 3, "kamikaze", push=80.0)
                    enemy.alive = False
                    self.retro_effects.append(RetroEffect(enemy.x, enemy.y, 70.0, 0.5, "boom"))
                    continue
            elif enemy.kind == "summoner":
                enemy.x += enemy.vx * 0.35 * dt * speed_factor
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0:
                    enemy.shoot_timer = self._enemy_fire_cooldown(3.2)
                    nearby = sum(1 for e in self.retro_enemies if e.alive and not e.kind.startswith("boss") and abs(e.x - enemy.x) < 420)
                    if nearby < 7:
                        ew, eh, hp, attack, speed = ENEMY_STATS["minor"]
                        hp, attack = self._scaled_enemy_stats(hp, attack)
                        sx = max(40.0, min(self.retro_world_width - 60.0, enemy.x + random.choice((-50, 50))))
                        sy = float(ground - eh)
                        self.retro_enemies.append(RetroEnemy(sx, sy, ew, eh, math.copysign(speed, player.x - sx), "minor", hp, hp, attack, sx - 120, sx + 120, home_y=sy, status_effects={}))
                        self.retro_effects.append(RetroEffect(sx, sy, 24.0, 0.4, "summon"))
            elif enemy.kind == "ghost":
                enemy.x += (math.sin(enemy.phase * 1.3) * 40.0 + math.copysign(20.0, player.x - enemy.x)) * dt * speed_factor
                enemy.y += math.sin(enemy.phase * 2.2) * 22.0 * dt
                enemy.y = max(70.0, min(float(ground - enemy.h), enemy.y))
            elif enemy.kind == "elite":
                enemy.x += enemy.vx * (1.25 if enemy.elite_mod == "rápido" else 0.75) * dt * speed_factor
                enemy.shoot_timer -= dt * speed_factor
                if enemy.shoot_timer <= 0 and abs(enemy.x - player.x) < 620:
                    enemy.shoot_timer = self._enemy_fire_cooldown(1.8)
                    self._spawn_enemy_bullet(enemy, speed=380.0, damage=enemy.attack)
            else:
                enemy.x += enemy.vx * dt * speed_factor
                if enemy.kind == "sprinter" and abs(enemy.x - player.x) < 360:
                    enemy.vx = math.copysign(118.0, player.x - enemy.x)

            if not enemy.kind.startswith("boss") and enemy.kind not in {"turret", "sniper"}:
                if enemy.x < enemy.patrol_left:
                    enemy.x = enemy.patrol_left
                    enemy.vx = abs(enemy.vx) or 20.0
                if enemy.x + enemy.w > enemy.patrol_right:
                    enemy.x = enemy.patrol_right - enemy.w
                    enemy.vx = -abs(enemy.vx) or -20.0
            if not self._enemy_is_ally(enemy) and self._retro_intersects(player.x, player.y, player.w, player.h, enemy):
                stomp = self._ability_owned("parry") and player.vy > 80 and player.y + player.h <= enemy.y + max(22.0, enemy.h * 0.38)
                nova_hit = self._ability_owned("nova") and player.dash_timer > 0
                if stomp:
                    self._retro_damage_enemy(enemy, self._parry_damage(), 0, ability="parry")
                    self.parry_timer = max(getattr(self, "parry_timer", 0.0), self._parry_window())
                    player.vy = -self._parry_bounce_velocity()
                    player.on_ground = False
                    player.jumps_used = max(1, player.jumps_used)
                    self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h, 24.0, 0.28, "parry"))
                    continue
                if nova_hit:
                    if enemy.hurt_flash <= 0:
                        self._retro_damage_enemy(enemy, self._nova_damage(), player.facing, ability="nova")
                    continue
                if player.hurt_timer <= 0:
                    if enemy.kind == "leech":
                        self._damage_player(enemy.attack, enemy.x + enemy.w * 0.5)
                        player.vx *= 0.55
                    else:
                        self._damage_player(enemy.attack, enemy.x + enemy.w * 0.5)
            # Las sombras rivales también pueden ser dañadas por enemigos y jefes.
            for shadow_index, shadow_x, shadow_y, _sf, _sg, _sj in self._shadow_snapshots():
                if self._retro_intersects(shadow_x, shadow_y, player.w, player.h, enemy):
                    self._damage_shadow_chaser(
                        shadow_index,
                        max(1, enemy.attack),
                        enemy.x + enemy.w * 0.5,
                        ability="enemy_contact",
                        grant_xp=False,
                    )

    def _spawn_enemy_bullet(self, enemy: RetroEnemy, *, speed: float = 340.0, damage: int | float = 1, spread: float = 0.0, kind: str = "enemy_bullet") -> None:
        player = self.retro_player
        ex = enemy.x + enemy.w * 0.5
        ey = enemy.y + enemy.h * 0.45
        target_x = player.x + player.w * 0.5
        target_y = player.y + player.h * 0.5
        allies = self._revived_allies()
        if allies:
            nearest = min(allies, key=lambda a: math.hypot((a.x + a.w * 0.5) - ex, (a.y + a.h * 0.5) - ey))
            ally_dist = math.hypot((nearest.x + nearest.w * 0.5) - ex, (nearest.y + nearest.h * 0.5) - ey)
            player_dist = math.hypot(target_x - ex, target_y - ey)
            if ally_dist < player_dist * 0.92 or random.random() < 0.35:
                target_x = nearest.x + nearest.w * 0.5
                target_y = nearest.y + nearest.h * 0.5
        dx = target_x - ex
        dy = target_y - ey
        length = max(1.0, math.hypot(dx, dy))
        angle = math.atan2(dy, dx) + spread
        vx = math.cos(angle) * speed
        vy = math.sin(angle) * speed
        self.retro_projectiles.append(
            RetroProjectile(
                x=ex,
                y=ey,
                vx=vx,
                vy=vy,
                life=3.0,
                damage=damage,
                kind=kind,
                owner="enemy",
                origin_x=ex,
                origin_y=ey,
                max_distance=900.0,
            )
        )

    def _update_boss(self, enemy: RetroEnemy, dt: float, player: RetroPlayer) -> None:
        # Agresividad reducida a la mitad del parche anterior: la movilidad se conserva, pero la cadencia queda en 2.5x.
        enemy.shoot_timer -= dt * 2.75
        boss_attack_ready = enemy.shoot_timer <= 0
        direction_to_player = 1 if player.x > enemy.x else -1
        phase_two = enemy.hp <= enemy.max_hp * 0.5
        enemy.x = max(enemy.patrol_left, min(enemy.patrol_right - enemy.w, enemy.x))

        def boss_damage(base_damage: int | float = 3) -> float:
            # Escala los ataques especiales del jefe en la misma proporción que su contacto.
            return round(float(base_damage) * (float(enemy.attack) / 3.0), 2)

        def aimed(speed: float = 360.0, damage: int | float = 3, spreads: tuple[float, ...] = (0.0,)) -> None:
            for spread in spreads:
                self._spawn_enemy_bullet(enemy, speed=speed, damage=boss_damage(damage), spread=spread)

        def drop_column(offsets: tuple[int, ...], speed: float = 430.0, kind: str = "enemy_drop") -> None:
            for offset in offsets:
                x = player.x + player.w * 0.5 + offset
                self.retro_projectiles.append(RetroProjectile(
                    x=x, y=max(35.0, player.y - 360.0), vx=0.0, vy=speed, life=2.4, damage=boss_damage(3),
                    kind=kind, owner="enemy", origin_x=x, origin_y=player.y - 360.0, max_distance=840.0
                ))

        def spawn_minion(kind: str = "minor", dx: float = 110.0) -> None:
            nearby = sum(1 for e in self.retro_enemies if e.alive and not e.kind.startswith("boss") and abs(e.x - enemy.x) < 520)
            if nearby >= (3 if not phase_two else 5):
                return
            ew, eh, hp, attack, speed = ENEMY_STATS.get(kind, ENEMY_STATS["minor"])
            hp, attack = self._scaled_enemy_stats(hp, attack)
            sx = max(40.0, min(self.retro_world_width - 90.0, enemy.x + direction_to_player * dx))
            sy = float(self._retro_ground_y() - eh)
            self.retro_enemies.append(RetroEnemy(
                x=sx, y=sy, w=ew, h=eh, vx=direction_to_player * max(40.0, speed), kind=kind,
                hp=hp, max_hp=hp, attack=attack, patrol_left=max(40.0, sx - 240), patrol_right=min(float(self.retro_world_width - 60), sx + 260), home_y=sy,
            ))

        def boss_varied_pressure() -> None:
            # Patrón secundario común: más variedad sin modificar movimiento ni ruta del jefe.
            roll = int((enemy.phase * 10 + enemy.x + enemy.y) % 5)
            if roll == 0:
                aimed(520.0 if phase_two else 455.0, 2.5, (-0.45, 0.0, 0.45))
            elif roll == 1:
                drop_column((-260, 0, 260) if phase_two else (-180, 180), 560.0, "enemy_pressure")
            elif roll == 2:
                ex, ey = self._enemy_center(enemy)
                for angle in (-0.85, -0.42, 0.0, 0.42, 0.85):
                    self.retro_projectiles.append(RetroProjectile(ex, ey, math.cos(angle) * 360.0 * direction_to_player, math.sin(angle) * 360.0, 2.0, boss_damage(2), "enemy_bullet", 0, "enemy", ex, ey, 720.0))
            elif roll == 3:
                spawn_minion("sprinter" if phase_two else "minor", dx=random.choice((-150.0, 150.0)))
            else:
                ex, ey = self._enemy_center(enemy)
                self.retro_projectiles.append(RetroProjectile(ex, ey, direction_to_player * 220.0, -250.0, 2.2, boss_damage(3), "enemy_bomb", 0, "enemy", ex, ey, 780.0, gravity=760.0, radius=54.0))

        kind = enemy.kind
        if kind == "boss_shadow_warp":
            # Jefe exclusivo de Desafío: ya no teletransporta. Mantiene presión desde el lado opuesto.
            enemy.pattern_timer = min(enemy.pattern_timer, 29.0)
            gap = abs((player.x + player.w * 0.5) - (enemy.x + enemy.w * 0.5))
            if gap < 245.0:
                enemy.x -= direction_to_player * (34.0 if not phase_two else 48.0) * dt
            else:
                enemy.x += direction_to_player * (22.0 if not phase_two else 34.0) * dt
            enemy.x = max(enemy.patrol_left, min(enemy.patrol_right - enemy.w, enemy.x))
            enemy.y = max(60.0, min(float(self._retro_ground_y() - enemy.h), enemy.home_y + math.sin(enemy.phase * 2.7) * (22.0 if phase_two else 12.0)))
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.35 if phase_two else 1.95)
                aimed(390.0 if phase_two else 330.0, 4, (-0.30, 0.0, 0.30) if phase_two else (-0.16, 0.16))
                if phase_two and random.random() < 0.28:
                    drop_column((-160, 0, 160), 470.0, "enemy_shadow_drop")
        elif kind == "boss_spread":
            enemy.x += enemy.vx * dt
            enemy.y = enemy.home_y + math.sin(enemy.phase * 2.0) * (16 if not phase_two else 28)
            if enemy.x <= enemy.patrol_left or enemy.x + enemy.w >= enemy.patrol_right:
                enemy.vx *= -1
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.9 if not phase_two else 1.2)
                spreads = (-0.42, -0.24, 0.0, 0.24, 0.42) if not phase_two else (-0.62, -0.42, -0.22, 0.0, 0.22, 0.42, 0.62)
                aimed(330.0 if not phase_two else 390.0, 3, spreads)
        elif kind == "boss_lightning_split":
            enemy.x += direction_to_player * (32 if not phase_two else 48) * dt
            enemy.y = enemy.home_y - abs(math.sin(enemy.phase * 1.6)) * (44 if not phase_two else 82)
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(2.25 if not phase_two else 1.45)
                drop_column((-150, 0, 150) if not phase_two else (-220, -110, 0, 110, 220), 460.0, "enemy_drop")
                if phase_two:
                    spawn_minion("flyer", dx=-140.0)
                    spawn_minion("flyer", dx=140.0)
        elif kind == "boss_flyer":
            enemy.x += math.sin(enemy.phase * 1.3) * 72.0 * dt + direction_to_player * 18.0 * dt
            enemy.y = max(70.0, enemy.home_y - 150 + math.sin(enemy.phase * 3.0) * (58 if phase_two else 36))
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.55 if not phase_two else 1.05)
                aimed(420.0, 3, (-0.18, 0.0, 0.18) if phase_two else (0.0,))
        elif kind == "boss_dragon":
            enemy.x += direction_to_player * (22 if not phase_two else 38) * dt
            enemy.y = enemy.home_y + math.sin(enemy.phase * 1.7) * 18
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.65 if not phase_two else 1.05)
                for vy in ((-90.0, 0.0, 90.0) if phase_two else (0.0, 70.0)):
                    self.retro_projectiles.append(RetroProjectile(
                        x=enemy.x + (enemy.w if direction_to_player > 0 else 0), y=enemy.y + enemy.h * 0.45,
                        vx=direction_to_player * 420.0, vy=vy, life=2.2, damage=boss_damage(3), kind="enemy_fire", owner="enemy",
                        origin_x=enemy.x, origin_y=enemy.y, max_distance=760.0
                    ))
        elif kind == "boss_colossus":
            enemy.vx = direction_to_player * (16 if not phase_two else 25)
            enemy.x += enemy.vx * dt
            enemy.y = enemy.home_y
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(2.4 if not phase_two else 1.65)
                drop_column((-180, 0, 180) if not phase_two else (-260, -130, 0, 130, 260), 520.0, "enemy_rock")
                aimed(270.0, 3, (-0.16, 0.16) if phase_two else (0.0,))
        elif kind == "boss_ninja":
            if enemy.pattern_timer >= (2.6 if not phase_two else 1.55):
                enemy.pattern_timer = 0.0
                radius = TILE * 2
                enemy.x = max(enemy.patrol_left, min(enemy.patrol_right - enemy.w, player.x + random.choice((-radius, radius))))
                enemy.y = max(80.0, min(float(self._retro_ground_y() - enemy.h), player.y + random.choice((-radius * 0.35, 0, radius * 0.35))))
                self.retro_effects.append(RetroEffect(enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.5, 28.0, 0.35, "portal"))
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.3 if not phase_two else 0.82)
                aimed(460.0, 3, (-0.24, 0.0, 0.24) if phase_two else (0.0,))
        elif kind == "boss_ice":
            enemy.x += math.sin(enemy.phase * 1.4) * 42.0 * dt
            enemy.y = enemy.home_y
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.95 if not phase_two else 1.18)
                aimed(300.0, 3, (-0.32, 0.0, 0.32) if phase_two else (-0.18, 0.18))
                drop_column((-120, 120) if not phase_two else (-220, 0, 220), 300.0, "enemy_ice")
        elif kind == "boss_fire":
            enemy.x += direction_to_player * (38 if not phase_two else 56) * dt
            enemy.y = enemy.home_y + math.sin(enemy.phase * 3.2) * 11
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.45 if not phase_two else 0.95)
                for vy in (-110.0, 0.0, 110.0) if phase_two else (0.0,):
                    self.retro_projectiles.append(RetroProjectile(enemy.x + enemy.w * 0.5, enemy.y + enemy.h * 0.5, direction_to_player * 500.0, vy, 1.8, boss_damage(3), "enemy_fire", 0, "enemy", enemy.x, enemy.y, 700.0))
        elif kind == "boss_plant":
            enemy.x += math.sin(enemy.phase * 0.9) * 18.0 * dt
            enemy.y = enemy.home_y
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(2.1 if not phase_two else 1.25)
                spawn_minion("hopper", dx=-130.0)
                spawn_minion("sprinter", dx=150.0)
                aimed(320.0, 3, (-0.2, 0.0, 0.2) if phase_two else (0.0,))
        elif kind == "boss_rock":
            enemy.x += direction_to_player * (14 if not phase_two else 24) * dt
            enemy.y = enemy.home_y
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(2.35 if not phase_two else 1.5)
                drop_column((-190, 0, 190) if not phase_two else (-300, -150, 0, 150, 300), 480.0, "enemy_rock")
        elif kind == "boss_water":
            enemy.x += math.sin(enemy.phase * 1.7) * 54.0 * dt
            enemy.y = enemy.home_y + math.sin(enemy.phase * 2.5) * (22 if phase_two else 12)
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.6 if not phase_two else 1.05)
                aimed(360.0, 3, (-0.35, 0.0, 0.35) if phase_two else (-0.18, 0.18))
        elif kind == "boss_aquatic":
            enemy.x += math.sin(enemy.phase * 2.0) * 92.0 * dt
            enemy.y = max(80.0, enemy.home_y - 95 + math.sin(enemy.phase * 3.1) * (68 if phase_two else 42))
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.5 if not phase_two else 0.95)
                aimed(440.0, 3, (-0.28, 0.0, 0.28) if phase_two else (0.0,))
                if phase_two:
                    spawn_minion("flyer", dx=120.0)
        elif kind == "boss_thunder":
            enemy.x += direction_to_player * (28 if not phase_two else 46) * dt
            enemy.y = enemy.home_y - abs(math.sin(enemy.phase * 2.2)) * (34 if not phase_two else 74)
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.8 if not phase_two else 0.95)
                drop_column((-240, 0, 240) if not phase_two else (-300, -150, 0, 150, 300), 620.0, "enemy_thunder")
                aimed(430.0, 3, (0.0,))
        elif kind == "boss_clone":
            # Imitación aproximada con 0.3 s de retraso: persigue la posición extrapolada hacia atrás del jugador.
            target_x = player.x - player.vx * 0.3 + (-120 if player.facing > 0 else 120)
            target_y = player.y - player.vy * 0.3
            enemy.x += (target_x - enemy.x) * min(1.0, (1.5 if not phase_two else 2.4) * dt)
            enemy.y += (target_y - enemy.y) * min(1.0, (1.2 if not phase_two else 2.0) * dt)
            enemy.y = max(70.0, min(float(self._retro_ground_y() - enemy.h), enemy.y))
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.25 if not phase_two else 0.75)
                aimed(430.0, 3, (-0.2, 0.0, 0.2) if phase_two else (0.0,))
        else:
            enemy.x += enemy.vx * dt
            if enemy.x < enemy.patrol_left or enemy.x + enemy.w > enemy.patrol_right:
                enemy.vx *= -1
            if enemy.shoot_timer <= 0:
                enemy.shoot_timer = self._enemy_fire_cooldown(1.8 if phase_two else 2.4)
                aimed(350.0, 3, (-0.25, 0.0, 0.25) if phase_two else (0.0,))

        if boss_attack_ready:
            boss_varied_pressure()
        enemy.x = max(enemy.patrol_left, min(enemy.patrol_right - enemy.w, enemy.x))

    def _update_projectiles(self, dt: float, viewport_width: int, viewport_height: int) -> None:
        player = self.retro_player
        # Protección de rendimiento: prioriza proyectiles cercanos si una pelea caótica genera demasiados.
        if len(self.retro_projectiles) > 360:
            px = player.x + player.w * 0.5
            py = player.y + player.h * 0.5
            self.retro_projectiles = sorted(self.retro_projectiles, key=lambda p: math.hypot(p.x - px, p.y - py))[:360]
        ground = self._retro_ground_y()
        obstacles = self._solid_rects()
        projectile_blockers = obstacles + self._box_solid_rects()
        kept: list[RetroProjectile] = []
        for projectile in self.retro_projectiles:
            projectile_dt = dt * self._time_slow_factor() if projectile.owner == "enemy" else dt
            if projectile.kind == "bomb":
                if not projectile.stuck:
                    projectile.vy += projectile.gravity * projectile_dt
                    projectile.x += projectile.vx * projectile_dt
                    projectile.y += projectile.vy * projectile_dt
                    if projectile.y + 8 >= ground and not self._retro_in_pit(projectile.x, 4):
                        projectile.y = ground - 8
                        if projectile.ability == "flight":
                            self._explode_bomb(projectile)
                            continue
                        projectile.vy = 0.0
                        projectile.vx *= 0.4
                        projectile.stuck = True
                    for rect in projectile_blockers:
                        if self._retro_intersects(projectile.x - 7, projectile.y - 7, 14, 14, rect):
                            if projectile.vy > 0:
                                projectile.y = rect.y - 8
                                projectile.vy = 0.0
                                projectile.vx *= 0.4
                                projectile.stuck = True
                            break
                projectile.life -= projectile_dt
                if projectile.life <= 0:
                    self._explode_bomb(projectile)
                    continue
                kept.append(projectile)
                continue

            if projectile.kind in {"boomerang", "mini_boomerang"} and projectile.owner == "player":
                if not projectile.returning and abs(projectile.x - projectile.origin_x) > projectile.max_distance:
                    projectile.returning = True
                if projectile.life < 1.0:
                    projectile.returning = True
                if projectile.returning:
                    target_x = player.x + player.w * 0.5
                    target_y = player.y + player.h * 0.5
                    dx = target_x - projectile.x
                    dy = target_y - projectile.y
                    length = max(1.0, math.hypot(dx, dy))
                    projectile.vx += ((dx / length) * 610.0 - projectile.vx) * min(1.0, 8.5 * dt)
                    projectile.vy += ((dy / length) * 610.0 - projectile.vy) * min(1.0, 8.5 * dt)
                    if abs(dx) < 18 and abs(dy) < 18:
                        continue

            if projectile.kind == "seeker_missile" and projectile.owner == "player":
                target = self._find_nearest_enemy(projectile.x, projectile.y, 560.0)
                if target:
                    tx, ty = self._enemy_center(target)
                    dx = tx - projectile.x
                    dy = ty - projectile.y
                    length = max(1.0, math.hypot(dx, dy))
                    speed = max(240.0, math.hypot(projectile.vx, projectile.vy))
                    projectile.vx += ((dx / length) * speed - projectile.vx) * min(1.0, 3.8 * dt)
                    projectile.vy += ((dy / length) * speed - projectile.vy) * min(1.0, 3.8 * dt)

            if projectile.kind in {"thorn_trap", "toxic_cloud"}:
                radius = projectile.radius or TILE
                status = "poison" if projectile.kind == "toxic_cloud" else "root"
                self._damage_area(projectile.x, projectile.y, radius, max(1, int(projectile.damage)), projectile.ability or projectile.kind, push=0.0, status=status)

            if getattr(projectile, "homing_time", 0.0) > 0 and projectile.owner in {"player", "clone", "p2"} and projectile.kind == "charged":
                projectile.homing_time = max(0.0, projectile.homing_time - projectile_dt)
                target = self._find_nearest_projectile_target(projectile.x, projectile.y, 680.0)
                if target is not None:
                    tx, ty = target
                    dx = tx - projectile.x
                    dy = ty - projectile.y
                    length = max(1.0, math.hypot(dx, dy))
                    speed = max(260.0, math.hypot(projectile.vx, projectile.vy))
                    turn = min(1.0, (4.2 + projectile.level * 0.7) * projectile_dt)
                    projectile.vx += ((dx / length) * speed - projectile.vx) * turn
                    projectile.vy += ((dy / length) * speed - projectile.vy) * turn

            if projectile.gravity:
                projectile.vy += projectile.gravity * projectile_dt

            projectile.x += projectile.vx * projectile_dt
            projectile.y += projectile.vy * projectile_dt
            projectile.life -= projectile_dt
            if projectile.life <= 0 or math.hypot(projectile.x - projectile.origin_x, projectile.y - projectile.origin_y) > projectile.max_distance + 80:
                continue
            if projectile.x < -80 or projectile.x > self.retro_world_width + 80 or projectile.y < -120 or projectile.y > self.retro_world_height + 160:
                continue

            body_w = 12 + projectile.level * 8
            body_h = 8 + projectile.level * 4
            if projectile.kind in {"flame", "laser_beam", "rail_shot"}:
                body_w = 58 if projectile.kind == "flame" else 86 + projectile.level * 18
                body_h = 28 if projectile.kind == "flame" else 12
            elif projectile.kind in {"acid_orb", "toxic_cloud", "mine", "meteor", "fire_wheel"}:
                body_w = body_h = 30 + projectile.level * 8
            # Las cajitas son cobertura real: bloquean proyectiles enemigos y del jugador,
            # incluso si el disparo cargado normalmente atravesaría obstáculos.
            box_hit = any(self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, rect) for rect in self._box_solid_rects())
            if box_hit:
                continue
            if projectile.owner.startswith("shadow:"):
                obstacle_hit = any(self._retro_intersects(projectile.x - 4, projectile.y - 4, 8, 8, rect) for rect in obstacles)
                if obstacle_hit:
                    continue
                if self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, RetroRect(player.x, player.y, player.w, player.h)):
                    self._damage_player(projectile.damage, projectile.x, allow_if_hurt=True)
                    continue
                kept.append(projectile)
                continue
            if projectile.owner.startswith("bot:"):
                obstacle_hit = any(self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, rect) for rect in obstacles)
                if obstacle_hit and projectile.kind != "bomb":
                    continue
                owner_team = self._arena_owner_team(projectile.owner)
                if owner_team is not None and self.arena_player_respawn_timer <= 0.0 and self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, RetroRect(player.x, player.y, player.w, player.h)):
                    self._arena_last_player_attacker = owner_team
                    self._damage_player(projectile.damage, projectile.x, allow_if_hurt=True)
                    continue
                removed_by_bot_hit = False
                if self.selected_mode == "arena":
                    for bot in self.arena_bots:
                        if not bot.alive or owner_team == bot.team:
                            continue
                        bp = bot.player
                        bot_id = -20000 - bot.index
                        hit_ids = projectile.hit_ids if projectile.hit_ids is not None else set()
                        if bot_id in hit_ids:
                            continue
                        if projectile.x - body_w * 0.5 < bp.x + bp.w and projectile.x + body_w * 0.5 > bp.x and projectile.y - body_h * 0.5 < bp.y + bp.h and projectile.y + body_h * 0.5 > bp.y:
                            self._damage_arena_bot(bot.index, projectile.damage, projectile.x, attacker_team=owner_team, ability=projectile.ability or projectile.kind)
                            hit_ids.add(bot_id)
                            projectile.hit_ids = hit_ids
                            removed_by_bot_hit = projectile.kind not in {"rail_shot", "laser_beam"}
                            break
                if removed_by_bot_hit:
                    continue
                kept.append(projectile)
                continue
            if projectile.owner == "enemy":
                obstacle_hit = any(self._retro_intersects(projectile.x - 4, projectile.y - 4, 8, 8, rect) for rect in obstacles)
                if obstacle_hit:
                    continue
                ally_hit = False
                for ally in self._revived_allies():
                    if self._retro_intersects(projectile.x - 6, projectile.y - 6, 12, 12, ally):
                        self._damage_resurrected_ally(ally, projectile.damage, projectile.x)
                        ally_hit = True
                        break
                if ally_hit:
                    continue
                if self._retro_intersects(projectile.x - 5, projectile.y - 5, 10, 10, RetroRect(player.x, player.y, player.w, player.h)):
                    if getattr(self, "parry_timer", 0.0) > 0:
                        projectile.owner = "player"
                        projectile.kind = "reflected"
                        projectile.vx *= -1.25
                        projectile.vy *= -1.25
                        projectile.damage = max(1, projectile.damage + 1)
                        self.retro_effects.append(RetroEffect(projectile.x, projectile.y, 20.0, 0.25, "parry"))
                        kept.append(projectile)
                        continue
                    self._damage_player(projectile.damage, projectile.x)
                    continue
                if self.p2_enabled and self._retro_intersects(projectile.x - 5, projectile.y - 5, 10, 10, RetroRect(self.p2_player.x, self.p2_player.y, self.p2_player.w, self.p2_player.h)):
                    self._damage_p2(projectile.damage, projectile.x)
                    continue
                shadow_hit = False
                for shadow_index, shadow_x, shadow_y, _sf, _sg, _sj in self._shadow_snapshots():
                    if self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, RetroRect(shadow_x, shadow_y, player.w, player.h)):
                        self._damage_shadow_chaser(
                            shadow_index,
                            projectile.damage,
                            projectile.x,
                            ability=projectile.ability or projectile.kind,
                            ignore_hurt=True,
                            grant_xp=False,
                        )
                        shadow_hit = True
                        break
                if shadow_hit:
                    continue
                kept.append(projectile)
                continue

            obstacle_hit = any(self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, rect) for rect in obstacles)
            if obstacle_hit and projectile.kind == "ricochet_disc" and projectile.bounces < 4:
                projectile.bounces += 1
                projectile.vx *= -0.92
                projectile.vy = -projectile.vy * 0.75 - 35.0
                obstacle_hit = False
            if obstacle_hit and projectile.kind in {"mine", "fire_wheel"}:
                projectile.y = max(8.0, projectile.y - 8.0)
                projectile.vy = 0.0
                projectile.gravity = 0.0
                obstacle_hit = False
            if obstacle_hit and projectile.kind not in {"boomerang", "mini_boomerang", "charged", "rail_shot", "laser_beam"}:
                continue
            if projectile.kind in {"boomerang", "mini_boomerang"}:
                self._try_open_secret_gates("boomerang", area=(projectile.x - 12, projectile.y - 12, 24, 24))
            if projectile.kind == "charged" and projectile.owner in {"player", "clone", "p2"}:
                self._try_open_secret_gates("gun", area=(projectile.x - 10, projectile.y - 10, 20, 20))
            removed_by_hit = False
            if self.p2_enabled and self.friendly_fire:
                if projectile.owner == "player" and self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, RetroRect(self.p2_player.x, self.p2_player.y, self.p2_player.w, self.p2_player.h)):
                    self._damage_p2(projectile.damage, projectile.x)
                    removed_by_hit = projectile.kind not in {"boomerang", "mini_boomerang", "rail_shot", "laser_beam"} and not (projectile.kind == "charged" and self._has_weapon_special("gun", "crit_pierce"))
                elif projectile.owner == "p2" and self._retro_intersects(projectile.x - body_w * 0.5, projectile.y - body_h * 0.5, body_w, body_h, RetroRect(player.x, player.y, player.w, player.h)):
                    self._damage_player(projectile.damage, projectile.x)
                    removed_by_hit = projectile.kind not in {"boomerang", "mini_boomerang", "rail_shot", "laser_beam"} and not (projectile.kind == "charged" and self._has_weapon_special("gun", "crit_pierce"))
            if removed_by_hit:
                continue
            if self.selected_mode == "arena" and projectile.owner in {"player", "clone"}:
                owner_team = self.arena_player_team
                for bot in self.arena_bots:
                    if not bot.alive or bot.team == owner_team:
                        continue
                    bp = bot.player
                    bot_id = -20000 - bot.index
                    hit_ids = projectile.hit_ids if projectile.hit_ids is not None else set()
                    if bot_id in hit_ids:
                        continue
                    if projectile.x - body_w * 0.5 < bp.x + bp.w and projectile.x + body_w * 0.5 > bp.x and projectile.y - body_h * 0.5 < bp.y + bp.h and projectile.y + body_h * 0.5 > bp.y:
                        self._damage_arena_bot(bot.index, projectile.damage, projectile.x, attacker_team=owner_team, ability=projectile.ability or projectile.kind)
                        hit_ids.add(bot_id)
                        projectile.hit_ids = hit_ids
                        gun_special = projectile.kind == "charged" and self._has_weapon_special("gun", "crit_pierce")
                        if projectile.kind in {"vshot", "normal", "ice_lance"}:
                            removed_by_hit = True
                        elif projectile.kind == "charged" and not gun_special and projectile.level < 2:
                            removed_by_hit = True
                        elif projectile.kind in {"rail_shot", "laser_beam", "boomerang", "mini_boomerang", "ricochet_disc", "seeker_missile"}:
                            removed_by_hit = False
                        break
                if removed_by_hit:
                    continue
            for shadow_index, shadow_x, shadow_y, _shadow_facing, _shadow_on_ground, _shadow_jumps in self._shadow_snapshots():
                shadow_id = -10000 - shadow_index
                hit_ids = projectile.hit_ids if projectile.hit_ids is not None else set()
                if shadow_id in hit_ids:
                    continue
                size = 12 + projectile.level * 6
                hit_w = 58 if projectile.kind == "flame" else size
                hit_h = 28 if projectile.kind == "flame" else size * 0.9
                if projectile.x - hit_w * 0.5 < shadow_x + player.w and projectile.x + hit_w * 0.5 > shadow_x and projectile.y - hit_h * 0.5 < shadow_y + player.h and projectile.y + hit_h * 0.5 > shadow_y:
                    attack_dir = 1 if projectile.vx >= 0 else -1
                    self._damage_shadow_chaser(
                        shadow_index,
                        projectile.damage,
                        projectile.x,
                        ability=projectile.ability or projectile.kind,
                        ignore_hurt=True,
                        grant_xp=projectile.owner in {"player", "clone", "p2"},
                    )
                    hit_ids.add(shadow_id)
                    projectile.hit_ids = hit_ids
                    gun_special = projectile.kind == "charged" and self._has_weapon_special("gun", "crit_pierce")
                    if projectile.kind in {"vshot", "normal", "ice_lance"}:
                        removed_by_hit = True
                    elif projectile.kind == "charged" and not gun_special and projectile.level < 2:
                        removed_by_hit = True
                    elif projectile.kind in {"rail_shot", "laser_beam", "boomerang", "mini_boomerang", "ricochet_disc", "seeker_missile"}:
                        removed_by_hit = False
                    elif projectile.kind in {"ally_bullet", "ally_star", "ally_shotgun", "ninja_star", "hunter_shell"}:
                        removed_by_hit = True
                    elif projectile.kind in {"acid_orb", "toxic_cloud", "mine", "meteor", "fire_wheel"}:
                        self._damage_shadow_area(projectile.x, projectile.y, projectile.radius or 48.0, max(1, int(projectile.damage)), projectile.ability or projectile.kind)
                        removed_by_hit = projectile.kind not in {"toxic_cloud", "fire_wheel"}
                    break
            if removed_by_hit:
                continue
            for enemy in self.retro_enemies:
                if not enemy.alive:
                    continue
                if self._enemy_is_ally(enemy) and projectile.owner in {"player", "clone", "p2", "ally"}:
                    continue
                if projectile.owner == "ally" and self._enemy_is_ally(enemy):
                    continue
                enemy_id = id(enemy)
                hit_ids = projectile.hit_ids if projectile.hit_ids is not None else set()
                if enemy_id in hit_ids:
                    continue
                size = 12 + projectile.level * 6
                hit_w = 58 if projectile.kind == "flame" else size
                hit_h = 28 if projectile.kind == "flame" else size * 0.9
                if projectile.x - hit_w * 0.5 < enemy.x + enemy.w and projectile.x + hit_w * 0.5 > enemy.x and projectile.y - hit_h * 0.5 < enemy.y + enemy.h and projectile.y + hit_h * 0.5 > enemy.y:
                    attack_dir = 1 if projectile.vx >= 0 else -1
                    damage = projectile.damage
                    gun_special = projectile.kind == "charged" and self._has_weapon_special("gun", "crit_pierce")
                    self._retro_damage_enemy(enemy, damage, attack_dir, ability=projectile.ability or projectile.kind)
                    hit_ids.add(enemy_id)
                    projectile.hit_ids = hit_ids
                    # Especial del disparo Nv5: toda carga de nivel 1+ atraviesa todos los enemigos que toca.
                    if projectile.kind in {"vshot", "normal", "ice_lance"}:
                        # Hielo atraviesa si mata; si no, se consume.
                        removed_by_hit = projectile.kind != "ice_lance" or enemy.alive
                    elif projectile.kind == "charged" and not gun_special and projectile.level < 2:
                        removed_by_hit = True
                    elif projectile.kind in {"rail_shot", "laser_beam", "boomerang", "mini_boomerang", "ricochet_disc", "seeker_missile"}:
                        removed_by_hit = False
                    elif projectile.kind in {"ally_bullet", "ally_star", "ally_shotgun", "ninja_star", "hunter_shell"}:
                        removed_by_hit = True
                    elif projectile.kind in {"acid_orb", "toxic_cloud", "mine", "meteor", "fire_wheel"}:
                        self._damage_area(projectile.x, projectile.y, projectile.radius or 48.0, max(1, int(projectile.damage)), projectile.ability or projectile.kind, status="burn" if projectile.kind in {"meteor", "fire_wheel"} else "poison")
                        removed_by_hit = projectile.kind not in {"toxic_cloud", "fire_wheel"}
                    break
            if not removed_by_hit:
                kept.append(projectile)
        self.retro_projectiles = kept

    def _explode_bomb(self, projectile: RetroProjectile) -> None:
        self.retro_effects.append(RetroEffect(projectile.x, projectile.y, projectile.radius, 0.65, "boom"))
        area = (projectile.x - projectile.radius, projectile.y - projectile.radius, projectile.radius * 2, projectile.radius * 2)
        self._try_open_secret_gates("bomb", area=area)
        for enemy in self.retro_enemies:
            if not enemy.alive:
                continue
            center_x = enemy.x + enemy.w * 0.5
            center_y = enemy.y + enemy.h * 0.5
            if math.hypot(center_x - projectile.x, center_y - projectile.y) <= projectile.radius:
                self._retro_damage_enemy(enemy, projectile.damage, 0, ability=projectile.ability or "bomb")
        if self.selected_mode == "arena":
            owner_team = self._arena_owner_team(projectile.owner)
            self._damage_arena_bots_area(projectile.x, projectile.y, projectile.radius, projectile.damage, attacker_team=owner_team, ability=projectile.ability or "bomb")
        player = self.retro_player
        if projectile.owner.startswith("bot:") and math.hypot(player.x + player.w * 0.5 - projectile.x, player.y + player.h * 0.5 - projectile.y) <= projectile.radius * 0.65:
            self._arena_last_player_attacker = self._arena_owner_team(projectile.owner)
            self._damage_player(projectile.damage, projectile.x, allow_if_hurt=True)
        if projectile.owner == "player" and math.hypot(player.x + player.w * 0.5 - projectile.x, player.y + player.h * 0.5 - projectile.y) <= projectile.radius * 0.55:
            self._damage_player(1, projectile.x)
        if self.p2_enabled:
            p2 = self.p2_player
            if projectile.owner == "p2" and math.hypot(p2.x + p2.w * 0.5 - projectile.x, p2.y + p2.h * 0.5 - projectile.y) <= projectile.radius * 0.55:
                self._damage_p2(1, projectile.x)
            elif self.friendly_fire and projectile.owner == "player" and math.hypot(p2.x + p2.w * 0.5 - projectile.x, p2.y + p2.h * 0.5 - projectile.y) <= projectile.radius * 0.55:
                self._damage_p2(1, projectile.x)
            elif self.friendly_fire and projectile.owner == "p2" and math.hypot(player.x + player.w * 0.5 - projectile.x, player.y + player.h * 0.5 - projectile.y) <= projectile.radius * 0.55:
                self._damage_player(1, projectile.x)

    def _draw_world_rect(self, canvas: tk.Canvas, x: float, y: float, w: float, h: float, *, fill: str, outline: str | None = None, width: int = 1) -> None:
        sx = self._screen_x(x)
        sy = self._screen_y(y)
        if sx + w < -60 or sx > canvas.winfo_width() + 60 or sy + h < -80 or sy > canvas.winfo_height() + 80:
            return
        canvas.create_rectangle(sx, sy, sx + w, sy + h, fill=fill, outline=outline if outline is not None else fill, width=width)

    def _draw_retro_city(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        ground = self._screen_y(self._retro_ground_y())
        horizon = min(height - 48, max(54, ground - 142))
        phase = int(self.anim_phase * 3) % 18
        for y in range(16, height + 28, 28):
            canvas.create_line(0, y + phase % 5, width, y + phase % 5, fill=ink, width=1)
        for i in range(18):
            x = int((i * 137 - self.anim_phase * 13) % max(1, width))
            y = 18 + (i * 29) % max(30, height - 50)
            canvas.create_rectangle(x, y, x + 3, y + 3, fill=ink, outline="")

        cam = self.retro_camera_x * 0.32
        scroll_y = self.retro_camera_y * 0.10
        for wx in range(-180, self.retro_world_width + 260, 88):
            sx = wx - cam
            if sx > width + 90 or sx + 58 < -90:
                continue
            b_h = 40 + ((wx // 88 + self.retro_seed) % 5) * 18
            y0 = ground - 38 - b_h + scroll_y
            y1 = ground - 38 + scroll_y
            if y1 < -80 or y0 > height + 80:
                continue
            canvas.create_rectangle(sx, y0, sx + 56, y1, fill=ink, outline="")
            canvas.create_rectangle(sx + 5, y0 + 6, sx + 51, y1 - 6, fill=base, outline="")
            for wy in range(int(y0 + 12), int(y1 - 8), 15):
                for wx2 in range(10, 46, 18):
                    if ((wy + wx2 + int(self.anim_phase)) // 2) % 3 != 0:
                        canvas.create_rectangle(sx + wx2, wy, sx + wx2 + 5, wy + 5, fill=ink, outline="")

        # Sin rótulos laterales: el nivel y bioma se anuncian al inicio del nivel.

    def _draw_retro_mech(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        ground = self._screen_y(self._retro_ground_y())
        cx = self._screen_x(self.retro_world_width - 420)
        if cx < -240 or cx > canvas.winfo_width() + 240:
            return
        y = ground - 176
        if y > canvas.winfo_height() + 120 or y < -260:
            return
        bob = int(math.sin(self.anim_phase * 0.9) * 3)
        canvas.create_rectangle(cx - 78, y + 116, cx + 92, ground - 16, fill=ink, outline="")
        canvas.create_rectangle(cx - 66, y + 124, cx + 80, ground - 26, fill=base, outline="")
        canvas.create_rectangle(cx - 44, y + 134, cx - 20, ground - 34, fill=ink, outline="")
        canvas.create_rectangle(cx + 24, y + 134, cx + 48, ground - 34, fill=ink, outline="")
        canvas.create_rectangle(cx - 74, y + bob, cx + 74, y + 112 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 62, y + 12 + bob, cx + 62, y + 100 + bob, fill=base, outline="")
        canvas.create_rectangle(cx - 44, y + 26 + bob, cx + 44, y + 84 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 32, y + 38 + bob, cx + 32, y + 72 + bob, fill=base, outline="")
        canvas.create_rectangle(cx - 18, y + 48 + bob, cx + 18, y + 62 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 112, y + 62 + bob, cx - 70, y + 88 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx + 70, y + 68 + bob, cx + 118, y + 94 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 138, y + 76 + bob, cx - 106, y + 108 + bob, fill=base, outline=ink, width=3)
        canvas.create_rectangle(cx + 112, y + 82 + bob, cx + 150, y + 116 + bob, fill=base, outline=ink, width=3)

    def _draw_retro_ground(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        ground = self._screen_y(self._retro_ground_y())
        segments: list[tuple[float, float]] = []
        start = 0.0
        for pit in sorted(self.retro_pits, key=lambda item: item.x):
            if pit.x > start:
                segments.append((start, pit.x))
            start = max(start, pit.x + pit.w)
        if start < self.retro_world_width:
            segments.append((start, float(self.retro_world_width)))
        for x0, x1 in segments:
            sx0 = self._screen_x(x0)
            sx1 = self._screen_x(x1)
            if sx1 < -30 or sx0 > width + 30:
                continue
            canvas.create_rectangle(sx0, ground, sx1, height + 90, fill=ink, outline="")
            canvas.create_rectangle(sx0, ground + 6, sx1, ground + 12, fill=base, outline="")
        for pit in self.retro_pits:
            sx = self._screen_x(pit.x)
            if sx + pit.w < -30 or sx > width + 30:
                continue
            canvas.create_rectangle(sx, ground + 2, sx + pit.w, height + 90, fill=base, outline=ink, width=2)
            canvas.create_rectangle(sx + 8, ground + 14, sx + pit.w - 8, ground + 20, fill=ink, outline="")
        scroll = int(self.retro_camera_x) % 32
        for x in range(-scroll, width + 36, 32):
            canvas.create_rectangle(x, ground + 17, x + 18, ground + 25, fill=base, outline="")
            canvas.create_line(x - 6, ground + 2, x + 32, ground + 2, fill=base, width=1)

    def _secret_gate_symbol(self, ability: str) -> str:
        return SECRET_GATE_SYMBOLS.get(ability, ability[:3].upper())

    def _secret_gate_for_rect(self, rect: RetroRect) -> SecretGate | None:
        for gate in self.secret_gates:
            if not gate.opened and gate.rect is rect:
                return gate
        return None

    def _draw_retro_obstacles(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        rects = list(self.retro_obstacles) + [gate.rect for gate in self.secret_gates if not gate.opened]
        for rect in rects:
            sx = self._screen_x(rect.x)
            sy = self._screen_y(rect.y)
            if sx + rect.w < -50 or sx > canvas.winfo_width() + 50 or sy + rect.h < -60 or sy > canvas.winfo_height() + 60:
                continue
            if rect.kind == "spike_trap":
                step = 12
                x_start = int(sx)
                x_end = int(sx + rect.w)
                for px in range(x_start, x_end, step):
                    canvas.create_polygon(px, sy + rect.h, px + step * 0.5, sy, min(px + step, x_end), sy + rect.h, fill=ink, outline=ink)
                continue
            self._draw_world_rect(canvas, rect.x, rect.y, rect.w, rect.h, fill=ink, outline=ink, width=2)
            for px in range(int(sx + 8), int(sx + rect.w - 4), 22):
                canvas.create_rectangle(px, sy + 4, px + 8, sy + max(5, rect.h - 4), fill=base, outline="")
            if rect.h > 34:
                for py in range(int(sy + 12), int(sy + rect.h - 6), 24):
                    canvas.create_rectangle(sx + 5, py, sx + rect.w - 5, py + 6, fill=base, outline="")
            if rect.kind.startswith("secret") or rect.kind == "gate":
                canvas.create_line(sx + 4, sy + 4, sx + rect.w - 4, sy + rect.h - 4, fill=base, width=2)
                canvas.create_line(sx + rect.w - 4, sy + 4, sx + 4, sy + rect.h - 4, fill=base, width=2)
                gate = self._secret_gate_for_rect(rect) if rect.kind == "secret_gate" else None
                if gate is not None:
                    symbol = self._secret_gate_symbol(gate.ability)
                    hits = max(0, int(getattr(gate, "hits_left", 1)))
                    total = max(1, int(getattr(gate, "max_hits", hits or 1)))
                    canvas.create_rectangle(sx + 5, sy + rect.h * 0.38 - 10, sx + rect.w - 5, sy + rect.h * 0.38 + 12, fill=base, outline=ink, width=1)
                    canvas.create_text(sx + rect.w / 2, sy + rect.h * 0.38 + 1, text=symbol, fill=ink, font=("Courier New", 6, "bold"))
                    if total > 1:
                        canvas.create_text(sx + rect.w / 2, sy + rect.h * 0.62, text=f"{hits}/{total}", fill=base, font=("Courier New", 6, "bold"))
                    canvas.create_text(sx + rect.w / 2, sy - 9, text=gate.label[:11], fill=ink, font=("Courier New", 5, "bold"))

    def _draw_health_bar(self, canvas: tk.Canvas, x: float, y: float, w: float, hp: int, max_hp: int, base: str, ink: str) -> None:
        max_hp = max(1, max_hp)
        ratio = max(0.0, min(1.0, hp / max_hp))
        canvas.create_rectangle(x, y, x + w, y + 7, fill=base, outline=ink, width=1)
        canvas.create_rectangle(x + 1, y + 1, x + 1 + (w - 2) * ratio, y + 6, fill=ink, outline="")

    def _draw_boss_sprite(self, canvas: tk.Canvas, enemy: RetroEnemy, sx: float, sy: float, base: str, ink: str, fill: str) -> None:
        # Siluetas distintas pero siempre en duotono y en escala de rival original.
        kind = enemy.kind
        w, h = enemy.w, enemy.h
        flash_base = base if fill == ink else ink
        cx = sx + w * 0.5
        phase = self.anim_phase

        def body_rect(head_h: float = 22.0, body_pad: float = 10.0) -> None:
            canvas.create_rectangle(sx + body_pad, sy + head_h, sx + w - body_pad, sy + h, fill=fill, outline=ink, width=2)
            canvas.create_rectangle(sx + 5, sy + 4, sx + w - 5, sy + head_h + 6, fill=fill, outline=ink, width=2)
            canvas.create_rectangle(sx + 16, sy + 11, sx + 25, sy + 17, fill=flash_base, outline="")
            canvas.create_rectangle(sx + w - 25, sy + 11, sx + w - 16, sy + 17, fill=flash_base, outline="")

        if kind == "boss_spread":
            body_rect()
            for i, dx in enumerate((-28, -14, 0, 14, 28)):
                canvas.create_line(cx, sy + 34, cx + dx, sy + 58 + (i % 2) * 4, fill=flash_base, width=2)
            canvas.create_rectangle(cx - 22, sy + 29, cx + 22, sy + 37, fill=flash_base, outline="")
        elif kind == "boss_lightning_split":
            canvas.create_polygon(cx, sy + 2, sx + w - 7, sy + 24, cx + 10, sy + h - 2, sx + 7, sy + 24, fill=fill, outline=ink)
            canvas.create_line(cx + 5, sy + 11, cx - 8, sy + 36, cx + 7, sy + 36, cx - 6, sy + 66, fill=flash_base, width=3)
            canvas.create_rectangle(sx + 13, sy + 18, sx + 25, sy + 25, fill=flash_base, outline="")
            canvas.create_rectangle(sx + w - 25, sy + 18, sx + w - 13, sy + 25, fill=flash_base, outline="")
        elif kind == "boss_flyer":
            canvas.create_oval(sx + 12, sy + 18, sx + w - 12, sy + h - 6, fill=fill, outline=ink, width=2)
            wing = 8 + int(abs(math.sin(phase * 5)) * 5)
            canvas.create_polygon(sx + 12, sy + 34, sx - 18, sy + 20 - wing, sx + 4, sy + 54, fill=fill, outline=ink)
            canvas.create_polygon(sx + w - 12, sy + 34, sx + w + 18, sy + 20 - wing, sx + w - 4, sy + 54, fill=fill, outline=ink)
            canvas.create_rectangle(cx - 10, sy + 28, cx + 10, sy + 35, fill=flash_base, outline="")
        elif kind == "boss_dragon":
            canvas.create_polygon(sx + 8, sy + 19, sx + w - 2, sy + 6, sx + w - 12, sy + 28, sx + 14, sy + 31, fill=fill, outline=ink)
            canvas.create_rectangle(sx + 12, sy + 30, sx + w - 16, sy + h - 3, fill=fill, outline=ink, width=2)
            for i in range(4):
                canvas.create_polygon(sx + 16 + i * 11, sy + 30, sx + 22 + i * 11, sy + 18, sx + 28 + i * 11, sy + 30, fill=flash_base, outline="")
            canvas.create_rectangle(sx + w - 20, sy + 14, sx + w - 12, sy + 20, fill=flash_base, outline="")
        elif kind == "boss_colossus":
            body_rect(head_h=18, body_pad=14)
            canvas.create_rectangle(sx - 12, sy + 30, sx + 12, sy + 68, fill=fill, outline=ink, width=2)
            canvas.create_rectangle(sx + w - 12, sy + 30, sx + w + 12, sy + 68, fill=fill, outline=ink, width=2)
            canvas.create_rectangle(cx - 8, sy + 42, cx + 8, sy + 58, fill=flash_base, outline="")
        elif kind == "boss_ninja":
            canvas.create_polygon(cx, sy + 2, sx + w - 8, sy + 22, sx + w - 18, sy + h, sx + 18, sy + h, sx + 8, sy + 22, fill=fill, outline=ink)
            canvas.create_rectangle(sx + 16, sy + 18, sx + w - 16, sy + 25, fill=flash_base, outline="")
            canvas.create_oval(sx - 13, sy + 8, sx + 15, sy + 36, outline=ink, width=2)
            canvas.create_oval(sx + w - 15, sy + 8, sx + w + 13, sy + 36, outline=ink, width=2)
        elif kind == "boss_ice":
            canvas.create_polygon(cx, sy, sx + w - 4, sy + 32, sx + w - 18, sy + h, sx + 18, sy + h, sx + 4, sy + 32, fill=fill, outline=ink)
            for dx in (-18, 0, 18):
                canvas.create_line(cx + dx, sy + 10, cx + dx - 10, sy + 35, cx + dx + 6, sy + 62, fill=flash_base, width=2)
        elif kind == "boss_fire":
            canvas.create_polygon(cx, sy, sx + w - 6, sy + 35, sx + w - 15, sy + h, sx + 15, sy + h, sx + 6, sy + 35, fill=fill, outline=ink)
            for dx in (-18, 0, 18):
                canvas.create_polygon(cx + dx, sy + 13, cx + dx + 9, sy + 44, cx + dx - 7, sy + 38, fill=flash_base, outline="")
        elif kind == "boss_plant":
            canvas.create_rectangle(sx + 19, sy + 28, sx + w - 19, sy + h, fill=fill, outline=ink, width=2)
            canvas.create_oval(sx + 7, sy + 6, sx + w - 7, sy + 42, fill=fill, outline=ink, width=2)
            for dx in (-25, 25):
                canvas.create_arc(cx + dx - 22, sy + 18, cx + dx + 22, sy + 64, start=80 if dx < 0 else 210, extent=210, outline=ink, width=3)
            canvas.create_rectangle(cx - 9, sy + 18, cx + 9, sy + 27, fill=flash_base, outline="")
        elif kind == "boss_rock":
            pts = [sx + 10, sy + 8, sx + w - 14, sy + 4, sx + w - 2, sy + 35, sx + w - 16, sy + h, sx + 15, sy + h - 2, sx + 2, sy + 34]
            canvas.create_polygon(*pts, fill=fill, outline=ink)
            for dx in (14, 34, 52):
                canvas.create_line(sx + dx, sy + 12, sx + dx - 8, sy + 58, fill=flash_base, width=2)
        elif kind == "boss_water":
            canvas.create_oval(sx + 6, sy + 12, sx + w - 6, sy + h - 2, fill=fill, outline=ink, width=2)
            for yy in (sy + 31, sy + 45, sy + 59):
                canvas.create_arc(sx + 10, yy - 8, sx + w - 10, yy + 8, start=0, extent=180, outline=flash_base, width=2)
            canvas.create_rectangle(cx - 13, sy + 22, cx + 13, sy + 29, fill=flash_base, outline="")
        elif kind == "boss_aquatic":
            canvas.create_oval(sx + 4, sy + 20, sx + w - 12, sy + h - 10, fill=fill, outline=ink, width=2)
            canvas.create_polygon(sx + w - 15, sy + 36, sx + w + 18, sy + 20, sx + w + 18, sy + 58, fill=fill, outline=ink)
            canvas.create_polygon(sx + 27, sy + 18, sx + 39, sy + 4, sx + 45, sy + 21, fill=flash_base, outline="")
            canvas.create_rectangle(sx + 15, sy + 32, sx + 23, sy + 39, fill=flash_base, outline="")
        elif kind == "boss_thunder":
            body_rect(head_h=20, body_pad=12)
            for dx in (-28, 28):
                canvas.create_line(cx + dx, sy + 5, cx + dx - 10, sy + 30, cx + dx + 7, sy + 30, cx + dx - 8, sy + 64, fill=flash_base, width=3)
        elif kind == "boss_clone":
            # El clon jefe se dibuja como una versión grande del jugador para que se identifique de inmediato.
            scale_x = w / max(1, self.retro_player.w)
            scale_y = h / max(1, self.retro_player.h)
            canvas.create_rectangle(sx + 12, sy + 34, sx + w - 12, sy + h - 14, fill=fill, outline=ink, width=2)
            canvas.create_rectangle(sx + 18, sy + 10, sx + w - 18, sy + 36, fill=fill, outline=ink, width=2)
            canvas.create_rectangle(sx + 28, sy + 19, sx + w - 28, sy + 26, fill=flash_base, outline="")
            canvas.create_line(sx + 9, sy + h - 10, sx + w - 9, sy + 10, fill=flash_base, width=2)
        else:
            body_rect()

    def _draw_retro_enemies(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        # Los enemigos comunes mantienen el diseño/altura original; los jefes usan siluetas
        # específicas en la misma escala rival y con el mismo duotono del nivel.
        for enemy in self.retro_enemies:
            if not enemy.alive:
                continue
            sx = self._screen_x(enemy.x)
            sy = self._screen_y(enemy.y)
            if sx + enemy.w < -40 or sx > canvas.winfo_width() + 40 or sy + enemy.h < -50 or sy > canvas.winfo_height() + 50:
                continue
            flash = enemy.hurt_flash > 0 and int(enemy.hurt_flash * 40) % 2 == 0
            fill = base if flash else ink
            outline = ink
            is_ally = self._enemy_is_ally(enemy)
            if is_ally:
                fill = base if not flash else ink
                outline = ink
            if enemy.kind.startswith("boss"):
                self._draw_boss_sprite(canvas, enemy, sx, sy, base, ink, fill)
                self._draw_health_bar(canvas, sx, sy - 10, max(58, enemy.w), enemy.hp, enemy.max_hp, base, ink)
                continue
            minor_visual = enemy.kind in {"minor", "hopper", "flyer", "sprinter", "burrower", "splitter", "healer", "leech", "kamikaze", "ghost", "ninja"}
            if minor_visual:
                canvas.create_rectangle(sx, sy + 5, sx + enemy.w, sy + enemy.h - 3, fill=fill, outline=outline, width=2)
                canvas.create_rectangle(sx + 5, sy, sx + enemy.w - 5, sy + 6, fill=ink if not flash else base, outline="")
                canvas.create_rectangle(sx + 7, sy + 10, sx + 11, sy + 14, fill=base if not flash else ink, outline="")
                canvas.create_rectangle(sx + enemy.w - 12, sy + 10, sx + enemy.w - 8, sy + 14, fill=base if not flash else ink, outline="")
                if enemy.kind == "flyer":
                    canvas.create_line(sx - 7, sy + 10, sx + enemy.w + 7, sy + 10, fill=ink, width=2)
                elif enemy.kind == "hopper":
                    canvas.create_polygon(sx + 2, sy + enemy.h - 2, sx + 11, sy + enemy.h + 7, sx + 20, sy + enemy.h - 2, fill=ink, outline=ink)
                elif enemy.kind == "sprinter":
                    canvas.create_line(sx - 7, sy + enemy.h - 3, sx + 2, sy + enemy.h - 9, fill=ink, width=2)
                elif enemy.kind == "kamikaze":
                    canvas.create_line(sx + 4, sy + 4, sx + enemy.w - 4, sy + enemy.h - 5, fill=base if not flash else ink, width=2)
                elif enemy.kind == "ghost":
                    canvas.create_oval(sx + 4, sy - 4, sx + enemy.w - 4, sy + enemy.h + 3, outline=ink, width=1)
                elif enemy.kind == "ninja":
                    canvas.create_line(sx + 3, sy + enemy.h - 5, sx + enemy.w + 8, sy + 5, fill=base if not flash else ink, width=2)
                    canvas.create_polygon(sx + enemy.w - 3, sy + 3, sx + enemy.w + 10, sy + 8, sx + enemy.w - 3, sy + 13, fill=ink, outline=ink)
            else:
                canvas.create_rectangle(sx + 10, sy + 16, sx + enemy.w - 10, sy + enemy.h, fill=fill, outline=outline, width=2)
                canvas.create_rectangle(sx + 4, sy + 4, sx + enemy.w - 4, sy + 24, fill=fill, outline=outline, width=2)
                canvas.create_rectangle(sx + 14, sy + 10, sx + 24, sy + 16, fill=base if not flash else ink, outline="")
                canvas.create_rectangle(sx + enemy.w - 24, sy + 10, sx + enemy.w - 14, sy + 16, fill=base if not flash else ink, outline="")
                cannon_dir = 1 if enemy.vx >= 0 else -1
                if cannon_dir > 0:
                    canvas.create_rectangle(sx + enemy.w - 6, sy + 28, sx + enemy.w + 18, sy + 36, fill=ink, outline="")
                else:
                    canvas.create_rectangle(sx - 18, sy + 28, sx + 6, sy + 36, fill=ink, outline="")
                if enemy.kind == "shield":
                    shield_x = sx + (enemy.w - 4 if enemy.vx >= 0 else 0)
                    canvas.create_rectangle(shield_x - 2, sy + 18, shield_x + 6, sy + enemy.h - 4, fill=base, outline=ink, width=2)
                elif enemy.kind == "sniper":
                    canvas.create_line(sx + enemy.w * 0.5, sy + 28, sx + enemy.w * 0.5 + (28 if enemy.vx >= 0 else -28), sy + 28, fill=ink, width=3)
                elif enemy.kind == "hunter":
                    barrel = 1 if enemy.vx >= 0 else -1
                    canvas.create_line(sx + enemy.w * 0.5, sy + 30, sx + enemy.w * 0.5 + barrel * 34, sy + 25, fill=ink, width=3)
                    canvas.create_line(sx + enemy.w * 0.5, sy + 36, sx + enemy.w * 0.5 + barrel * 34, sy + 41, fill=ink, width=3)
                elif enemy.kind == "bomber":
                    canvas.create_oval(sx + enemy.w * 0.5 - 10, sy + enemy.h - 18, sx + enemy.w * 0.5 + 10, sy + enemy.h + 2, outline=ink, width=2)
                elif enemy.kind == "healer":
                    canvas.create_rectangle(sx + enemy.w * 0.5 - 3, sy + 28, sx + enemy.w * 0.5 + 3, sy + 46, fill=base if not flash else ink, outline="")
                    canvas.create_rectangle(sx + enemy.w * 0.5 - 10, sy + 34, sx + enemy.w * 0.5 + 10, sy + 40, fill=base if not flash else ink, outline="")
            if is_ally:
                canvas.create_text(sx + enemy.w * 0.5, sy - 18, text="ALLY", fill=ink, font=("Courier New", 6, "bold"))
            self._draw_health_bar(canvas, sx, sy - 9, max(28, enemy.w), enemy.hp, enemy.max_hp, base, ink)

    def _draw_player_sprite(self, canvas: tk.Canvas, x: float, y: float, base: str, ink: str, *, facing: int, on_ground: bool, jumps_used: int, walk_phase: float, hurt_timer: float = 0.0, clone: bool = False) -> None:
        w, h = self.retro_player.w, self.retro_player.h
        if hurt_timer > 0 and int(hurt_timer * 30) % 2 == 0:
            return
        if getattr(self.retro_player, "crouching", False) and not clone:
            visor = 3 if facing >= 0 else -3
            canvas.create_rectangle(x + 3, y + 5, x + w - 3, y + h - 3, fill=base, outline=ink, width=2)
            canvas.create_rectangle(x + 6, y + 10, x + w - 6, y + h - 5, fill=ink, outline="")
            canvas.create_rectangle(x + 6, y, x + w - 6, y + 10, fill=base, outline=ink, width=2)
            canvas.create_rectangle(x + 10 + visor, y + 4, x + 18 + visor, y + 7, fill=ink, outline="")
            canvas.create_rectangle(x + (w if facing > 0 else -8), y + 12, x + (w + 8 if facing > 0 else 0), y + 17, fill=ink, outline="")
            canvas.create_rectangle(x + 4, y + h - 5, x + w - 4, y + h, fill=ink, outline="")
            return
        step = int(abs(math.sin(walk_phase)) * 3) if on_ground else 2
        visor = 3 if facing >= 0 else -3
        if clone:
            canvas.create_rectangle(x + 1, y + 15, x + w - 1, y + h - 7, outline=ink, width=1)
            canvas.create_rectangle(x + 6, y + 6, x + w - 6, y + 16, outline=ink, width=1)
            return
        if self.retro_player.dash_timer > 0:
            trail_dir = -1 if facing >= 0 else 1
            for i in range(3):
                tx = x + trail_dir * (13 + i * 9)
                canvas.create_rectangle(tx + 4, y + 8 + i * 3, tx + w - 6, y + h - 9 - i, fill=ink, outline="")
                canvas.create_rectangle(tx + 8, y + 12 + i * 3, tx + w - 10, y + h - 13 - i, fill=base, outline="")
        canvas.create_rectangle(x + 4, y + h - 10, x + 10, y + h, fill=ink, outline="")
        canvas.create_rectangle(x + w - 10, y + h - 10 + step, x + w - 4, y + h + step, fill=ink, outline="")
        canvas.create_rectangle(x + 3, y + 14, x + w - 3, y + h - 8, fill=base, outline=ink, width=2)
        canvas.create_rectangle(x + 8, y + 18, x + w - 8, y + h - 9, fill=ink, outline="")
        canvas.create_rectangle(x + 5, y + 5, x + w - 5, y + 18, fill=base, outline=ink, width=2)
        canvas.create_rectangle(x + 4, y + 1, x + w - 4, y + 9, fill=ink, outline="")
        canvas.create_rectangle(x + 9 + visor, y + 10, x + 18 + visor, y + 14, fill=ink, outline="")
        canvas.create_rectangle(x + 12 + visor, y + 11, x + 15 + visor, y + 13, fill=base, outline="")
        canvas.create_rectangle(x + (w if facing > 0 else -7), y + 19, x + (w + 7 if facing > 0 else 0), y + 24, fill=ink, outline="")
        if not on_ground and jumps_used >= 2:
            canvas.create_rectangle(x - 6, y + h - 4, x + w + 6, y + h, fill=ink, outline="")
            canvas.create_rectangle(x - 2, y + h - 8, x + w + 2, y + h - 5, fill=ink, outline="")

    def _shadow_specs(self) -> list[tuple[float, bool]]:
        """Devuelve (delay, espejo) para cada sombra activa."""
        if self.selected_mode == "race":
            delays = [d for d in SHADOW_DELAY_PRESETS if d in set(getattr(self, "race_shadow_delays", list(SHADOW_DELAY_PRESETS)))]
            if not delays:
                delays = [3.0]
            return [(float(d), False) for d in delays]
        if self.selected_mode == "challenge":
            # Sin sombras espejo: 8 sombras, todas con aparición mínima de 3s para evitar caos inicial.
            return [(float(d), False) for d in CHALLENGE_SHADOW_DELAYS]
        if self._is_campaign_mode():
            table = {
                2: [(3.0, False)],
                3: [(1.5, True)],
                4: [(3.0, False), (2.0, False)],
                5: [(3.0, False), (2.0, False), (1.0, False)],
                6: [(1.0, True)],
            }
            return table.get(int(self.level_number), [])
        return []

    def _record_shadow_action(self, action: str, **payload: object) -> None:
        if not self._shadow_specs():
            return
        action_id = self._shadow_next_action_id
        self._shadow_next_action_id += 1
        self.shadow_action_history.append((action_id, time.perf_counter(), action, dict(payload)))
        if len(self.shadow_action_history) > 260:
            self.shadow_action_history = self.shadow_action_history[-220:]

    def _shadow_delay_for_index(self, index: int) -> float:
        specs = self._shadow_specs()
        if not specs:
            return 0.0
        return specs[max(0, min(index, len(specs) - 1))][0]

    def _shadow_is_mirror(self, index: int) -> bool:
        specs = self._shadow_specs()
        return bool(specs[index][1]) if 0 <= index < len(specs) else False

    def _trigger_shadow_action(self, index: int, action: str, x: float, y: float, facing: int, payload: dict[str, object]) -> None:
        if self.shadow_chaser_hp.get(index, 0.0) <= 0:
            return
        player = self.retro_player
        # Los ataques de sombras están aislados: solo pueden dañar al jugador, nunca a enemigos.
        if action == "gun":
            level = int(payload.get("level", 0))
            direction = 1 if facing >= 0 else -1
            damage_by_level = {0: 1, 1: 2, 2: 4, 3: 6}
            self._retro_spawn_projectile(
                kind="shadow_bullet",
                vx=direction * (360.0 + level * 110.0),
                vy=float(payload.get("vy", 0.0)),
                life=1.15 + level * 0.18,
                damage=SHADOW_FIXED_DAMAGE,
                level=level,
                max_distance=TILE * (3.2 + level * 0.6),
                owner=f"shadow:{index}",
                source_x=x,
                source_y=y,
                source_facing=facing,
                ability="shadow_gun",
            )
            self.retro_effects.append(RetroEffect(x + player.w * 0.5, y + player.h * 0.42, 16.0 + level * 5.0, 0.22, "shadow_shot"))
        elif action in {"sword", "boomerang"}:
            reach = TILE * 0.95
            sx = x + (player.w if facing > 0 else -reach)
            sy = y + 3.0
            if action == "boomerang":
                direction = 1 if facing >= 0 else -1
                self._retro_spawn_projectile(kind="shadow_boomerang", vx=direction * 450.0, life=1.6, damage=3, level=1, max_distance=TILE * 4.0, owner=f"shadow:{index}", source_x=x, source_y=y, source_facing=facing, ability="shadow_sword")
            if self._retro_intersects(player.x, player.y, player.w, player.h, RetroRect(sx, sy, reach, player.h + 4.0, "shadow_sword")):
                self._damage_player(SHADOW_FIXED_DAMAGE, sx, allow_if_hurt=True)
            self.retro_effects.append(RetroEffect(sx + reach * 0.5, sy + 14.0, 28.0, 0.20, "shadow_sword"))
        elif action == "shield":
            self.retro_effects.append(RetroEffect(x + player.w * 0.5, y + player.h * 0.5, 36.0, 0.45, "shadow_shield"))
        elif action == "time_space":
            # Imitación hostil: microfractura temporal que castiga al jugador si está cerca.
            cx = x + player.w * 0.5
            cy = y + player.h * 0.5
            if math.hypot((player.x + player.w * 0.5) - cx, (player.y + player.h * 0.5) - cy) < TILE * 2.1:
                self._damage_player(SHADOW_FIXED_DAMAGE, cx, allow_if_hurt=True)
                player.vx *= 0.55
            self.retro_effects.append(RetroEffect(cx, cy, 54.0, 0.55, "shadow_time"))
        elif action == "nova":
            cx = x + player.w * 0.5
            cy = y + player.h * 0.5
            if math.hypot((player.x + player.w * 0.5) - cx, (player.y + player.h * 0.5) - cy) < TILE * 1.7:
                self._damage_player(SHADOW_FIXED_DAMAGE, cx, allow_if_hurt=True)
            self.retro_effects.append(RetroEffect(cx, cy, 46.0, 0.38, "shadow_nova"))
        elif action in {"flight", "telekinesis", "parry", "triple_jump"}:
            self.retro_effects.append(RetroEffect(x + player.w * 0.5, y + player.h * 0.5, 28.0, 0.28, f"shadow_{action}"))

    def _update_shadow_actions(self) -> None:
        if not self._shadow_specs() or not self.shadow_action_history:
            return
        now = time.perf_counter()
        snapshots = {idx: (x, y, facing) for idx, x, y, facing, _on_ground, _jumps in self._shadow_snapshots()}
        for index, (x, y, facing) in snapshots.items():
            delay = self._shadow_delay_for_index(index)
            due_time = now - delay
            cursor = self.shadow_action_cursors.get(index, 1)
            next_cursor = cursor
            for action_id, action_time, action, payload in self.shadow_action_history:
                if action_id < cursor:
                    continue
                if action_time <= due_time:
                    self._trigger_shadow_action(index, action, x, y, facing, payload)
                    next_cursor = action_id + 1
                else:
                    break
            self.shadow_action_cursors[index] = next_cursor

    def _shadow_chaser_count(self) -> int:
        return len(self._shadow_specs())

    def _shadow_chaser_max_health(self, index: int) -> float:
        # Las sombras enemigas usan la misma vida base actual del jugador.
        # Las sombras espejo de campaña en niveles 3 y 6 son objetivos especiales
        # y ahora tienen x3 de vida, sin alterar al resto de sombras.
        player_max_hp = float(getattr(self.retro_player, "max_hp", STARTING_PLAYER_HP))
        is_level_3_or_6_mirror = (
            self._is_campaign_mode()
            and int(self.level_number) in {3, 6}
            and self._shadow_is_mirror(index)
        )
        return max(1.0, player_max_hp * (3.0 if is_level_3_or_6_mirror else 1.0))

    def _ensure_shadow_chaser_health(self) -> None:
        count = self._shadow_chaser_count()
        if count <= 0:
            self.shadow_chaser_hp.clear()
            self.shadow_chaser_max_hp.clear()
            self.shadow_chaser_hurt.clear()
            self.shadow_chaser_respawn.clear()
            self.shadow_action_history.clear()
            self.shadow_action_cursors.clear()
            return
        active = set(range(count))
        for store in (self.shadow_chaser_hp, self.shadow_chaser_max_hp, self.shadow_chaser_hurt, self.shadow_chaser_respawn):
            for key in list(store):
                if key not in active:
                    del store[key]
        for index in range(count):
            max_hp = self._shadow_chaser_max_health(index)
            old_max = self.shadow_chaser_max_hp.get(index)
            if old_max != max_hp:
                ratio = 1.0 if old_max in (None, 0) else max(0.0, min(1.0, self.shadow_chaser_hp.get(index, old_max) / old_max))
                self.shadow_chaser_max_hp[index] = max_hp
                self.shadow_chaser_hp[index] = max(1.0, max_hp * ratio)
            self.shadow_chaser_hp.setdefault(index, max_hp)
            self.shadow_chaser_hurt.setdefault(index, 0.0)
            self.shadow_chaser_respawn.setdefault(index, 0.0)

    def _damage_shadow_chaser(
        self,
        index: int,
        amount: int | float,
        source_x: float,
        *,
        ability: str = "",
        ignore_hurt: bool = False,
        grant_xp: bool = True,
    ) -> bool:
        self._ensure_shadow_chaser_health()
        if index not in self.shadow_chaser_hp or self.shadow_chaser_hp.get(index, 0.0) <= 0:
            return False
        if self.shadow_chaser_hurt.get(index, 0.0) > 0 and not ignore_hurt:
            return False
        damage = max(0.5, float(amount))
        if ability and random.random() < self._ability_crit_chance(ability):
            damage *= 2.0
        self.shadow_chaser_hp[index] = max(0.0, self.shadow_chaser_hp.get(index, 0.0) - damage)
        self.shadow_chaser_hurt[index] = 0.17
        for snap in self._shadow_snapshots(include_dead=True):
            snap_index, x, y, _facing, _on_ground, _jumps_used = snap
            if snap_index == index:
                self.retro_effects.append(RetroEffect(x + self.retro_player.w * 0.5, y + self.retro_player.h * 0.45, 18.0, 0.22, "shadow_hit"))
                break
        if self.shadow_chaser_hp[index] <= 0:
            if self._campaign_is_arena_stage():
                # En los niveles de arena de campaña la sombra es objetivo real:
                # no reaparece, y su derrota puede completar el stage.
                self.shadow_chaser_respawn[index] = 0.0
            else:
                self.shadow_chaser_respawn[index] = 3.0
            self.retro_effects.append(RetroEffect(source_x, self.retro_player.y, 34.0, 0.55, "defeat"))
            # La XP por sombra solo se concede cuando la derrota proviene de daño
            # controlado por el jugador. Enemigos y proyectiles ajenos ya no generan
            # autofarming al destruir sombras por su cuenta.
            if grant_xp:
                self.xp_count += max(1, 6 + 2 * max(1, int(self.level_number)))
            self._maybe_complete_campaign_arena_objective()
        return True

    def _damage_shadow_area(self, x: float, y: float, radius: float, damage: int | float, ability: str) -> int:
        hits = 0
        for index, sx, sy, _facing, _on_ground, _jumps_used in self._shadow_snapshots():
            cx = sx + self.retro_player.w * 0.5
            cy = sy + self.retro_player.h * 0.5
            if math.hypot(cx - x, cy - y) <= radius:
                if self._damage_shadow_chaser(index, damage, x, ability=ability):
                    hits += 1
        return hits

    def _damage_shadow_rect(self, x: float, y: float, w: float, h: float, damage: int | float, ability: str, facing: int) -> int:
        hits = 0
        for index, sx, sy, _shadow_facing, _on_ground, _jumps_used in self._shadow_snapshots():
            if sx < x + w and sx + self.retro_player.w > x and sy < y + h and sy + self.retro_player.h > y:
                if self._damage_shadow_chaser(index, damage, sx + self.retro_player.w * 0.5, ability=ability):
                    hits += 1
        return hits

    def _all_challenge_shadows_defeated(self) -> bool:
        # En Desafío v2, las sombras son presión permanente; la condición real
        # de victoria es derrotar al jefe especial del otro lado del mapa.
        return False

    def _shadow_snapshots(self, *, include_dead: bool = False) -> list[tuple[int, float, float, int, bool, int]]:
        if not self.shadow_chaser_history:
            return []
        self._ensure_shadow_chaser_health()
        now = time.perf_counter()
        specs = self._shadow_specs()
        result: list[tuple[int, float, float, int, bool, int]] = []
        for index, (delay, mirror) in enumerate(specs):
            if not include_dead and self.shadow_chaser_hp.get(index, 0.0) <= 0:
                continue
            age = now - self.shadow_chaser_history[0][0]
            min_spawn_age = max(delay, CHALLENGE_SHADOW_SPAWN_GRACE) if self.selected_mode == "challenge" else delay
            if age < min_spawn_age:
                # La sombra todavía se está cargando: no aparece ni colisiona encima del jugador.
                continue
            target_time = now - delay
            snap = min(self.shadow_chaser_history, key=lambda item: abs(item[0] - target_time))
            _, x, y, facing, on_ground, jumps_used = snap
            if mirror:
                x = max(8.0, min(self.retro_world_width - self.retro_player.w - 8.0, self.retro_world_width - x - self.retro_player.w))
                facing = -facing
            result.append((index, x, y, facing, on_ground, jumps_used))
        return result

    def _update_shadow_chasers(self, dt: float) -> None:
        self.shadow_damage_cooldown = max(0.0, self.shadow_damage_cooldown - dt)
        if not self._shadow_specs():
            self.shadow_chaser_history.clear()
            self.shadow_chaser_hp.clear()
            self.shadow_chaser_max_hp.clear()
            self.shadow_chaser_hurt.clear()
            self.shadow_chaser_respawn.clear()
            return
        self._ensure_shadow_chaser_health()
        for index in range(self._shadow_chaser_count()):
            self.shadow_chaser_hurt[index] = max(0.0, self.shadow_chaser_hurt.get(index, 0.0) - dt)
            if self.shadow_chaser_hp.get(index, 0.0) <= 0 and self.shadow_chaser_respawn.get(index, 0.0) > 0:
                self.shadow_chaser_respawn[index] = max(0.0, self.shadow_chaser_respawn[index] - dt)
                if self.shadow_chaser_respawn[index] <= 0:
                    self.shadow_chaser_hp[index] = self.shadow_chaser_max_hp.get(index, self._shadow_chaser_max_health(index))
                    self.retro_effects.append(RetroEffect(self.retro_player.x + self.retro_player.w * 0.5, self.retro_player.y - 26.0, 28.0, 0.45, "clone"))
        player = self.retro_player
        now = time.perf_counter()
        self.shadow_chaser_history.append((now, player.x, player.y, player.facing, player.on_ground, player.jumps_used))
        max_delay = max((delay for delay, _mirror in self._shadow_specs()), default=0.0)
        cutoff = now - max_delay - 0.75
        self.shadow_chaser_history = [snap for snap in self.shadow_chaser_history if snap[0] >= cutoff]
        if self.shadow_damage_cooldown > 0:
            return
        for index, x, y, _facing, _on_ground, _jumps in self._shadow_snapshots():
            if self._retro_intersects(player.x, player.y, player.w, player.h, RetroRect(x, y, player.w, player.h, "shadow")):
                stomp = self._ability_owned("parry") and player.vy > 80 and player.y + player.h <= y + max(18.0, player.h * 0.38)
                nova_hit = self._ability_owned("nova") and player.dash_timer > 0
                if stomp:
                    self._damage_shadow_chaser(index, self._parry_damage(), x, ability="parry")
                    self.parry_timer = max(getattr(self, "parry_timer", 0.0), self._parry_window())
                    player.vy = -self._parry_bounce_velocity()
                    player.on_ground = False
                    player.jumps_used = max(1, player.jumps_used)
                    self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h, 24.0, 0.28, "parry"))
                    continue
                if nova_hit:
                    self._damage_shadow_chaser(index, self._nova_damage(), x, ability="nova")
                    continue
                damage = SHADOW_FIXED_DAMAGE
                self._damage_player(damage, x, allow_if_hurt=True)
                self.shadow_damage_cooldown = 1.25
                self.retro_effects.append(RetroEffect(player.x + player.w * 0.5, player.y + player.h * 0.5, 36.0, 0.45, "shadow_hit"))
                break
        self._update_shadow_actions()
        if self._all_challenge_shadows_defeated() and self.level_intro_timer <= 0 and self._pending_level_advance <= 0:
            self.win_banner_timer = 1.25
            self._pending_level_advance = 1.25

    def _draw_shadow_chasers(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        if not self._shadow_specs():
            return
        for draw_order, (idx, x, y, facing, on_ground, jumps_used) in enumerate(self._shadow_snapshots()):
            sx = self._screen_x(x) - 6 - draw_order * 2
            sy = self._screen_y(y)
            # Dibujar las sombras con el mismo lenguaje visual del clon visible.
            # En una versión anterior se reutilizaba este diseño; si se invierten
            # los colores aquí, el contorno queda del mismo color del fondo y la
            # sombra prácticamente desaparece.
            pulse = int(abs(math.sin(self.anim_phase * 4 + idx)) * 2)
            canvas.create_rectangle(sx - 3 - pulse, sy + 4 - pulse, sx + self.retro_player.w + 3 + pulse, sy + self.retro_player.h + 2 + pulse, outline=ink, width=1)
            self._draw_player_sprite(canvas, sx, sy, base, ink, facing=facing, on_ground=on_ground, jumps_used=jumps_used, walk_phase=self.retro_player.walk_phase, clone=True)
            hp = self.shadow_chaser_hp.get(idx, 0.0)
            max_hp = self.shadow_chaser_max_hp.get(idx, max(1.0, hp))
            self._draw_health_bar(canvas, sx - 2, sy - 12, self.retro_player.w + 4, hp, max_hp, base, ink)
            canvas.create_text(sx + self.retro_player.w * 0.5, sy - 18, text=f"S{idx + 1}", fill=ink, font=("Courier New", 6, "bold"))

    def _draw_clone(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        if self.clone_timer <= 0 or not self.clone_history:
            return
        target_time = time.perf_counter() - 0.25
        snapshot = min(self.clone_history, key=lambda item: abs(item[0] - target_time))
        _, x, y, facing, on_ground, jumps_used = snapshot
        self._draw_player_sprite(canvas, self._screen_x(x) - 6, self._screen_y(y), base, ink, facing=facing, on_ground=on_ground, jumps_used=jumps_used, walk_phase=self.retro_player.walk_phase, clone=True)

    def _draw_p2_player(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        if not self.p2_enabled:
            return
        p = self.p2_player
        x = self._screen_x(p.x)
        y = self._screen_y(p.y)
        if x + p.w < -80 or x > canvas.winfo_width() + 80 or y + p.h < -90 or y > canvas.winfo_height() + 90:
            return
        sprite_base, sprite_ink = ink, base
        self._draw_player_sprite(canvas, x, y, sprite_base, sprite_ink, facing=p.facing, on_ground=p.on_ground, jumps_used=p.jumps_used, walk_phase=p.walk_phase, hurt_timer=p.hurt_timer)
        if p.attack_timer > 0:
            if p.facing > 0:
                canvas.create_rectangle(x + p.w + 4, y + 9, x + p.w + 44, y + 14, fill=base, outline=ink)
            else:
                canvas.create_rectangle(x - 44, y + 9, x - 4, y + 14, fill=base, outline=ink)
        label = "CPU" if self.p2_is_cpu else "P2"
        canvas.create_text(x + p.w * 0.5, y - 8, text=label, fill=ink, font=("Courier New", 7, "bold"))

    def _draw_retro_player(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        p = self.retro_player
        x = self._screen_x(p.x)
        y = self._screen_y(p.y)
        sprite_base, sprite_ink = (ink, base) if ((self._ability_owned("nova") and p.dash_timer > 0) or self.slow_time_timer > 0) else (base, ink)
        self._draw_player_sprite(canvas, x, y, sprite_base, sprite_ink, facing=p.facing, on_ground=p.on_ground, jumps_used=p.jumps_used, walk_phase=p.walk_phase, hurt_timer=p.hurt_timer)
        w, h = p.w, p.h
        if self.shield_timer > 0:
            pulse = int(abs(math.sin(self.anim_phase * 7)) * 4)
            canvas.create_rectangle(x - 8 - pulse, y - 8 - pulse, x + w + 8 + pulse, y + h + 8 + pulse, outline=ink, width=2)
            canvas.create_rectangle(x - 3 - pulse, y - 3 - pulse, x + w + 3 + pulse, y + h + 3 + pulse, outline=ink, width=1)
        if p.attack_timer > 0:
            if p.facing > 0:
                canvas.create_rectangle(x + w + 4, y + 9, x + w + 48, y + 14, fill=ink, outline="")
                canvas.create_rectangle(x + w + 34, y + 6, x + w + 50, y + 17, fill=ink, outline="")
            else:
                canvas.create_rectangle(x - 48, y + 9, x - 4, y + 14, fill=ink, outline="")
                canvas.create_rectangle(x - 50, y + 6, x - 34, y + 17, fill=ink, outline="")
        if self._x_charge_active:
            held = max(0.0, time.perf_counter() - self._x_charge_started)
            level = 3 if held >= 5 else 2 if held >= 3 else 1 if held >= 1 else 0
            bx = x - 4
            by = y - 10
            canvas.create_rectangle(bx, by, bx + 34, by + 5, fill=base, outline=ink, width=1)
            fill_w = min(34, int((held / 5.0) * 34))
            if fill_w > 0:
                canvas.create_rectangle(bx, by, bx + fill_w, by + 5, fill=ink, outline="")
            for marker in (7, 20, 34):
                canvas.create_line(bx + marker, by, bx + marker, by + 5, fill=base if marker <= fill_w else ink, width=1)
            if level:
                canvas.create_rectangle(x + (w + 9 if p.facing > 0 else -13), y + 18, x + (w + 13 if p.facing > 0 else -9), y + 22, fill=ink, outline="")
        if self._z_sword_charge_active:
            held = max(0.0, time.perf_counter() - self._z_sword_charge_started)
            bx = x - 4
            by = y - 18
            canvas.create_rectangle(bx, by, bx + 34, by + 5, fill=base, outline=ink, width=1)
            fill_w = min(34, int((held / 2.0) * 34))
            if fill_w > 0:
                canvas.create_rectangle(bx, by, bx + fill_w, by + 5, fill=ink, outline="")
            canvas.create_line(bx + 34, by, bx + 34, by + 5, fill=base if fill_w >= 34 else ink, width=1)
            canvas.create_text(bx + 17, by - 7, text="BOOM", fill=ink, font=("Courier New", 5, "bold"))

    def _draw_retro_projectiles(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        for projectile in self.retro_projectiles:
            sx = self._screen_x(projectile.x)
            sy = self._screen_y(projectile.y)
            if sx < -40 or sx > width + 40 or sy < -50 or sy > height + 50:
                continue
            if projectile.kind in {"boomerang", "mini_boomerang"}:
                size = 9 + int(2 * math.sin(self.anim_phase * 4))
                canvas.create_rectangle(sx - size, sy - 3, sx + size, sy + 3, fill=ink, outline="")
                canvas.create_rectangle(sx - 3, sy - size, sx + 3, sy + size, fill=ink, outline="")
            elif projectile.kind in {"triple", "enemy"}:
                canvas.create_rectangle(sx - 4, sy - 3, sx + 8, sy + 3, fill=ink, outline="")
            elif projectile.kind in {"ninja_star", "ally_star"}:
                size = 8
                canvas.create_line(sx - size, sy, sx + size, sy, fill=ink, width=2)
                canvas.create_line(sx, sy - size, sx, sy + size, fill=ink, width=2)
                canvas.create_line(sx - size * .7, sy - size * .7, sx + size * .7, sy + size * .7, fill=base if projectile.owner == "ally" else ink, width=1)
            elif projectile.kind in {"hunter_shell", "ally_shotgun", "ally_bullet"}:
                canvas.create_rectangle(sx - 6, sy - 3, sx + 7, sy + 3, fill=base if projectile.owner == "ally" else ink, outline=ink, width=1)
            elif projectile.kind == "bomb":
                canvas.create_rectangle(sx - 8, sy - 8, sx + 8, sy + 8, fill=base, outline=ink, width=2)
                canvas.create_rectangle(sx - 3, sy - 12, sx + 3, sy - 8, fill=ink, outline="")
            elif projectile.kind == "flame":
                direction = 1 if projectile.vx >= 0 else -1
                fx0, fx1 = (sx - 4, sx + 34) if direction > 0 else (sx - 34, sx + 4)
                tx0, tx1 = (sx + 20, sx + 42) if direction > 0 else (sx - 42, sx - 20)
                canvas.create_rectangle(fx0, sy - 6, fx1, sy + 6, fill=ink, outline="")
                canvas.create_rectangle(tx0, sy - 10, tx1, sy + 10, fill=base, outline=ink, width=2)
            elif projectile.kind in {"toxic_cloud", "thorn_trap"}:
                r = projectile.radius or 34.0
                canvas.create_oval(sx - r * .35, sy - r * .35, sx + r * .35, sy + r * .35, outline=ink, width=2)
                canvas.create_rectangle(sx - 5, sy - 5, sx + 5, sy + 5, fill=ink, outline="")
            elif projectile.kind in {"mine", "meteor", "fire_wheel", "acid_orb", "seeker_missile"}:
                size = 12 + projectile.level * 4
                canvas.create_oval(sx - size, sy - size, sx + size, sy + size, fill=base, outline=ink, width=2)
                canvas.create_rectangle(sx - 4, sy - 4, sx + 4, sy + 4, fill=ink, outline="")
            else:
                size = 8 + projectile.level * 4
                canvas.create_rectangle(sx - size, sy - 4 - projectile.level, sx + size, sy + 4 + projectile.level, fill=ink, outline="")
                canvas.create_rectangle(sx - max(2, size - 4), sy - 1, sx + max(2, size - 4), sy + 1, fill=base, outline="")

    def _draw_race_finish(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        if (self.selected_mode != "race" and not self._campaign_has_finish_goal() and not self._is_tutorial_guided()) or self.race_finish_x <= 0.0:
            return
        sx = self._screen_x(self.race_finish_x)
        sy = self._screen_y(self._retro_ground_y() - 12.0)
        if sx < -80 or sx > canvas.winfo_width() + 120:
            return
        pulse = int(abs(math.sin(self.anim_phase * 4.0)) * 4)
        canvas.create_rectangle(sx - 4, sy - 104, sx + 4, sy + 8, fill=ink, outline="")
        canvas.create_polygon(sx + 4, sy - 100, sx + 66 + pulse, sy - 84, sx + 4, sy - 68, fill=base, outline=ink, width=2)
        canvas.create_text(sx + 36, sy - 55, text="META", fill=ink, font=("Courier New", 9, "bold"))

    def _draw_checkpoints(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        for checkpoint in self.retro_checkpoints:
            sx = self._screen_x(checkpoint.x)
            sy = self._screen_y(checkpoint.y)
            if sx < -60 or sx > canvas.winfo_width() + 60 or sy < -80 or sy > canvas.winfo_height() + 80:
                continue
            pole = ink if checkpoint.activated else base
            outline = ink
            canvas.create_rectangle(sx - 3, sy - 48, sx + 3, sy + 6, fill=ink, outline="")
            canvas.create_rectangle(sx - 12, sy + 2, sx + 14, sy + 8, fill=ink, outline="")
            if checkpoint.activated:
                pulse = int(abs(math.sin(self.anim_phase * 3)) * 3)
                canvas.create_rectangle(sx - 16 - pulse, sy - 42 - pulse, sx + 16 + pulse, sy - 10 + pulse, outline=ink, width=2)
            canvas.create_polygon(sx + 2, sy - 40, sx + 45, sy - 30, sx + 2, sy - 20, fill=pole, outline=outline)
            canvas.create_text(sx, sy + 20, text=checkpoint.label.replace("CHECKPOINT ", "CP "), fill=ink, font=("Courier New", 7, "bold"))

    def _draw_boxes(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        for box in self.retro_boxes:
            sx = self._screen_x(box.x)
            sy = self._screen_y(box.y)
            if sx + box.w < -40 or sx > canvas.winfo_width() + 40 or sy + box.h < -50 or sy > canvas.winfo_height() + 50:
                continue
            outline_w = 3 if box.grabbed else 2
            canvas.create_rectangle(sx, sy, sx + box.w, sy + box.h, fill=base, outline=ink, width=outline_w)
            canvas.create_rectangle(sx + 5, sy + 5, sx + box.w - 5, sy + box.h - 5, fill=ink, outline="")
            canvas.create_line(sx + 5, sy + 5, sx + box.w - 5, sy + box.h - 5, fill=base, width=2)
            canvas.create_line(sx + box.w - 5, sy + 5, sx + 5, sy + box.h - 5, fill=base, width=2)
            if self._ability_owned("telekinesis"):
                pulse = int(abs(math.sin(self.anim_phase * 4 + box.x)) * 3)
                canvas.create_rectangle(sx - 2 - pulse, sy - 2 - pulse, sx + box.w + 2 + pulse, sy + box.h + 2 + pulse, outline=ink, width=1)
            if box.grabbed:
                canvas.create_text(sx + box.w / 2, sy - 10, text="MOVER", fill=ink, font=("Courier New", 6, "bold"))

    def _draw_pickups_and_effects(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        for pickup in self.retro_pickups:
            if pickup.collected:
                continue
            sx = self._screen_x(pickup.x)
            sy = self._screen_y(pickup.y + math.sin(self.anim_phase * 2.5 + pickup.x) * 3)
            if sx < -40 or sx > self.canvas.winfo_width() + 40 or sy < -40 or sy > self.canvas.winfo_height() + 40:
                continue
            pulse = int(abs(math.sin(self.anim_phase * 3.2 + pickup.x)) * 3)
            if pickup.kind == "xp_orb":
                canvas.create_oval(sx - 8 - pulse, sy - 8 - pulse, sx + 8 + pulse, sy + 8 + pulse, outline=ink, width=1)
                canvas.create_oval(sx - 8, sy - 8, sx + 8, sy + 8, fill=base, outline=ink, width=2)
                canvas.create_rectangle(sx - 2, sy - 6, sx + 2, sy + 6, fill=ink, outline="")
            elif pickup.kind == "point_orb":
                canvas.create_rectangle(sx - 8 - pulse, sy - 8 - pulse, sx + 8 + pulse, sy + 8 + pulse, outline=ink, width=1)
                canvas.create_rectangle(sx - 7, sy - 7, sx + 7, sy + 7, fill=base, outline=ink, width=2)
                canvas.create_text(sx, sy, text="P", fill=ink, font=("Courier New", 8, "bold"))
            else:
                canvas.create_rectangle(sx - 11 - pulse, sy - 11 - pulse, sx + 11 + pulse, sy + 11 + pulse, outline=ink, width=1)
                canvas.create_rectangle(sx - 9, sy - 9, sx + 9, sy + 9, fill=base, outline=ink, width=2)
                canvas.create_rectangle(sx - 3, sy - 8, sx + 3, sy + 8, fill=ink, outline="")
                canvas.create_rectangle(sx - 8, sy - 3, sx + 8, sy + 3, fill=ink, outline="")
        for effect in self.retro_effects:
            sx = self._screen_x(effect.x)
            sy = self._screen_y(effect.y)
            if effect.kind == "xp_orb":
                canvas.create_text(sx, sy - effect.radius, text="+1", fill=ink, font=("Courier New", 9, "bold"))
            elif effect.kind == "heal":
                canvas.create_text(sx, sy - effect.radius, text="+HP", fill=ink, font=("Courier New", 9, "bold"))
            elif effect.kind == "point_orb":
                canvas.create_text(sx, sy - effect.radius, text="+P", fill=ink, font=("Courier New", 9, "bold"))
            elif effect.kind == "tank":
                canvas.create_text(sx, sy - effect.radius, text="TANQUE +5", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "no_xp":
                canvas.create_text(sx, sy - effect.radius, text="FALTA XP", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "locked":
                canvas.create_text(sx, sy - effect.radius, text="BLOQUEADA", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "select":
                canvas.create_text(sx, sy - effect.radius, text="EQUIPADA", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "no_heal":
                canvas.create_text(sx, sy - effect.radius, text="SIN TANQUE", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "cooldown":
                canvas.create_text(sx, sy - effect.radius, text="COOLDOWN", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind.startswith("upgrade"):
                canvas.create_text(sx, sy - effect.radius, text="MEJORA", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "slow_time":
                canvas.create_text(sx, sy - effect.radius, text="TIEMPO LENTO", fill=ink, font=("Courier New", 8, "bold"))
            elif effect.kind == "trap":
                canvas.create_text(sx, sy - effect.radius, text="TRAMPA", fill=ink, font=("Courier New", 7, "bold"))
                canvas.create_polygon(sx - 10, sy + 8, sx, sy - 10, sx + 10, sy + 8, fill=ink, outline=ink)
            elif effect.kind.startswith("atk_") or effect.kind.startswith("atk2_"):
                radius = effect.radius
                direction = 1 if self.retro_player.facing >= 0 else -1
                # Flash principal + trazo direccional. Sirve para todas las armas sin sprites externos.
                canvas.create_oval(sx - radius * 0.55, sy - radius * 0.35, sx + radius * 0.55, sy + radius * 0.35, outline=ink, width=2)
                canvas.create_line(sx - direction * radius * 0.75, sy + radius * 0.35, sx + direction * radius * 0.9, sy - radius * 0.35, fill=ink, width=3)
                canvas.create_rectangle(sx + direction * radius * 0.55 - 4, sy - 4, sx + direction * radius * 0.55 + 4, sy + 4, fill=ink, outline="")
            else:
                canvas.create_oval(sx - effect.radius, sy - effect.radius, sx + effect.radius, sy + effect.radius, outline=ink, width=2)
                canvas.create_oval(sx - effect.radius * 0.45, sy - effect.radius * 0.45, sx + effect.radius * 0.45, sy + effect.radius * 0.45, outline=ink, width=1)

    def _draw_pause_overlay(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        self.pause_buttons.clear()
        panel_w = min(930, width - 28)
        panel_h = min(536, height - 28)
        x0 = (width - panel_w) / 2
        y0 = (height - panel_h) / 2
        x1 = x0 + panel_w
        y1 = y0 + panel_h
        canvas.create_rectangle(0, 0, width, height, fill=base, stipple="gray25", outline="")
        canvas.create_rectangle(x0, y0, x1, y1, fill=base, outline=ink, width=4)
        canvas.create_rectangle(x0 + 8, y0 + 8, x1 - 8, y1 - 8, fill=base, outline=ink, width=2)
        canvas.create_text((x0 + x1) / 2, y0 + 23, text="PAUSA / TALLER LEMAT · ÁRBOLES LIBRES", fill=ink, font=("Courier New", 13, "bold"))
        self._ensure_quick_slots()
        slots_text = " ".join(f"{d}:{self._ability_name(a)[:8]}" for d, a in self.quick_slots.items())
        canvas.create_text((x0 + x1) / 2, y0 + 43, text=f"XP: {self.xp_count} · X=DISPARO · Z={self._ability_name(self.active_secondary_slot)} · SLOTS ACTIVOS 1-3: {slots_text}", fill=ink, font=("Courier New", 7, "bold"))

        def button(name: str, bx: float, by: float, bw: float, bh: float, title: str, enabled: bool = True) -> None:
            self.pause_buttons[name] = (bx, by, bx + bw, by + bh)
            fill = ink if enabled else base
            text_fill = base if enabled else ink
            canvas.create_rectangle(bx, by, bx + bw, by + bh, fill=fill, outline=ink, width=2)
            canvas.create_text(bx + bw / 2, by + bh / 2, text=title, fill=text_fill, font=("Courier New", 6, "bold"))

        abilities = ("gun", *ABILITY_ORDER)
        per_page = 5
        max_page = max(0, (len(abilities) - 1) // per_page)
        self.pause_page = max(0, min(getattr(self, "pause_page", 0), max_page))
        start_idx = self.pause_page * per_page
        shown = abilities[start_idx:start_idx + per_page]

        list_x = x0 + 20
        y = y0 + 68
        row_h = 70
        canvas.create_text(list_x, y - 10, text=f"ARMAS/HABILIDADES · PÁGINA {self.pause_page + 1}/{max_page + 1} · compra cualquier rama disponible, no solo la siguiente", anchor="w", fill=ink, font=("Courier New", 7, "bold"))
        button("page_prev", x1 - 188, y - 20, 82, 20, "< PÁG", self.pause_page > 0)
        button("page_next", x1 - 98, y - 20, 82, 20, "PÁG >", self.pause_page < max_page)

        for ability in shown:
            info = ABILITY_INFO[ability]
            owned = self._ability_owned(ability)
            num = self._quick_slot_label(ability)
            title = f"[{num}] {info.get('name', ability)}"
            canvas.create_rectangle(list_x, y, x1 - 20, y + row_h - 5, fill=base, outline=ink, width=1)
            canvas.create_text(list_x + 7, y + 6, text=title[:28], anchor="nw", fill=ink, font=("Courier New", 8, "bold"))
            canvas.create_text(list_x + 7, y + 21, text=str(info.get("desc", ""))[:60], anchor="nw", fill=ink, font=("Courier New", 6, "bold"))
            canvas.create_text(list_x + 7, y + 36, text=self._tree_branch_summary(ability)[:72] if owned else "bloqueada: compra o derrota requisito", anchor="nw", fill=ink, font=("Courier New", 6, "bold"))
            if owned and bool(info.get("upgradeable", False)):
                available = self._available_tree_nodes(ability)
                if available:
                    for idx, (branch, node) in enumerate(available[:4]):
                        cost = int(node.get("cost", UPGRADE_COST))
                        node_id = str(node.get("id", ""))
                        bx = list_x + 260 + idx * 112
                        label = f"{str(node.get('name', '?'))[:12]} {cost}XP"
                        button(f"upnode_{ability}|{node_id}", bx, y + 40, 104, 20, label, self.xp_count >= cost)
                else:
                    canvas.create_text(list_x + 270, y + 50, text="ÁRBOL COMPLETO", fill=ink, font=("Courier New", 6, "bold"))
            status_x = x1 - 356
            if not owned:
                cost = int(info.get("cost", 0))
                button(f"buy_{ability}", status_x, y + 10, 84, 22, f"BUY {cost}", self.xp_count >= cost)
            elif not bool(info.get("upgradeable", False)):
                canvas.create_text(status_x + 42, y + 20, text="PASIVA", fill=ink, font=("Courier New", 6, "bold"))
            if ability == "gun":
                canvas.create_text(x1 - 216, y + 19, text="X fijo", fill=ink, font=("Courier New", 6, "bold"))
            elif self._is_passive_auto_ability(ability):
                canvas.create_text(x1 - 250, y + 19, text="AUTO", fill=ink, font=("Courier New", 7, "bold"))
                canvas.create_text(x1 - 180, y + 19, text="sin slot 1-3", fill=ink, font=("Courier New", 6, "bold"))
            else:
                button(f"setz_{ability}", x1 - 260, y + 10, 38, 22, "Z", owned)
                for idx, digit in enumerate(("1", "2", "3")):
                    bx_slot = x1 - 216 + idx * 36
                    button(f"slot_{digit}_{ability}", bx_slot, y + 10, 30, 22, f"S{digit}", owned)
                    if self.quick_slots.get(digit) == ability:
                        canvas.create_rectangle(bx_slot - 2, y + 8, bx_slot + 32, y + 34, outline=ink, width=2)
                if self.active_secondary_slot == ability:
                    canvas.create_rectangle(x1 - 264, y + 7, x1 - 220, y + 36, outline=ink, width=2)
            y += row_h

        info_y = min(y1 - 116, y + 4)
        canvas.create_rectangle(x0 + 20, info_y, x1 - 20, info_y + 62, fill=base, outline=ink, width=1)
        canvas.create_text(x0 + 28, info_y + 8, text="CONTROLES / LECTURA", anchor="nw", fill=ink, font=("Courier New", 7, "bold"))
        if self.selected_mode == "multiplayer":
            canvas.create_text(x0 + 28, info_y + 24, text="J1: Flechas mover/saltar/agachar · Enter/Espacio dash · X disparo · Z habilidad · C/V/B accesos", anchor="nw", fill=ink, font=("Courier New", 6, "bold"))
            canvas.create_text(x0 + 28, info_y + 40, text="J2: J/L mover · I saltar · K dash · U disparo · O sable/habilidad · J1 sin WASD para evitar doble control", anchor="nw", fill=ink, font=("Courier New", 6, "bold"))
        else:
            canvas.create_text(x0 + 28, info_y + 24, text="X dispara/carga · Z usa selección activa · C Jetpack · F linterna noche · Click cajas · B Shield · 0 tanque", anchor="nw", fill=ink, font=("Courier New", 6, "bold"))
            canvas.create_text(x0 + 28, info_y + 40, text=f"Modo: {self._mode_label().upper()} · XP: {self.xp_count} · Linterna mejora con ramas de 7XP", anchor="nw", fill=ink, font=("Courier New", 6, "bold"))

        life_y = y1 - 44
        button("upgrade_life", x0 + 20, life_y, 136, 26, "Vida +5 / 3XP", self.xp_count >= UPGRADE_COST)
        button("setz_none", x0 + 166, life_y, 110, 26, "Z = ninguna", True)
        small_w = 150
        button("resume", x1 - small_w * 2 - 34, life_y, small_w, 26, "CONTINUAR", True)
        button("menu", x1 - small_w - 20, life_y, small_w, 26, "REINICIAR", True)

    def _draw_arena_scoreboard(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        if self.selected_mode != "arena" or not self.arena_match_over:
            return
        ranking = self._arena_rankings()[:16]
        panel_w = min(540, width - 40)
        panel_h = min(430, height - 50)
        x0 = (width - panel_w) / 2
        y0 = (height - panel_h) / 2
        x1 = x0 + panel_w
        y1 = y0 + panel_h
        canvas.create_rectangle(0, 0, width, height, fill=base, stipple="gray25", outline="")
        canvas.create_rectangle(x0, y0, x1, y1, fill=base, outline=ink, width=4)
        canvas.create_text((x0+x1)/2, y0 + 28, text="TABLA FINAL · ARENA 5:00", fill=ink, font=("Courier New", 15, "bold"))
        canvas.create_text((x0+x1)/2, y0 + 52, text="GANA QUIEN TIENE MÁS PUNTOS", fill=ink, font=("Courier New", 8, "bold"))
        row_y = y0 + 82
        for pos, (_pid, name, score) in enumerate(ranking, start=1):
            line = f"{pos:02d}. {name:<16} {score:>3} pts"
            canvas.create_text(x0 + 54, row_y, text=line, anchor="w", fill=ink, font=("Courier New", 9 if pos <= 3 else 8, "bold"))
            row_y += 20
        canvas.create_text((x0+x1)/2, y1 - 24, text="ESC pausa · M reinicia desde menú", fill=ink, font=("Courier New", 7, "bold"))

    def _draw_hud(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        player = self.retro_player
        px0, py0, px1, py1 = self._pause_button_bbox
        canvas.create_rectangle(px0, py0, px1, py1, fill=ink, outline=ink, width=2)
        canvas.create_rectangle(px0 + 3, py0 + 3, px1 - 3, py1 - 3, fill=base, outline="")
        canvas.create_text((px0 + px1) / 2, (py0 + py1) / 2, text="PAUSA", fill=ink, font=("Courier New", 8, "bold"))

        # HUD principal: menos texto permanente, más barras leíbles.
        hud_x = 164
        hud_y = 10
        hud_w = min(width - hud_x - 18, 560)
        canvas.create_rectangle(hud_x, hud_y, hud_x + hud_w, hud_y + 46, fill=base, outline=ink, width=2)
        canvas.create_text(hud_x + 10, hud_y + 11, text="VIDA", anchor="w", fill=ink, font=("Courier New", 9, "bold"))
        self._draw_health_bar(canvas, hud_x + 58, hud_y + 9, 154, player.hp, player.max_hp, base, ink)
        cp_label = "Inicio" if self.active_checkpoint_index < 0 else self.retro_checkpoints[self.active_checkpoint_index].label.replace("CHECKPOINT ", "CP ")
        canvas.create_text(hud_x + 228, hud_y + 11, text=f"XP {self.xp_count} · TANQUES {self.heal_tanks}", anchor="w", fill=ink, font=("Courier New", 8, "bold"))
        canvas.create_text(hud_x + 10, hud_y + 31, text=f"Z {self._ability_name(self.active_secondary_slot)[:14]} · {self._mode_label().upper()[:18]} · {cp_label}", anchor="w", fill=ink, font=("Courier New", 7, "bold"))
        spec_short = str(getattr(self, "level_spec", {}).get("modifier_name", ""))[:14]
        combo = f" · COMBO x{self.combo_count}" if getattr(self, "combo_count", 0) > 1 else ""
        canvas.create_text(hud_x + 292, hud_y + 31, text=f"{spec_short}{combo}", anchor="w", fill=ink, font=("Courier New", 7, "bold"))

        self._ensure_quick_slots()
        slot_y = 60
        slot_x = hud_x
        for idx, digit in enumerate(("1", "2", "3")):
            ability = self.quick_slots.get(digit, "none")
            bx = slot_x + idx * 72
            selected = ability == self.active_secondary_slot and ability != "none"
            canvas.create_rectangle(bx, slot_y, bx + 66, slot_y + 20, fill=ink if selected else base, outline=ink, width=1)
            canvas.create_text(bx + 33, slot_y + 10, text=f"{digit}:{self._ability_name(ability)[:5]}", fill=base if selected else ink, font=("Courier New", 6, "bold"))

        status_y = 86
        if self._is_mode_night():
            max_bat = self._flashlight_battery_max()
            canvas.create_rectangle(hud_x, status_y, hud_x + 170, status_y + 12, fill=base, outline=ink, width=1)
            if self.flashlight_on:
                ratio = self.flashlight_energy / max(0.1, max_bat)
                label = f"F LINTERNA {self.flashlight_energy:.1f}s"
            elif self.flashlight_recharge > 0:
                ratio = 1.0 - self.flashlight_recharge / max(0.1, self.flashlight_recharge_total or max_bat)
                label = f"F RECARGA {self.flashlight_recharge:.1f}s"
            elif self.flashlight_energy < max_bat:
                ratio = self.flashlight_energy / max(0.1, max_bat)
                label = f"F APAGADA {self.flashlight_energy:.1f}s"
            else:
                ratio = 1.0
                label = "F LINTERNA LISTA"
            fill_w = int(168 * max(0.0, min(1.0, ratio)))
            if fill_w > 0:
                canvas.create_rectangle(hud_x + 1, status_y + 1, hud_x + 1 + fill_w, status_y + 11, fill=ink, outline="")
            canvas.create_text(hud_x + 178, status_y, text=label, anchor="nw", fill=ink, font=("Courier New", 7, "bold"))
            status_y += 16
        if self._ability_owned("flight"):
            max_flight = self._flight_max_duration()
            canvas.create_rectangle(hud_x, status_y, hud_x + 170, status_y + 12, fill=base, outline=ink, width=1)
            fill_w = int(168 * max(0.0, min(1.0, player.flight_left / max(1.0, max_flight))))
            if fill_w > 0:
                canvas.create_rectangle(hud_x + 1, status_y + 1, hud_x + 1 + fill_w, status_y + 11, fill=ink, outline="")
            flight_label = "C JETPACK" if player.flight_cooldown <= 0 else f"C CD {player.flight_cooldown:.1f}s"
            canvas.create_text(hud_x + 178, status_y, text=flight_label, anchor="nw", fill=ink, font=("Courier New", 7, "bold"))
            status_y += 16
        if self.slow_time_timer > 0 or self.slow_time_cooldown > 0:
            active = self.slow_time_timer > 0
            remaining = self.slow_time_timer if active else max(0.0, self.slow_time_cooldown)
            label = f"TIME {remaining:.1f}s" if active else f"TIME CD {remaining:.1f}s"
            if active and getattr(self, "_time_space_teleport_cooldown", 0.0) > 0:
                label += f" · TP {self._time_space_teleport_cooldown:.1f}s"
            canvas.create_rectangle(hud_x, status_y, hud_x + 170, status_y + 12, fill=base, outline=ink, width=1)
            ratio = self.slow_time_timer / max(0.1, self._time_space_duration()) if active else max(0.0, min(1.0, self.slow_time_cooldown / max(0.1, self._time_space_cooldown())))
            fill_w = int(168 * max(0.0, min(1.0, ratio)))
            if fill_w > 0:
                canvas.create_rectangle(hud_x + 1, status_y + 1, hud_x + 1 + fill_w, status_y + 11, fill=ink, outline="")
            canvas.create_text(hud_x + 178, status_y, text=label, anchor="nw", fill=ink, font=("Courier New", 7, "bold"))
            status_y += 16
        if self.shield_cooldown > 0 or self.shield_timer > 0:
            shield_label = "B ESCUDO ON" if self.shield_timer > 0 else f"B CD {self.shield_cooldown:.1f}s"
            canvas.create_text(hud_x, status_y, text=shield_label, anchor="nw", fill=ink, font=("Courier New", 7, "bold"))
            status_y += 14
        if self.clone_timer > 0:
            canvas.create_text(hud_x, status_y, text=f"CLON {self.clone_timer:.1f}s", anchor="nw", fill=ink, font=("Courier New", 7, "bold"))
            status_y += 14
        if getattr(player, "crouching", False):
            canvas.create_text(hud_x, status_y, text="AGACHADO", anchor="nw", fill=ink, font=("Courier New", 7, "bold"))

        if getattr(self, "status_notice_timer", 0.0) > 0 and getattr(self, "status_notice_text", ""):
            canvas.create_rectangle(width / 2 - 260, 112, width / 2 + 260, 142, fill=base, outline=ink, width=2)
            canvas.create_text(width / 2, 127, text=self.status_notice_text[:68], fill=ink, font=("Courier New", 8, "bold"))
        alive_bosses = self._alive_boss_count()
        if alive_bosses > 0:
            canvas.create_text(width - 12, 48, text=f"JEFES RESTANTES: {alive_bosses}", anchor="ne", fill=ink, font=("Courier New", 8, "bold"))
        if self._shadow_specs():
            now = time.perf_counter()
            age = now - self.shadow_chaser_history[0][0] if self.shadow_chaser_history else 0.0
            min_delay = min((d for d, _m in self._shadow_specs()), default=0.0)
            if self.selected_mode == "challenge":
                min_delay = max(min_delay, CHALLENGE_SHADOW_SPAWN_GRACE)
            warmup = max(0.0, min_delay - age)
            if warmup > 0:
                label = f"SOMBRA ACTIVA EN {math.ceil(warmup)}"
            else:
                if self.selected_mode == "race":
                    label = "SOMBRAS " + "/".join(str(int(d)) for d, _m in self._shadow_specs()) + "s"
                elif self.selected_mode == "challenge":
                    label = "8 SOMBRAS +3s · JEFE SIN TP"
                elif any(m for _d, m in self._shadow_specs()):
                    label = "SOMBRA ESPEJO " + "/".join(f"{d:g}s" for d, _m in self._shadow_specs())
                else:
                    label = "SOMBRAS " + "/".join(f"{d:g}s" for d, _m in self._shadow_specs())
            canvas.create_rectangle(width - 230, height - 30, width - 12, height - 10, fill=base, outline=ink, width=1)
            canvas.create_text(width - 121, height - 20, text=label, fill=ink, font=("Courier New", 7, "bold"))
        if self.selected_mode == "arena":
            alive = sum(1 for b in self.arena_bots if b.alive) + (1 if self.arena_player_respawn_timer <= 0.0 else 0)
            minutes = int(max(0.0, self.arena_match_timer) // 60)
            seconds = int(max(0.0, self.arena_match_timer) % 60)
            leader = self._arena_rankings()[0] if self.arena_scores else (self.arena_player_team, "?", 0)
            respawn = f" · RESPAWN {self.arena_player_respawn_timer:.1f}s" if self.arena_player_respawn_timer > 0 else ""
            panel_w = min(470, width - 24)
            canvas.create_rectangle(width / 2 - panel_w / 2, 52, width / 2 + panel_w / 2, 82, fill=base, outline=ink, width=3)
            canvas.create_text(width / 2, 67, text=f"ARENA {minutes}:{seconds:02d}  ·  VIVOS {alive}/16  ·  LÍDER {leader[1]} {leader[2]}{respawn}", fill=ink, font=("Courier New", 9, "bold"))
        elif self.p2_enabled:
            p2_label = "CPU" if self.p2_is_cpu else "P2"
            canvas.create_rectangle(width - 300, height - 54, width - 12, height - 34, fill=base, outline=ink, width=1)
            canvas.create_text(width - 156, height - 44, text=f"{p2_label} HP {int(self.p2_player.hp)}/{int(self.p2_player.max_hp)}", fill=ink, font=("Courier New", 7, "bold"))
        if self.level_intro_timer > 0:
            intro_total = CHALLENGE_SAFE_INTRO if self.selected_mode == "challenge" else 7.0
            progress = max(0.0, min(1.0, self.level_intro_timer / max(0.1, intro_total)))
            label = f"NIVEL {self._display_level_label()}"
            biome_label = self._level_biome_label().upper()
            panel_w = min(width - 60, 650)
            panel_h = 116
            cx = width / 2
            cy = min(height * 0.34, 150)
            canvas.create_rectangle(cx - panel_w / 2, cy - panel_h / 2, cx + panel_w / 2, cy + panel_h / 2, fill=base, outline=ink, width=4)
            canvas.create_rectangle(cx - panel_w / 2 + 8, cy - panel_h / 2 + 8, cx + panel_w / 2 - 8, cy + panel_h / 2 - 8, fill=base, outline=ink, width=2)
            canvas.create_text(cx, cy - 22, text=label, fill=ink, font=("Courier New", 31, "bold"))
            canvas.create_text(cx, cy + 14, text=biome_label, fill=ink, font=("Courier New", 12, "bold"))
            objective = str(getattr(self, "level_spec", {}).get("objective", "")).upper()[:58]
            if self.selected_mode == "race":
                objective = "CARRERA: CRUZA LA BANDERA · SIN JEFE FINAL"
            elif self.selected_mode == "challenge":
                objective = "3s SEGUROS · 8 SOMBRAS · JEFE SIN TELEPORT"
            elif self.selected_mode == "arena":
                objective = "ARENA FFA: 15 IA + JUGADOR · 5 MIN · 6XP POR BAJA"
            canvas.create_text(cx, cy + 31, text=objective, fill=ink, font=("Courier New", 7, "bold"))
            canvas.create_rectangle(cx - panel_w / 2 + 36, cy + 42, cx + panel_w / 2 - 36, cy + 50, fill=base, outline=ink, width=1)
            canvas.create_rectangle(cx - panel_w / 2 + 38, cy + 44, cx - panel_w / 2 + 38 + (panel_w - 76) * (1.0 - progress), cy + 48, fill=ink, outline="")
        if self.win_banner_timer > 0:
            canvas.create_rectangle(width / 2 - 225, 62, width / 2 + 225, 108, fill=base, outline=ink, width=3)
            canvas.create_text(width / 2, 84, text="¡TODOS LOS JEFES DERROTADOS!", fill=ink, font=("Courier New", 14, "bold"))

    def _draw_hard_spike_wall(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        if not self._campaign_has_spike_wall():
            return
        sx = self._screen_x(self.hard_spike_wall_x)
        wall_w = self.hard_spike_wall_width
        if sx > width + 80 or sx + wall_w < -120:
            return
        y0 = -20
        y1 = height + 20
        canvas.create_rectangle(sx, y0, sx + wall_w * 0.62, y1, fill=ink, outline=ink, width=2)
        canvas.create_rectangle(sx + 6, y0 + 4, sx + wall_w * 0.62 - 6, y1 - 4, fill=base, outline="")
        spike_x = sx + wall_w * 0.62
        step = 28
        offset = int((self.anim_phase * 10) % step)
        for y in range(y0 - step + offset, y1 + step, step):
            canvas.create_polygon(spike_x, y, spike_x + wall_w * 0.38, y + step * 0.5, spike_x, y + step, fill=ink, outline=ink)
        canvas.create_text(sx + wall_w / 2, max(18, min(height - 18, self._screen_y(self.retro_player.y))), text="PINCHOS", angle=90, fill=ink, font=("Courier New", 7, "bold"))

    def _draw_tutorial_messages(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        if not self._is_tutorial_guided() or not self.tutorial_messages:
            return
        width = max(360, self.canvas.winfo_width())
        for x, y, text in self.tutorial_messages:
            sx = self._screen_x(x)
            sy = self._screen_y(y)
            if sx < -180 or sx > width + 180:
                continue
            lines = self._wrap_text(text, 34)
            box_w = min(310, max(190, max((len(line) for line in lines), default=10) * 8 + 24))
            box_h = 24 + 15 * len(lines)
            x0 = sx - box_w / 2
            y0 = sy - box_h / 2
            canvas.create_rectangle(x0, y0, x0 + box_w, y0 + box_h, fill=ink, outline=ink, width=2)
            canvas.create_rectangle(x0 + 4, y0 + 4, x0 + box_w - 4, y0 + box_h - 4, fill=base, outline="")
            ty = y0 + 10
            for line in lines:
                canvas.create_text(x0 + box_w / 2, ty, text=line, fill=ink, font=("Courier New", 7, "bold"))
                ty += 15

    def _draw_color_button(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        x0, y0, x1, y1 = self._color_button_bbox
        canvas.create_rectangle(x0, y0, x1, y1, fill=ink, outline=ink, width=2)
        canvas.create_rectangle(x0 + 3, y0 + 3, x1 - 3, y1 - 3, fill=base, outline="")
        canvas.create_text((x0 + x1) / 2, (y0 + y1) / 2, text="Color", fill=ink, font=("Courier New", 8, "bold"))

    def _draw_charge_particles(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        active = self._x_charge_active or self._z_sword_charge_active
        if not active or self.game_state not in {"playing", "paused"}:
            return
        player = self.retro_player
        cx = self._screen_x(player.x + player.w * 0.5)
        cy = self._screen_y(player.y + player.h * 0.52)
        held = 0.0
        kind = "X"
        if self._x_charge_active:
            held = max(0.0, time.perf_counter() - self._x_charge_started)
        if self._z_sword_charge_active:
            held = max(held, time.perf_counter() - self._z_sword_charge_started)
            kind = "Z"
        intensity = min(1.0, held / 3.0)
        base_count = 8 + int(intensity * 10)
        # Menos ruido visual por etapa de carga: Nv1 -80%, Nv2 -65%, Nv3+ -50%.
        if held >= 5.0:
            particle_multiplier = 0.50
        elif held >= 3.0:
            particle_multiplier = 0.35
        else:
            particle_multiplier = 0.20
        count = max(1, int(round(base_count * particle_multiplier)))
        radius = 34.0 + intensity * 28.0
        particle_time = self.anim_phase * 0.70  # 30% más lento.
        for i in range(count):
            phase = particle_time * (2.2 + intensity) + i * (math.tau / max(1, count))
            progress = (particle_time * 0.55 + i / max(1, count)) % 1.0
            r = radius * (1.0 - progress * 0.82)
            px = cx + math.cos(phase) * r
            py = cy + math.sin(phase * 1.17) * r * 0.72
            size = 2 + int(2 * intensity)
            canvas.create_rectangle(px - size, py - size, px + size, py + size, fill=ink, outline="")
        canvas.create_oval(cx - 10 - intensity * 8, cy - 10 - intensity * 8, cx + 10 + intensity * 8, cy + 10 + intensity * 8, outline=ink, width=2)
        canvas.create_text(cx, cy - 28 - intensity * 10, text=f"CARGA {kind}", fill=ink, font=("Courier New", 6, "bold"))

    def _draw_night_lighting(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        if not self._is_mode_night() or self.game_state not in {"playing", "paused"}:
            return

        def merge_intervals(intervals: list[tuple[float, float]]) -> list[tuple[float, float]]:
            if not intervals:
                return []
            intervals = sorted((max(0.0, a), min(float(width), b)) for a, b in intervals if b > 0 and a < width)
            merged: list[list[float]] = []
            for a, b in intervals:
                if not merged or a > merged[-1][1] + 1.0:
                    merged.append([a, b])
                else:
                    merged[-1][1] = max(merged[-1][1], b)
            return [(a, b) for a, b in merged]

        def draw_dark_segments(y0: float, y1: float, visible: list[tuple[float, float]], *, stipple: str = "", solid: bool = False) -> None:
            x_cursor = 0.0
            for a, b in visible:
                if a > x_cursor:
                    canvas.create_rectangle(x_cursor, y0, a, y1, fill="#000000", outline="", stipple=("" if solid else stipple))
                x_cursor = max(x_cursor, b)
            if x_cursor < width:
                canvas.create_rectangle(x_cursor, y0, width, y1, fill="#000000", outline="", stipple=("" if solid else stipple))

        player = self.retro_player
        px = player.x + player.w * 0.5
        py = player.y + player.h * 0.5
        entity_radius = max(26.0, TILE * self._entity_luminosity_factor())

        light_sources: list[tuple[float, float, float]] = [
            (self._screen_x(px), self._screen_y(py), entity_radius * 1.18),
        ]

        for enemy in self.retro_enemies:
            if enemy.alive:
                light_sources.append((self._screen_x(enemy.x + enemy.w * 0.5), self._screen_y(enemy.y + enemy.h * 0.5), entity_radius * 0.92))
        for _idx, sx, sy, _f, _g, _j in self._shadow_snapshots():
            light_sources.append((self._screen_x(sx + player.w * 0.5), self._screen_y(sy + player.h * 0.5), entity_radius * 0.88))

        if self.flashlight_on:
            facing = 1 if player.facing >= 0 else -1
            fr = max(84.0, TILE * self._flashlight_range_factor())
            light_sources.append((self._screen_x(px + facing * fr * 0.72), self._screen_y(py - player.h * 0.06), fr))
            light_sources.append((self._screen_x(px + facing * fr * 0.28), self._screen_y(py - player.h * 0.02), fr * 0.62))

        band_h = 8.0
        soft_factor = 1.30
        bands = int(math.ceil(height / band_h))
        for band in range(bands):
            y0 = band * band_h
            y1 = min(float(height), y0 + band_h)
            ymid = (y0 + y1) * 0.5
            hard_intervals: list[tuple[float, float]] = []
            soft_intervals: list[tuple[float, float]] = []
            for sx, sy, radius in light_sources[:96]:
                dy = abs(ymid - sy)
                soft_r = radius * soft_factor
                if dy <= soft_r:
                    dx = math.sqrt(max(0.0, soft_r * soft_r - dy * dy))
                    soft_intervals.append((sx - dx, sx + dx))
                if dy <= radius:
                    dx = math.sqrt(max(0.0, radius * radius - dy * dy))
                    hard_intervals.append((sx - dx, sx + dx))
            merged_soft = merge_intervals(soft_intervals)
            merged_hard = merge_intervals(hard_intervals)
            # Capa 1: oscuridad extrema en casi todo el mapa.
            draw_dark_segments(y0, y1, merged_soft, stipple="gray50", solid=False)
            # Capa 2: se conserva solo la zona local visible alrededor de jugador/entidades.
            draw_dark_segments(y0, y1, merged_hard, solid=True)

        # Reafirma la legibilidad del jugador sobre la máscara de oscuridad.
        psx = self._screen_x(px)
        psy = self._screen_y(py)
        core = max(10.0, entity_radius * 0.34)
        canvas.create_oval(psx - core, psy - core, psx + core, psy + core, outline=ink, width=2)
        self._draw_retro_player(canvas, base, ink)

    def _draw_retro_scene(self, canvas: tk.Canvas, width: int, height: int) -> None:
        width = max(360, width)
        height = max(220, height)
        self._ensure_retro_world(width, height)
        base, ink = self._retro_duotone()
        canvas.create_rectangle(0, 0, width, height, fill=base, outline=ink, width=2)
        self._draw_retro_city(canvas, width, height, base, ink)
        self._draw_retro_mech(canvas, base, ink)
        self._draw_retro_obstacles(canvas, base, ink)
        self._draw_boxes(canvas, base, ink)
        self._draw_retro_ground(canvas, width, height, base, ink)
        self._draw_hard_spike_wall(canvas, width, height, base, ink)
        self._draw_race_finish(canvas, base, ink)
        self._draw_checkpoints(canvas, base, ink)
        self._draw_pickups_and_effects(canvas, base, ink)
        self._draw_tutorial_messages(canvas, base, ink)
        self._draw_retro_enemies(canvas, base, ink)
        self._draw_retro_projectiles(canvas, width, height, base, ink)
        self._draw_clone(canvas, base, ink)
        self._draw_shadow_chasers(canvas, base, ink)
        self._draw_arena_bots(canvas, base, ink)
        self._draw_p2_player(canvas, base, ink)
        self._draw_retro_player(canvas, base, ink)
        self._draw_charge_particles(canvas, base, ink)
        self._draw_night_lighting(canvas, width, height, base, ink)
        self._draw_color_button(canvas, base, ink)
        self._draw_hud(canvas, width, height, base, ink)
        self._draw_arena_scoreboard(canvas, width, height, base, ink)
        if self.game_state == "paused":
            self._draw_pause_overlay(canvas, width, height, base, ink)


def main() -> None:
    root = tk.Tk()
    RetroMinigame(root)
    root.mainloop()


if __name__ == "__main__":
    main()
