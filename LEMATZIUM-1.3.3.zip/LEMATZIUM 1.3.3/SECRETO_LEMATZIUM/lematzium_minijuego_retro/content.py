from __future__ import annotations

from .models import BiomeSpec, CharacterSpec, Palette


APP_TITLE = "LEMATZIUM · Minijuego retro"
FRAME_MS = 32
TILE = 96.0

# Duotonos globales: cada vista debe construir contraste con solo dos tonos.
PALETTES: tuple[Palette, ...] = (
    Palette("Azul Eléctrico", "#071521", "#26A9FF"),
    Palette("Rosa Francés", "#170813", "#FF49C4"),
    Palette("Blanco Moderno", "#F1F5F9", "#2563EB"),
    Palette("Negro Premium", "#050505", "#B58DFF"),
    Palette("Verde Laboratorio", "#061510", "#38F08A"),
    Palette("Ámbar Ensayo", "#150F05", "#FFB800"),
)


CHARACTERS: tuple[CharacterSpec, ...] = (
    CharacterSpec(
        key="L",
        name="LEMAT",
        desc="Unidad retro LEMAT: dispara, carga, se agacha y mejora armas por árbol usando XP.",
        primary="X: disparo normal/cargado. Abajo/S: agacharse.",
        secondary="Z: habilidad secundaria. 1-3 son slots activos; pasivas como Nova/Parry/Salto/Telequinesis se activan al desbloquearse.",
        jumps=2,
    ),
)


# Cada bioma respeta el duotono: solo base + tinta repetidos en los campos de color.
BIOMES: tuple[BiomeSpec, ...] = (
    BiomeSpec("water", "Archivo abisal", "Corrientes, ascensores de burbuja y túneles inundados.", "#061827", "#061827", "#061827", "#47D7FF", "#47D7FF", "#47D7FF", "#47D7FF", 0.74, 0.86, 1.16, 1.18, 0.82),
    BiomeSpec("lava", "Forja de axiomas", "Cámaras de calor, columnas de magma y rutas altas de riesgo.", "#170606", "#170606", "#170606", "#FF5A1F", "#FF5A1F", "#FF5A1F", "#FF5A1F", 1.06, 1.00, 1.10, 1.08, 1.34),
    BiomeSpec("forest", "Bosque de grafos", "Ramas conectadas, lianas y rutas verticales secretas.", "#06140C", "#06140C", "#06140C", "#7CFF8D", "#7CFF8D", "#7CFF8D", "#7CFF8D", 0.96, 1.03, 1.18, 1.22, 0.92),
    BiomeSpec("lunar", "Cráter de funciones", "Gravedad baja, saltos largos y plataformas orbitales.", "#090A18", "#090A18", "#090A18", "#D7E2FF", "#D7E2FF", "#D7E2FF", "#D7E2FF", 0.62, 1.02, 1.20, 1.32, 1.08),
    BiomeSpec("city", "Ciudad matriz", "Carriles, torretas, drones y atajos por techos.", "#060B18", "#060B18", "#060B18", "#00E5FF", "#00E5FF", "#00E5FF", "#00E5FF", 1.00, 1.04, 1.16, 1.10, 1.00),
    BiomeSpec("village", "Pueblo de prototipos", "Tejados, molinos mecánicos y callejones de precisión.", "#120D08", "#120D08", "#120D08", "#FFB86B", "#FFB86B", "#FFB86B", "#FFB86B", 1.00, 1.00, 1.08, 1.04, 0.88),
    BiomeSpec("mountain", "Montañas de cálculo", "Ascenso vertical, viento duro y balcones de doble salto.", "#080D13", "#080D13", "#080D13", "#C7F0FF", "#C7F0FF", "#C7F0FF", "#C7F0FF", 1.12, 0.98, 1.12, 1.48, 1.10),
    BiomeSpec("valley", "Valle vectorial", "Pendientes, ráfagas laterales y plataformas en arco.", "#07110F", "#07110F", "#07110F", "#52FFB8", "#52FFB8", "#52FFB8", "#52FFB8", 0.92, 1.06, 1.22, 1.18, 1.18),
)

STARTING_PLAYER_HP = 30
UPGRADE_COST = 3
XP_MINOR = 1
XP_MAJOR = 2
XP_ELITE = 4
XP_BOSS = 10
DASH_MAX_SPEED = 680.0
PLAYER_WALK_SPEED = 178.0
HARD_CHASER_SPEED = PLAYER_WALK_SPEED / 3.0
FLIGHT_DURATION = 3.0
FLIGHT_COOLDOWN = 3.0

LEVEL_MODIFIERS: dict[str, dict[str, object]] = {
    "storm": {"name": "Tormenta", "enemy_density": 1.08, "platform_density": 1.00, "hazard": "storm", "reward": 1.05, "goal": "sobrevive a proyectiles ambientales"},
    "instability": {"name": "Inestabilidad", "enemy_density": 0.95, "platform_density": 1.18, "hazard": "unstable", "reward": 1.05, "goal": "plataformas temporales"},
    "hunt": {"name": "Caza", "enemy_density": 1.28, "platform_density": 0.95, "hazard": "hunters", "reward": 1.10, "goal": "enemigos veloces y menos curaciones"},
    "ruins": {"name": "Ruinas", "enemy_density": 1.00, "platform_density": 1.08, "hazard": "breakable", "reward": 1.15, "goal": "rutas secretas y muros rompibles"},
    "arena": {"name": "Arena", "enemy_density": 1.22, "platform_density": 0.92, "hazard": "waves", "reward": 1.15, "goal": "oleadas antes del jefe"},
    "ascent": {"name": "Ascenso", "enemy_density": 0.98, "platform_density": 1.25, "hazard": "vertical", "reward": 1.08, "goal": "ruta vertical con checkpoints altos"},
    "chase": {"name": "Persecución", "enemy_density": 1.06, "platform_density": 1.00, "hazard": "chase", "reward": 1.12, "goal": "peligro móvil más activo"},
    "treasure": {"name": "Tesoro", "enemy_density": 1.14, "platform_density": 1.02, "hazard": "elite", "reward": 1.35, "goal": "más XP, enemigos élite"},
}
LEVEL_MODIFIER_ORDER: tuple[str, ...] = tuple(LEVEL_MODIFIERS.keys())

BIOME_RULES: dict[str, dict[str, object]] = {
    "water": {"hazards": ("currents", "bubbles"), "preferred_enemies": ("flyer", "ghost", "burrower", "boss_water"), "platform": "bubble_path", "physics": "soft_gravity", "event": "corriente sinusoidal", "bonus": "más control aéreo", "secret": "túneles sumergidos"},
    "lava": {"hazards": ("lava_columns", "hot_floor"), "preferred_enemies": ("major", "bomber", "shield", "kamikaze"), "platform": "heat_bridge", "physics": "heat_push", "event": "columnas de fuego", "bonus": "más XP", "secret": "forjas altas"},
    "forest": {"hazards": ("roots", "thorns"), "preferred_enemies": ("hopper", "healer", "summoner", "leech"), "platform": "canopy", "physics": "branch_steps", "event": "raíces temporales", "bonus": "curaciones raras", "secret": "rutas de lianas"},
    "lunar": {"hazards": ("meteors", "low_gravity"), "preferred_enemies": ("flyer", "ghost", "sniper", "mirror"), "platform": "climb_node", "physics": "low_gravity", "event": "meteoritos", "bonus": "saltos largos", "secret": "órbitas altas"},
    "city": {"hazards": ("rails", "turrets"), "preferred_enemies": ("turret", "sniper", "sprinter", "summoner", "hunter", "ninja"), "platform": "rooftop", "physics": "conveyor", "event": "drones", "bonus": "más tecnología", "secret": "azoteas"},
    "village": {"hazards": ("simple_traps",), "preferred_enemies": ("minor", "hopper", "sprinter", "shield", "ninja", "hunter"), "platform": "rooftop", "physics": "standard", "event": "emboscadas", "bonus": "rutas fáciles", "secret": "callejones"},
    "mountain": {"hazards": ("wind", "falling_rocks"), "preferred_enemies": ("major", "hopper", "bomber", "rock"), "platform": "climb_node", "physics": "wind", "event": "rocas caen", "bonus": "alturas", "secret": "balcones"},
    "valley": {"hazards": ("gusts", "slopes"), "preferred_enemies": ("sprinter", "flyer", "kamikaze", "leech", "ninja"), "platform": "speed_lane", "physics": "side_gusts", "event": "ráfagas laterales", "bonus": "velocidad", "secret": "pendientes"},
}

# kind -> (w, h, hp, attack, speed). Las siluetas mantienen el estilo menor/mayor original.
ENEMY_STATS: dict[str, tuple[float, float, int, int, float]] = {
    "minor": (24.0, 20.0, 5, 1, 48.0),
    "major": (52.0, 58.0, 10, 2, 22.0),
    "hopper": (24.0, 20.0, 6, 1, 42.0),
    "flyer": (24.0, 20.0, 4, 1, 56.0),
    "turret": (52.0, 58.0, 7, 2, 0.0),
    "shield": (52.0, 58.0, 12, 2, 28.0),
    "sprinter": (24.0, 20.0, 5, 2, 96.0),
    "burrower": (24.0, 20.0, 7, 2, 42.0),
    "splitter": (24.0, 20.0, 8, 1, 44.0),
    "healer": (24.0, 20.0, 6, 1, 36.0),
    "bomber": (52.0, 58.0, 9, 2, 24.0),
    "sniper": (52.0, 58.0, 8, 2, 18.0),
    "leech": (24.0, 20.0, 7, 1, 72.0),
    "mirror": (52.0, 58.0, 9, 2, 24.0),
    "kamikaze": (24.0, 20.0, 4, 3, 112.0),
    "summoner": (52.0, 58.0, 8, 1, 22.0),
    "ghost": (24.0, 20.0, 6, 1, 50.0),
    "ninja": (26.0, 24.0, 7, 2, 124.0),
    "hunter": (42.0, 46.0, 9, 2, 44.0),
    "elite": (52.0, 58.0, 18, 3, 42.0),
}

ENEMY_BEHAVIOR_SPECS: dict[str, dict[str, object]] = {
    "minor": {"size_class": "minor", "tags": ("physical",), "biome_affinity": ("village", "valley"), "behavior": "patrol"},
    "major": {"size_class": "major", "tags": ("armor",), "biome_affinity": ("lava", "mountain"), "behavior": "tank"},
    "hopper": {"size_class": "minor", "tags": ("organic",), "biome_affinity": ("forest", "mountain"), "behavior": "hop"},
    "flyer": {"size_class": "minor", "tags": ("air",), "biome_affinity": ("water", "lunar"), "behavior": "sine_fly"},
    "turret": {"size_class": "major", "tags": ("machine",), "biome_affinity": ("city",), "behavior": "turret"},
    "shield": {"size_class": "major", "tags": ("armor",), "biome_affinity": ("lava", "village"), "behavior": "front_shield"},
    "sprinter": {"size_class": "minor", "tags": ("fast",), "biome_affinity": ("valley", "village"), "behavior": "charge"},
    "burrower": {"size_class": "minor", "tags": ("earth",), "biome_affinity": ("water", "forest"), "behavior": "burrow"},
    "splitter": {"size_class": "minor", "tags": ("swarm",), "biome_affinity": ("forest", "village"), "behavior": "split"},
    "healer": {"size_class": "minor", "tags": ("support",), "biome_affinity": ("forest",), "behavior": "heal"},
    "bomber": {"size_class": "major", "tags": ("fire", "explosive"), "biome_affinity": ("lava", "mountain"), "behavior": "lob"},
    "sniper": {"size_class": "major", "tags": ("machine",), "biome_affinity": ("city", "lunar"), "behavior": "snipe"},
    "leech": {"size_class": "minor", "tags": ("toxic",), "biome_affinity": ("forest", "valley"), "behavior": "drain"},
    "mirror": {"size_class": "major", "tags": ("crystal",), "biome_affinity": ("lunar",), "behavior": "reflect"},
    "kamikaze": {"size_class": "minor", "tags": ("explosive",), "biome_affinity": ("lava", "valley"), "behavior": "explode"},
    "summoner": {"size_class": "major", "tags": ("support",), "biome_affinity": ("city", "forest"), "behavior": "summon"},
    "ghost": {"size_class": "minor", "tags": ("void",), "biome_affinity": ("water", "lunar"), "behavior": "phase"},
    "ninja": {"size_class": "minor", "tags": ("fast", "slash", "ranged"), "biome_affinity": ("city", "village", "valley"), "behavior": "ninja_star_saber"},
    "hunter": {"size_class": "major", "tags": ("physical", "shotgun"), "biome_affinity": ("city", "mountain", "village"), "behavior": "shotgun_dual"},
    "elite": {"size_class": "major", "tags": ("elite",), "biome_affinity": tuple(b.key for b in BIOMES), "behavior": "random_elite"},
}


# Armas activas primero; pasivas automáticas al final del taller.
ABILITY_ORDER: tuple[str, ...] = (
    "sword", "flight", "shield", "time_space", "n_resurrection", "flashlight",
    "parry", "nova", "triple_jump", "telekinesis",
)

ABILITY_INFO: dict[str, dict[str, object]] = {
    "gun": {
        "num": "X",
        "name": "X Buster",
        "cost": 0,
        "upgradeable": True,
        "tags": ("physical", "buster"),
        "desc": "Arma inicial. Árbol libre: ataque, rango, cadencia, balas, crítico y perforación.",
    },
    "sword": {
        "num": "Z",
        "name": "Z Saber",
        "cost": 6,
        "upgradeable": True,
        "tags": ("physical", "slash"),
        "desc": "Corte frontal. Árbol: ataque, rango, cadencia y boomerangs.",
    },
    "flight": {
        "num": "C",
        "name": "C Jetpack",
        "cost": 6,
        "upgradeable": True,
        "tags": ("mobility", "explosive"),
        "desc": "Vuelo limitado. Árbol: tiempo, balas hacia abajo y bombas por vuelo.",
    },
    "telekinesis": {
        "num": "",
        "name": "Telequinesis",
        "cost": 6,
        "upgradeable": True,
        "tags": ("psychic", "box"),
        "desc": "Pasiva: al desbloquearse, click y arrastre sobre cajas las agarra y lanza. Base: 2s y 1 daño.",
    },
    "shield": {
        "num": "B",
        "name": "B Shield",
        "cost": 6,
        "upgradeable": True,
        "tags": ("defense", "shadow"),
        "desc": "Escudo 2s, CD 5s. Árbol: defensa, duración, clon 2→7s y sombra en cooldown.",
    },
    "parry": {
        "num": "",
        "name": "Parry",
        "cost": 18,
        "upgradeable": True,
        "tags": ("mobility", "physical"),
        "desc": "Pasiva: saltar sobre enemigos causa daño, rebota y abre una ventana breve de desvío. Árbol: daño, ventana y rebote.",
    },
    "nova": {
        "num": "",
        "name": "Nova",
        "cost": 18,
        "upgradeable": True,
        "tags": ("mobility", "dash"),
        "desc": "Pasiva: el dash se vuelve ofensivo, atraviesa enemigos, evita contacto y causa daño. Especial LEMON DASH: disparar durante el dash causa crítico asegurado.",
    },
    "time_space": {
        "num": "",
        "name": "Time-space",
        "cost": 18,
        "upgradeable": True,
        "tags": ("time", "mobility"),
        "desc": "Ralentiza el mundo y permite teleports repetidos con click hasta agotar tiempo; cada teleport tiene CD interno reducido 70%. Árbol: duración, daño de ruptura y recarga.",
    },
    "n_resurrection": {
        "num": "N",
        "name": "N-Resurrection",
        "cost": 18,
        "upgradeable": True,
        "tags": ("necromancy", "ally"),
        "desc": "Revive el último enemigo asesinado por el jugador como aliado. Base: 1 aliado; mejoras: hasta 5 aliados, +vida y +ataque.",
    },
    "flashlight": {
        "num": "F",
        "name": "Linterna",
        "cost": 0,
        "upgradeable": True,
        "tags": ("light", "night"),
        "desc": "F enciende/apaga la linterna nocturna. Árbol 7XP: rango, batería y luminosidad de entidades.",
    },
    "triple_jump": {
        "num": "",
        "name": "Tercer/Cuarto salto",
        "cost": 18,
        "upgradeable": True,
        "tags": ("mobility",),
        "desc": "Pasiva: desbloquea tercer salto; su rama evoluciona a cuarto salto permanente.",
    },
}


# Árboles libres: cada rama puede elegirse de forma independiente. Cada nodo cuesta 3 XP.
WEAPON_UPGRADE_TREES: dict[str, dict[str, list[dict[str, object]]]] = {
    "gun": {
        "damage": [
            {"id": "d1", "name": "Ataque I", "description": "Ataque +1", "cost": 3, "requires": (), "effects": {"damage": 1}},
            {"id": "d2", "name": "Ataque II", "description": "Ataque +1", "cost": 3, "requires": ("d1",), "effects": {"damage": 1}},
        ],
        "range": [
            {"id": "r1", "name": "Rango I", "description": "Rango +1", "cost": 3, "requires": (), "effects": {"range": 1}},
            {"id": "r2", "name": "Rango II", "description": "Rango +1", "cost": 3, "requires": ("r1",), "effects": {"range": 1}},
        ],
        "speed": [
            {"id": "s1", "name": "Cadencia I", "description": "Velocidad de ataque +15%", "cost": 3, "requires": (), "effects": {"speed": 0.85}},
            {"id": "s2", "name": "Cadencia II", "description": "Velocidad de ataque +20%", "cost": 3, "requires": ("s1",), "effects": {"speed": 0.80}},
        ],
        "bullets": [
            {"id": "b1", "name": "3 balas", "description": "Disparo base lanza 3 balas", "cost": 3, "requires": (), "effects": {"bullets": 3}},
            {"id": "b2", "name": "5 balas", "description": "Disparo base lanza 5 balas", "cost": 3, "requires": ("b1",), "effects": {"bullets": 5}},
        ],
        "tracking": [
            {"id": "trk1", "name": "Seguimiento I", "description": "Desbloquea seguimiento del X Buster por 1.0s", "cost": 3, "requires": (), "effects": {"homing_time": 1.0}},
            {"id": "trk2", "name": "Seguimiento II", "description": "X Buster persigue enemigos +0.25s", "cost": 3, "requires": ("trk1",), "effects": {"homing_time": 0.25}},
            {"id": "trk3", "name": "Seguimiento III", "description": "X Buster persigue enemigos +0.25s", "cost": 3, "requires": ("trk2",), "effects": {"homing_time": 0.25}},
            {"id": "trk4", "name": "Seguimiento IV", "description": "X Buster persigue enemigos +0.25s", "cost": 3, "requires": ("trk3",), "effects": {"homing_time": 0.25}},
            {"id": "trk5", "name": "Seguimiento V", "description": "X Buster persigue enemigos +0.25s", "cost": 3, "requires": ("trk4",), "effects": {"homing_time": 0.25}},
        ],
        "special": [
            {"id": "sp1", "name": "Crítico + perforación", "description": "Añade crítico y perforación al X Buster", "cost": 3, "requires": (), "effects": {"crit": 0.12, "pierce": 1, "special": "crit_pierce"}},
        ],
    },
    "sword": {
        "damage": [
            {"id": "d1", "name": "Ataque I", "description": "Ataque +1", "cost": 3, "requires": (), "effects": {"damage": 1}},
            {"id": "d2", "name": "Ataque II", "description": "Ataque +1", "cost": 3, "requires": ("d1",), "effects": {"damage": 1}},
        ],
        "range": [
            {"id": "r1", "name": "Rango I", "description": "Rango +1", "cost": 3, "requires": (), "effects": {"range": 1}},
            {"id": "r2", "name": "Rango II", "description": "Rango +1", "cost": 3, "requires": ("r1",), "effects": {"range": 1}},
        ],
        "speed": [
            {"id": "s1", "name": "Cadencia I", "description": "Velocidad de ataque +15%", "cost": 3, "requires": (), "effects": {"speed": 0.85}},
            {"id": "s2", "name": "Cadencia II", "description": "Velocidad de ataque +20%", "cost": 3, "requires": ("s1",), "effects": {"speed": 0.80}},
        ],
        "special": [
            {"id": "sp1", "name": "Boomerang 2s", "description": "Carga Z 2s: boomerang con daño duplicado", "cost": 3, "requires": (), "effects": {"special": "boomerang"}},
            {"id": "sp2", "name": "Mini boomerang", "description": "Cada 3 ataques lanza boomerang pequeño", "cost": 3, "requires": ("sp1",), "effects": {"special": "mini_boomerang"}},
        ],
    },
    "flight": {
        "duration": [
            {"id": "t1", "name": "Vuelo +1.0s", "description": "Tiempo de vuelo +1.0 segundo", "cost": 3, "requires": (), "effects": {"flight_time": 1.0}},
            {"id": "t2", "name": "Vuelo +0.5s", "description": "Tiempo de vuelo +0.5 segundo", "cost": 3, "requires": ("t1",), "effects": {"flight_time": 0.5}},
        ],
        "special": [
            {"id": "sp1", "name": "Balas hacia abajo", "description": "Durante vuelo dispara dos balas hacia abajo con cadencia del X Buster", "cost": 3, "requires": (), "effects": {"special": "down_shots"}},
            {"id": "sp2", "name": "Bombas de vuelo", "description": "Lanza bomba por cada 2s de vuelo; estalla al tocar suelo", "cost": 3, "requires": (), "effects": {"special": "flight_bombs"}},
        ],
    },
    "telekinesis": {
        "duration": [
            {"id": "t1", "name": "Agarre +1.0s", "description": "Tiempo de agarre +1.0 segundo", "cost": 3, "requires": (), "effects": {"grab_time": 1.0}},
            {"id": "t2", "name": "Agarre +0.5s", "description": "Tiempo de agarre +0.5 segundo", "cost": 3, "requires": ("t1",), "effects": {"grab_time": 0.5}},
        ],
        "damage": [
            {"id": "d1", "name": "Impacto +1", "description": "Daño de cajas +1", "cost": 3, "requires": (), "effects": {"damage": 1}},
            {"id": "d2", "name": "Impacto +0.5", "description": "Daño de cajas +0.5", "cost": 3, "requires": ("d1",), "effects": {"damage": 0.5}},
        ],
    },
    "shield": {
        "defense": [
            {"id": "def1", "name": "Defensa I", "description": "Protege +1 daño", "cost": 3, "requires": (), "effects": {"shield_defense": 1}},
            {"id": "def2", "name": "Defensa II", "description": "Protege +1 daño", "cost": 3, "requires": ("def1",), "effects": {"shield_defense": 1}},
            {"id": "def3", "name": "Defensa III", "description": "Protege +1 daño", "cost": 3, "requires": ("def2",), "effects": {"shield_defense": 1}},
            {"id": "def4", "name": "Defensa IV", "description": "Protege +1 daño", "cost": 3, "requires": ("def3",), "effects": {"shield_defense": 1}},
        ],
        "duration": [
            {"id": "dur1", "name": "Duración +1.0s", "description": "Duración +1.0 segundo", "cost": 3, "requires": (), "effects": {"shield_time": 1.0}},
            {"id": "dur2", "name": "Duración +0.5s", "description": "Duración +0.5 segundo", "cost": 3, "requires": ("dur1",), "effects": {"shield_time": 0.5}},
        ],
        "clone": [
            {"id": "clone1", "name": "Clon +5.0s", "description": "Duración del clon +5.0 segundos en total", "cost": 15, "requires": (), "effects": {"clone_time": 5.0}},
        ],
        "special": [
            {"id": "sp1", "name": "Sombra en cooldown", "description": "Mientras el escudo enfría, una sombra replica movimientos y ataques", "cost": 3, "requires": (), "effects": {"special": "cooldown_shadow"}},
        ],
    },

    "parry": {
        "damage": [
            {"id": "d1", "name": "Impacto I", "description": "Daño de parry +1", "cost": 3, "requires": (), "effects": {"damage": 1}},
            {"id": "d2", "name": "Impacto II", "description": "Daño de parry +1", "cost": 3, "requires": ("d1",), "effects": {"damage": 1}},
        ],
        "duration": [
            {"id": "w1", "name": "Ventana I", "description": "Ventana de desvío +0.20s", "cost": 3, "requires": (), "effects": {"parry_window": 0.20}},
            {"id": "w2", "name": "Ventana II", "description": "Ventana de desvío +0.20s", "cost": 3, "requires": ("w1",), "effects": {"parry_window": 0.20}},
        ],
        "mobility": [
            {"id": "b1", "name": "Rebote I", "description": "Rebote de parry +35", "cost": 3, "requires": (), "effects": {"parry_bounce": 35}},
            {"id": "b2", "name": "Rebote II", "description": "Rebote de parry +35", "cost": 3, "requires": ("b1",), "effects": {"parry_bounce": 35}},
        ],
    },
    "nova": {
        "damage": [
            {"id": "d1", "name": "Choque I", "description": "Daño de Nova +1", "cost": 3, "requires": (), "effects": {"damage": 1}},
            {"id": "d2", "name": "Choque II", "description": "Daño de Nova +1", "cost": 3, "requires": ("d1",), "effects": {"damage": 1}},
        ],
        "duration": [
            {"id": "t1", "name": "Estela I", "description": "Duración del dash Nova +0.08s", "cost": 3, "requires": (), "effects": {"nova_time": 0.08}},
            {"id": "t2", "name": "Estela II", "description": "Duración del dash Nova +0.08s", "cost": 3, "requires": ("t1",), "effects": {"nova_time": 0.08}},
        ],
        "special": [
            {"id": "ld", "name": "LEMON DASH", "description": "Disparar durante Nova Dash causa crítico asegurado", "cost": 3, "requires": (), "effects": {"special": "lemon_dash"}},
        ],
    },
    "n_resurrection": {
        "count": [
            {"id": "c1", "name": "Aliado II", "description": "Permite mantener +1 enemigo revivido", "cost": 3, "requires": (), "effects": {"revive_slots": 1}},
            {"id": "c2", "name": "Aliado III", "description": "Permite mantener +1 enemigo revivido", "cost": 3, "requires": ("c1",), "effects": {"revive_slots": 1}},
            {"id": "c3", "name": "Aliado IV", "description": "Permite mantener +1 enemigo revivido", "cost": 3, "requires": ("c2",), "effects": {"revive_slots": 1}},
            {"id": "c4", "name": "Aliado V", "description": "Permite mantener +1 enemigo revivido", "cost": 3, "requires": ("c3",), "effects": {"revive_slots": 1}},
        ],
        "life": [
            {"id": "hp1", "name": "Vida revivida I", "description": "Aliados revividos +10% de vida", "cost": 3, "requires": (), "effects": {"revive_hp_mult": 0.10}},
            {"id": "hp2", "name": "Vida revivida II", "description": "Aliados revividos +10% de vida", "cost": 3, "requires": ("hp1",), "effects": {"revive_hp_mult": 0.10}},
            {"id": "hp3", "name": "Vida revivida III", "description": "Aliados revividos +10% de vida", "cost": 3, "requires": ("hp2",), "effects": {"revive_hp_mult": 0.10}},
            {"id": "hp4", "name": "Vida revivida IV", "description": "Aliados revividos +10% de vida", "cost": 3, "requires": ("hp3",), "effects": {"revive_hp_mult": 0.10}},
            {"id": "hp5", "name": "Vida revivida V", "description": "Aliados revividos +10% de vida", "cost": 3, "requires": ("hp4",), "effects": {"revive_hp_mult": 0.10}},
        ],
        "attack": [
            {"id": "atk1", "name": "Ataque revivido I", "description": "Aliados revividos +10% de ataque", "cost": 3, "requires": (), "effects": {"revive_attack_mult": 0.10}},
            {"id": "atk2", "name": "Ataque revivido II", "description": "Aliados revividos +10% de ataque", "cost": 3, "requires": ("atk1",), "effects": {"revive_attack_mult": 0.10}},
            {"id": "atk3", "name": "Ataque revivido III", "description": "Aliados revividos +10% de ataque", "cost": 3, "requires": ("atk2",), "effects": {"revive_attack_mult": 0.10}},
            {"id": "atk4", "name": "Ataque revivido IV", "description": "Aliados revividos +10% de ataque", "cost": 3, "requires": ("atk3",), "effects": {"revive_attack_mult": 0.10}},
            {"id": "atk5", "name": "Ataque revivido V", "description": "Aliados revividos +10% de ataque", "cost": 3, "requires": ("atk4",), "effects": {"revive_attack_mult": 0.10}},
        ],
    },
    "time_space": {
        "duration": [
            {"id": "t1", "name": "Dilatación I", "description": "Slow time +1.0s", "cost": 3, "requires": (), "effects": {"time_duration": 1.0}},
            {"id": "t2", "name": "Dilatación II", "description": "Slow time +1.0s", "cost": 3, "requires": ("t1",), "effects": {"time_duration": 1.0}},
        ],
        "damage": [
            {"id": "d1", "name": "Ruptura I", "description": "Teletransporte causa +1 daño radial", "cost": 3, "requires": (), "effects": {"time_blast_damage": 1}},
            {"id": "d2", "name": "Ruptura II", "description": "Teletransporte causa +1 daño radial", "cost": 3, "requires": ("d1",), "effects": {"time_blast_damage": 1}},
        ],
        "reload": [
            {"id": "c1", "name": "Recarga I", "description": "Cooldown de Time-space -0.7s", "cost": 3, "requires": (), "effects": {"time_cooldown": -0.7}},
            {"id": "c2", "name": "Recarga II", "description": "Cooldown de Time-space -0.7s", "cost": 3, "requires": ("c1",), "effects": {"time_cooldown": -0.7}},
        ],
    },
}

# Granularidad nueva: cada rama del árbol se divide en 5 partes.
# Ejemplo: si una rama sumaba +2 en 2 nodos, ahora son 5 nodos de +0.4.
TREE_STAGE_COUNT = 5


def _effect_label(key: str) -> str:
    return {
        "damage": "Daño", "range": "Rango", "speed": "Cadencia", "bullets": "Balas",
        "crit": "Crítico", "pierce": "Perforación", "homing_time": "Seguimiento", "flight_time": "Vuelo",
        "grab_time": "Agarre", "shield_time": "Escudo", "shield_defense": "Defensa", "clone_time": "Clon",
        "parry_window": "Ventana", "parry_bounce": "Rebote", "nova_time": "Nova",
        "time_duration": "Time-space", "time_blast_damage": "Ruptura", "time_cooldown": "Recarga",
        "revive_slots": "Aliados", "revive_hp_mult": "Vida revivida", "revive_attack_mult": "Ataque revivido",
        "light_range": "Rango luz", "light_battery": "Batería", "entity_light": "Luminosidad",
    }.get(key, key.replace("_", " ").title())


def _stage_name(branch: str, stage: int) -> str:
    return {
        "damage": "Daño", "range": "Rango", "speed": "Cadencia", "bullets": "Balas", "tracking": "Seguimiento",
        "duration": "Duración", "defense": "Defensa", "clone": "Clon", "special": "Especial",
        "mobility": "Movilidad", "reload": "Recarga", "count": "Aliados", "life": "Vida", "attack": "Ataque", "entity_light": "Luminosidad",
    }.get(branch, branch.title()) + f" {stage}/5"


def _fractionalized_tree(tree: dict[str, list[dict[str, object]]]) -> dict[str, list[dict[str, object]]]:
    new_tree: dict[str, list[dict[str, object]]] = {}
    for branch, nodes in tree.items():
        numeric_totals: dict[str, float] = {}
        speed_product = 1.0
        special_values: list[str] = []
        final_bullet_value: float | None = None
        total_old_cost = 0
        for node in nodes:
            total_old_cost += int(node.get("cost", 3))
            effects = node.get("effects", {})
            if not isinstance(effects, dict):
                continue
            for key, value in effects.items():
                if key == "special":
                    if value:
                        special_values.append(str(value))
                elif key == "speed":
                    speed_product *= float(value)
                elif key == "bullets":
                    final_bullet_value = max(final_bullet_value or 1.0, float(value))
                elif isinstance(value, (int, float)):
                    numeric_totals[key] = numeric_totals.get(key, 0.0) + float(value)
        stage_cost = max(1, int(round(max(1, total_old_cost) / TREE_STAGE_COUNT)))
        branch_nodes: list[dict[str, object]] = []
        previous_id = ""
        for stage in range(1, TREE_STAGE_COUNT + 1):
            effects: dict[str, object] = {}
            descriptions: list[str] = []
            if speed_product != 1.0:
                per_stage = round(speed_product ** (1.0 / TREE_STAGE_COUNT), 4)
                effects["speed"] = per_stage
                descriptions.append("cadencia progresiva")
            if final_bullet_value is not None:
                effects["bullets"] = round(1.0 + (final_bullet_value - 1.0) * (stage / TREE_STAGE_COUNT), 2)
                descriptions.append(f"balas hacia {final_bullet_value:g}")
            for key, total in numeric_totals.items():
                value = total / TREE_STAGE_COUNT
                effects[key] = round(value, 4)
                sign = "+" if value >= 0 and key != "time_cooldown" else ""
                descriptions.append(f"{_effect_label(key)} {sign}{value:g}")
            if special_values:
                # Distribuye especiales por hitos. Si hay uno, se desbloquea en 5/5;
                # si hay dos, el primero cae en 3/5 y el segundo en 5/5.
                unlock_positions = [TREE_STAGE_COUNT] if len(special_values) == 1 else [max(2, round((i + 1) * TREE_STAGE_COUNT / len(special_values))) for i in range(len(special_values))]
                for pos, special in zip(unlock_positions, special_values):
                    if stage == pos:
                        effects["special"] = special
                        descriptions.append("desbloqueo especial")
            node_id = f"{branch}_{stage}"
            branch_nodes.append({
                "id": node_id,
                "name": _stage_name(branch, stage),
                "description": "; ".join(descriptions) if descriptions else "Progreso fino de rama",
                "cost": stage_cost,
                "requires": (previous_id,) if previous_id else (),
                "effects": effects,
            })
            previous_id = node_id
        new_tree[branch] = branch_nodes
    return new_tree


WEAPON_UPGRADE_TREES = {ability: _fractionalized_tree(tree) for ability, tree in WEAPON_UPGRADE_TREES.items()}

# Árboles manuales que no se fraccionan: linterna usa costes de 7XP y el cuarto salto
# debe ser evolución directa del tercer salto.
WEAPON_UPGRADE_TREES["flashlight"] = {
    "range": [
        {"id": "range_1", "name": "Rango 1/5", "description": "Rango de linterna +0.11", "cost": 7, "requires": (), "effects": {"light_range": 0.11}},
        {"id": "range_2", "name": "Rango 2/5", "description": "Rango de linterna +0.11", "cost": 7, "requires": ("range_1",), "effects": {"light_range": 0.11}},
        {"id": "range_3", "name": "Rango 3/5", "description": "Rango de linterna +0.11", "cost": 7, "requires": ("range_2",), "effects": {"light_range": 0.11}},
        {"id": "range_4", "name": "Rango 4/5", "description": "Rango de linterna +0.11", "cost": 7, "requires": ("range_3",), "effects": {"light_range": 0.11}},
        {"id": "range_5", "name": "Rango 5/5", "description": "Rango máximo 1.05", "cost": 7, "requires": ("range_4",), "effects": {"light_range": 0.11}},
    ],
    "duration": [
        {"id": "battery_1", "name": "Batería 1/5", "description": "Duración +1s", "cost": 7, "requires": (), "effects": {"light_battery": 1.0}},
        {"id": "battery_2", "name": "Batería 2/5", "description": "Duración +1s", "cost": 7, "requires": ("battery_1",), "effects": {"light_battery": 1.0}},
        {"id": "battery_3", "name": "Batería 3/5", "description": "Duración +1s", "cost": 7, "requires": ("battery_2",), "effects": {"light_battery": 1.0}},
        {"id": "battery_4", "name": "Batería 4/5", "description": "Duración +1s", "cost": 7, "requires": ("battery_3",), "effects": {"light_battery": 1.0}},
        {"id": "battery_5", "name": "Batería 5/5", "description": "Duración máxima 15s", "cost": 7, "requires": ("battery_4",), "effects": {"light_battery": 1.0}},
    ],
    "entity_light": [
        {"id": "entity_1", "name": "Luminosidad 1/4", "description": "Entidades +0.1", "cost": 7, "requires": (), "effects": {"entity_light": 0.1}},
        {"id": "entity_2", "name": "Luminosidad 2/4", "description": "Entidades +0.1", "cost": 7, "requires": ("entity_1",), "effects": {"entity_light": 0.1}},
        {"id": "entity_3", "name": "Luminosidad 3/4", "description": "Entidades +0.1", "cost": 7, "requires": ("entity_2",), "effects": {"entity_light": 0.1}},
        {"id": "entity_4", "name": "Luminosidad 4/4", "description": "Entidades máximo 0.5", "cost": 7, "requires": ("entity_3",), "effects": {"entity_light": 0.1}},
    ],
}
WEAPON_UPGRADE_TREES["triple_jump"] = {
    "mobility": [
        {"id": "third_jump", "name": "Tercer salto", "description": "Desbloquea un salto adicional", "cost": 6, "requires": (), "effects": {"special": "third_jump"}},
        {"id": "fourth_jump", "name": "Cuarto salto", "description": "Evolución: un salto adicional más", "cost": 9, "requires": ("third_jump",), "effects": {"special": "fourth_jump"}},
    ],
}

# Seguimiento del X Buster no debe existir antes de desbloquear la rama.
# 1/5 activa 1.0s; 5/5 llega a 2.0s, conservando ids versionados tracking_N.
WEAPON_UPGRADE_TREES.setdefault("gun", {})["tracking"] = [
    {"id": "tracking_1", "name": "Seguimiento 1/5", "description": "Desbloquea seguimiento por 1.0s", "cost": 3, "requires": (), "effects": {"homing_time": 1.0}},
    {"id": "tracking_2", "name": "Seguimiento 2/5", "description": "Seguimiento +0.25s", "cost": 3, "requires": ("tracking_1",), "effects": {"homing_time": 0.25}},
    {"id": "tracking_3", "name": "Seguimiento 3/5", "description": "Seguimiento +0.25s", "cost": 3, "requires": ("tracking_2",), "effects": {"homing_time": 0.25}},
    {"id": "tracking_4", "name": "Seguimiento 4/5", "description": "Seguimiento +0.25s", "cost": 3, "requires": ("tracking_3",), "effects": {"homing_time": 0.25}},
    {"id": "tracking_5", "name": "Seguimiento 5/5", "description": "Seguimiento +0.25s", "cost": 3, "requires": ("tracking_4",), "effects": {"homing_time": 0.25}},
]

# N-Resurrection tiene una rama de cantidad exactamente de 4 mejoras: 1 aliado base -> 5 aliados.
WEAPON_UPGRADE_TREES.setdefault("n_resurrection", {})["count"] = [
    {"id": "count_1", "name": "Aliados 1/4", "description": "Capacidad +1 enemigo revivido", "cost": 3, "requires": (), "effects": {"revive_slots": 1}},
    {"id": "count_2", "name": "Aliados 2/4", "description": "Capacidad +1 enemigo revivido", "cost": 3, "requires": ("count_1",), "effects": {"revive_slots": 1}},
    {"id": "count_3", "name": "Aliados 3/4", "description": "Capacidad +1 enemigo revivido", "cost": 3, "requires": ("count_2",), "effects": {"revive_slots": 1}},
    {"id": "count_4", "name": "Aliados 4/4", "description": "Capacidad +1 enemigo revivido", "cost": 3, "requires": ("count_3",), "effects": {"revive_slots": 1}},
]


BOSS_ORDER: tuple[str, ...] = (
    "boss_spread", "boss_lightning_split", "boss_flyer", "boss_dragon", "boss_colossus", "boss_ninja", "boss_ice", "boss_fire", "boss_plant", "boss_rock", "boss_water", "boss_aquatic", "boss_thunder", "boss_clone",
)



BOSS_SPECS: dict[str, dict[str, object]] = {
    "boss_spread": {"name": "Dispersor", "title": "abanico imposible", "hp_mult": 1.0, "attack_mult": 1.0, "move_style": "sine_strife", "attacks": ("spread", "safe_zones"), "phase2": "abanico doble", "weakness": "pulse", "arena_modifier": "zonas seguras"},
    "boss_lightning_split": {"name": "Prisma de Rayos", "title": "columnas marcadas", "hp_mult": 0.9, "attack_mult": 1.1, "move_style": "vertical_bounce", "attacks": ("lightning_columns", "side_prisms"), "phase2": "prismas laterales", "weakness": "ice", "arena_modifier": "rayos"},
    "boss_flyer": {"name": "Volador", "title": "patrón aéreo", "hp_mult": 0.85, "attack_mult": 1.0, "move_style": "air_loop", "attacks": ("aimed", "dive"), "phase2": "vuelo errático", "weakness": "rail", "arena_modifier": "aire"},
    "boss_dragon": {"name": "Dragón", "title": "llamarada frontal", "hp_mult": 1.1, "attack_mult": 1.15, "move_style": "hover", "attacks": ("fire_breath", "floor_flare"), "phase2": "llama triple", "weakness": "ice", "arena_modifier": "calor"},
    "boss_colossus": {"name": "Coloso", "title": "choque sísmico", "hp_mult": 1.45, "attack_mult": 1.0, "move_style": "slow_crush", "attacks": ("rocks", "shockwave"), "phase2": "caídas dobles", "weakness": "sonic", "arena_modifier": "rocas"},
    "boss_ninja": {"name": "Ninja Portal", "title": "teletransporte", "hp_mult": 0.9, "attack_mult": 1.05, "move_style": "portal", "attacks": ("shadow_shot", "counter"), "phase2": "portales rápidos", "weakness": "lightning", "arena_modifier": "sombras"},
    "boss_ice": {"name": "Hielo", "title": "lento inevitable", "hp_mult": 1.0, "attack_mult": 1.0, "move_style": "slide", "attacks": ("ice_shards", "slow_field"), "phase2": "escarcha radial", "weakness": "fire", "arena_modifier": "hielo"},
    "boss_fire": {"name": "Fuego", "title": "furia diagonal", "hp_mult": 1.0, "attack_mult": 1.18, "move_style": "aggressive", "attacks": ("flame", "bomb"), "phase2": "llama triple", "weakness": "water", "arena_modifier": "lava"},
    "boss_plant": {"name": "Planta", "title": "raíces vivas", "hp_mult": 1.15, "attack_mult": 0.95, "move_style": "rooted", "attacks": ("roots", "seeds"), "phase2": "semillas dobles", "weakness": "fire", "arena_modifier": "raíces"},
    "boss_rock": {"name": "Roca", "title": "derrumbe", "hp_mult": 1.25, "attack_mult": 1.05, "move_style": "slow", "attacks": ("rocks",), "phase2": "derrumbe ancho", "weakness": "acid", "arena_modifier": "piedras"},
    "boss_water": {"name": "Agua", "title": "corriente viva", "hp_mult": 1.0, "attack_mult": 1.0, "move_style": "wave", "attacks": ("waves", "currents"), "phase2": "mareas", "weakness": "lightning", "arena_modifier": "corrientes"},
    "boss_aquatic": {"name": "Pez Abisal", "title": "gravedad líquida", "hp_mult": 0.95, "attack_mult": 1.12, "move_style": "swim", "attacks": ("bite", "minions"), "phase2": "nado veloz", "weakness": "lightning", "arena_modifier": "burbujas"},
    "boss_thunder": {"name": "Rayo", "title": "descarga en cadena", "hp_mult": 0.88, "attack_mult": 1.25, "move_style": "fast_zigzag", "attacks": ("thunder", "chain"), "phase2": "más velocidad", "weakness": "earth", "arena_modifier": "rayos"},
    "boss_clone": {"name": "Clon LEMAT", "title": "copia retrasada", "hp_mult": 1.2, "attack_mult": 1.1, "move_style": "mimic", "attacks": ("copy", "mirror"), "phase2": "copia frecuente", "weakness": "shadow", "arena_modifier": "espejo"},
}

BOSS_NAMES: dict[str, str] = {key: f"Jefe {idx + 1}: {spec['name']}" for idx, (key, spec) in enumerate(BOSS_SPECS.items())}

ENEMY_XP: dict[str, int] = {kind: XP_MINOR for kind in ENEMY_STATS}
for _kind in ("major", "turret", "shield", "bomber", "sniper", "mirror", "summoner", "hunter"):
    ENEMY_XP[_kind] = XP_MAJOR
ENEMY_XP["elite"] = XP_ELITE
for _boss_key in BOSS_ORDER:
    ENEMY_XP[_boss_key] = XP_BOSS
