from __future__ import annotations

"""Entrada de compatibilidad para builds existentes de PyInstaller.

El código real del HUB vive en ``lematzium_suite_launcher.py``. Este archivo se
mantiene porque los scripts de compilación históricos lo referencian como punto
de entrada.
"""

from lematzium_suite_launcher import LematZiumSuiteLauncher, main

__all__ = ["LematZiumSuiteLauncher", "main"]


if __name__ == "__main__":
    raise SystemExit(main())
