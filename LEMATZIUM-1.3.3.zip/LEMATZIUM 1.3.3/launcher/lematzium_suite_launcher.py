
from __future__ import annotations

import ctypes
from ctypes import wintypes
import json
import math
import os
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from launch_runtime import (
    candidate_python_executables,
    install_missing_dependencies,
    popen_normal_window,
    python_has_imports,
    select_python_for_module,
)

APP_TITLE = "LEMATZIUM"
PREFS_FILE = "lematzium_suite_launcher_prefs.json"

SUPPORTED_THEMES = [
    "Azul Eléctrico",
    "Rosa Francés",
    "Blanco Moderno",
    "Negro Premium",
]

CLASSIC_UI_MODE = "Clásico original"
RETRO_UI_MODE = "Retro laboratorio · ciudad procedural"

SUPPORTED_UI_MODES = [
    CLASSIC_UI_MODE,
]

UI_MODE_ALIASES = {
    "Clasico original": CLASSIC_UI_MODE,
    "Clásico actual · sin cambios visuales": CLASSIC_UI_MODE,
    "Modo clásico · microdestellos": CLASSIC_UI_MODE,
    "classic": CLASSIC_UI_MODE,
    "classic_micro_sparks": CLASSIC_UI_MODE,
    "physics_blocks": RETRO_UI_MODE,
    "Modo físico · bloques arrastrables": RETRO_UI_MODE,
    "Físico": RETRO_UI_MODE,
    "Físico · bloques arrastrables": RETRO_UI_MODE,
    "retro": RETRO_UI_MODE,
    "retro_platformer": RETRO_UI_MODE,
    "Retro": RETRO_UI_MODE,
    "Retro laboratorio": RETRO_UI_MODE,
    "Retro laboratorio · plataforma": RETRO_UI_MODE,
    "Retro laboratorio · ciudad": RETRO_UI_MODE,
}

THEME_ALIASES = {
    "Azul eléctrico": "Azul Eléctrico",
    "Rosa francés": "Rosa Francés",
    "Blanco moderno": "Blanco Moderno",
    "Negro premium": "Negro Premium",
    "Magenta Neón": "Rosa Francés",
    "Blanco Sobrio": "Blanco Moderno",
}

STATUS_FRAMES = [
    "SINCRONIZANDO MÓDULOS...",
    "CARGANDO ENTORNO VISUAL...",
    "VALIDANDO RUTAS DE ARRANQUE...",
    "LEMATZIUM LISTO...",
]

ICON_CANDIDATES = {
    "Azul-cian": "1-removebg-preview.png",
    "Rosa": "2-removebg-preview.png",
    "Naranja": "3-removebg-preview.png",
    "Verde": "4-removebg-preview.png",
    "Azul profundo": "5-removebg-preview.png",
    "Morado": "6-removebg-preview.png",
}

ASSISTANT_TEXT_MODELS = (
    "Gemini 3.1 Flash Lite",
    "Gemma 4 31B",
)

ASSISTANT_AUDIO_MODELS = (
    "Gemini 3.1 Flash Live",
    "Gemini 2.5 Flash Native Audio Dialog",
)

ASSISTANT_RESPONSE_MODES = (
    "Auditoría estricta",
    "Capacitación",
    "Soporte técnico",
)

ASSISTANT_GEMMA_THINKING_MODES = (
    "Thinking",
    "No thinking",
)

DEFAULT_ASSISTANT_NAME = "LEMATZIUM IA"
DEFAULT_ASSISTANT_TEXT_MODEL = "Gemini 3.1 Flash Lite"
DEFAULT_ASSISTANT_AUDIO_MODEL = "Gemini 3.1 Flash Live"
DEFAULT_ASSISTANT_AUDIO_VOICE = "Gacrux"
DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER = "LEMATRÓN grave limpio"
DEFAULT_ASSISTANT_RESPONSE_MODE = "Auditoría estricta"
DEFAULT_ASSISTANT_GEMMA_THINKING_MODE = "Thinking"


@dataclass(frozen=True)
class Palette:
    name: str
    bg: str
    panel: str
    panel_alt: str
    border: str
    accent: str
    accent_soft: str
    text: str
    text_soft: str
    success: str
    warning: str
    danger: str
    hero: str
    grid: str


@dataclass(frozen=True)
class ModuleDefinition:
    key: str
    title: str
    description: str
    relative_candidates: tuple[str, ...]
    basename_fallbacks: tuple[str, ...]
    frozen_exe_relative: str


@dataclass(frozen=True)
class ModuleResolved:
    definition: ModuleDefinition
    script_path: Path | None


@dataclass
class RetroPlayer:
    """Personaje original de estilo pixel para la pantalla retro del launcher."""

    x: float = 94.0
    y: float = 0.0
    w: float = 26.0
    h: float = 34.0
    vx: float = 0.0
    vy: float = 0.0
    facing: int = 1
    on_ground: bool = False
    jumps_used: int = 0
    wall_side: int = 0
    walk_phase: float = 0.0
    dash_timer: float = 0.0
    dash_cooldown: float = 0.0
    sword_timer: float = 0.0
    sword_cooldown: float = 0.0
    shoot_cooldown: float = 0.0
    hurt_timer: float = 0.0


@dataclass
class RetroProjectile:
    x: float
    y: float
    vx: float
    vy: float = 0.0
    life: float = 1.4
    damage: int = 1
    kind: str = "normal"
    level: int = 0
    origin_x: float = 0.0
    returning: bool = False
    hit_ids: set[int] | None = None


@dataclass(frozen=True)
class RetroRect:
    """Rectángulo de colisión del mundo retro, en coordenadas del mundo."""

    x: float
    y: float
    w: float
    h: float
    kind: str = "platform"


@dataclass(frozen=True)
class RetroPit:
    x: float
    w: float


@dataclass
class RetroEnemy:
    x: float
    y: float
    w: float
    h: float
    vx: float
    kind: str
    hp: int
    patrol_left: float
    patrol_right: float
    phase: float = 0.0
    alive: bool = True
    hurt_flash: float = 0.0


PALETTES = {
    "Azul Eléctrico": Palette(
        "Azul Eléctrico",
        "#071521",
        "#10263A",
        "#15324C",
        "#29557D",
        "#26A9FF",
        "#73C9FF",
        "#F3FAFF",
        "#C5DCF0",
        "#39D98A",
        "#FFB800",
        "#FF6B6B",
        "#061827",
        "#173A59",
    ),
    "Rosa Francés": Palette(
        "Rosa Francés",
        "#170813",
        "#2A1230",
        "#35193C",
        "#6B2E73",
        "#FF49C4",
        "#FF9BE0",
        "#FFF5FD",
        "#F1D8EC",
        "#48E1A8",
        "#FFC857",
        "#FF7A96",
        "#1A0918",
        "#4B2750",
    ),
    "Blanco Moderno": Palette(
        "Blanco Moderno",
        "#F1F5F9",
        "#FFFFFF",
        "#F8FAFC",
        "#CBD5E1",
        "#2563EB",
        "#60A5FA",
        "#0F172A",
        "#334155",
        "#16A34A",
        "#CA8A04",
        "#DC2626",
        "#EAF2F8",
        "#B5C9DA",
    ),
    "Negro Premium": Palette(
        "Negro Premium",
        "#050505",
        "#111111",
        "#191919",
        "#303030",
        "#B58DFF",
        "#D0BDFF",
        "#F8F8F8",
        "#D5D5D5",
        "#3DD598",
        "#F6C945",
        "#FF808B",
        "#09090C",
        "#282833",
    ),
}

DEFAULT_AUDIT_DOCUMENT_CONTENT = '# AUDITORÍA 17020-17025 · LEMATZIUM\n\nDocumento de lectura rápida para revisión funcional del programa. Aplica a:\n\n- Módulo 1 - Tracción Metales 1.3.0\n- Módulo 2 - Tracción plásticos 1.0.0\n\nEste documento explica el flujo informático de lectura CSV, graficación, cálculo, ubicación de puntos, edición controlada y exportación de informes. No reemplaza procedimientos del laboratorio, métodos normalizados ni registros primarios.\n\n## 1. Flujo general\n\n1. El usuario abre el módulo desde el launcher.\n2. Importa un CSV de ensayo.\n3. El sistema interpreta columnas de fuerza, desplazamiento, deformación, esfuerzo, tiempo o identificación de probeta, según estén disponibles.\n4. Se separan curvas por probeta o serie.\n5. El usuario revisa geometría, parámetros del método, identificación y observaciones.\n6. El programa grafica la curva y calcula resultados.\n7. Los puntos característicos se reflejan en tabla y en gráfica.\n8. El reportador agrupa probetas, selecciona plantilla y exporta Word editable.\n\n## 2. Lectura del CSV\n\nLEMATZIUM no modifica el CSV original. El archivo se lee como dato externo y se convierte en vectores internos. Las filas vacías, encabezados repetidos o valores no numéricos se omiten cuando no son útiles para la curva. Si no existen datos numéricos suficientes, el módulo no debe calcular resultados automáticamente.\n\n## 3. Graficación\n\nLa curva se genera con los vectores del CSV y la geometría ingresada. Cuando hay fuerza y área inicial, se calcula esfuerzo ingenieril. Cuando hay desplazamiento/deformación y longitud de referencia, se calcula deformación ingenieril. Al cambiar de curva o importar otro CSV, la escala debe reiniciarse para evitar arrastrar zoom o límites anteriores.\n\n## 4. Cálculos básicos\n\n- Esfuerzo ingenieril: σ = F / A.\n- Deformación ingenieril: ε = ΔL / L0.\n- Resistencia máxima: mayor esfuerzo válido de la curva.\n- Punto final o rotura: último tramo útil, caída de esfuerzo/carga o último dato válido según configuración.\n\n## 5. Módulo 1 - Tracción Metales 1.3.0\n\nProcesa curvas de tracción en metales. Identifica resistencia máxima, fluencia cuando sea detectable, offset cuando aplica, rotura y resultados asociados. El usuario puede revisar la tabla, la gráfica y exportar informes con plantilla acreditada, no acreditada o plantillas agregadas.\n\n## 6. Módulo 2 - Tracción plásticos 1.0.0\n\nProcesa curvas de tracción en plásticos bajo enfoque ISO 527. El sistema reconoce comportamientos tipo A, B, C y D para ubicar los puntos relevantes. Los parámetros editables permiten ajustar deformaciones de módulo, deformación auxiliar, umbrales de caída/final y criterios auxiliares de detección.\n\nLos puntos del módulo de plásticos se muestran con nombres técnicos legibles. El usuario puede cambiar esos nombres desde la tabla y guardarlos como predeterminados para evitar códigos ambiguos en futuras sesiones.\n\n## 7. Ubicación de puntos\n\nLos puntos se calculan a partir de la curva activa. En curvas sin fluencia se prioriza máximo y rotura/final. En curvas con fluencia se identifican puntos de fluencia o equivalentes técnicos. Para el módulo de plásticos, el módulo se calcula con dos deformaciones de referencia configurables y sus esfuerzos asociados.\n\n## 8. Reportador y plantillas\n\nEl reportador incluye las plantillas base:\n\n- Acreditado (MC2202-08)\n- No acreditado (MC2201-06)\n\nEl botón **Agregar plantilla** permite seleccionar un archivo `.docx` adicional. El programa copia esa plantilla a una carpeta persistente y la registra en un manifiesto JSON. Desde ese momento aparece como opción permanente, aun después de cerrar y volver a abrir LEMATZIUM.\n\n## 9. Exportación\n\nCada grupo creado en el reportador genera un informe Word independiente. El programa abre la plantilla seleccionada, inserta encabezado, datos de cliente, muestra, observaciones, resultados, tablas/gráficas disponibles y bloque de firma. No altera el CSV original ni la plantilla original seleccionada.\n\n## 10. Verificación sugerida para auditoría\n\n- El launcher debe mostrar solo los dos módulos aprobados.\n- El conocimiento de auditoría 17020-17025 debe permanecer como fuente interna del asistente IA; no se muestra como botón independiente en las tarjetas de módulos.\n- El CSV debe importarse sin modificarse.\n- La gráfica debe corresponder a los datos importados.\n- La tabla y los puntos de la gráfica deben coincidir.\n- Los parámetros editables solo deben afectar el análisis interno.\n- Los nombres de puntos personalizados deben conservarse al reiniciar.\n- Una plantilla agregada debe quedar disponible como opción permanente.\n- Los informes exportados deben ser Word editables y trazables al CSV y a los datos ingresados.\n'

VISIBLE_MODULE_KEYS = ("tensile_unified", "traccion_plasticos", "ai_assistant", "uncertainty")

MODULE_DEFINITIONS: tuple[ModuleDefinition, ...] = (
    ModuleDefinition(
        key="modulo1",
        title="Módulo 1 · Fluencia por caída de 1 MPa",
        description="Traza esfuerzo-alargamiento con selección automática del primer máximo con caída de 1 MPa y ajuste manual del punto.",
        relative_candidates=(
            "modules/module_1_drop1mpa/launch_modulo_1.py",
            "modules/module_1_drop1mpa/lematzium_modulo1/app/main.py",
        ),
        basename_fallbacks=("launch_modulo_1.py", "main.py"),
        frozen_exe_relative="modules/module_1_drop1mpa/LEMATZIUM_Modulo1.exe",
    ),
    ModuleDefinition(
        key="modulo2",
        title="Módulo 2 · Fluencia por offset 0.2%",
        description="Módulo individual con recta offset ajustable, resultados editables y exportación alineada al flujo institucional.",
        relative_candidates=(
            "modules/module_2_offset02/launch_modulo2.py",
        ),
        basename_fallbacks=("launch_modulo2.py",),
        frozen_exe_relative="modules/module_2_offset02/LEMATZIUM_Modulo2.exe",
    ),
    ModuleDefinition(
        key="tensile_unified",
        title="Módulo 1 - Tracción Metales 1.3.0",
        description="Analiza curvas de tracción en metales con detección automática, geometría editable, puntos característicos y exportación institucional.",
        relative_candidates=(
            "modules/module_tensile_unified/launch_tensile_unified.py",
        ),
        basename_fallbacks=("launch_tensile_unified.py",),
        frozen_exe_relative="modules/module_tensile_unified/LEMATZIUM_Tension_Unificada.exe",
    ),
    ModuleDefinition(
        key="traccion_plasticos",
        title="Módulo 2 - Tracción plásticos 1.0.0",
        description="Analiza curvas ISO 527 de plásticos con clasificación A/B/C/D, parámetros normativos editables, puntos característicos y exportación institucional.",
        relative_candidates=(
            "modules/module_4_traccion_plasticos/launch_traccion_plasticos.py",
        ),
        basename_fallbacks=("launch_traccion_plasticos.py",),
        frozen_exe_relative="modules/module_4_traccion_plasticos/LEMATZIUM_Traccion_Plasticos.exe",
    ),
    ModuleDefinition(
        key="ai_assistant",
        title="Módulo 3 - Asistente virtual IA",
        description="Chat IA con Gemini/Gemma, fallback automático entre modelos de escritura y botón de micrófono para audio en vivo.",
        relative_candidates=(
            "modules/module_3_ai_assistant/launch_ai_assistant.py",
        ),
        basename_fallbacks=("launch_ai_assistant.py",),
        frozen_exe_relative="modules/module_3_ai_assistant/LEMATZIUM_Asistente_IA.exe",
    ),
    ModuleDefinition(
        key="uncertainty",
        title="INCERTIDUMBRE",
        description="Edita las fuentes de incertidumbre compartidas de fuerza/área y los parámetros independientes por geometría usados en los comentarios del módulo de metales.",
        relative_candidates=(
            "launcher/uncertainty_editor.py",
        ),
        basename_fallbacks=("uncertainty_editor.py",),
        frozen_exe_relative="launcher/uncertainty_editor.py",
    ),
)


REQUIRED_IMPORTS_BY_MODULE = {
    "tensile_unified": ("matplotlib", "numpy", "pandas", "docx", "PIL"),
    "modulo1": ("matplotlib", "numpy", "pandas", "docx", "PIL"),
    "modulo2": ("matplotlib", "numpy", "pandas", "docx", "PIL"),
    "traccion_plasticos": ("matplotlib", "numpy", "pandas", "docx", "PIL"),
    "ai_assistant": ("google.genai",),
    "uncertainty": (),
}

PIP_PACKAGES_BY_MODULE = {
    "tensile_unified": ("numpy", "pandas", "matplotlib", "python-docx", "pillow", "openpyxl", "pypdf"),
    "modulo1": ("numpy", "pandas", "matplotlib", "python-docx", "pillow", "openpyxl", "pypdf"),
    "modulo2": ("numpy", "pandas", "matplotlib", "python-docx", "pillow", "openpyxl", "pypdf"),
    "traccion_plasticos": ("numpy", "pandas", "matplotlib", "python-docx", "pillow", "openpyxl", "pypdf"),
    "ai_assistant": ("google-genai", "sounddevice", "numpy"),
    "uncertainty": (),
}


def resolve_theme_name(theme_name: str | None) -> str:
    theme_name = (theme_name or "Azul Eléctrico").strip()
    theme_name = THEME_ALIASES.get(theme_name, theme_name)
    return theme_name if theme_name in PALETTES else "Azul Eléctrico"


def resolve_ui_mode(mode_name: str | None) -> str:
    mode_name = (mode_name or "Clásico original").strip()
    mode_name = UI_MODE_ALIASES.get(mode_name, mode_name)
    return mode_name if mode_name in SUPPORTED_UI_MODES else CLASSIC_UI_MODE


def resolve_assistant_text_model(model_name: str | None) -> str:
    candidate = (model_name or DEFAULT_ASSISTANT_TEXT_MODEL).strip()
    legacy_aliases = {
        "Gemini 3 Flash": "Gemini 3.1 Flash Lite",
        "Gemini 3.1 Flash": "Gemini 3.1 Flash Lite",
        "Gemini 3.1 Flash-Lite": "Gemini 3.1 Flash Lite",
    }
    candidate = legacy_aliases.get(candidate, candidate)
    return candidate if candidate in ASSISTANT_TEXT_MODELS else DEFAULT_ASSISTANT_TEXT_MODEL


def resolve_assistant_audio_model(model_name: str | None) -> str:
    candidate = (model_name or DEFAULT_ASSISTANT_AUDIO_MODEL).strip()
    return candidate if candidate in ASSISTANT_AUDIO_MODELS else DEFAULT_ASSISTANT_AUDIO_MODEL


def resolve_assistant_response_mode(mode_name: str | None) -> str:
    candidate = (mode_name or DEFAULT_ASSISTANT_RESPONSE_MODE).strip()
    return candidate if candidate in ASSISTANT_RESPONSE_MODES else DEFAULT_ASSISTANT_RESPONSE_MODE


def resolve_assistant_gemma_thinking_mode(mode_name: str | None) -> str:
    candidate = (mode_name or DEFAULT_ASSISTANT_GEMMA_THINKING_MODE).strip()
    return candidate if candidate in ASSISTANT_GEMMA_THINKING_MODES else DEFAULT_ASSISTANT_GEMMA_THINKING_MODE


def get_palette(theme_name: str | None) -> Palette:
    return PALETTES[resolve_theme_name(theme_name)]


def _is_light_palette(palette: Palette) -> bool:
    return palette.name == "Blanco Moderno"


def _is_frozen_app() -> bool:
    return bool(getattr(sys, "frozen", False))


def _launcher_base_dir() -> Path:
    if _is_frozen_app():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _suite_root_from_base(base_dir: Path) -> Path:
    return base_dir if _is_frozen_app() else base_dir.parent


def _prefs_path(base_dir: Path) -> Path:
    return base_dir / PREFS_FILE


def load_prefs(base_dir: Path) -> dict:
    path = _prefs_path(base_dir)
    if not path.exists():
        return {
            "theme": "Azul Eléctrico",
            "icon": "Azul-cian",
            "music_enabled": True,
            "music_volume": 35,
            "brightness": 85,
            "ui_mode": CLASSIC_UI_MODE,
            "assistant_name": DEFAULT_ASSISTANT_NAME,
            "assistant_text_model": DEFAULT_ASSISTANT_TEXT_MODEL,
            "assistant_response_mode": DEFAULT_ASSISTANT_RESPONSE_MODE,
            "assistant_gemma_thinking_mode": DEFAULT_ASSISTANT_GEMMA_THINKING_MODE,
            "gemini_api_key": "",
            "assistant_audio_model": DEFAULT_ASSISTANT_AUDIO_MODEL,
            "assistant_audio_voice": DEFAULT_ASSISTANT_AUDIO_VOICE,
            "assistant_audio_voice_filter": DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER,
        }
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    raw_mode = data.get("ui_mode", data.get("ui_style", "Clásico original"))
    return {
        "theme": resolve_theme_name(data.get("theme")),
        "icon": data.get("icon", "Azul-cian"),
        "music_enabled": bool(data.get("music_enabled", True)),
        "music_volume": int(data.get("music_volume", 35)),
        "brightness": int(data.get("brightness", 85)),
        "ui_mode": CLASSIC_UI_MODE,
        "assistant_name": str(data.get("assistant_name", DEFAULT_ASSISTANT_NAME)).strip() or DEFAULT_ASSISTANT_NAME,
        "assistant_text_model": resolve_assistant_text_model(data.get("assistant_text_model")),
        "assistant_response_mode": resolve_assistant_response_mode(data.get("assistant_response_mode")),
        "assistant_gemma_thinking_mode": resolve_assistant_gemma_thinking_mode(data.get("assistant_gemma_thinking_mode")),
        "gemini_api_key": str(data.get("gemini_api_key", "")).strip(),
        "assistant_audio_model": resolve_assistant_audio_model(data.get("assistant_audio_model")),
        "assistant_audio_voice": str(data.get("assistant_audio_voice", DEFAULT_ASSISTANT_AUDIO_VOICE)).strip() or DEFAULT_ASSISTANT_AUDIO_VOICE,
        "assistant_audio_voice_filter": str(data.get("assistant_audio_voice_filter", DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER)).strip() or DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER,
    }


def save_prefs(base_dir: Path, prefs: dict) -> None:
    _prefs_path(base_dir).write_text(json.dumps(prefs, ensure_ascii=False, indent=2), encoding="utf-8")


def _prepend_pythonpath(env: dict[str, str], *paths: Path) -> None:
    existing = env.get("PYTHONPATH", "")
    cleaned = [str(path.resolve()) for path in paths if path.exists()]
    if existing:
        cleaned.append(existing)
    env["PYTHONPATH"] = os.pathsep.join(cleaned)


def _find_best_candidate(base_dir: Path, definition: ModuleDefinition) -> Path | None:
    for relative_path in definition.relative_candidates:
        candidate = base_dir / relative_path
        if candidate.exists():
            return candidate.resolve()

    found: list[Path] = []
    for basename in definition.basename_fallbacks:
        found.extend(base_dir.rglob(basename))
    if not found:
        return None

    def score(path: Path) -> tuple[int, int, str]:
        path_s = str(path).lower().replace("\\", "/")
        value = 0
        if definition.key == "modulo1":
            if "module_1_drop1mpa" in path_s:
                value += 12
            if path.name == "launch_modulo_1.py":
                value += 9
            if "/app/main.py" in path_s:
                value += 6
        elif definition.key == "modulo2":
            if "module_2_offset02" in path_s:
                value += 12
            if path.name == "launch_modulo2.py":
                value += 9
        elif definition.key == "tensile_unified":
            if "module_tensile_unified" in path_s:
                value += 12
            if path.name == "launch_tensile_unified.py":
                value += 9
        elif definition.key == "traccion_plasticos":
            if "module_4_traccion_plasticos" in path_s:
                value += 12
            if path.name == "launch_traccion_plasticos.py":
                value += 9
        elif definition.key == "ai_assistant":
            if "module_3_ai_assistant" in path_s:
                value += 12
            if path.name == "launch_ai_assistant.py":
                value += 9
        elif definition.key == "uncertainty":
            if "launcher" in path_s:
                value += 12
            if path.name == "uncertainty_editor.py":
                value += 9
        value += max(0, 8 - len(path.parts))
        return (value, -len(path.parts), path_s)

    return sorted(found, key=score, reverse=True)[0].resolve()


def _find_best_frozen_executable(base_dir: Path, definition: ModuleDefinition) -> Path | None:
    app_root = Path(sys.executable).resolve().parent
    exe_name = Path(definition.frozen_exe_relative).name

    root_candidates: list[Path] = [app_root]
    for parent in app_root.parents:
        root_candidates.append(parent)
        if len(root_candidates) >= 5:
            break
    root_candidates.append(base_dir)

    seen: set[Path] = set()
    normalized_roots: list[Path] = []
    for root in root_candidates:
        try:
            resolved_root = root.resolve()
        except Exception:
            resolved_root = root
        if resolved_root in seen:
            continue
        seen.add(resolved_root)
        normalized_roots.append(resolved_root)

    exact_candidates: list[Path] = []
    for root in normalized_roots:
        exact_candidate = root / definition.frozen_exe_relative
        if exact_candidate.exists():
            exact_candidates.append(exact_candidate.resolve())

    if exact_candidates:
        return exact_candidates[0]

    found_exe: list[Path] = []
    for root in normalized_roots:
        try:
            found_exe.extend(root.rglob(exe_name))
        except Exception:
            continue

    if not found_exe:
        return None

    def score(path: Path) -> tuple[int, int, str]:
        path_s = str(path).lower().replace("\\", "/")
        value = 0
        module_folder = definition.frozen_exe_relative.lower().replace("\\", "/").rsplit("/", 1)[0]
        if module_folder and module_folder in path_s:
            value += 20
        if path.name.lower() == exe_name.lower():
            value += 10
        if "/dist/" in path_s:
            value += 4
        if "/release/" in path_s or "/app/" in path_s:
            value += 6
        return (value, -len(path.parts), path_s)

    return sorted(found_exe, key=score, reverse=True)[0].resolve()


def detect_modules(base_dir: Path) -> dict[str, ModuleResolved]:
    resolved: dict[str, ModuleResolved] = {}
    frozen = _is_frozen_app()

    for definition in MODULE_DEFINITIONS:
        launch_path: Path | None = None

        if frozen:
            launch_path = _find_best_frozen_executable(base_dir, definition)

        if launch_path is None:
            launch_path = _find_best_candidate(base_dir, definition)

        resolved[definition.title] = ModuleResolved(
            definition=definition,
            script_path=launch_path,
        )
    return resolved


class MusicController:
    def __init__(self, music_path: Path | None) -> None:
        self.music_path = music_path
        self.alias = "lematzium_bgm"
        self.available = sys.platform.startswith("win") and music_path is not None
        self._opened = False
        self._paused = False

    def _send(self, command: str) -> int:
        if not self.available:
            return -1
        try:
            return ctypes.windll.winmm.mciSendStringW(command, None, 0, None)
        except Exception:
            self.available = False
            return -1

    def open(self) -> None:
        if not self.available or self._opened:
            return
        safe_path = str(self.music_path).replace('"', "")
        self._send(f"close {self.alias}")
        err = self._send(f'open "{safe_path}" type mpegvideo alias {self.alias}')
        if err == 0:
            self._opened = True
            self._paused = False
        else:
            self.available = False

    def play_loop(self) -> None:
        if not self.available:
            return
        self.open()
        if not self._opened:
            return
        if self._paused:
            err = self._send(f"resume {self.alias}")
            if err == 0:
                self._paused = False
                return
        self._send(f"play {self.alias} repeat")
        self._paused = False

    def stop(self) -> None:
        if not self.available or not self._opened:
            return
        self._send(f"stop {self.alias}")
        self._paused = True

    def close(self) -> None:
        if not self.available:
            return
        self._send(f"close {self.alias}")
        self._opened = False
        self._paused = False

    def set_volume(self, percent: int) -> None:
        if not self.available:
            return
        self.open()
        if not self._opened:
            return
        clamped = max(0, min(100, int(percent)))
        device_volume = int(clamped * 10)
        self._send(f"setaudio {self.alias} volume to {device_volume}")


class AnimatedActionButton(tk.Button):
    def __init__(self, master: tk.Misc, *, palette: Palette, filled: bool = False, compact: bool = False, **kwargs) -> None:
        self._palette = palette
        self._filled = filled
        self._compact = compact
        self._duotone: tuple[str, str, str, str] | None = None
        super().__init__(master, **kwargs)
        self.configure(
            relief="flat",
            bd=0,
            cursor="hand2",
            font=("Segoe UI Semibold", 10),
            padx=12 if compact else 14,
            pady=8 if compact else 10,
            highlightthickness=1,
        )
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.apply_palette(palette)

    def set_duotone(self, normal_bg: str, normal_fg: str, hover_bg: str, hover_fg: str) -> None:
        self._duotone = (normal_bg, normal_fg, hover_bg, hover_fg)
        self.configure(
            bg=normal_bg,
            fg=normal_fg,
            activebackground=hover_bg,
            activeforeground=hover_fg,
            highlightbackground=normal_fg,
            highlightcolor=normal_fg,
        )

    def clear_duotone(self) -> None:
        self._duotone = None
        self.apply_palette(self._palette)

    def apply_palette(self, palette: Palette) -> None:
        self._palette = palette
        if self._duotone is not None:
            bg, fg, hover_bg, hover_fg = self._duotone
            self.configure(
                bg=bg,
                fg=fg,
                activebackground=hover_bg,
                activeforeground=hover_fg,
                highlightbackground=fg,
                highlightcolor=fg,
            )
            return
        if self._filled:
            fg = "#FFFFFF" if palette.name != "Blanco Moderno" else "#F8FAFC"
            self.configure(
                bg=palette.accent,
                fg=fg,
                activebackground=palette.accent_soft,
                activeforeground=fg,
                highlightbackground=palette.accent,
                highlightcolor=palette.accent_soft,
            )
        else:
            self.configure(
                bg=palette.panel_alt,
                fg=palette.text,
                activebackground=palette.border,
                activeforeground=palette.text,
                highlightbackground=palette.border,
                highlightcolor=palette.accent,
            )

    def _on_enter(self, _event: tk.Event) -> None:
        if self._duotone is not None:
            _bg, _fg, hover_bg, hover_fg = self._duotone
            self.configure(bg=hover_bg, fg=hover_fg)
            return
        if self._filled:
            self.configure(bg=self._palette.accent_soft)
        else:
            self.configure(bg=self._palette.border)

    def _on_leave(self, _event: tk.Event) -> None:
        if self._duotone is not None:
            bg, fg, _hover_bg, _hover_fg = self._duotone
            self.configure(bg=bg, fg=fg)
            return
        if self._filled:
            self.configure(bg=self._palette.accent)
        else:
            self.configure(bg=self._palette.panel_alt)


class IconPreviewButton(tk.Frame):
    def __init__(self, master: tk.Misc, *, icon_name: str, image: tk.PhotoImage | None, callback, palette: Palette) -> None:
        super().__init__(master, bd=1, relief="solid", cursor="hand2")
        self.icon_name = icon_name
        self._callback = callback
        self.image_label = tk.Label(self, image=image)
        self.image_label.image = image
        self.text_label = tk.Label(self, text=icon_name)
        self.image_label.pack(padx=14, pady=(14, 8))
        self.text_label.pack(padx=10, pady=(0, 12))
        for widget in (self, self.image_label, self.text_label):
            widget.bind("<Button-1>", self._on_click)
        self.apply_palette(palette, selected=False)

    def _on_click(self, _event=None) -> None:
        self._callback(self.icon_name)

    def apply_palette(self, palette: Palette, *, selected: bool) -> None:
        bg = palette.panel_alt if selected else palette.panel
        border = palette.accent if selected else palette.border
        self.configure(bg=bg, highlightbackground=border, highlightcolor=border, padx=2, pady=2)
        self.image_label.configure(bg=bg)
        self.text_label.configure(bg=bg, fg=palette.text, font=("Segoe UI", 10))


class ModuleCard:
    def __init__(self, master: tk.Misc, *, module_name: str, module_resolved: ModuleResolved, palette: Palette, open_callback) -> None:
        self.module_name = module_name
        self.module_resolved = module_resolved
        self.palette = palette
        self.open_callback = open_callback
        self.frame = tk.Frame(master, bd=2, relief="ridge", cursor="hand2", highlightthickness=2)
        self.accent_bar = tk.Frame(self.frame, height=4, bd=0)
        self.title_label = tk.Label(self.frame, text=module_name, justify="center", anchor="center", wraplength=320)
        self.hint_label = tk.Label(self.frame, text="Doble clic para abrir", justify="center", anchor="center")
        self.path_hint = tk.Label(self.frame, text="", justify="left", anchor="w")

        self.accent_bar.pack(fill="x", pady=(0, 18))
        self.title_label.pack(fill="both", expand=True, anchor="center", pady=(8, 10))
        self.hint_label.pack(fill="x", anchor="center", pady=(0, 8))

        for widget in (self.frame, self.title_label, self.hint_label, self.path_hint):
            widget.bind("<Enter>", self._hover_on)
            widget.bind("<Leave>", self._hover_off)
            widget.bind("<Double-Button-1>", self._open_by_double_click)
        self.apply_palette(palette)
        self._hover_off(None)

    def _open_by_double_click(self, _event=None) -> None:
        self.open_callback(self.module_name)

    def apply_palette(self, palette: Palette) -> None:
        self.palette = palette
        self.frame.configure(bg=palette.panel, highlightbackground=palette.accent_soft, highlightcolor=palette.accent, padx=18, pady=18)
        self.accent_bar.configure(bg=palette.accent)
        self.title_label.configure(bg=palette.panel, fg=palette.text, font=("Segoe UI Semibold", 18))
        self.hint_label.configure(bg=palette.panel, fg=palette.text_soft, font=("Segoe UI", 10))
        # Sin leyenda de ruta visible; la trazabilidad queda como fuente interna del asistente IA.
        self.path_hint.configure(bg=palette.panel, fg=palette.text_soft, font=("Segoe UI", 1), text="")
        self._hover_off(None)

    def _hover_on(self, _event) -> None:
        self.frame.configure(bg=self.palette.panel_alt, highlightbackground=self.palette.accent)
        self.title_label.configure(bg=self.palette.panel_alt)
        self.hint_label.configure(bg=self.palette.panel_alt)
        self.path_hint.configure(bg=self.palette.panel_alt)

    def _hover_off(self, _event) -> None:
        self.frame.configure(bg=self.palette.panel, highlightbackground=self.palette.border)
        self.title_label.configure(bg=self.palette.panel)
        self.hint_label.configure(bg=self.palette.panel)
        self.path_hint.configure(bg=self.palette.panel)


class ConfigDialog:
    def __init__(self, hub: "LematZiumSuiteLauncher") -> None:
        self.hub = hub
        self.window = tk.Toplevel(hub.root)
        self.window.title("Configuración")
        self.window.geometry("860x680")
        self.window.minsize(760, 620)
        self.window.transient(hub.root)
        self.window.configure(bg=get_palette(hub.theme_name.get()).bg)
        self.window.protocol("WM_DELETE_WINDOW", self.close)

        self.theme_var = tk.StringVar(value=hub.theme_name.get())
        self.ui_mode_var = tk.StringVar(value=CLASSIC_UI_MODE)
        self.icon_var = tk.StringVar(value=hub.icon_name.get())
        self.music_var = tk.BooleanVar(value=hub.music_enabled.get())
        self.volume_var = tk.IntVar(value=hub.music_volume.get())
        self.brightness_var = tk.IntVar(value=hub.brightness_var.get())
        self.assistant_name_var = tk.StringVar(value=hub.assistant_name.get())
        self.assistant_text_model_var = tk.StringVar(value=hub.assistant_text_model.get())
        self.assistant_response_mode_var = tk.StringVar(value=hub.assistant_response_mode.get())
        self.assistant_gemma_thinking_mode_var = tk.StringVar(value=hub.assistant_gemma_thinking_mode.get())
        self.gemini_api_key_var = tk.StringVar(value=hub.gemini_api_key.get())
        self.assistant_audio_model_var = tk.StringVar(value=hub.assistant_audio_model.get())

        self.style = ttk.Style(self.window)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass

        self.canvas = tk.Canvas(self.window, highlightthickness=0, bd=0)
        self.vscroll = ttk.Scrollbar(self.window, orient="vertical", command=self.canvas.yview)
        self.hscroll = ttk.Scrollbar(self.window, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=self.vscroll.set, xscrollcommand=self.hscroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vscroll.pack(side="right", fill="y")
        self.hscroll.pack(side="bottom", fill="x")
        self.root_frame = tk.Frame(self.canvas, bd=0)
        self.canvas_window = self.canvas.create_window((0, 0), window=self.root_frame, anchor="nw")
        self.root_frame.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"), add="+")
        self.canvas.bind("<Shift-MouseWheel>", lambda e: self.canvas.xview_scroll(int(-1 * (e.delta / 120)), "units"), add="+")

        self.title_label = tk.Label(self.root_frame, text="Panel de configuración", anchor="w")
        self.title_label.pack(fill="x")
        self.info_label = tk.Label(
            self.root_frame,
            text="Desde aquí cambias el tema, el icono, la música, el brillo y la configuración del asistente virtual IA. Todo se aplica en tiempo real.",
            anchor="w",
            justify="left",
        )
        self.info_label.pack(fill="x", pady=(8, 18))

        self.icon_section = tk.Frame(self.root_frame, bd=1, relief="solid")
        self.icon_section.pack(fill="x", pady=(0, 16))
        self.icon_title = tk.Label(self.icon_section, text="Icono visual de inicio", anchor="w")
        self.icon_title.pack(fill="x", padx=16, pady=(14, 8))
        self.icon_grid = tk.Frame(self.icon_section, bd=0)
        self.icon_grid.pack(fill="x", padx=14, pady=(0, 14))
        self.icon_buttons: list[IconPreviewButton] = []
        self._build_icon_grid()

        self.theme_section = tk.Frame(self.root_frame, bd=1, relief="solid")
        self.theme_section.pack(fill="x", pady=(0, 16))
        self.theme_title = tk.Label(self.theme_section, text="Tema de interfaz", anchor="w")
        self.theme_title.pack(fill="x", padx=16, pady=(14, 8))
        self.theme_row = tk.Frame(self.theme_section, bd=0)
        self.theme_row.pack(fill="x", padx=14, pady=(0, 14))
        self._build_theme_row()

        self.mode_section = tk.Frame(self.root_frame, bd=1, relief="solid")
        self.mode_section.pack(fill="x", pady=(0, 16))
        self.mode_title = tk.Label(self.mode_section, text="Modo visual del launcher", anchor="w")
        self.mode_title.pack(fill="x", padx=16, pady=(14, 8))
        self.mode_info = tk.Label(
            self.mode_section,
            text="La interfaz principal queda fija en Clásico original. No hay modo retro visible en el HUB.",
            anchor="w",
            justify="left",
        )
        self.mode_info.pack(fill="x", padx=16, pady=(0, 8))
        self.mode_row = tk.Frame(self.mode_section, bd=0)
        self.mode_row.pack(fill="x", padx=14, pady=(0, 14))
        self._build_mode_row()

        self.music_section = tk.Frame(self.root_frame, bd=1, relief="solid")
        self.music_section.pack(fill="x")
        self.music_title = tk.Label(self.music_section, text="Música y volumen", anchor="w")
        self.music_title.pack(fill="x", padx=16, pady=(14, 8))
        self.music_check = tk.Checkbutton(self.music_section, text="Activar música ambiente", variable=self.music_var, command=self._apply_live)
        self.music_check.pack(anchor="w", padx=16)
        self.volume_scale = tk.Scale(
            self.music_section,
            from_=0,
            to=100,
            orient="horizontal",
            variable=self.volume_var,
            command=lambda _v: self._apply_live(),
            length=320,
            showvalue=True,
            label="Volumen",
        )
        self.volume_scale.pack(anchor="w", padx=16, pady=(10, 8))
        self.brightness_scale = tk.Scale(
            self.music_section,
            from_=35,
            to=100,
            orient="horizontal",
            variable=self.brightness_var,
            command=lambda _v: self._apply_live(),
            length=320,
            showvalue=True,
            label="Brillo",
        )
        self.brightness_scale.pack(anchor="w", padx=16, pady=(0, 14))

        self.ai_section = tk.Frame(self.root_frame, bd=1, relief="solid")
        self.ai_section.pack(fill="x", pady=(16, 0))
        self.ai_title = tk.Label(self.ai_section, text="Asistente virtual IA", anchor="w")
        self.ai_title.pack(fill="x", padx=16, pady=(14, 8))
        self.ai_info = tk.Label(
            self.ai_section,
            text="Configura el nombre visible del asistente, el modelo de escritura, el modo de respuesta experto, Gemma Thinking/No thinking, la API de Google AI y el modelo de audio usado por el botón de micrófono del Módulo 3.",
            anchor="w",
            justify="left",
            wraplength=780,
        )
        self.ai_info.pack(fill="x", padx=16, pady=(0, 10))

        self.ai_grid = tk.Frame(self.ai_section, bd=0)
        self.ai_grid.pack(fill="x", padx=16, pady=(0, 14))
        self.ai_grid.grid_columnconfigure(1, weight=1)

        self.assistant_name_label = tk.Label(self.ai_grid, text="Nombre del asistente:", anchor="w")
        self.assistant_name_label.grid(row=0, column=0, sticky="w", padx=(0, 12), pady=6)
        self.assistant_name_entry = tk.Entry(self.ai_grid, textvariable=self.assistant_name_var, width=42)
        self.assistant_name_entry.grid(row=0, column=1, sticky="ew", pady=6)
        self.assistant_name_entry.bind("<FocusOut>", lambda _e: self._apply_live())
        self.assistant_name_entry.bind("<Return>", lambda _e: self._apply_live())

        self.assistant_text_model_label = tk.Label(self.ai_grid, text="Modelo de escritura:", anchor="w")
        self.assistant_text_model_label.grid(row=1, column=0, sticky="w", padx=(0, 12), pady=6)
        self.assistant_text_model_combo = ttk.Combobox(
            self.ai_grid,
            values=ASSISTANT_TEXT_MODELS,
            textvariable=self.assistant_text_model_var,
            state="readonly",
            width=42,
            style="Config.TCombobox",
        )
        self.assistant_text_model_combo.grid(row=1, column=1, sticky="ew", pady=6)
        self.assistant_text_model_combo.bind("<<ComboboxSelected>>", lambda _e: self._apply_live())

        self.assistant_response_mode_label = tk.Label(self.ai_grid, text="Modo experto:", anchor="w")
        self.assistant_response_mode_label.grid(row=2, column=0, sticky="w", padx=(0, 12), pady=6)
        self.assistant_response_mode_combo = ttk.Combobox(
            self.ai_grid,
            values=ASSISTANT_RESPONSE_MODES,
            textvariable=self.assistant_response_mode_var,
            state="readonly",
            width=42,
            style="Config.TCombobox",
        )
        self.assistant_response_mode_combo.grid(row=2, column=1, sticky="ew", pady=6)
        self.assistant_response_mode_combo.bind("<<ComboboxSelected>>", lambda _e: self._apply_live())

        self.assistant_gemma_thinking_mode_label = tk.Label(self.ai_grid, text="Gemma 4:", anchor="w")
        self.assistant_gemma_thinking_mode_label.grid(row=3, column=0, sticky="w", padx=(0, 12), pady=6)
        self.assistant_gemma_thinking_mode_combo = ttk.Combobox(
            self.ai_grid,
            values=ASSISTANT_GEMMA_THINKING_MODES,
            textvariable=self.assistant_gemma_thinking_mode_var,
            state="readonly",
            width=42,
            style="Config.TCombobox",
        )
        self.assistant_gemma_thinking_mode_combo.grid(row=3, column=1, sticky="ew", pady=6)
        self.assistant_gemma_thinking_mode_combo.bind("<<ComboboxSelected>>", lambda _e: self._apply_live())

        self.gemini_api_key_label = tk.Label(self.ai_grid, text="API key Google AI:", anchor="w")
        self.gemini_api_key_label.grid(row=4, column=0, sticky="w", padx=(0, 12), pady=6)
        self.gemini_api_key_entry = tk.Entry(self.ai_grid, textvariable=self.gemini_api_key_var, show="•", width=42)
        self.gemini_api_key_entry.grid(row=4, column=1, sticky="ew", pady=6)
        self.gemini_api_key_entry.bind("<FocusOut>", lambda _e: self._apply_live())
        self.gemini_api_key_entry.bind("<Return>", lambda _e: self._apply_live())

        self.assistant_audio_model_label = tk.Label(self.ai_grid, text="Modelo de audio:", anchor="w")
        self.assistant_audio_model_label.grid(row=5, column=0, sticky="w", padx=(0, 12), pady=6)
        self.assistant_audio_model_combo = ttk.Combobox(
            self.ai_grid,
            values=ASSISTANT_AUDIO_MODELS,
            textvariable=self.assistant_audio_model_var,
            state="readonly",
            width=42,
            style="Config.TCombobox",
        )
        self.assistant_audio_model_combo.grid(row=5, column=1, sticky="ew", pady=6)
        self.assistant_audio_model_combo.bind("<<ComboboxSelected>>", lambda _e: self._apply_live())

        self.close_button = AnimatedActionButton(
            self.root_frame,
            text="Cerrar",
            command=self.close,
            palette=get_palette(hub.theme_name.get()),
            filled=False,
        )
        self.close_button.pack(anchor="e", pady=(18, 0))

        self.window.bind("<Escape>", lambda _e: self.close())
        self.apply_palette(get_palette(hub.theme_name.get()))

    def _build_icon_grid(self) -> None:
        for col in range(3):
            self.icon_grid.grid_columnconfigure(col, weight=1)
        for idx, (icon_name, _filename) in enumerate(ICON_CANDIDATES.items()):
            image = self.hub.icon_images_small.get(icon_name)
            item = IconPreviewButton(
                self.icon_grid,
                icon_name=icon_name,
                image=image,
                callback=self._select_icon,
                palette=get_palette(self.hub.theme_name.get()),
            )
            row, col = divmod(idx, 3)
            item.grid(row=row, column=col, sticky="nsew", padx=8, pady=8)
            self.icon_buttons.append(item)

    def _build_theme_row(self) -> None:
        self.theme_combo = ttk.Combobox(
            self.theme_row,
            values=SUPPORTED_THEMES,
            textvariable=self.theme_var,
            state="readonly",
            width=24,
            style="Config.TCombobox",
        )
        self.theme_combo.pack(side="left")
        self.theme_combo.bind("<<ComboboxSelected>>", lambda _e: self._apply_live())

    def _build_mode_row(self) -> None:
        self.mode_combo = ttk.Combobox(
            self.mode_row,
            values=SUPPORTED_UI_MODES,
            textvariable=self.ui_mode_var,
            state="disabled",
            width=34,
            style="Config.TCombobox",
        )
        self.mode_combo.pack(side="left")
        self.mode_combo.bind("<<ComboboxSelected>>", lambda _e: self._apply_live())

    def _select_icon(self, icon_name: str) -> None:
        self.icon_var.set(icon_name)
        self._apply_live()

    def _apply_live(self) -> None:
        self.hub.icon_name.set(self.icon_var.get())
        self.hub.music_enabled.set(bool(self.music_var.get()))
        self.hub.music_volume.set(int(self.volume_var.get()))
        self.hub.brightness_var.set(int(self.brightness_var.get()))
        self.hub.assistant_name.set(self.assistant_name_var.get().strip() or DEFAULT_ASSISTANT_NAME)
        self.assistant_name_var.set(self.hub.assistant_name.get())
        self.hub.assistant_text_model.set(resolve_assistant_text_model(self.assistant_text_model_var.get()))
        self.assistant_text_model_var.set(self.hub.assistant_text_model.get())
        self.hub.assistant_response_mode.set(resolve_assistant_response_mode(self.assistant_response_mode_var.get()))
        self.assistant_response_mode_var.set(self.hub.assistant_response_mode.get())
        self.hub.assistant_gemma_thinking_mode.set(resolve_assistant_gemma_thinking_mode(self.assistant_gemma_thinking_mode_var.get()))
        self.assistant_gemma_thinking_mode_var.set(self.hub.assistant_gemma_thinking_mode.get())
        self.hub.gemini_api_key.set(self.gemini_api_key_var.get().strip())
        self.hub.assistant_audio_model.set(resolve_assistant_audio_model(self.assistant_audio_model_var.get()))
        self.assistant_audio_model_var.set(self.hub.assistant_audio_model.get())
        self.hub.theme_name.set(resolve_theme_name(self.theme_var.get()))
        self.hub.ui_mode.set(CLASSIC_UI_MODE)
        self.ui_mode_var.set(CLASSIC_UI_MODE)
        self.hub.save_current_prefs()
        self.hub.apply_theme(live_status=False)
        self.apply_palette(get_palette(self.hub.theme_name.get()))

    def apply_palette(self, palette: Palette) -> None:
        self.window.configure(bg=palette.bg)
        self.canvas.configure(bg=palette.bg)
        self.root_frame.configure(bg=palette.bg)
        self.title_label.configure(bg=palette.bg, fg=palette.text, font=("Segoe UI Semibold", 23))
        self.info_label.configure(bg=palette.bg, fg=palette.text_soft, font=("Segoe UI", 10))
        for section, title in (
            (self.icon_section, self.icon_title),
            (self.theme_section, self.theme_title),
            (self.mode_section, self.mode_title),
            (self.music_section, self.music_title),
            (self.ai_section, self.ai_title),
        ):
            section.configure(bg=palette.panel, highlightbackground=palette.border, highlightcolor=palette.border)
            title.configure(bg=palette.panel, fg=palette.accent, font=("Segoe UI Semibold", 12))
        self.icon_grid.configure(bg=palette.panel)
        self.theme_row.configure(bg=palette.panel)
        self.mode_row.configure(bg=palette.panel)
        self.mode_info.configure(bg=palette.panel, fg=palette.text_soft, font=("Segoe UI", 10))
        self.ai_info.configure(bg=palette.panel, fg=palette.text_soft, font=("Segoe UI", 10))
        self.ai_grid.configure(bg=palette.panel)
        for label in (
            self.assistant_name_label,
            self.assistant_text_model_label,
            self.assistant_response_mode_label,
            self.assistant_gemma_thinking_mode_label,
            self.gemini_api_key_label,
            self.assistant_audio_model_label,
        ):
            label.configure(bg=palette.panel, fg=palette.text, font=("Segoe UI", 10))
        for entry in (self.assistant_name_entry, self.gemini_api_key_entry):
            entry.configure(
                bg=palette.panel_alt if palette.name != "Blanco Moderno" else "#FFFFFF",
                fg=palette.text,
                insertbackground=palette.text,
                relief="solid",
                bd=1,
                highlightthickness=1,
                highlightbackground=palette.border,
                highlightcolor=palette.accent,
                font=("Segoe UI", 10),
            )
        self.music_check.configure(
            bg=palette.panel,
            fg=palette.text,
            activebackground=palette.panel,
            activeforeground=palette.text,
            selectcolor=palette.panel_alt,
            highlightthickness=0,
            font=("Segoe UI", 10),
        )
        for scale in (self.volume_scale, self.brightness_scale):
            scale.configure(
                bg=palette.panel,
                fg=palette.text,
                troughcolor=palette.panel_alt,
                activebackground=palette.accent,
                highlightthickness=0,
                font=("Segoe UI", 9),
            )
        self.style.configure(
            "Config.TCombobox",
            fieldbackground=palette.panel_alt if palette.name != "Blanco Moderno" else "#FFFFFF",
            background=palette.panel_alt if palette.name != "Blanco Moderno" else "#FFFFFF",
            foreground=palette.text,
            arrowcolor=palette.accent,
            bordercolor=palette.border,
            lightcolor=palette.border,
            darkcolor=palette.border,
            padding=6,
        )
        self.style.map(
            "Config.TCombobox",
            fieldbackground=[("readonly", palette.panel_alt if palette.name != "Blanco Moderno" else "#FFFFFF")],
            foreground=[("readonly", palette.text)],
            selectbackground=[("readonly", palette.accent_soft)],
            selectforeground=[("readonly", "#FFFFFF")],
        )
        for item in self.icon_buttons:
            item.apply_palette(palette, selected=(item.icon_name == self.icon_var.get()))
        self.close_button.apply_palette(palette)

    def focus(self) -> None:
        self.window.deiconify()
        self.window.lift()
        self.window.focus_force()

    def close(self) -> None:
        self._apply_live()
        self.window.destroy()
        self.hub.config_dialog = None


class LematZiumSuiteLauncher:
    def __init__(self) -> None:
        self.base_dir = _launcher_base_dir()
        self.suite_root = _suite_root_from_base(self.base_dir)
        prefs = load_prefs(self.base_dir)

        if os.name == "nt":
            try:
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("LEMATZIUM.Launcher")
            except Exception:
                pass

        self.root = tk.Tk()
        self.root.title(APP_TITLE)
        self.root.geometry("1240x860")
        self.root.minsize(920, 620)
        self.root.protocol("WM_DELETE_WINDOW", self._on_exit)

        self.theme_name = tk.StringVar(master=self.root, value=resolve_theme_name(prefs.get("theme")))
        self.ui_mode = tk.StringVar(master=self.root, value=CLASSIC_UI_MODE)
        self.icon_name = tk.StringVar(master=self.root, value=prefs.get("icon", "Azul-cian"))
        self.music_enabled = tk.BooleanVar(master=self.root, value=bool(prefs.get("music_enabled", True)))
        self.music_volume = tk.IntVar(master=self.root, value=int(prefs.get("music_volume", 35)))
        self.brightness_var = tk.IntVar(master=self.root, value=int(prefs.get("brightness", 85)))
        self.assistant_name = tk.StringVar(master=self.root, value=str(prefs.get("assistant_name", DEFAULT_ASSISTANT_NAME)).strip() or DEFAULT_ASSISTANT_NAME)
        self.assistant_text_model = tk.StringVar(master=self.root, value=resolve_assistant_text_model(prefs.get("assistant_text_model")))
        self.assistant_response_mode = tk.StringVar(master=self.root, value=resolve_assistant_response_mode(prefs.get("assistant_response_mode")))
        self.assistant_gemma_thinking_mode = tk.StringVar(master=self.root, value=resolve_assistant_gemma_thinking_mode(prefs.get("assistant_gemma_thinking_mode")))
        self.gemini_api_key = tk.StringVar(master=self.root, value=str(prefs.get("gemini_api_key", "")).strip())
        self.assistant_audio_model = tk.StringVar(master=self.root, value=resolve_assistant_audio_model(prefs.get("assistant_audio_model")))
        self.assistant_audio_voice = tk.StringVar(master=self.root, value=str(prefs.get("assistant_audio_voice", DEFAULT_ASSISTANT_AUDIO_VOICE)).strip() or DEFAULT_ASSISTANT_AUDIO_VOICE)
        self.assistant_audio_voice_filter = tk.StringVar(master=self.root, value=str(prefs.get("assistant_audio_voice_filter", DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER)).strip() or DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER)
        self.status_var = tk.StringVar(master=self.root, value="Selecciona un módulo para abrirlo en una ventana independiente.")
        self.module_processes: dict[str, object] = {}

        self.style = ttk.Style(self.root)
        self.modules = detect_modules(self.suite_root)
        self.cards: list[ModuleCard] = []
        self.config_dialog: ConfigDialog | None = None
        self.icon_images_small: dict[str, tk.PhotoImage] = {}
        self.icon_images_large: dict[str, tk.PhotoImage] = {}
        self.hero_button_window: int | None = None
        self.hero_config_button: AnimatedActionButton | None = None
        self._classic_wheel_hitbox: tuple[float, float, float] | None = None
        self._egg_click_count = 0
        self._egg_last_click_time = 0.0
        self._minigame_window: tk.Toplevel | None = None
        self._minigame_app: object | None = None

        self.anim_phase = 0.0
        self.grid_offset = 0.0
        self.progress = 0
        self.status_index = 0
        self.hero_glow = 0.0

        self.retro_seed = random.SystemRandom().randrange(1, 2_147_483_647)
        self.retro_player = RetroPlayer()
        self.retro_projectiles: list[RetroProjectile] = []
        self.retro_obstacles: list[RetroRect] = []
        self.retro_pits: list[RetroPit] = []
        self.retro_enemies: list[RetroEnemy] = []
        self.retro_world_size: tuple[int, int, int, int] | None = None
        self.retro_world_width = 0
        self.retro_camera_x = 0.0
        self.retro_buttons: list[AnimatedActionButton] = []
        self.pressed_keys: set[str] = set()
        self._last_jump_pressed = False
        self._last_dash_pressed = False
        self._last_sword_pressed = False
        self._last_boomerang_pressed = False
        self._last_triple_pressed = False
        self._x_charge_active = False
        self._x_charge_started = 0.0
        self._last_frame_time = time.perf_counter()

        # Arranque optimizado: mostrar la pantalla principal antes de iniciar
        # tareas secundarias (música, carga total de iconos y animación continua).
        self.music_controller = MusicController(None)
        self._load_icon_assets(load_all=False)
        self._build_ui()
        self.apply_theme(initial=True)
        self.root.after_idle(self._start_deferred_launcher_services)

    def _build_root_scrollable(self) -> None:
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.root_canvas = tk.Canvas(self.root, highlightthickness=0, bd=0)
        self.root_vscroll = ttk.Scrollbar(self.root, orient="vertical", command=self.root_canvas.yview)
        self.root_hscroll = ttk.Scrollbar(self.root, orient="horizontal", command=self.root_canvas.xview)
        self.root_canvas.configure(yscrollcommand=self.root_vscroll.set, xscrollcommand=self.root_hscroll.set)
        self.root_canvas.grid(row=0, column=0, sticky="nsew")
        self.root_vscroll.grid(row=0, column=1, sticky="ns")
        self.root_hscroll.grid(row=1, column=0, sticky="ew")
        self.scroll_host = tk.Frame(self.root_canvas, bd=0)
        self.root_canvas_window = self.root_canvas.create_window((0, 0), window=self.scroll_host, anchor="nw")
        self.scroll_host.bind("<Configure>", self._on_root_host_configure)
        self.root_canvas.bind("<Configure>", self._on_root_canvas_configure)
        self.root_canvas.bind_all("<MouseWheel>", self._on_root_mousewheel, add="+")
        self.root_canvas.bind_all("<Shift-MouseWheel>", self._on_root_shift_mousewheel, add="+")

    def _on_root_host_configure(self, _event=None) -> None:
        self.root_canvas.configure(scrollregion=self.root_canvas.bbox("all"))

    def _on_root_canvas_configure(self, event=None) -> None:
        if event is None:
            return
        self.root_canvas.itemconfigure(
            self.root_canvas_window,
            width=max(event.width, self.scroll_host.winfo_reqwidth()),
            height=max(event.height, self.scroll_host.winfo_reqheight()),
        )

    def _on_root_mousewheel(self, event) -> None:
        self.root_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_root_shift_mousewheel(self, event) -> None:
        self.root_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")

    def _apply_brightness(self) -> None:
        level = max(35, min(100, int(self.brightness_var.get())))
        try:
            self.root.attributes("-alpha", 0.55 + (level / 100.0) * 0.45)
        except Exception:
            pass
        if self.config_dialog is not None:
            try:
                self.config_dialog.window.attributes("-alpha", 0.55 + (level / 100.0) * 0.45)
            except Exception:
                pass

    def _find_music_file(self) -> Path | None:
        candidates = [
            self.suite_root / "Había una vez un laboratorio.mpeg",
            self.suite_root / "Habia una vez un laboratorio.mpeg",
            self.suite_root / "assets" / "music" / "Había una vez un laboratorio.mpeg",
            self.suite_root / "assets" / "music" / "Habia una vez un laboratorio.mpeg",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate.resolve()

        matches = sorted((self.suite_root / "assets" / "music").glob("*.mpeg")) if (self.suite_root / "assets" / "music").exists() else []
        if matches:
            return matches[0].resolve()

        matches = sorted(self.suite_root.glob("*.mpeg"))
        return matches[0].resolve() if matches else None

    def _load_icon_assets(self, *, load_all: bool = True) -> None:
        """Carga iconos del launcher de forma selectiva.

        En el arranque solo se necesita el icono activo para la ventana. Los
        demás se cargan de forma diferida o al abrir Configuración, evitando
        bloquear la aparición de la pantalla principal.
        """
        selected = self.icon_name.get() if hasattr(self, "icon_name") else "Azul-cian"
        names = ICON_CANDIDATES.keys() if load_all else (selected,)
        for icon_name in names:
            if icon_name in self.icon_images_small:
                continue
            filename = ICON_CANDIDATES.get(icon_name)
            if not filename:
                continue
            path = self.suite_root / filename
            if not path.exists():
                continue
            try:
                self.icon_images_small[icon_name] = tk.PhotoImage(file=str(path)).subsample(4, 4)
            except Exception:
                continue

    def _start_deferred_launcher_services(self) -> None:
        """Inicializa tareas no críticas después de mostrar la UI principal."""
        try:
            self.music_controller = MusicController(self._find_music_file())
            self._update_music_state()
        except Exception:
            self.music_controller = MusicController(None)
        try:
            # Carga suave para que Configuración tenga vistas previas sin afectar
            # el primer pintado del HUB.
            self.root.after(120, lambda: self._load_icon_assets(load_all=True))
        except Exception:
            pass
        try:
            self.root.after(120, self._schedule_animation)
        except Exception:
            self._schedule_animation()

    def save_current_prefs(self) -> None:
        save_prefs(
            self.base_dir,
            {
                "theme": self.theme_name.get(),
                "ui_mode": CLASSIC_UI_MODE,
                "icon": self.icon_name.get(),
                "music_enabled": bool(self.music_enabled.get()),
                "music_volume": int(self.music_volume.get()),
                "brightness": int(self.brightness_var.get()),
                "assistant_name": self.assistant_name.get().strip() or DEFAULT_ASSISTANT_NAME,
                "assistant_text_model": resolve_assistant_text_model(self.assistant_text_model.get()),
                "assistant_response_mode": resolve_assistant_response_mode(self.assistant_response_mode.get()),
                "assistant_gemma_thinking_mode": resolve_assistant_gemma_thinking_mode(self.assistant_gemma_thinking_mode.get()),
                "gemini_api_key": self.gemini_api_key.get().strip(),
                "assistant_audio_model": resolve_assistant_audio_model(self.assistant_audio_model.get()),
                "assistant_audio_voice": self.assistant_audio_voice.get().strip() or DEFAULT_ASSISTANT_AUDIO_VOICE,
                "assistant_audio_voice_filter": self.assistant_audio_voice_filter.get().strip() or DEFAULT_ASSISTANT_AUDIO_VOICE_FILTER,
            },
        )
        if not _is_frozen_app():
            try:
                from dev_shortcut_sync import sync_dev_shortcut_for_suite

                sync_dev_shortcut_for_suite(self.suite_root, icon_name=self.icon_name.get())
            except Exception:
                pass

    def _visible_module_names(self) -> list[str]:
        visible: list[str] = []
        for module_name, resolved in self.modules.items():
            if resolved.definition.key in VISIBLE_MODULE_KEYS:
                visible.append(module_name)
        return visible

    def _build_ui(self) -> None:
        self._build_root_scrollable()
        self.scroll_host.grid_rowconfigure(0, weight=1)
        self.scroll_host.grid_columnconfigure(0, weight=1)

        self.container = tk.Frame(self.scroll_host, bd=0)
        self.container.grid(row=0, column=0, sticky="nsew")
        self.container.grid_rowconfigure(2, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        self.header_frame = tk.Frame(self.container, bd=0)
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=24, pady=(24, 12))
        self.header_frame.grid_columnconfigure(1, weight=1)

        self.title_label = tk.Label(self.header_frame, text="LEMATZIUM", anchor="w")
        self.title_label.grid(row=0, column=0, sticky="w")
        self.subtitle_label = tk.Label(
            self.header_frame,
            text="Centro de control LEMATZIUM: acceso a tracción en metales, tracción en plásticos, incertidumbre y asistente virtual IA.",
            anchor="w",
            justify="left",
        )
        self.subtitle_label.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))

        self.topbar_frame = tk.Frame(self.container, bd=0)
        self.topbar_frame.grid(row=1, column=0, sticky="ew", padx=24, pady=(0, 14))
        self.topbar_frame.grid_columnconfigure(3, weight=1)

        self.theme_label = tk.Label(self.topbar_frame, text="Tema visual:")
        self.theme_label.grid(row=0, column=0, sticky="w")

        self._build_ttk_style()
        self.theme_combo = ttk.Combobox(
            self.topbar_frame,
            values=SUPPORTED_THEMES,
            textvariable=self.theme_name,
            state="readonly",
            width=20,
            style="Hub.TCombobox",
        )
        self.theme_combo.grid(row=0, column=1, sticky="w", padx=(10, 8))
        self.button_apply = AnimatedActionButton(
            self.topbar_frame,
            text="Aplicar",
            command=self._on_apply_theme,
            palette=get_palette(self.theme_name.get()),
            filled=True,
        )
        self.button_apply.grid(row=0, column=2, sticky="w")

        self.status_label = tk.Label(self.topbar_frame, textvariable=self.status_var, anchor="e", justify="right")
        self.status_label.grid(row=0, column=3, sticky="e", padx=(18, 0))

        self.hero_canvas = tk.Canvas(self.container, highlightthickness=0, bd=0, height=250)
        self.hero_canvas.grid(row=2, column=0, sticky="ew", padx=24, pady=(0, 18))
        self.hero_canvas.bind("<Configure>", lambda _e: self._draw_hero())
        self.hero_canvas.bind("<ButtonPress-1>", self._on_retro_canvas_click)
        self.hero_canvas.bind("<B1-Motion>", self._on_retro_canvas_drag)
        self.hero_canvas.bind("<ButtonRelease-1>", self._on_retro_canvas_release)
        self.root.bind("<KeyPress>", self._on_retro_key_press, add="+")
        self.root.bind("<KeyRelease>", self._on_retro_key_release, add="+")
        self.hero_config_button = AnimatedActionButton(
            self.hero_canvas,
            text="Configuración",
            command=self._open_config,
            palette=get_palette(self.theme_name.get()),
            filled=True,
            compact=True,
        )
        self.retro_module1_button = AnimatedActionButton(
            self.hero_canvas,
            text="Módulo 1 - Tracción Metales 1.3.0",
            command=self._launch_tensile_metals_from_retro,
            palette=get_palette(self.theme_name.get()),
            filled=True,
            compact=True,
        )
        self.retro_module2_button = AnimatedActionButton(
            self.hero_canvas,
            text="Módulo 2 - Tracción plásticos 1.0.0",
            command=self._launch_plastics_from_retro,
            palette=get_palette(self.theme_name.get()),
            filled=False,
            compact=True,
        )
        self.retro_config_button = AnimatedActionButton(
            self.hero_canvas,
            text="Configuración",
            command=self._open_config,
            palette=get_palette(self.theme_name.get()),
            filled=False,
            compact=True,
        )
        self.retro_buttons = [self.retro_module1_button, self.retro_module2_button, self.retro_config_button]
        for retro_button in self.retro_buttons:
            retro_button.configure(font=("Courier New", 8, "bold"), width=30)

        self.cards_frame = tk.Frame(self.container, bd=0)
        self.cards_frame.grid(row=3, column=0, sticky="nsew", padx=24)
        visible_modules = self._visible_module_names()
        card_columns = 2
        for col in range(card_columns):
            self.cards_frame.grid_columnconfigure(col, weight=1, uniform="cards")

        for index, module_name in enumerate(visible_modules):
            row, col = divmod(index, card_columns)
            module_card = ModuleCard(
                self.cards_frame,
                module_name=module_name,
                module_resolved=self.modules[module_name],
                palette=get_palette(self.theme_name.get()),
                open_callback=self._launch_module,
            )
            module_card.frame.grid(
                row=row,
                column=col,
                sticky="nsew",
                padx=(0 if col == 0 else 10, 0 if col == card_columns - 1 else 10),
                pady=(0 if row == 0 else 16, 12),
            )
            self.cards.append(module_card)

        self.footer_frame = tk.Frame(self.container, bd=0)
        self.footer_frame.grid(row=4, column=0, sticky="ew", padx=24, pady=(16, 22))
        self.footer_frame.grid_columnconfigure(0, weight=1)
        self.footer_hint = tk.Label(
            self.footer_frame,
            text="Vista operativa simplificada: acceso visible a Tracción Metales, Tracción plásticos e INCERTIDUMBRE.",
            anchor="w",
            justify="left",
        )
        self.footer_hint.grid(row=0, column=0, sticky="w")
        self.button_exit = AnimatedActionButton(
            self.footer_frame,
            text="Salir",
            command=self._on_exit,
            palette=get_palette(self.theme_name.get()),
            filled=False,
        )
        self.button_exit.grid(row=0, column=1, sticky="e")

    def _build_ttk_style(self) -> None:
        try:
            self.style.theme_use("clam")
        except Exception:
            pass

    def _on_apply_theme(self) -> None:
        self.save_current_prefs()
        self.apply_theme()
        self.ui_mode.set(CLASSIC_UI_MODE)
        self.status_var.set(f"Tema aplicado al HUB: {self.theme_name.get()} | Interfaz clásica fija.")

    def apply_theme(self, *, initial: bool = False, live_status: bool = True) -> None:
        self.ui_mode.set(CLASSIC_UI_MODE)
        palette = get_palette(self.theme_name.get())
        light = _is_light_palette(palette)
        self.root.configure(bg=palette.bg)
        self.container.configure(bg=palette.bg)
        self.header_frame.configure(bg=palette.bg)
        self.topbar_frame.configure(bg=palette.bg)
        self.cards_frame.configure(bg=palette.bg)
        self.footer_frame.configure(bg=palette.bg)
        self.hero_canvas.configure(bg=palette.hero, height=250)

        self.title_label.configure(bg=palette.bg, fg=palette.text, font=("Segoe UI Semibold", 31))
        self.subtitle_label.configure(bg=palette.bg, fg=palette.text_soft, font=("Segoe UI", 12))
        self.theme_label.configure(bg=palette.bg, fg=palette.text, font=("Segoe UI Semibold", 11))
        self.status_label.configure(bg=palette.bg, fg=palette.accent_soft, font=("Segoe UI Semibold", 10))
        self.footer_hint.configure(bg=palette.bg, fg=palette.text_soft, font=("Segoe UI", 10))

        combo_background = palette.panel if not light else "#FFFFFF"
        combo_foreground = palette.text
        arrow = palette.text if light else palette.accent
        self.style.configure(
            "Hub.TCombobox",
            fieldbackground=combo_background,
            background=combo_background,
            foreground=combo_foreground,
            arrowcolor=arrow,
            bordercolor=palette.border,
            lightcolor=palette.border,
            darkcolor=palette.border,
            insertcolor=combo_foreground,
            selectbackground=palette.accent_soft,
            selectforeground="#FFFFFF" if not light else "#F8FAFC",
            padding=6,
        )
        self.style.map(
            "Hub.TCombobox",
            fieldbackground=[("readonly", combo_background)],
            foreground=[("readonly", combo_foreground)],
            selectbackground=[("readonly", palette.accent_soft)],
            selectforeground=[("readonly", "#FFFFFF" if not light else "#F8FAFC")],
        )

        self.button_apply.apply_palette(palette)
        self.button_exit.apply_palette(palette)
        if self.hero_config_button is not None:
            self.hero_config_button.apply_palette(palette)
        for retro_button in getattr(self, "retro_buttons", []):
            retro_button.apply_palette(palette)
            retro_button.configure(font=("Courier New", 8, "bold"), width=30)
        self._apply_retro_button_tone(palette)
        for card in self.cards:
            card.apply_palette(palette)

        self._sync_mode_layout()
        self._apply_window_icon()
        if hasattr(self, "root_canvas"):
            self.root_canvas.configure(bg=palette.bg)
        self._draw_hero()
        self._apply_brightness()
        self._update_music_state()
        if self.config_dialog is not None:
            self.config_dialog.ui_mode_var.set(self.ui_mode.get())
            self.config_dialog.apply_palette(palette)
        if initial:
            self.status_var.set("Selecciona un módulo para abrirlo en una ventana independiente.")
        elif live_status:
            self.status_var.set(f"Tema activo: {self.theme_name.get()} | Música: {'Activada' if self.music_enabled.get() else 'Desactivada'}")

    def _sync_mode_layout(self) -> None:
        retro_mode = resolve_ui_mode(self.ui_mode.get()) == RETRO_UI_MODE
        if retro_mode:
            self.subtitle_label.grid_remove()
            self.status_label.grid_remove()
            self.cards_frame.grid_remove()
            self.footer_frame.grid_remove()
            self.hero_canvas.focus_set()
        else:
            self.subtitle_label.grid()
            self.status_label.grid()
            self.cards_frame.grid()
            self.footer_frame.grid()

    def _apply_retro_button_tone(self, palette: Palette) -> None:
        if not hasattr(self, "retro_buttons"):
            return
        retro_mode = resolve_ui_mode(self.ui_mode.get()) == RETRO_UI_MODE
        base, ink = self._retro_duotone(palette)
        for index, button in enumerate(self.retro_buttons):
            if not retro_mode:
                button.clear_duotone()
                continue
            if index == 0:
                button.set_duotone(ink, base, base, ink)
            else:
                button.set_duotone(base, ink, ink, base)
            button.configure(font=("Courier New", 8, "bold"), width=30)

    def _apply_window_icon(self) -> None:
        icon = self.icon_images_small.get(self.icon_name.get()) or next(iter(self.icon_images_small.values()), None)
        if icon is not None:
            self.root.iconphoto(True, icon)

    def _schedule_animation(self) -> None:
        now = time.perf_counter()
        dt = max(0.012, min(0.075, now - self._last_frame_time))
        self._last_frame_time = now

        self.anim_phase += 0.09
        self.grid_offset = (self.grid_offset + 1.4) % 36.0
        self.progress = (self.progress + 1) % 101
        self.hero_glow = (math.sin(self.anim_phase) + 1.0) / 2.0
        if self.progress % 24 == 0:
            self.status_index = (self.status_index + 1) % len(STATUS_FRAMES)
        if resolve_ui_mode(self.ui_mode.get()) == RETRO_UI_MODE:
            self._update_retro_game(dt)
        self._draw_hero()
        self.root.after(48, self._schedule_animation)

    def _draw_hero(self) -> None:
        palette = get_palette(self.theme_name.get())
        canvas = self.hero_canvas
        width = max(120, canvas.winfo_width())
        height = max(220, canvas.winfo_height())
        canvas.delete("all")
        if resolve_ui_mode(self.ui_mode.get()) == RETRO_UI_MODE:
            self._classic_wheel_hitbox = None
            self._draw_retro_hero(canvas, palette, width, height)
            return
        canvas.create_rectangle(0, 0, width, height, fill=palette.hero, outline=palette.border, width=1)

        grid_step = 34
        start_x = -int(self.grid_offset)
        for x in range(start_x, width + grid_step, grid_step):
            canvas.create_line(x, 0, x, height, fill=palette.grid)
        for y in range(0, height + grid_step, grid_step):
            canvas.create_line(0, y, width, y, fill=palette.grid)

        cx = width * 0.72
        cy = height * 0.50
        pulse = 6 * math.sin(self.anim_phase)
        radius_outer = 88 + pulse
        radius_inner = 58
        radius_mid = 124
        # Hitbox secreta del easter egg: solo la ruedita circular del hero clásico.
        self._classic_wheel_hitbox = (float(cx), float(cy), 138.0)

        outline2 = 2 if palette.name != "Blanco Moderno" else 1
        canvas.create_oval(cx - radius_mid, cy - radius_mid, cx + radius_mid, cy + radius_mid, outline=palette.border, width=outline2)
        canvas.create_oval(cx - radius_outer, cy - radius_outer, cx + radius_outer, cy + radius_outer, outline=palette.accent_soft, width=3)
        canvas.create_oval(cx - radius_inner, cy - radius_inner, cx + radius_inner, cy + radius_inner, outline=palette.accent, width=2)

        for index in range(28):
            angle = math.radians(index * (360 / 28) + self.anim_phase * 28)
            x1 = cx + math.cos(angle) * 98
            y1 = cy + math.sin(angle) * 98
            x2 = cx + math.cos(angle) * 132
            y2 = cy + math.sin(angle) * 132
            color = palette.accent if index % 2 == 0 else palette.accent_soft
            canvas.create_line(x1, y1, x2, y2, fill=color, width=2 if index % 3 == 0 else 1)

        sweep_angle = math.radians((self.anim_phase * 50) % 360)
        sx = cx + math.cos(sweep_angle) * 120
        sy = cy + math.sin(sweep_angle) * 120
        canvas.create_line(cx, cy, sx, sy, fill=palette.accent, width=3)
        canvas.create_oval(sx - 4, sy - 4, sx + 4, sy + 4, fill=palette.accent, outline="")

        button_x = 26
        button_y = 34
        if self.hero_config_button is not None:
            self.hero_button_window = canvas.create_window(button_x, button_y, anchor="nw", window=self.hero_config_button)

        bar_x = 26
        bar_y = height - 48
        bar_w = 320
        bar_h = 16
        canvas.create_rectangle(bar_x, bar_y, bar_x + bar_w, bar_y + bar_h, outline=palette.accent, width=2)
        fill_w = max(6, int((self.progress / 100) * (bar_w - 4)))
        canvas.create_rectangle(bar_x + 2, bar_y + 2, bar_x + 2 + fill_w, bar_y + bar_h - 2, fill=palette.accent, outline="")
        canvas.create_text(bar_x, bar_y - 10, anchor="w", text=f"Carga visual del sistema: {self.progress}%", fill=palette.text, font=("Segoe UI", 10))
        canvas.create_text(bar_x, 118, anchor="w", text=STATUS_FRAMES[self.status_index], fill=palette.accent_soft, font=("Segoe UI Semibold", 16))

        points = [
            (bar_x - 4, height - 114),
            (bar_x + 54, height - 100),
            (bar_x + 104, height - 102),
            (bar_x + 166, height - 74),
            (bar_x + 220, height - 90),
            (bar_x + 280, height - 70),
        ]
        for index in range(len(points) - 1):
            canvas.create_line(*points[index], *points[index + 1], fill=palette.accent, width=3)
        for px, py in points:
            canvas.create_oval(px - 4, py - 4, px + 4, py + 4, fill=palette.accent_soft, outline="")

        glow_alpha_width = 1 + int(self.hero_glow * 3)
        canvas.create_rectangle(0, height - 4, width, height, fill=palette.accent_soft, outline="", width=glow_alpha_width)

    def _retro_duotone(self, palette: Palette) -> tuple[str, str]:
        """Devuelve los dos únicos colores usados por la escena retro."""
        return palette.hero, palette.accent

    def _retro_ground_y(self, height: int) -> int:
        return max(154, height - 34)

    def _retro_world_span(self, viewport_width: int) -> int:
        # El viewport mantiene el mismo tamaño que el modo clásico; el mundo interno es el que crece.
        return max(5200, int(max(360, viewport_width) * 6.8))

    @staticmethod
    def _retro_intersects(x: float, y: float, w: float, h: float, rect: RetroRect | RetroEnemy) -> bool:
        return x < rect.x + rect.w and x + w > rect.x and y < rect.y + rect.h and y + h > rect.y

    def _retro_in_pit(self, x: float, w: float = 0.0) -> bool:
        center = x + w * 0.5
        return any(pit.x + 4 <= center <= pit.x + pit.w - 4 for pit in self.retro_pits)

    def _retro_generate_level(self, width: int, height: int) -> None:
        width = max(360, width)
        height = max(220, height)
        world_w = self._retro_world_span(width)
        ground = self._retro_ground_y(height)
        rng = random.Random(self.retro_seed + width * 31 + height * 17)

        self.retro_world_width = world_w
        self.retro_obstacles = []
        self.retro_pits = []
        self.retro_enemies = []

        # Pits: obligan a usar dash y doble salto, pero mantienen zonas de aterrizaje seguras.
        x = 520
        while x < world_w - 620:
            pit_w = rng.choice((76, 92, 108, 124, 142))
            self.retro_pits.append(RetroPit(float(x), float(pit_w)))
            # Plataforma auxiliar sobre algunos pits.
            if rng.random() < 0.72:
                self.retro_obstacles.append(
                    RetroRect(
                        float(x + rng.randint(-34, 34)),
                        float(ground - rng.choice((72, 92, 118))),
                        float(rng.randint(106, 172)),
                        14.0,
                        "bridge",
                    )
                )
            x += rng.randint(390, 620)

        # Plataformas, muros de trepa y bloques técnicos distribuidos por secciones.
        section = 280
        while section < world_w - 360:
            y_level = ground - rng.choice((54, 76, 98, 122, 146))
            self.retro_obstacles.append(
                RetroRect(
                    float(section + rng.randint(-42, 72)),
                    float(y_level),
                    float(rng.randint(112, 235)),
                    14.0,
                    "platform",
                )
            )
            if rng.random() < 0.54:
                wall_h = rng.choice((62, 86, 112, 138, 166))
                self.retro_obstacles.append(
                    RetroRect(
                        float(section + rng.randint(170, 320)),
                        float(ground - wall_h),
                        float(rng.choice((26, 30, 34))),
                        float(wall_h),
                        "wall",
                    )
                )
            if rng.random() < 0.40:
                # Escalones cortos que invitan a usar espada/disparos alrededor de rivales.
                base_x = section + rng.randint(70, 260)
                for step in range(rng.randint(2, 4)):
                    self.retro_obstacles.append(
                        RetroRect(
                            float(base_x + step * 58),
                            float(ground - 34 - step * 28),
                            58.0,
                            12.0,
                            "step",
                        )
                    )
            section += rng.randint(360, 520)

        # Plataformas finales cerca del robot mayor.
        self.retro_obstacles.extend(
            [
                RetroRect(float(world_w - 620), float(ground - 82), 210.0, 14.0, "platform"),
                RetroRect(float(world_w - 390), float(ground - 132), 190.0, 14.0, "platform"),
                RetroRect(float(world_w - 150), float(ground - 176), 34.0, 176.0, "wall"),
            ]
        )

        # Rivales menores y mayores. Sus posiciones también dependen de la semilla.
        enemy_id = 0
        x = 420
        while x < world_w - 520:
            if rng.random() < 0.82:
                kind = "minor"
                ew, eh, hp = 24.0, 20.0, 1
                if rng.random() < 0.22:
                    kind = "major"
                    ew, eh, hp = 52.0, 58.0, 4
                patrol = rng.randint(80, 170)
                ex = float(x + rng.randint(-30, 130))
                ey = float(ground - eh)
                # Algunos drones menores se ubican sobre plataformas visibles.
                nearby_platforms = [r for r in self.retro_obstacles if abs(r.x - ex) < 220 and r.h <= 16]
                if nearby_platforms and rng.random() < 0.45:
                    platform = rng.choice(nearby_platforms)
                    ex = min(platform.x + platform.w - ew - 6, max(platform.x + 6, ex))
                    ey = platform.y - eh
                speed = rng.choice((-1.0, 1.0)) * (44.0 if kind == "minor" else 20.0)
                self.retro_enemies.append(
                    RetroEnemy(
                        x=ex,
                        y=ey,
                        w=ew,
                        h=eh,
                        vx=speed,
                        kind=kind,
                        hp=hp,
                        patrol_left=max(40.0, ex - patrol),
                        patrol_right=min(float(world_w - 80), ex + patrol),
                        phase=float(enemy_id),
                    )
                )
                enemy_id += 1
            x += rng.randint(330, 510)

        self.retro_enemies.append(
            RetroEnemy(
                x=float(world_w - 480),
                y=float(ground - 78),
                w=68.0,
                h=78.0,
                vx=-18.0,
                kind="major",
                hp=7,
                patrol_left=float(world_w - 590),
                patrol_right=float(world_w - 310),
                phase=4.0,
            )
        )

    def _reset_retro_world(self, width: int, height: int, *, keep_player_ratio: bool = True) -> None:
        width = max(360, width)
        height = max(220, height)
        previous = self.retro_world_size
        old_world_w = previous[2] if previous else 0
        old_ground = self._retro_ground_y(previous[1]) if previous else self._retro_ground_y(height)
        self._retro_generate_level(width, height)
        ground = self._retro_ground_y(height)
        player = self.retro_player

        if previous is None or not keep_player_ratio:
            player.x = 94.0
            player.y = float(ground - player.h)
            self.retro_camera_x = 0.0
        else:
            ratio = self.retro_world_width / max(1, old_world_w)
            player.x = max(8.0, min(self.retro_world_width - player.w - 8.0, player.x * ratio))
            if abs((player.y + player.h) - old_ground) < 5:
                player.y = float(ground - player.h)
            else:
                player.y = max(8.0, min(ground - player.h, player.y))
            self.retro_camera_x = max(0.0, min(float(max(0, self.retro_world_width - width)), self.retro_camera_x * ratio))

        player.vx = 0.0
        player.vy = 0.0
        player.on_ground = True
        player.jumps_used = 0
        player.wall_side = 0
        player.dash_timer = 0.0
        player.dash_cooldown = 0.0
        player.sword_timer = 0.0
        player.sword_cooldown = 0.0
        player.shoot_cooldown = 0.0
        player.hurt_timer = 0.0
        self.retro_projectiles.clear()
        self.retro_world_size = (width, height, self.retro_world_width, self.retro_seed)

    def _ensure_retro_world(self, width: int, height: int) -> None:
        width = max(360, width)
        height = max(220, height)
        size_key = (width, height, self._retro_world_span(width), self.retro_seed)
        if self.retro_world_size != size_key:
            self._reset_retro_world(width, height)

    def _retro_respawn(self, width: int, height: int) -> None:
        ground = self._retro_ground_y(height)
        player = self.retro_player
        safe_x = max(94.0, player.x - 260.0)
        # Busca una zona sin pit antes de reposicionar.
        while safe_x > 94.0 and self._retro_in_pit(safe_x, player.w):
            safe_x -= 70.0
        player.x = max(94.0, min(self.retro_world_width - player.w - 8.0, safe_x))
        player.y = float(ground - player.h)
        player.vx = 0.0
        player.vy = 0.0
        player.on_ground = True
        player.jumps_used = 0
        player.hurt_timer = 0.45
        self.retro_projectiles.clear()

    def _retro_touching_wall(self, player: RetroPlayer, obstacles: list[RetroRect]) -> int:
        eps = 4.0
        if player.x <= 8.0 + eps:
            return -1
        if player.x + player.w >= self.retro_world_width - 8.0 - eps:
            return 1
        for rect in obstacles:
            vertical_overlap = player.y + player.h > rect.y + 3 and player.y < rect.y + rect.h - 3
            if not vertical_overlap:
                continue
            if abs((player.x + player.w) - rect.x) <= eps:
                return 1
            if abs(player.x - (rect.x + rect.w)) <= eps:
                return -1
        return 0

    def _retro_update_camera(self, viewport_width: int) -> None:
        player = self.retro_player
        limit = max(0.0, float(self.retro_world_width - viewport_width))
        desired = player.x + player.w * 0.5 - viewport_width * 0.40
        desired = max(0.0, min(limit, desired))
        self.retro_camera_x += (desired - self.retro_camera_x) * 0.22
        if abs(self.retro_camera_x - desired) < 0.5:
            self.retro_camera_x = desired

    def _retro_key_pressed(self, *names: str) -> bool:
        return any(name in self.pressed_keys for name in names)

    def _on_retro_key_press(self, event) -> None:
        key = getattr(event, "keysym", "")
        if not key:
            return
        self.pressed_keys.add(key)
        if resolve_ui_mode(self.ui_mode.get()) != RETRO_UI_MODE:
            return

        if key in {"Up", "w", "W"}:
            if not self._last_jump_pressed:
                self._retro_jump()
            self._last_jump_pressed = True
        elif key == "space":
            if not self._last_dash_pressed:
                self._retro_dash()
            self._last_dash_pressed = True
        elif key in {"z", "Z"}:
            if not self._last_sword_pressed:
                self._retro_sword()
            self._last_sword_pressed = True
        elif key in {"x", "X"}:
            if not self._x_charge_active:
                self._x_charge_active = True
                self._x_charge_started = time.perf_counter()
        elif key in {"c", "C"}:
            if not self._last_boomerang_pressed:
                self._retro_shoot_boomerang()
            self._last_boomerang_pressed = True
        elif key in {"v", "V"}:
            if not self._last_triple_pressed:
                self._retro_shoot_triple()
            self._last_triple_pressed = True
        self._draw_hero()

    def _on_retro_key_release(self, event) -> None:
        key = getattr(event, "keysym", "")
        if not key:
            return
        self.pressed_keys.discard(key)
        if key in {"Up", "w", "W"}:
            self._last_jump_pressed = self._retro_key_pressed("Up", "w", "W")
        elif key == "space":
            self._last_dash_pressed = self._retro_key_pressed("space")
        elif key in {"z", "Z"}:
            self._last_sword_pressed = self._retro_key_pressed("z", "Z")
        elif key in {"c", "C"}:
            self._last_boomerang_pressed = self._retro_key_pressed("c", "C")
        elif key in {"v", "V"}:
            self._last_triple_pressed = self._retro_key_pressed("v", "V")
        elif key in {"x", "X"} and self._x_charge_active:
            self._retro_release_charge()

    def _retro_jump(self) -> None:
        if resolve_ui_mode(self.ui_mode.get()) != RETRO_UI_MODE:
            return
        player = self.retro_player
        if player.wall_side and not player.on_ground:
            player.vy = -430.0
            player.vx = -player.wall_side * 285.0
            player.facing = -player.wall_side
            player.jumps_used = 1
            return
        if player.on_ground:
            player.vy = -462.0
            player.on_ground = False
            player.jumps_used = 1
            return
        if player.jumps_used < 2:
            player.vy = -412.0
            player.jumps_used = 2

    def _retro_dash(self) -> None:
        if resolve_ui_mode(self.ui_mode.get()) != RETRO_UI_MODE:
            return
        player = self.retro_player
        if player.dash_cooldown > 0:
            return
        direction = 1 if player.facing >= 0 else -1
        if self._retro_key_pressed("Left", "a", "A") and not self._retro_key_pressed("Right", "d", "D"):
            direction = -1
        elif self._retro_key_pressed("Right", "d", "D") and not self._retro_key_pressed("Left", "a", "A"):
            direction = 1
        player.facing = direction
        player.vx = direction * 650.0
        player.vy = min(player.vy, 25.0)
        player.dash_timer = 0.18
        player.dash_cooldown = 0.52

    def _retro_sword(self) -> None:
        player = self.retro_player
        if player.sword_cooldown > 0:
            return
        player.sword_timer = 0.18
        player.sword_cooldown = 0.34
        self._retro_apply_sword_damage()

    def _retro_release_charge(self) -> None:
        held = max(0.0, time.perf_counter() - self._x_charge_started)
        self._x_charge_active = False
        self._x_charge_started = 0.0
        level = 0
        if held >= 5.0:
            level = 3
        elif held >= 3.0:
            level = 2
        elif held >= 1.0:
            level = 1
        self._retro_shoot_charged(level)

    def _retro_spawn_projectile(self, *, kind: str, vx: float, vy: float = 0.0, life: float = 1.4, damage: int = 1, level: int = 0) -> None:
        player = self.retro_player
        direction = 1 if player.facing >= 0 else -1
        x = player.x + (player.w if direction > 0 else -7)
        y = player.y + player.h * 0.44
        self.retro_projectiles.append(
            RetroProjectile(
                x=x,
                y=y,
                vx=vx,
                vy=vy,
                life=life,
                damage=damage,
                kind=kind,
                level=level,
                origin_x=x,
                hit_ids=set(),
            )
        )

    def _retro_shoot_charged(self, level: int) -> None:
        player = self.retro_player
        if player.shoot_cooldown > 0 and level == 0:
            return
        direction = 1 if player.facing >= 0 else -1
        speed = 560.0 + level * 110.0
        self._retro_spawn_projectile(kind="charged", vx=direction * speed, life=1.35 + level * 0.28, damage=1 + level, level=level)
        player.shoot_cooldown = max(0.12, 0.26 - level * 0.035)

    def _retro_shoot_boomerang(self) -> None:
        player = self.retro_player
        if player.shoot_cooldown > 0:
            return
        direction = 1 if player.facing >= 0 else -1
        self._retro_spawn_projectile(kind="boomerang", vx=direction * 470.0, life=1.9, damage=2, level=1)
        player.shoot_cooldown = 0.42

    def _retro_shoot_triple(self) -> None:
        player = self.retro_player
        if player.shoot_cooldown > 0:
            return
        direction = 1 if player.facing >= 0 else -1
        for vy in (-150.0, 0.0, 150.0):
            self._retro_spawn_projectile(kind="triple", vx=direction * 560.0, vy=vy, life=1.12, damage=1, level=0)
        player.shoot_cooldown = 0.38

    def _retro_apply_sword_damage(self) -> None:
        player = self.retro_player
        reach = 44.0
        sx = player.x + (player.w if player.facing > 0 else -reach)
        sy = player.y + 8.0
        for enemy in self.retro_enemies:
            if not enemy.alive or enemy.hurt_flash > 0:
                continue
            if sx < enemy.x + enemy.w and sx + reach > enemy.x and sy < enemy.y + enemy.h and sy + 22.0 > enemy.y:
                self._retro_damage_enemy(enemy, 2)

    def _retro_damage_enemy(self, enemy: RetroEnemy, amount: int) -> None:
        if not enemy.alive:
            return
        enemy.hp -= amount
        enemy.hurt_flash = 0.16
        if enemy.hp <= 0:
            enemy.alive = False

    def _update_retro_game(self, dt: float) -> None:
        viewport_width = max(360, self.hero_canvas.winfo_width())
        height = max(220, self.hero_canvas.winfo_height())
        self._ensure_retro_world(viewport_width, height)
        player = self.retro_player
        ground = self._retro_ground_y(height)
        obstacles = self.retro_obstacles

        left = self._retro_key_pressed("Left", "a", "A")
        right = self._retro_key_pressed("Right", "d", "D")
        climb = self._retro_key_pressed("Up", "w", "W")
        crouch = self._retro_key_pressed("Down", "s", "S")
        running = self._retro_key_pressed("Shift_L", "Shift_R")
        speed = 282.0 if running else 172.0
        acceleration = 18.0 if player.on_ground else 10.0
        friction = 16.0 if player.on_ground else 3.8

        if player.dash_cooldown > 0:
            player.dash_cooldown = max(0.0, player.dash_cooldown - dt)
        if player.sword_cooldown > 0:
            player.sword_cooldown = max(0.0, player.sword_cooldown - dt)
        if player.sword_timer > 0:
            player.sword_timer = max(0.0, player.sword_timer - dt)
            self._retro_apply_sword_damage()
        if player.shoot_cooldown > 0:
            player.shoot_cooldown = max(0.0, player.shoot_cooldown - dt)
        if player.hurt_timer > 0:
            player.hurt_timer = max(0.0, player.hurt_timer - dt)

        dashing = player.dash_timer > 0
        if dashing:
            player.dash_timer = max(0.0, player.dash_timer - dt)
            player.vx = player.facing * 650.0
        else:
            target_vx = 0.0
            if left and not right:
                target_vx = -speed
                player.facing = -1
            elif right and not left:
                target_vx = speed
                player.facing = 1
            if target_vx:
                player.vx += (target_vx - player.vx) * min(1.0, acceleration * dt)
            else:
                player.vx += (0.0 - player.vx) * min(1.0, friction * dt)
                if abs(player.vx) < 4:
                    player.vx = 0.0

        player.wall_side = self._retro_touching_wall(player, obstacles)
        gravity = 1060.0
        if player.wall_side and not player.on_ground and climb:
            player.vy = min(player.vy, -120.0 if not crouch else 145.0)
            player.vy -= 280.0 * dt
        elif player.wall_side and not player.on_ground and player.vy > 88:
            player.vy = min(player.vy, 120.0)
        else:
            player.vy += (gravity * 0.22 if dashing else gravity) * dt

        old_x = player.x
        player.x += player.vx * dt
        if player.x < 8.0:
            player.x = 8.0
            if player.vx < 0:
                player.vx = 0.0
        if player.x + player.w > self.retro_world_width - 8.0:
            player.x = self.retro_world_width - 8.0 - player.w
            if player.vx > 0:
                player.vx = 0.0
        for rect in obstacles:
            if not self._retro_intersects(player.x, player.y, player.w, player.h, rect):
                continue
            if player.vx > 0 or (player.vx == 0 and old_x + player.w <= rect.x):
                player.x = rect.x - player.w
                player.wall_side = 1
            elif player.vx < 0 or (player.vx == 0 and old_x >= rect.x + rect.w):
                player.x = rect.x + rect.w
                player.wall_side = -1
            player.vx = 0.0

        old_y = player.y
        player.y += player.vy * dt
        player.on_ground = False
        has_ground = not self._retro_in_pit(player.x, player.w)
        if has_ground and player.y + player.h >= ground:
            player.y = float(ground - player.h)
            player.vy = 0.0
            player.on_ground = True
            player.jumps_used = 0
        for rect in obstacles:
            if not self._retro_intersects(player.x, player.y, player.w, player.h, rect):
                continue
            if player.vy > 0 or (player.vy == 0 and old_y + player.h <= rect.y):
                player.y = rect.y - player.h
                player.vy = 0.0
                player.on_ground = True
                player.jumps_used = 0
            elif player.vy < 0 or (player.vy == 0 and old_y >= rect.y + rect.h):
                player.y = rect.y + rect.h
                player.vy = 0.0
        if player.y < 8.0:
            player.y = 8.0
            player.vy = max(0.0, player.vy)
        if player.y > height + 70:
            self._retro_respawn(viewport_width, height)

        player.wall_side = self._retro_touching_wall(player, obstacles)
        if player.on_ground:
            player.wall_side = 0
        if abs(player.vx) > 12 or not player.on_ground:
            player.walk_phase += dt * (9.0 if not running else 15.0)

        # Movimiento y contacto de rivales.
        for enemy in self.retro_enemies:
            if not enemy.alive:
                continue
            enemy.phase += dt
            if enemy.hurt_flash > 0:
                enemy.hurt_flash = max(0.0, enemy.hurt_flash - dt)
            if enemy.kind == "minor":
                enemy.y += math.sin(enemy.phase * 3.2) * 8.0 * dt
            enemy.x += enemy.vx * dt
            if enemy.x < enemy.patrol_left:
                enemy.x = enemy.patrol_left
                enemy.vx = abs(enemy.vx)
            if enemy.x + enemy.w > enemy.patrol_right:
                enemy.x = enemy.patrol_right - enemy.w
                enemy.vx = -abs(enemy.vx)
            if player.hurt_timer <= 0 and self._retro_intersects(player.x, player.y, player.w, player.h, enemy):
                player.hurt_timer = 0.55
                player.vx = -math.copysign(260.0, enemy.x + enemy.w * 0.5 - (player.x + player.w * 0.5))
                player.vy = -240.0
                player.on_ground = False

        kept: list[RetroProjectile] = []
        for projectile in self.retro_projectiles:
            if projectile.kind == "boomerang":
                if not projectile.returning and abs(projectile.x - projectile.origin_x) > 310:
                    projectile.returning = True
                if projectile.life < 0.88:
                    projectile.returning = True
                if projectile.returning:
                    target_x = player.x + player.w * 0.5
                    target_y = player.y + player.h * 0.5
                    direction = 1.0 if target_x > projectile.x else -1.0
                    projectile.vx += (direction * 520.0 - projectile.vx) * min(1.0, 9.0 * dt)
                    projectile.vy += ((target_y - projectile.y) * 3.0 - projectile.vy) * min(1.0, 7.0 * dt)
                    if abs(projectile.x - target_x) < 18 and abs(projectile.y - target_y) < 18:
                        continue
            projectile.x += projectile.vx * dt
            projectile.y += projectile.vy * dt
            projectile.life -= dt
            if projectile.life <= 0 or projectile.x < -40 or projectile.x > self.retro_world_width + 40 or projectile.y < -60 or projectile.y > height + 80:
                continue
            obstacle_hit = any(self._retro_intersects(projectile.x - 4, projectile.y - 3, 12, 6, rect) for rect in obstacles)
            if obstacle_hit and projectile.kind not in {"boomerang", "charged"}:
                continue
            removed_by_hit = False
            for enemy in self.retro_enemies:
                if not enemy.alive:
                    continue
                enemy_id = id(enemy)
                hit_ids = projectile.hit_ids if projectile.hit_ids is not None else set()
                if enemy_id in hit_ids:
                    continue
                size = 10 + projectile.level * 5
                if projectile.x - size * 0.5 < enemy.x + enemy.w and projectile.x + size * 0.5 > enemy.x and projectile.y - 5 < enemy.y + enemy.h and projectile.y + 5 > enemy.y:
                    self._retro_damage_enemy(enemy, projectile.damage)
                    hit_ids.add(enemy_id)
                    projectile.hit_ids = hit_ids
                    if projectile.kind in {"normal", "triple"} or (projectile.kind == "charged" and projectile.level < 2):
                        removed_by_hit = True
                    break
            if not removed_by_hit:
                kept.append(projectile)
        self.retro_projectiles = kept
        self._retro_update_camera(viewport_width)

    def _retro_screen_x(self, world_x: float) -> float:
        return world_x - self.retro_camera_x

    def _draw_world_rect(self, canvas: tk.Canvas, x: float, y: float, w: float, h: float, *, fill: str, outline: str | None = None, width: int = 1) -> None:
        sx = self._retro_screen_x(x)
        if sx + w < -50 or sx > canvas.winfo_width() + 50:
            return
        canvas.create_rectangle(sx, y, sx + w, y + h, fill=fill, outline=outline if outline is not None else fill, width=width)

    def _draw_retro_city(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        ground = self._retro_ground_y(height)
        horizon = ground - 142
        phase = int(self.anim_phase * 3) % 18
        for y in range(16, max(22, horizon), 28):
            canvas.create_line(0, y + phase % 5, width, y + phase % 5, fill=ink, width=1)
        for i in range(18):
            x = int((i * 137 - self.anim_phase * 13) % max(1, width))
            y = 18 + (i * 29) % max(30, ground - 72)
            canvas.create_rectangle(x, y, x + 3, y + 3, fill=ink, outline="")

        cam = self.retro_camera_x * 0.32
        for wx in range(-180, self.retro_world_width + 260, 88):
            sx = wx - cam
            if sx > width + 90 or sx + 58 < -90:
                continue
            b_h = 40 + ((wx // 88) % 5) * 18
            y0 = ground - 38 - b_h
            canvas.create_rectangle(sx, y0, sx + 56, ground - 38, fill=ink, outline="")
            canvas.create_rectangle(sx + 5, y0 + 6, sx + 51, ground - 44, fill=base, outline="")
            for wy in range(int(y0 + 12), int(ground - 52), 15):
                for wx2 in range(10, 46, 18):
                    if ((wy + wx2 + int(self.anim_phase)) // 2) % 3 != 0:
                        canvas.create_rectangle(sx + wx2, wy, sx + wx2 + 5, wy + 5, fill=ink, outline="")

    def _draw_retro_mech(self, canvas: tk.Canvas, height: int, base: str, ink: str) -> None:
        ground = self._retro_ground_y(height)
        cx = self._retro_screen_x(self.retro_world_width - 420)
        if cx < -220 or cx > canvas.winfo_width() + 220:
            return
        y = ground - 176
        bob = int(math.sin(self.anim_phase * 0.9) * 3)
        # Mecha pixelado usando solo rectángulos.
        canvas.create_rectangle(cx - 78, y + 116, cx + 92, ground - 16, fill=ink, outline="")
        canvas.create_rectangle(cx - 66, y + 124, cx + 80, ground - 26, fill=base, outline="")
        canvas.create_rectangle(cx - 44, y + 134, cx - 20, ground - 34, fill=ink, outline="")
        canvas.create_rectangle(cx + 24, y + 134, cx + 48, ground - 34, fill=ink, outline="")
        canvas.create_rectangle(cx - 74, y + bob, cx + 74, y + 112 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 62, y + 12 + bob, cx + 62, y + 100 + bob, fill=base, outline="")
        canvas.create_rectangle(cx - 44, y + 26 + bob, cx + 44, y + 84 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 32, y + 38 + bob, cx + 32, y + 72 + bob, fill=base, outline="")
        canvas.create_rectangle(cx - 18, y + 48 + bob, cx + 18, y + 62 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 112, y + 62 + bob, cx - 70, y + 88 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx + 70, y + 68 + bob, cx + 118, y + 94 + bob, fill=ink, outline="")
        canvas.create_rectangle(cx - 138, y + 76 + bob, cx - 106, y + 108 + bob, fill=base, outline=ink, width=3)
        canvas.create_rectangle(cx + 112, y + 82 + bob, cx + 150, y + 116 + bob, fill=base, outline=ink, width=3)

    def _draw_retro_ground(self, canvas: tk.Canvas, width: int, height: int, base: str, ink: str) -> None:
        ground = self._retro_ground_y(height)
        segments: list[tuple[float, float]] = []
        start = 0.0
        for pit in sorted(self.retro_pits, key=lambda item: item.x):
            if pit.x > start:
                segments.append((start, pit.x))
            start = max(start, pit.x + pit.w)
        if start < self.retro_world_width:
            segments.append((start, float(self.retro_world_width)))
        for x0, x1 in segments:
            sx0 = self._retro_screen_x(x0)
            sx1 = self._retro_screen_x(x1)
            if sx1 < -30 or sx0 > width + 30:
                continue
            canvas.create_rectangle(sx0, ground, sx1, height, fill=ink, outline="")
            canvas.create_rectangle(sx0, ground + 6, sx1, ground + 12, fill=base, outline="")
        for pit in self.retro_pits:
            sx = self._retro_screen_x(pit.x)
            if sx + pit.w < -30 or sx > width + 30:
                continue
            canvas.create_rectangle(sx, ground + 2, sx + pit.w, height, fill=base, outline=ink, width=2)
            canvas.create_rectangle(sx + 8, ground + 14, sx + pit.w - 8, ground + 20, fill=ink, outline="")
        scroll = int(self.retro_camera_x) % 32
        for x in range(-scroll, width + 36, 32):
            canvas.create_rectangle(x, ground + 17, x + 18, ground + 25, fill=base, outline="")
            canvas.create_line(x - 6, ground + 2, x + 32, ground + 2, fill=base, width=1)

    def _draw_retro_obstacles(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        for rect in self.retro_obstacles:
            self._draw_world_rect(canvas, rect.x, rect.y, rect.w, rect.h, fill=ink, outline=ink, width=2)
            sx = self._retro_screen_x(rect.x)
            if sx + rect.w < -40 or sx > canvas.winfo_width() + 40:
                continue
            for px in range(int(sx + 8), int(sx + rect.w - 4), 22):
                canvas.create_rectangle(px, rect.y + 4, px + 8, rect.y + max(5, rect.h - 4), fill=base, outline="")
            if rect.h > 34:
                for py in range(int(rect.y + 12), int(rect.y + rect.h - 6), 24):
                    canvas.create_rectangle(sx + 5, py, sx + rect.w - 5, py + 6, fill=base, outline="")

    def _draw_retro_enemies(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        for enemy in self.retro_enemies:
            if not enemy.alive:
                continue
            sx = self._retro_screen_x(enemy.x)
            if sx + enemy.w < -40 or sx > canvas.winfo_width() + 40:
                continue
            flash = enemy.hurt_flash > 0 and int(enemy.hurt_flash * 40) % 2 == 0
            fill = base if flash else ink
            outline = ink
            if enemy.kind == "minor":
                canvas.create_rectangle(sx, enemy.y + 5, sx + enemy.w, enemy.y + enemy.h - 3, fill=fill, outline=outline, width=2)
                canvas.create_rectangle(sx + 5, enemy.y, sx + enemy.w - 5, enemy.y + 6, fill=ink if not flash else base, outline="")
                canvas.create_rectangle(sx + 7, enemy.y + 10, sx + 11, enemy.y + 14, fill=base if not flash else ink, outline="")
                canvas.create_rectangle(sx + enemy.w - 12, enemy.y + 10, sx + enemy.w - 8, enemy.y + 14, fill=base if not flash else ink, outline="")
            else:
                canvas.create_rectangle(sx + 10, enemy.y + 16, sx + enemy.w - 10, enemy.y + enemy.h, fill=fill, outline=outline, width=2)
                canvas.create_rectangle(sx + 4, enemy.y + 4, sx + enemy.w - 4, enemy.y + 24, fill=fill, outline=outline, width=2)
                canvas.create_rectangle(sx + 14, enemy.y + 10, sx + 24, enemy.y + 16, fill=base if not flash else ink, outline="")
                canvas.create_rectangle(sx + enemy.w - 24, enemy.y + 10, sx + enemy.w - 14, enemy.y + 16, fill=base if not flash else ink, outline="")
                cannon_dir = 1 if enemy.vx >= 0 else -1
                if cannon_dir > 0:
                    canvas.create_rectangle(sx + enemy.w - 6, enemy.y + 28, sx + enemy.w + 18, enemy.y + 36, fill=ink, outline="")
                else:
                    canvas.create_rectangle(sx - 18, enemy.y + 28, sx + 6, enemy.y + 36, fill=ink, outline="")

    def _draw_retro_player(self, canvas: tk.Canvas, base: str, ink: str) -> None:
        p = self.retro_player
        x = self._retro_screen_x(p.x)
        y, w, h = p.y, p.w, p.h
        if p.hurt_timer > 0 and int(p.hurt_timer * 30) % 2 == 0:
            return
        step = int(abs(math.sin(p.walk_phase)) * 3) if p.on_ground else 2
        visor = 3 if p.facing >= 0 else -3
        if p.dash_timer > 0:
            trail_dir = -1 if p.facing >= 0 else 1
            for i in range(3):
                tx = x + trail_dir * (13 + i * 9)
                canvas.create_rectangle(tx + 4, y + 8 + i * 3, tx + w - 6, y + h - 9 - i, fill=ink, outline="")
                canvas.create_rectangle(tx + 8, y + 12 + i * 3, tx + w - 10, y + h - 13 - i, fill=base, outline="")
        canvas.create_rectangle(x + 4, y + h - 10, x + 10, y + h, fill=ink, outline="")
        canvas.create_rectangle(x + w - 10, y + h - 10 + step, x + w - 4, y + h + step, fill=ink, outline="")
        canvas.create_rectangle(x + 3, y + 14, x + w - 3, y + h - 8, fill=base, outline=ink, width=2)
        canvas.create_rectangle(x + 8, y + 18, x + w - 8, y + h - 9, fill=ink, outline="")
        canvas.create_rectangle(x + 5, y + 5, x + w - 5, y + 18, fill=base, outline=ink, width=2)
        canvas.create_rectangle(x + 4, y + 1, x + w - 4, y + 9, fill=ink, outline="")
        canvas.create_rectangle(x + 9 + visor, y + 10, x + 18 + visor, y + 14, fill=ink, outline="")
        canvas.create_rectangle(x + 12 + visor, y + 11, x + 15 + visor, y + 13, fill=base, outline="")
        canvas.create_rectangle(x + (w if p.facing > 0 else -7), y + 19, x + (w + 7 if p.facing > 0 else 0), y + 24, fill=ink, outline="")
        if not p.on_ground and p.jumps_used == 2:
            canvas.create_rectangle(x - 6, y + h - 4, x + w + 6, y + h, fill=ink, outline="")
            canvas.create_rectangle(x - 2, y + h - 8, x + w + 2, y + h - 5, fill=ink, outline="")
        if p.sword_timer > 0:
            if p.facing > 0:
                canvas.create_rectangle(x + w + 4, y + 9, x + w + 48, y + 14, fill=ink, outline="")
                canvas.create_rectangle(x + w + 34, y + 6, x + w + 50, y + 17, fill=ink, outline="")
            else:
                canvas.create_rectangle(x - 48, y + 9, x - 4, y + 14, fill=ink, outline="")
                canvas.create_rectangle(x - 50, y + 6, x - 34, y + 17, fill=ink, outline="")
        if self._x_charge_active:
            held = max(0.0, time.perf_counter() - self._x_charge_started)
            level = 3 if held >= 5 else 2 if held >= 3 else 1 if held >= 1 else 0
            bx = x - 4
            by = y - 10
            canvas.create_rectangle(bx, by, bx + 34, by + 5, fill=base, outline=ink, width=1)
            fill_w = min(34, int((held / 5.0) * 34))
            if fill_w > 0:
                canvas.create_rectangle(bx, by, bx + fill_w, by + 5, fill=ink, outline="")
            for marker in (7, 20, 34):
                canvas.create_line(bx + marker, by, bx + marker, by + 5, fill=base if marker <= fill_w else ink, width=1)
            if level:
                canvas.create_rectangle(x + (w + 9 if p.facing > 0 else -13), y + 18, x + (w + 13 if p.facing > 0 else -9), y + 22, fill=ink, outline="")

    def _draw_retro_projectiles(self, canvas: tk.Canvas, width: int, base: str, ink: str) -> None:
        for projectile in self.retro_projectiles:
            sx = self._retro_screen_x(projectile.x)
            if sx < -30 or sx > width + 30:
                continue
            if projectile.kind == "boomerang":
                size = 9 + int(2 * math.sin(self.anim_phase * 4))
                canvas.create_rectangle(sx - size, projectile.y - 3, sx + size, projectile.y + 3, fill=ink, outline="")
                canvas.create_rectangle(sx - 3, projectile.y - size, sx + 3, projectile.y + size, fill=ink, outline="")
            elif projectile.kind == "triple":
                canvas.create_rectangle(sx - 4, projectile.y - 3, sx + 8, projectile.y + 3, fill=ink, outline="")
            else:
                size = 8 + projectile.level * 4
                canvas.create_rectangle(sx - size, projectile.y - 4 - projectile.level, sx + size, projectile.y + 4 + projectile.level, fill=ink, outline="")
                canvas.create_rectangle(sx - max(2, size - 4), projectile.y - 1, sx + max(2, size - 4), projectile.y + 1, fill=base, outline="")

    def _draw_retro_hero(self, canvas: tk.Canvas, palette: Palette, width: int, height: int) -> None:
        width = max(360, width)
        height = max(220, height)
        self._ensure_retro_world(width, height)
        base, ink = self._retro_duotone(palette)
        self._apply_retro_button_tone(palette)

        canvas.create_rectangle(0, 0, width, height, fill=base, outline=ink, width=2)
        self._draw_retro_city(canvas, width, height, base, ink)
        self._draw_retro_mech(canvas, height, base, ink)
        self._draw_retro_obstacles(canvas, base, ink)
        self._draw_retro_ground(canvas, width, height, base, ink)
        self._draw_retro_enemies(canvas, base, ink)
        self._draw_retro_projectiles(canvas, width, base, ink)
        self._draw_retro_player(canvas, base, ink)

        # Botones Tk clicables, fijos sobre el viewport para no aumentar el espacio ocupado por la UI.
        if self.retro_buttons:
            button_x = min(width - 176, max(176, width * 0.76))
            first_y = 42
            gap = 34
            canvas.create_rectangle(button_x - 176, first_y - 24, button_x + 176, first_y + gap * 2 + 23, fill=base, outline=ink, width=2)
            canvas.create_window(button_x, first_y, window=self.retro_module1_button, anchor="center")
            canvas.create_window(button_x, first_y + gap, window=self.retro_module2_button, anchor="center")
            canvas.create_window(button_x, first_y + gap * 2, window=self.retro_config_button, anchor="center")

    def _on_retro_canvas_click(self, event) -> None:
        if resolve_ui_mode(self.ui_mode.get()) == RETRO_UI_MODE:
            self.hero_canvas.focus_set()
            return
        self._handle_hidden_minigame_click(event)

    def _is_classic_wheel_click(self, x: float, y: float) -> bool:
        hitbox = self._classic_wheel_hitbox
        if hitbox is None:
            return False
        cx, cy, radius = hitbox
        distance = math.hypot(float(x) - cx, float(y) - cy)
        return distance <= radius

    def _handle_hidden_minigame_click(self, event) -> None:
        # Se activa únicamente con 5 clicks consecutivos sobre la ruedita
        # mientras Espacio está presionado. Cualquier otro click reinicia la clave.
        space_down = self._retro_key_pressed("space")
        wheel_hit = self._is_classic_wheel_click(getattr(event, "x", 0), getattr(event, "y", 0))
        now = time.perf_counter()
        if not (space_down and wheel_hit):
            self._egg_click_count = 0
            self._egg_last_click_time = 0.0
            return
        if now - self._egg_last_click_time > 3.0:
            self._egg_click_count = 0
        self._egg_click_count += 1
        self._egg_last_click_time = now
        if self._egg_click_count >= 5:
            self._egg_click_count = 0
            self._egg_last_click_time = 0.0
            self._open_hidden_minigame()

    def _open_hidden_minigame(self) -> None:
        if self._minigame_window is not None:
            try:
                if self._minigame_window.winfo_exists():
                    self._minigame_window.deiconify()
                    self._minigame_window.lift()
                    self._minigame_window.focus_force()
                    self.status_var.set("Easter egg retro ya está abierto.")
                    return
            except Exception:
                self._minigame_window = None
                self._minigame_app = None

        # Resolver robustamente la ruta del easter egg tanto en ejecución desde código fuente
        # como desde PyInstaller. En la versión 1.3.1 la carpeta se empaquetó accidentalmente
        # como "sl"; se mantiene ese alias como respaldo para no romper copias existentes.
        bundle_root = Path(getattr(sys, "_MEIPASS", self.suite_root))
        candidate_roots: list[Path] = []
        for parent in (self.suite_root, self.base_dir, bundle_root):
            candidate_roots.extend((parent / "SECRETO_LEMATZIUM", parent / "sl"))

        secret_root: Path | None = None
        for candidate in candidate_roots:
            if (candidate / "lematzium_minijuego_retro" / "app.py").exists():
                secret_root = candidate.resolve()
                break

        if secret_root is None:
            messagebox.showerror(
                "Easter egg no disponible",
                "No se encontró la carpeta del minijuego retro dentro de LEMATZIUM.\n\n"
                "Se revisaron las rutas de código fuente, carpeta del ejecutable y paquete PyInstaller.",
                parent=self.root,
            )
            return

        try:
            secret_path = str(secret_root)
            if secret_path in sys.path:
                sys.path.remove(secret_path)
            sys.path.insert(0, secret_path)
            from lematzium_minijuego_retro.app import RetroMinigame

            window = tk.Toplevel(self.root)
            self._minigame_window = window

            def _close_minigame() -> None:
                self._minigame_app = None
                self._minigame_window = None
                try:
                    window.destroy()
                except Exception:
                    pass

            window.protocol("WM_DELETE_WINDOW", _close_minigame)
            self._minigame_app = RetroMinigame(window)
            window.lift()
            window.focus_force()
            self.status_var.set("Easter egg retro activado.")
        except Exception as exc:
            self._minigame_window = None
            self._minigame_app = None
            messagebox.showerror(
                "No se pudo abrir el easter egg",
                f"El minijuego retro está integrado, pero falló al abrirse.\n\nDetalle: {exc}",
                parent=self.root,
            )

    def _on_retro_canvas_drag(self, _event) -> None:
        return

    def _on_retro_canvas_release(self, _event) -> None:
        return

    def _module_name_by_key(self, module_key: str) -> str | None:
        for module_name, resolved in self.modules.items():
            if resolved.definition.key == module_key:
                return module_name
        return None

    def _launch_tensile_metals_from_retro(self) -> None:
        module_name = self._module_name_by_key("tensile_unified")
        if module_name is None:
            messagebox.showerror("Módulo no encontrado", "No se encontró el Módulo 1 - Tracción Metales 1.3.0.", parent=self.root)
            return
        self._launch_module(module_name)

    def _launch_plastics_from_retro(self) -> None:
        module_name = self._module_name_by_key("traccion_plasticos")
        if module_name is None:
            messagebox.showerror("Módulo no encontrado", "No se encontró el módulo de Tracción plásticos ISO 527.", parent=self.root)
            return
        self._launch_module(module_name)

    def _infer_module_root(self, script_path: Path, module_key: str) -> Path:
        expected = {
            "modulo1": "module_1_drop1mpa",
            "modulo2": "module_2_offset02",
            "traccion_plasticos": "module_4_traccion_plasticos",
            "tensile_unified": "module_tensile_unified",
            "ai_assistant": "module_3_ai_assistant",
            "uncertainty": "launcher",
        }.get(module_key)

        if expected:
            for parent in [script_path.parent, *script_path.parents]:
                if parent.name == expected:
                    return parent
        return script_path.parent

    def _module_launch_context(self, script_path: Path, module_key: str) -> tuple[Path, dict[str, str]]:
        env = os.environ.copy()
        env["LEMATZIUM_THEME"] = self.theme_name.get()
        env["LEMATZIUM_THEME_NAME"] = self.theme_name.get()
        env["LEMATZIUM_THEME_FILE"] = str(_prefs_path(self.base_dir))
        env["LEMATZIUM_BRIGHTNESS"] = str(int(self.brightness_var.get()))
        env["PYTHONDONTWRITEBYTECODE"] = "1"

        module_root = self._infer_module_root(script_path, module_key)
        cwd = module_root
        _prepend_pythonpath(env, module_root.parent, module_root, script_path.parent)
        return cwd, env

    def _candidate_python_executables(self, module_root: Path) -> list[Path]:
        return candidate_python_executables(module_root, suite_root=self.suite_root)

    def _python_has_imports(self, python_exe: Path, imports: tuple[str, ...], *, cwd: Path, env: dict[str, str]) -> tuple[bool, str]:
        return python_has_imports(python_exe, imports, cwd=cwd, env=env)

    def _install_missing_dependencies(self, python_exe: Path, module_key: str, *, cwd: Path, env: dict[str, str]) -> bool:
        return install_missing_dependencies(
            python_exe,
            module_key,
            cwd=cwd,
            env=env,
            packages_by_module=PIP_PACKAGES_BY_MODULE,
            root=self.root,
            status_var=self.status_var,
        )

    def _select_python_for_module(self, script_path: Path, module_key: str, cwd: Path, env: dict[str, str]) -> Path | None:
        return select_python_for_module(
            module_key,
            cwd=cwd,
            env=env,
            required_imports_by_module=REQUIRED_IMPORTS_BY_MODULE,
            packages_by_module=PIP_PACKAGES_BY_MODULE,
            suite_root=self.suite_root,
            root=self.root,
            status_var=self.status_var,
        )

    def _popen_normal_window(self, args: list[str], *, cwd: str, env: dict[str, str] | None = None):
        return popen_normal_window(args, cwd=cwd, env=env)

    def _restore_process_window_nt(self, pid: int) -> bool:
        """Restaura con mayor agresividad la ventana principal de un módulo.

        En Windows, después de usar diálogos de exportación o abrir Word, la
        ventana Tk puede quedar minimizada pero viva. La versión anterior podía
        no encontrarla si el estado/visibilidad llegaba retrasado. Esta rutina
        enumera todas las ventanas con título del proceso, prioriza LEMATZIUM y
        aplica ShowWindowAsync + SetWindowPos para devolverla al frente sin abrir
        otra instancia.
        """
        if os.name != "nt":
            return False
        try:
            user32 = ctypes.windll.user32
            hwnds: list[int] = []

            EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

            def _title(hwnd: int) -> str:
                try:
                    n = user32.GetWindowTextLengthW(hwnd) + 1
                    if n <= 1:
                        return ""
                    buff = ctypes.create_unicode_buffer(n)
                    user32.GetWindowTextW(hwnd, buff, n)
                    return buff.value or ""
                except Exception:
                    return ""

            def _callback(hwnd, _lparam):
                try:
                    proc_id = wintypes.DWORD()
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(proc_id))
                    if int(proc_id.value) != int(pid):
                        return True
                    title = _title(int(hwnd)).strip()
                    if not title:
                        return True
                    hwnds.append(int(hwnd))
                except Exception:
                    return True
                return True

            user32.EnumWindows(EnumWindowsProc(_callback), 0)
            if not hwnds:
                return False

            def _score(hwnd: int) -> tuple[int, int]:
                title_upper = _title(hwnd).upper()
                # Primero la ventana principal del módulo, luego otros diálogos.
                return (0 if "LEMATZIUM" in title_upper else 1, len(title_upper))

            hwnds.sort(key=_score)
            hwnd = hwnds[0]
            SW_RESTORE = 9
            SW_SHOW = 5
            HWND_TOP = 0
            SWP_NOSIZE = 0x0001
            SWP_NOMOVE = 0x0002
            SWP_SHOWWINDOW = 0x0040
            try:
                user32.AllowSetForegroundWindow(int(pid))
            except Exception:
                pass
            try:
                user32.ShowWindowAsync(hwnd, SW_RESTORE)
            except Exception:
                user32.ShowWindow(hwnd, SW_RESTORE)
            try:
                user32.ShowWindow(hwnd, SW_SHOW)
            except Exception:
                pass
            try:
                user32.SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
            except Exception:
                pass
            try:
                user32.BringWindowToTop(hwnd)
            except Exception:
                pass
            try:
                user32.SetForegroundWindow(hwnd)
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _restore_running_module(self, module_name: str) -> bool:
        proc = self.module_processes.get(module_name)
        if proc is None:
            return False
        try:
            poll = proc.poll()  # type: ignore[attr-defined]
        except Exception:
            self.module_processes.pop(module_name, None)
            return False
        if poll is not None:
            self.module_processes.pop(module_name, None)
            return False
        try:
            pid = int(proc.pid)  # type: ignore[attr-defined]
        except Exception:
            pid = -1
        restored = self._restore_process_window_nt(pid) if pid > 0 else False
        if restored:
            self.status_var.set(f"Restaurado: {module_name}")
        else:
            self.status_var.set(f"{module_name} ya está abierto. Revísalo en la barra de tareas.")
        return True

    def _launch_module(self, module_name: str) -> None:
        if self._restore_running_module(module_name):
            return

        resolved = self.modules[module_name]
        if resolved.script_path is None:
            messagebox.showerror(
                "Módulo no encontrado",
                f"No se encontró la ruta de arranque de {module_name}.\n\nRevisa las fuentes internas desde el Módulo 3 - Asistente virtual IA.",
                parent=self.root,
            )
            return

        target_path = resolved.script_path

        try:
            if str(target_path).lower().endswith(".exe"):
                proc = self._popen_normal_window([str(target_path)], cwd=str(target_path.parent))
            else:
                cwd, env = self._module_launch_context(target_path, resolved.definition.key)
                python_exe = self._select_python_for_module(target_path, resolved.definition.key, cwd, env)
                if python_exe is None:
                    return
                proc = self._popen_normal_window([str(python_exe), str(target_path)], cwd=str(cwd), env=env)
            self.module_processes[module_name] = proc
        except Exception as exc:
            messagebox.showerror(
                "Error al abrir módulo",
                f"No se pudo abrir {module_name}.\n\nDetalle: {exc}",
                parent=self.root,
            )
            return

        self.status_var.set(f"Abierto: {module_name}")
        self.progress = min(100, self.progress + 12)
        self._draw_hero()

    def _open_config(self) -> None:
        if self.config_dialog is not None:
            self.config_dialog.focus()
            return
        # Las miniaturas de icono no deben bloquear el arranque inicial, pero sí
        # deben estar disponibles cuando el usuario entra a Configuración.
        self._load_icon_assets(load_all=True)
        self.config_dialog = ConfigDialog(self)

    def _update_music_state(self) -> None:
        if not self.music_controller.available:
            return
        if self.music_enabled.get():
            self.music_controller.set_volume(self.music_volume.get())
            self.music_controller.play_loop()
        else:
            self.music_controller.stop()

    def _on_exit(self) -> None:
        self.save_current_prefs()
        self.music_controller.close()
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    app = LematZiumSuiteLauncher()
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
