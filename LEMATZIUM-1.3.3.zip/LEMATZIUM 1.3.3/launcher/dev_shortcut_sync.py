from __future__ import annotations

import argparse
import base64
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

PREFS_FILE = "lematzium_suite_launcher_prefs.json"
DEFAULT_ICON_NAME = "Azul-cian"
SHORTCUT_NAME = "LEMATZIUM DEV.lnk"
RUNNER_BAT_NAME = "run_lematzium_dev.bat"

ICON_ICO_MAP = {
    "Azul-cian": "lematzium_azul_cian.ico",
    "Rosa": "lematzium_rosa.ico",
    "Naranja": "lematzium_naranja.ico",
    "Verde": "lematzium_verde.ico",
    "Azul profundo": "lematzium_azul_profundo.ico",
    "Morado": "lematzium_morado.ico",
}


def _suite_root_from_here() -> Path:
    return Path(__file__).resolve().parent.parent


def _launcher_dir(suite_root: Path) -> Path:
    return suite_root / "launcher"


def _prefs_path(suite_root: Path) -> Path:
    return _launcher_dir(suite_root) / PREFS_FILE


def _is_windows() -> bool:
    return os.name == "nt" or sys.platform.startswith("win")


def _expand_windows_path(value: str) -> Path | None:
    value = (value or "").strip().strip('"')
    if not value:
        return None
    return Path(os.path.expandvars(value)).expanduser()


def _desktop_dir_from_registry() -> Path | None:
    """Obtiene el Escritorio real de Windows, incluso si está redirigido a OneDrive."""
    if not _is_windows():
        return None

    try:
        import winreg  # type: ignore
    except Exception:
        return None

    keys_to_try = [
        (r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders", "Desktop"),
        (r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Desktop"),
    ]
    for key_name, value_name in keys_to_try:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_name) as key:
                value, _ = winreg.QueryValueEx(key, value_name)
            candidate = _expand_windows_path(str(value))
            if candidate and candidate.exists():
                return candidate
        except Exception:
            continue
    return None


def _desktop_dir() -> Path:
    """
    Devuelve el Escritorio real.

    Corrección importante:
    No se asume siempre C:\\Users\\usuario\\Desktop, porque en equipos ESPOL/OneDrive
    el Escritorio puede estar redirigido a OneDrive\\Escritorio o OneDrive\\Desktop.
    """
    registry_desktop = _desktop_dir_from_registry()
    if registry_desktop:
        return registry_desktop

    candidates: list[Path] = []
    for env_name in ("OneDriveCommercial", "OneDrive", "USERPROFILE"):
        value = os.environ.get(env_name)
        if not value:
            continue
        root = Path(value)
        candidates.extend([root / "Escritorio", root / "Desktop"])

    candidates.extend([Path.home() / "Escritorio", Path.home() / "Desktop"])

    for candidate in candidates:
        if candidate.exists():
            return candidate

    # Último recurso: no debe ser lo normal, pero evita fallar antes de crear el .lnk.
    return Path.home() / "Desktop"


def load_prefs(suite_root: Path) -> dict:
    path = _prefs_path(suite_root)
    if not path.exists():
        return {"icon": DEFAULT_ICON_NAME}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"icon": DEFAULT_ICON_NAME}


def _safe_icon_name(icon_name: str | None) -> str:
    icon_name = (icon_name or DEFAULT_ICON_NAME).strip()
    return icon_name if icon_name in ICON_ICO_MAP else DEFAULT_ICON_NAME


def icon_asset_path(suite_root: Path, icon_name: str | None = None) -> Path | None:
    icon_name = _safe_icon_name(icon_name)
    icons_dir = suite_root / "build_assets" / "icons"

    candidate = icons_dir / ICON_ICO_MAP[icon_name]
    if candidate.exists():
        return candidate.resolve()

    fallback = icons_dir / "lematzium_default.ico"
    if fallback.exists():
        return fallback.resolve()

    # No forzar un icono inexistente: algunos Windows/COM pueden fallar al guardar el .lnk.
    return None


def ensure_dev_runner_bat(suite_root: Path) -> Path:
    path = suite_root / RUNNER_BAT_NAME
    content = r'''@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "LOG_FILE=%TEMP%\lematzium_dev_launcher.log"
set "PY_CMD="

if exist ".venv\Scripts\python.exe" set "PY_CMD=.venv\Scripts\python.exe"
if not defined PY_CMD if exist "venv\Scripts\python.exe" set "PY_CMD=venv\Scripts\python.exe"

if not defined PY_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
    where py >nul 2>&1
    if not errorlevel 1 set "PY_CMD=py"
)

if not defined PY_CMD (
    > "%LOG_FILE%" echo No se encontro un interprete de Python utilizable.
    >>"%LOG_FILE%" echo Prueba creando un entorno virtual .venv o instala Python y agregalo al PATH.
    echo No se encontro un interprete de Python utilizable.
    echo Revisa el log: %LOG_FILE%
    pause
    exit /b 1
)

> "%LOG_FILE%" echo Usando interprete: %PY_CMD%
"%PY_CMD%" "launcher\lematzium_suite_launcher.py" 1>>"%LOG_FILE%" 2>&1

set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
    echo LEMATZIUM se cerro con error %EXIT_CODE%.
    echo Revisa el log: %LOG_FILE%
    pause
)
exit /b %EXIT_CODE%
'''
    if not path.exists() or path.read_text(encoding="utf-8", errors="ignore") != content:
        path.write_text(content, encoding="utf-8")
    return path.resolve()


def _ps_single_quote(value: str | Path) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _powershell_encoded_command(script: str) -> str:
    return base64.b64encode(script.encode("utf-16le")).decode("ascii")


def _run_powershell(script: str) -> None:
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise RuntimeError("No se encontro powershell.exe en el PATH de Windows.")

    completed = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-EncodedCommand",
            _powershell_encoded_command(script),
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    if completed.returncode != 0:
        details = []
        if completed.stdout.strip():
            details.append("STDOUT:\n" + completed.stdout.strip())
        if completed.stderr.strip():
            details.append("STDERR:\n" + completed.stderr.strip())
        detail_text = "\n\n".join(details) or "PowerShell no devolvio detalle adicional."
        raise RuntimeError(f"No se pudo crear/actualizar el acceso directo.\n{detail_text}")


def create_or_update_shortcut(
    *,
    suite_root: Path,
    shortcut_path: Path | None = None,
    icon_name: str | None = None,
) -> Path:
    suite_root = suite_root.resolve()
    shortcut_path = (shortcut_path or (_desktop_dir() / SHORTCUT_NAME)).resolve()
    runner_bat = ensure_dev_runner_bat(suite_root)
    icon_path = icon_asset_path(suite_root, icon_name)

    if not _is_windows():
        return shortcut_path

    shortcut_path.parent.mkdir(parents=True, exist_ok=True)

    # Nota: se usa -EncodedCommand para evitar fallas por acentos, espacios y rutas de OneDrive.
    icon_block = ""
    if icon_path is not None:
        icon_block = f"""
if (Test-Path -LiteralPath {_ps_single_quote(icon_path)}) {{
    $Shortcut.IconLocation = {_ps_single_quote(str(icon_path) + ',0')}
}}
"""

    powershell_script = f"""
$ErrorActionPreference = 'Stop'
$shortcutPath = {_ps_single_quote(shortcut_path)}
$runnerBat = {_ps_single_quote(runner_bat)}
$suiteRoot = {_ps_single_quote(suite_root)}

if (-not (Test-Path -LiteralPath (Split-Path -Parent $shortcutPath))) {{
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $shortcutPath) | Out-Null
}}

if (-not (Test-Path -LiteralPath $runnerBat)) {{
    throw "No existe el archivo BAT del lanzador DEV: $runnerBat"
}}

$cmdPath = $env:ComSpec
if ([string]::IsNullOrWhiteSpace($cmdPath)) {{
    $cmdPath = Join-Path $env:SystemRoot 'System32\\cmd.exe'
}}
if (-not (Test-Path -LiteralPath $cmdPath)) {{
    throw "No se encontro cmd.exe: $cmdPath"
}}

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($shortcutPath)
$Shortcut.TargetPath = $cmdPath
$Shortcut.Arguments = '/c "' + $runnerBat + '"'
$Shortcut.WorkingDirectory = $suiteRoot
$Shortcut.Description = 'LEMATZIUM en modo desarrollador'
$Shortcut.WindowStyle = 1
{icon_block}
$Shortcut.Save()
Write-Output $shortcutPath
"""
    _run_powershell(powershell_script)
    return shortcut_path


def sync_dev_shortcut_for_suite(suite_root: Path | None = None, *, icon_name: str | None = None) -> Path:
    suite_root = (suite_root or _suite_root_from_here()).resolve()
    prefs = load_prefs(suite_root)
    resolved_icon_name = _safe_icon_name(icon_name or prefs.get("icon"))
    return create_or_update_shortcut(suite_root=suite_root, icon_name=resolved_icon_name)


def main() -> int:
    parser = argparse.ArgumentParser(description="Crea o actualiza el acceso directo de LEMATZIUM en modo desarrollador.")
    parser.add_argument("--suite-root", default=str(_suite_root_from_here()))
    parser.add_argument("--icon-name", default=None)
    parser.add_argument("--shortcut-path", default=None)
    args = parser.parse_args()

    try:
        suite_root = Path(args.suite_root).resolve()
        if not suite_root.exists():
            raise FileNotFoundError(f"No existe la carpeta suite_root: {suite_root}")

        ensure_dev_runner_bat(suite_root)

        if args.shortcut_path:
            shortcut_path = create_or_update_shortcut(
                suite_root=suite_root,
                shortcut_path=Path(args.shortcut_path),
                icon_name=args.icon_name,
            )
        else:
            shortcut_path = sync_dev_shortcut_for_suite(suite_root, icon_name=args.icon_name)

        print(f"Acceso directo DEV actualizado: {shortcut_path}")
        return 0
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
