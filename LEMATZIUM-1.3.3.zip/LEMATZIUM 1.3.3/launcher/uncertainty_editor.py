from __future__ import annotations

"""Editor de fuentes de incertidumbre para LEMATZIUM.

Permite modificar las fuentes equivalentes a la hoja "Fuent. Incertidumbre" sin
editar directamente los libros Excel. Los cambios se guardan en
user_config/uncertainty_sources.local.json y son leídos por el módulo de metales.
"""

import copy
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any, Mapping

SUITE_ROOT = Path(__file__).resolve().parents[1]
MODULES_ROOT = SUITE_ROOT / "modules"
if str(MODULES_ROOT) not in sys.path:
    sys.path.insert(0, str(MODULES_ROOT))

from shared.tensile_unified.uncertainty import (  # noqa: E402
    DEFAULT_UNCERTAINTY_CONFIG,
    LOCAL_CONFIG_PATH,
    ensure_default_uncertainty_config_file,
    load_uncertainty_config,
    save_user_uncertainty_config,
)

TITLE = "LEMATZIUM · INCERTIDUMBRE"
GEOMETRY_LABELS = {
    "rectangular": "Plancha / rectangular",
    "circular": "Circular",
    "tubular": "Tubería / anular",
    "irregular": "Área nominal / irregular",
}

FORCE_FIELDS = (
    ("uncertainty_kN", "Incertidumbre (kN)"),
    ("resolution_kN", "Resolución (kN)"),
    ("drift_kN", "Deriva (kN)"),
    ("correction_kN", "Corrección no realizada (kN)"),
)

INSTRUMENT_FIELDS = (
    ("label", "Instrumento"),
    ("resolution_mm", "Resolución (mm)"),
    ("certificate_um", "Incertidumbre certificado (µm)"),
    ("drift_mm", "Deriva (mm)"),
    ("correction_mm", "Corrección no realizada (mm)"),
)

GEOMETRY_FIELDS = (
    ("force_cell", "Celda de fuerza", "auto / 12 / 30 / 60 / 120 / 300 / 600"),
    ("thickness_instrument", "Instrumento espesor / diámetro interior", "solo rectangular/tubería"),
    ("width_instrument", "Instrumento anchura", "solo rectangular"),
    ("diameter_instrument", "Instrumento diámetro", "solo circular"),
    ("inner_diameter_instrument", "Instrumento diámetro interior máx.", "solo tubería"),
    ("outer_diameter_instrument", "Instrumento diámetro exterior máx.", "solo tubería"),
    ("yield_inner_diameter_instrument", "Instrumento diámetro interior fluencia", "solo tubería"),
    ("yield_outer_diameter_instrument", "Instrumento diámetro exterior fluencia", "solo tubería"),
    ("elongation_instrument", "Instrumento elongación", "longitud calibrada/final"),
    ("dimension_repeatability_max_mpa", "Tubería máx.: componente diámetro interior", "replica celda C11"),
    ("dimension_reproducibility_max_mpa", "Tubería máx.: componente diámetro exterior", "replica celda C12"),
    ("repeatability_yield_mpa", "Repetibilidad fluencia (MPa)", ""),
    ("reproducibility_yield_mpa", "Reproducibilidad fluencia (MPa)", ""),
    ("repeatability_max_mpa", "Repetibilidad máximo (MPa)", ""),
    ("reproducibility_max_mpa", "Reproducibilidad máximo (MPa)", ""),
    ("repeatability_elongation_pct", "Repetibilidad elongación (%)", ""),
    ("reproducibility_elongation_pct", "Reproducibilidad elongación (%)", ""),
)


def _deep_get(data: Mapping[str, Any], *keys: str, default: Any = "") -> Any:
    current: Any = data
    for key in keys:
        if not isinstance(current, Mapping):
            return default
        current = current.get(key)
    return default if current is None else current


def _set_nested(data: dict[str, Any], path: tuple[str, ...], value: Any) -> None:
    current = data
    for key in path[:-1]:
        current = current.setdefault(key, {})
    current[path[-1]] = value


def _coerce_value(text: str) -> Any:
    raw = str(text or "").strip()
    if raw == "":
        return ""
    lowered = raw.lower()
    if lowered == "auto":
        return "auto"
    try:
        return float(raw.replace(",", "."))
    except Exception:
        return raw


class ScrollableFrame(ttk.Frame):
    def __init__(self, parent: tk.Widget) -> None:
        super().__init__(parent)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.v_scroll = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self.inner.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.v_scroll.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.v_scroll.grid(row=0, column=1, sticky="ns")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.canvas.bind("<Configure>", self._resize_inner)

    def _resize_inner(self, event: Any) -> None:
        self.canvas.itemconfigure(self.window_id, width=event.width)


class UncertaintyEditor(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(TITLE)
        self.geometry("1180x760")
        self.minsize(980, 620)
        self.config_data = load_uncertainty_config()
        self.entries: dict[tuple[str, ...], tk.StringVar] = {}
        self._build_ui()

    def _add_entry(self, parent: tk.Widget, row: int, column: int, path: tuple[str, ...], value: Any, width: int = 16) -> ttk.Entry:
        var = tk.StringVar(value="" if value is None else str(value))
        self.entries[path] = var
        entry = ttk.Entry(parent, textvariable=var, width=width)
        entry.grid(row=row, column=column, sticky="ew", padx=4, pady=3)
        return entry

    def _build_ui(self) -> None:
        header = ttk.Frame(self, padding=(14, 12, 14, 6))
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(0, weight=1)
        ttk.Label(header, text="INCERTIDUMBRE", font=("Segoe UI", 16, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text="Edición de fuentes compartidas de fuerza/área y fuentes independientes por geometría. Los cambios alimentan los comentarios del módulo de metales.",
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))
        self.path_var = tk.StringVar(value=f"Archivo local: {LOCAL_CONFIG_PATH}")
        ttk.Label(header, textvariable=self.path_var, foreground="#555555").grid(row=2, column=0, sticky="w", pady=(4, 0))

        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=1, column=0, sticky="nsew", padx=14, pady=8)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self._build_force_tab()
        self._build_area_tab()
        self._build_geometry_tab()

        buttons = ttk.Frame(self, padding=(14, 6, 14, 14))
        buttons.grid(row=2, column=0, sticky="ew")
        buttons.grid_columnconfigure(0, weight=1)
        ttk.Button(buttons, text="Restaurar valores Excel base", command=self.reset_defaults).grid(row=0, column=1, padx=4)
        ttk.Button(buttons, text="Guardar cambios", command=self.save).grid(row=0, column=2, padx=4)
        ttk.Button(buttons, text="Cerrar", command=self.destroy).grid(row=0, column=3, padx=4)

    def _build_force_tab(self) -> None:
        tab = ScrollableFrame(self.notebook)
        self.notebook.add(tab, text="Fuerza MUE 600 kN")
        frame = tab.inner
        ttk.Label(frame, text="Fuentes de Incertidumbre Fuerza (kN)", font=("Segoe UI", 11, "bold")).grid(row=0, column=0, columnspan=5, sticky="w", pady=(8, 10))
        headers = ["Celda"] + [label for _key, label in FORCE_FIELDS]
        for col, text in enumerate(headers):
            ttk.Label(frame, text=text, font=("Segoe UI", 9, "bold")).grid(row=1, column=col, sticky="w", padx=4)
            frame.grid_columnconfigure(col, weight=1 if col else 0)
        cells = _deep_get(self.config_data, "shared", "force", "cells", default={})
        for row, cell in enumerate(sorted(cells.keys(), key=lambda x: float(x)), start=2):
            ttk.Label(frame, text=str(cell)).grid(row=row, column=0, sticky="w", padx=4, pady=3)
            for col, (key, _label) in enumerate(FORCE_FIELDS, start=1):
                self._add_entry(frame, row, col, ("shared", "force", "cells", str(cell), key), cells[cell].get(key, ""))

    def _build_area_tab(self) -> None:
        tab = ScrollableFrame(self.notebook)
        self.notebook.add(tab, text="Área e instrumentos")
        frame = tab.inner
        ttk.Label(frame, text="Fuentes de Incertidumbre Área (Espesor / Ancho / Diámetro)", font=("Segoe UI", 11, "bold")).grid(row=0, column=0, columnspan=6, sticky="w", pady=(8, 10))
        headers = ["ID"] + [label for _key, label in INSTRUMENT_FIELDS]
        for col, text in enumerate(headers):
            ttk.Label(frame, text=text, font=("Segoe UI", 9, "bold")).grid(row=1, column=col, sticky="w", padx=4)
            frame.grid_columnconfigure(col, weight=1 if col else 0)
        instruments = _deep_get(self.config_data, "shared", "area", "instruments", default={})
        row = 2
        for instr_id, values in instruments.items():
            ttk.Label(frame, text=str(instr_id)).grid(row=row, column=0, sticky="w", padx=4, pady=3)
            for col, (key, _label) in enumerate(INSTRUMENT_FIELDS, start=1):
                self._add_entry(frame, row, col, ("shared", "area", "instruments", str(instr_id), key), values.get(key, ""), width=26 if key == "label" else 14)
            row += 1
        row += 1
        ttk.Label(frame, text="Redondeo Ancho/Espesor/Diámetro (mm)", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=3, sticky="w", pady=(14, 6))
        rounding = _deep_get(self.config_data, "shared", "area", "rounding_mm", default={})
        labels = (("ge_5", "Mayor o igual a 5 mm"), ("between_2_5_and_5", "2.5 ≤ e < 5"), ("lt_2_5", "0.5 ≤ e < 2.5"))
        for i, (key, label) in enumerate(labels, start=row + 1):
            ttk.Label(frame, text=label).grid(row=i, column=0, sticky="w", padx=4, pady=3)
            self._add_entry(frame, i, 1, ("shared", "area", "rounding_mm", key), rounding.get(key, ""))

    def _build_geometry_tab(self) -> None:
        tab = ScrollableFrame(self.notebook)
        self.notebook.add(tab, text="Por geometría")
        frame = tab.inner
        instruments = list((_deep_get(self.config_data, "shared", "area", "instruments", default={}) or {}).keys())
        ttk.Label(frame, text="Fuentes independientes por tipo de geometría", font=("Segoe UI", 11, "bold")).grid(row=0, column=0, columnspan=5, sticky="w", pady=(8, 10))
        ttk.Label(frame, text="Use los ID de instrumentos disponibles: " + ", ".join(instruments), foreground="#555555", wraplength=1050).grid(row=1, column=0, columnspan=5, sticky="w", pady=(0, 10))
        geometries = _deep_get(self.config_data, "geometries", default={})
        row = 2
        for geom_key, geom_data in geometries.items():
            title = GEOMETRY_LABELS.get(str(geom_key), str(geom_key))
            ttk.Label(frame, text=title, font=("Segoe UI", 10, "bold")).grid(row=row, column=0, columnspan=3, sticky="w", pady=(12, 4))
            row += 1
            ttk.Label(frame, text="Campo", font=("Segoe UI", 9, "bold")).grid(row=row, column=0, sticky="w", padx=4)
            ttk.Label(frame, text="Valor", font=("Segoe UI", 9, "bold")).grid(row=row, column=1, sticky="w", padx=4)
            ttk.Label(frame, text="Referencia", font=("Segoe UI", 9, "bold")).grid(row=row, column=2, sticky="w", padx=4)
            row += 1
            for field_key, label, note in GEOMETRY_FIELDS:
                if field_key not in geom_data and field_key.endswith("instrument"):
                    # Mantiene visible solo lo que aplica a la geometría, evitando ruido.
                    continue
                ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=4, pady=3)
                self._add_entry(frame, row, 1, ("geometries", str(geom_key), field_key), geom_data.get(field_key, ""), width=28)
                ttk.Label(frame, text=note).grid(row=row, column=2, sticky="w", padx=4, pady=3)
                row += 1
            frame.grid_columnconfigure(1, weight=1)

    def save(self) -> None:
        data = copy.deepcopy(load_uncertainty_config())
        for path, var in self.entries.items():
            _set_nested(data, path, _coerce_value(var.get()))
        try:
            ensure_default_uncertainty_config_file()
            save_user_uncertainty_config(data)
            messagebox.showinfo("Guardado", f"Fuentes de incertidumbre guardadas correctamente.\n\n{LOCAL_CONFIG_PATH}", parent=self)
            self.path_var.set(f"Archivo local: {LOCAL_CONFIG_PATH}")
        except Exception as exc:
            messagebox.showerror("No se pudo guardar", str(exc), parent=self)

    def reset_defaults(self) -> None:
        if not messagebox.askyesno("Restaurar", "¿Restaurar en esta pantalla los valores base de los Excel entregados?\n\nDebe presionar Guardar cambios para aplicarlos.", parent=self):
            return
        self.config_data = copy.deepcopy(DEFAULT_UNCERTAINTY_CONFIG)
        for widget in self.notebook.winfo_children():
            widget.destroy()
        self.entries.clear()
        self._build_force_tab()
        self._build_area_tab()
        self._build_geometry_tab()


def main() -> int:
    ensure_default_uncertainty_config_file()
    app = UncertaintyEditor()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
