from __future__ import annotations

"""Funciones de ejecución para el HUB LEMATZIUM.

Se separan del archivo visual principal para que el launcher sea más fácil de
mantener y para que la apertura de módulos, selección de intérprete y validación
de dependencias tengan una sola implementación.
"""

import os
import subprocess
import sys
from pathlib import Path
from tkinter import messagebox
from typing import Mapping, Sequence


def candidate_python_executables(module_root: Path, *, suite_root: Path | None = None) -> list[Path]:
    """Devuelve intérpretes Python candidatos, priorizando entornos locales."""
    candidates: list[Path] = []
    env_python = os.environ.get("LEMATZIUM_PYTHON") or os.environ.get("PYTHON_EXECUTABLE")
    if env_python:
        candidates.append(Path(env_python))

    roots = [module_root]
    if suite_root is not None:
        roots.extend([suite_root, suite_root.parent])

    for root in roots:
        candidates.extend(
            [
                root / ".venv" / "Scripts" / "python.exe",
                root / "venv" / "Scripts" / "python.exe",
                root / ".venv" / "bin" / "python",
                root / "venv" / "bin" / "python",
            ]
        )
    candidates.append(Path(sys.executable))

    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except Exception:
            resolved = candidate
        key = str(resolved).lower()
        if key in seen or not resolved.exists():
            continue
        seen.add(key)
        unique.append(resolved)
    return unique


def python_has_imports(
    python_exe: Path,
    imports: Sequence[str],
    *,
    cwd: Path,
    env: Mapping[str, str],
    timeout_seconds: int = 12,
) -> tuple[bool, str]:
    """Verifica si un intérprete puede importar las librerías requeridas."""
    if not imports:
        return True, ""
    code = "\n".join(f"import {name}" for name in imports)
    try:
        completed = subprocess.run(
            [str(python_exe), "-c", code],
            cwd=str(cwd),
            env=dict(env),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_seconds,
            check=False,
        )
    except Exception as exc:
        return False, str(exc)
    if completed.returncode == 0:
        return True, ""
    return False, (completed.stderr or completed.stdout or "Dependencias no disponibles.").strip()


def install_missing_dependencies(
    python_exe: Path,
    module_key: str,
    *,
    cwd: Path,
    env: Mapping[str, str],
    packages_by_module: Mapping[str, Sequence[str]],
    root,
    status_var=None,
) -> bool:
    """Pregunta al usuario e instala dependencias con pip cuando faltan."""
    packages = packages_by_module.get(module_key, packages_by_module.get("tensile_unified", ()))
    if not packages:
        return False

    command_text = f'"{python_exe}" -m pip install ' + " ".join(packages)
    proceed = messagebox.askyesno(
        "Dependencias faltantes",
        "El módulo requiere librerías de Python que no están instaladas en el intérprete seleccionado.\n\n"
        "Se detectó, por ejemplo, la ausencia de matplotlib.\n\n"
        "¿Deseas intentar instalar automáticamente las dependencias ahora?\n\n"
        f"Comando:\n{command_text}",
        parent=root,
    )
    if not proceed:
        messagebox.showinfo(
            "Instalación pendiente",
            "Instala las dependencias y vuelve a abrir el módulo.\n\n"
            f"Comando sugerido:\n{command_text}",
            parent=root,
        )
        return False

    try:
        if status_var is not None:
            status_var.set("Instalando dependencias del módulo...")
        try:
            root.update_idletasks()
        except Exception:
            pass
        completed = subprocess.run(
            [str(python_exe), "-m", "pip", "install", *packages],
            cwd=str(cwd),
            env=dict(env),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=300,
            check=False,
        )
    except Exception as exc:
        messagebox.showerror("No se pudieron instalar dependencias", str(exc), parent=root)
        return False

    if completed.returncode != 0:
        messagebox.showerror(
            "No se pudieron instalar dependencias",
            "pip terminó con error.\n\n"
            f"Comando sugerido:\n{command_text}\n\n"
            f"Detalle:\n{(completed.stderr or completed.stdout)[-1800:]}",
            parent=root,
        )
        return False

    messagebox.showinfo(
        "Dependencias instaladas",
        "La instalación terminó correctamente. Se abrirá el módulo.",
        parent=root,
    )
    return True


def select_python_for_module(
    module_key: str,
    *,
    cwd: Path,
    env: Mapping[str, str],
    required_imports_by_module: Mapping[str, Sequence[str]],
    packages_by_module: Mapping[str, Sequence[str]],
    suite_root: Path,
    root,
    status_var=None,
) -> Path | None:
    """Selecciona un intérprete válido para abrir un módulo Python."""
    required = tuple(required_imports_by_module.get(module_key, ()))
    candidates = candidate_python_executables(cwd, suite_root=suite_root)
    last_error = ""

    for python_exe in candidates:
        ok, error = python_has_imports(python_exe, required, cwd=cwd, env=env)
        if ok:
            return python_exe
        last_error = error

    python_exe = candidates[0] if candidates else Path(sys.executable)
    if install_missing_dependencies(
        python_exe,
        module_key,
        cwd=cwd,
        env=env,
        packages_by_module=packages_by_module,
        root=root,
        status_var=status_var,
    ):
        ok, error = python_has_imports(python_exe, required, cwd=cwd, env=env)
        if ok:
            return python_exe
        last_error = error

    messagebox.showerror(
        "No se pudo iniciar el módulo",
        "No se encontró un intérprete de Python con las dependencias requeridas.\n\n"
        "El módulo no se abrirá para evitar el traceback de arranque.\n\n"
        f"Último detalle técnico:\n{last_error[-1200:]}",
        parent=root,
    )
    return None


def popen_normal_window(args: list[str], *, cwd: str, env: Mapping[str, str] | None = None) -> subprocess.Popen:
    """Abre procesos hijos en ventana normal aunque el HUB esté minimizado."""
    kwargs: dict[str, object] = {"cwd": cwd}
    if env is not None:
        kwargs["env"] = dict(env)
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 1  # SW_SHOWNORMAL
        kwargs["startupinfo"] = startupinfo
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    return subprocess.Popen(args, **kwargs)


__all__ = [
    "candidate_python_executables",
    "install_missing_dependencies",
    "popen_normal_window",
    "python_has_imports",
    "select_python_for_module",
]
