from __future__ import annotations

"""Validación rápida del refactor LEMATZIUM.

Ejecutar desde la raíz del proyecto:
    python tools/validate_refactor.py

La validación compila todos los .py e importa los adaptadores compartidos sin
abrir ventanas Tkinter ni generar reportes.
"""

import compileall
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULES_DIR = ROOT / "modules"
LAUNCHER_DIR = ROOT / "launcher"

for path in (
    ROOT,
    MODULES_DIR,
    MODULES_DIR / "module_1_drop1mpa",
    MODULES_DIR / "module_2_offset02",
    MODULES_DIR / "module_tensile_unified",
    LAUNCHER_DIR,
):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def main() -> int:
    ok = compileall.compile_dir(str(ROOT), quiet=1)
    if not ok:
        print("ERROR: falló la compilación Python.")
        return 1

    from shared.bootstrap import run_module_main  # noqa: F401
    from shared.preferences import PreferenceStore  # noqa: F401
    from shared.report_templates import ACCREDITATION_NON_ACCREDITED  # noqa: F401
    from shared.runtime_theme import load_runtime_theme  # noqa: F401
    from shared.ot_pdf_reader import OTContext  # noqa: F401
    from launch_runtime import candidate_python_executables  # noqa: F401
    from lematzium_modulo1.reports.templates import get_report_template_path as get_m1_template
    from lematzium_modulo2.reports.ot_pdf_reader import parse_ot_pdf as parse_m2_ot  # noqa: F401
    from lematzium_tensile_unified.reports.templates import get_report_template_path as get_unified_template

    m1_template = get_m1_template("non_accredited")
    unified_template = get_unified_template("non_accredited")
    if not m1_template.exists() or not unified_template.exists():
        print("ERROR: no se encontraron plantillas institucionales.")
        return 1

    print("OK - refactor validado: compilación, imports compartidos y plantillas.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
