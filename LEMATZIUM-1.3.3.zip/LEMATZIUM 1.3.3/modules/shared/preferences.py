from __future__ import annotations

"""Persistencia común de preferencias locales para módulos LEMATZIUM."""

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

APP_DIR_NAME = "LEMATZIUM"
EXPORT_OUTPUT_DIR_KEY = "export_output_dir"
LAST_OPEN_DIR_KEY = "last_open_dir"


def get_app_prefs_dir(app_dir_name: str = APP_DIR_NAME) -> Path:
    home = Path.home()
    if os.name == "nt":
        base_dir = home / "AppData" / "Local" / app_dir_name
    else:
        base_dir = home / f".{app_dir_name.lower()}"
    base_dir.mkdir(parents=True, exist_ok=True)
    return base_dir


@dataclass(frozen=True)
class PreferenceStore:
    filename: str
    app_dir_name: str = APP_DIR_NAME

    @property
    def path(self) -> Path:
        return get_app_prefs_dir(self.app_dir_name) / self.filename

    def load(self) -> dict[str, Any]:
        prefs_path = self.path
        if not prefs_path.exists():
            return {}
        try:
            data = json.loads(prefs_path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        return data if isinstance(data, dict) else {}

    def save(self, prefs: dict[str, Any]) -> None:
        self.path.write_text(json.dumps(prefs, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_text(self, key: str) -> str:
        return str(self.load().get(key, "") or "").strip()

    def set_text(self, key: str, value: str) -> None:
        clean_value = str(value or "").strip()
        if not clean_value:
            return
        prefs = self.load()
        prefs[key] = clean_value
        self.save(prefs)


__all__ = [
    "APP_DIR_NAME",
    "EXPORT_OUTPUT_DIR_KEY",
    "LAST_OPEN_DIR_KEY",
    "PreferenceStore",
    "get_app_prefs_dir",
]
