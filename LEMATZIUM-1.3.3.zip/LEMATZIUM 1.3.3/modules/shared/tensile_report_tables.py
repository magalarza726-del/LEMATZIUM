from __future__ import annotations

import math
import re
from typing import Any, Optional, Sequence

from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

try:
    from shared.tensile_geometry import (
        SHAPE_CIRCULAR,
        SHAPE_IRREGULAR,
        SHAPE_RECTANGULAR,
        SHAPE_TUBULAR,
        normalize_shape,
    )
except Exception:  # pragma: no cover - fallback para ejecuciones aisladas
    SHAPE_RECTANGULAR = "Rectangular"
    SHAPE_CIRCULAR = "Circular"
    SHAPE_IRREGULAR = "Irregular"
    SHAPE_TUBULAR = "Tubería"

    def normalize_shape(shape: Any, default: str = SHAPE_RECTANGULAR) -> str:
        text = "" if shape is None else str(shape).strip().lower()
        if text == "circular":
            return SHAPE_CIRCULAR
        if text == "irregular":
            return SHAPE_IRREGULAR
        return default


ARIAL = "Arial"
GEOMETRY_TABLE_FONT_SIZE_PT = 8
GEOMETRY_TABLE_BORDER_SIZE = "6"


def _safe(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", str(value).replace("\ufeff", ""))


def _format_float(value: Optional[float], ndigits: int = 2) -> str:
    try:
        if value is None:
            return ""
        number = float(value)
        if math.isnan(number) or math.isinf(number):
            return ""
        return f"{number:.{ndigits}f}"
    except Exception:
        return ""


def _cm_to_dxa(width_cm: float) -> int:
    """Convierte centímetros a twips/dxa para Word."""
    return max(1, int(round(width_cm * 1440 / 2.54)))


def _set_table_borders(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)

    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), GEOMETRY_TABLE_BORDER_SIZE)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "000000")


def _set_table_border_nil(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "nil")


def _set_cell_border(cell, **edges: str) -> None:
    """Set individual cell borders (OOXML). Values: 'single', 'nil', etc."""
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_borders = tc_pr.first_child_found_in("w:tcBorders")
    if tc_borders is None:
        tc_borders = OxmlElement("w:tcBorders")
        tc_pr.append(tc_borders)
    for edge, val in edges.items():
        edge_el = tc_borders.find(qn(f"w:{edge}"))
        if edge_el is None:
            edge_el = OxmlElement(f"w:{edge}")
            tc_borders.append(edge_el)
        edge_el.set(qn("w:val"), val)
        if val != "nil":
            edge_el.set(qn("w:sz"), GEOMETRY_TABLE_BORDER_SIZE)
            edge_el.set(qn("w:space"), "0")
            edge_el.set(qn("w:color"), "000000")


def _hide_spacer_columns(table, visible_columns: int) -> None:
    """Make trailing spacer columns invisible while preserving the shared grid."""
    if visible_columns >= len(table.columns):
        return
    for row in table.rows:
        # Ensure the right edge of the last visible cell is the visible end of the table.
        if visible_columns > 0:
            _set_cell_border(row.cells[visible_columns - 1], right="single")
        for col_index in range(visible_columns, len(row.cells)):
            cell = row.cells[col_index]
            _set_cell_text(cell, "")
            _set_cell_border(cell, top="nil", left="nil", bottom="nil", right="nil", insideH="nil", insideV="nil")


def _align_widths_to_result_grid(widths_cm: Sequence[float], result_widths_cm: Optional[Sequence[float]] = None) -> tuple[list[float], int]:
    """Return table widths and visible column count.

    If result_widths_cm is provided, the visible geometry columns use the first
    columns of that grid and invisible spacer columns are added with the
    remaining widths. This keeps cell borders in phase with the results table
    without visually stretching the geometry table.
    """
    visible = len(widths_cm)
    if not result_widths_cm:
        return [float(w) for w in widths_cm], visible
    result = [float(w) for w in result_widths_cm]
    if len(result) < visible:
        # No hay grilla suficiente para alinear todas las columnas visibles;
        # se conserva la geometría compacta original.
        return [float(w) for w in widths_cm], visible
    # Cuando la grilla de resultados tiene el mismo número de columnas visibles
    # también se debe usar esa grilla. Esto evita que la tabla rectangular de
    # fluencia superior quede desfasada por usar anchos propios de geometría.
    return result, visible


def _set_table_fixed_widths(table, widths_cm: Sequence[float]) -> None:
    """Fija el ancho real de columnas para evitar tablas demasiado anchas o AutoFit."""
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    tbl = table._tbl
    tbl_pr = tbl.tblPr

    tbl_jc = tbl_pr.find(qn("w:jc"))
    if tbl_jc is None:
        tbl_jc = OxmlElement("w:jc")
        tbl_pr.append(tbl_jc)
    tbl_jc.set(qn("w:val"), "center")

    for tbl_ind in list(tbl_pr.findall(qn("w:tblInd"))):
        tbl_pr.remove(tbl_ind)

    tbl_layout = tbl_pr.find(qn("w:tblLayout"))
    if tbl_layout is None:
        tbl_layout = OxmlElement("w:tblLayout")
        tbl_pr.append(tbl_layout)
    tbl_layout.set(qn("w:type"), "fixed")

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), str(_cm_to_dxa(sum(widths_cm))))

    existing_grid = tbl.find(qn("w:tblGrid"))
    if existing_grid is not None:
        tbl.remove(existing_grid)

    tbl_grid = OxmlElement("w:tblGrid")
    for width in widths_cm:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(_cm_to_dxa(width)))
        tbl_grid.append(grid_col)
    tbl.insert(1, tbl_grid)

    for row in table.rows:
        for column_index, width in enumerate(widths_cm):
            cell = row.cells[column_index]
            cell.width = Cm(width)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:type"), "dxa")
            tc_w.set(qn("w:w"), str(_cm_to_dxa(width)))


def _set_cell_text(
    cell,
    text: str,
    *,
    bold: bool = False,
    align: int = WD_ALIGN_PARAGRAPH.CENTER,
    font_size: int = GEOMETRY_TABLE_FONT_SIZE_PT,
) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = align
    run = paragraph.add_run(_safe(text))
    run.bold = bold
    run.font.name = ARIAL
    run.font.size = Pt(font_size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _make_geometry_table(document, rows: int, cols: int, widths_cm: Sequence[float]):
    table = document.add_table(rows=rows, cols=cols)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    _set_table_fixed_widths(table, widths_cm)
    _set_table_borders(table)
    return table


def geometry_shape_label(geometry) -> str:
    """Devuelve la etiqueta normalizada para el reporte.

    Soporta tanto el modelo histórico ``shared.tensile_geometry``
    (``shape``, ``side1_mm``, ``side2_mm``) como el modelo nuevo
    ``shared.tensile_unified.TensileGeometry`` (``geometry_type``,
    ``thickness_mm``, ``width_mm``).
    """
    shape_value = getattr(geometry, "shape", None)
    if shape_value is None:
        shape_value = getattr(geometry, "geometry_type", None)
    return normalize_shape(shape_value, default=SHAPE_RECTANGULAR)


def _geometry_value(geometry, *names: str):
    """Lee el primer atributo disponible, soportando modelos nuevos y antiguos."""
    for name in names:
        try:
            value = getattr(geometry, name)
        except Exception:
            continue
        if callable(value):
            try:
                value = value()
            except Exception:
                continue
        if value is not None:
            return value
    return None


def _geometry_area(geometry):
    area = _geometry_value(geometry, "area_mm2", "area_mm2_manual")
    if area is not None:
        return area
    try:
        return geometry.effective_area_mm2
    except Exception:
        return None


def geometry_shape_report_label(geometry) -> str:
    """Etiqueta visual de forma usada en los reportes institucionales."""
    shape = geometry_shape_label(geometry)
    if shape == SHAPE_CIRCULAR:
        return "Circular"
    if shape == SHAPE_TUBULAR:
        return "Tubería"
    if shape == SHAPE_IRREGULAR:
        # La forma debe mantenerse como clasificación geométrica.
        # El área queda solamente como columna de dimensión cuando aplica.
        return "Irregular"
    return "Plana"


def geometry_table_spec(geometry, specimen_id: str):
    """Devuelve encabezados, unidades, valores y anchos según la geometría.

    Esta tabla replica los ejemplos de reporte: la forma se informa como texto
    previo (``Forma: ...``) y la tabla no se estira para igualar el ancho de la
    tabla de resultados. No se incluyen columnas auxiliares como área o probeta;
    la primera columna identifica la fila de unidades y el código de muestra.
    """
    shape = geometry_shape_label(geometry)

    if shape == SHAPE_CIRCULAR:
        headers = ["", "Diámetro", "Longitud calibrada"]
        units = ["Unidades", "mm", "mm"]
        values = [
            _safe(specimen_id),
            _format_float(_geometry_value(geometry, "diameter_mm"), 2),
            _format_float(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = [2.7, 5.1, 5.1]
    elif shape == SHAPE_TUBULAR:
        headers = ["", "Diámetro interior", "Diámetro exterior", "Longitud calibrada"]
        units = ["Unidades", "mm", "mm", "mm"]
        values = [
            _safe(specimen_id),
            _format_float(_geometry_value(geometry, "side1_mm", "thickness_mm"), 2),
            _format_float(_geometry_value(geometry, "side2_mm", "width_mm"), 2),
            _format_float(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = [2.7, 3.6, 3.6, 4.1]
    elif shape == SHAPE_IRREGULAR:
        headers = ["", "Área", "Longitud calibrada"]
        units = ["Unidades", "mm2", "mm"]
        values = [
            _safe(specimen_id),
            _format_float(_geometry_area(geometry), 2),
            _format_float(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = [2.7, 5.1, 5.1]
    else:
        headers = ["", "Espesor", "Anchura", "Longitud calibrada"]
        units = ["Unidades", "mm", "mm", "mm"]
        values = [
            _safe(specimen_id),
            _format_float(_geometry_value(geometry, "side1_mm", "thickness_mm"), 3),
            _format_float(_geometry_value(geometry, "side2_mm", "width_mm"), 2),
            _format_float(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = [2.7, 3.6, 3.6, 4.1]

    return headers, units, values, widths


def _usable_width_cm(document) -> float:
    try:
        section = document.sections[0]
        width = section.page_width - section.left_margin - section.right_margin
        return max(1.0, float(width.cm))
    except Exception:
        return 16.5


def _add_forma_paragraph(document, geometry, table_width_cm: float) -> None:
    # La etiqueta se coloca dentro de una tabla invisible, centrada y con el
    # mismo ancho real que la tabla de geometría. Así "Forma:" empieza
    # exactamente en el mismo borde izquierdo de la tabla, sin depender de
    # sangrías de párrafo que Word/LibreOffice pueden interpretar distinto.
    table = document.add_table(rows=1, cols=1)
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    _set_table_fixed_widths(table, [float(table_width_cm)])
    _set_table_border_nil(table)
    cell = table.cell(0, 0)
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run(f"Forma: {geometry_shape_report_label(geometry)}")
    run.font.name = ARIAL
    run.font.size = Pt(GEOMETRY_TABLE_FONT_SIZE_PT)


def build_geometry_table(document, geometry, specimen_id: str, result_widths_cm: Optional[Sequence[float]] = None):
    """Construye la tabla editable de geometría según los ejemplos Word.

    Casos:
    - Rectangular/plana: Espesor | Anchura | Longitud calibrada.
    - Circular/varilla: Diámetro | Longitud calibrada.
    - Irregular/área: Área | Longitud calibrada.

    Cuando se entrega result_widths_cm, la tabla usa la misma grilla que la
    tabla de resultados: las columnas visibles quedan alineadas celda con celda
    y las columnas sobrantes se vuelven invisibles. Así no se dibuja una
    extensión artificial de la tabla superior.
    """
    headers, units, values, widths = geometry_table_spec(geometry, specimen_id)
    table_widths, visible_columns = _align_widths_to_result_grid(widths, result_widths_cm)
    _add_forma_paragraph(document, geometry, sum(table_widths))
    table = _make_geometry_table(document, 3, len(table_widths), table_widths)

    rows = (headers, units, values)
    for row_index, row_values in enumerate(rows):
        for col, text in enumerate(row_values):
            _set_cell_text(table.cell(row_index, col), text, bold=(row_index == 0 or (row_index == 1 and col == 0)))
        for col in range(len(row_values), len(table_widths)):
            _set_cell_text(table.cell(row_index, col), "")

    _hide_spacer_columns(table, visible_columns)
    return table


__all__ = [
    "build_geometry_table",
    "geometry_shape_label",
    "geometry_table_spec",
    "geometry_shape_report_label",
]
