from __future__ import annotations

import copy
from pathlib import Path
from typing import Iterable, Optional, Sequence

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

DEFAULT_REPORT_BODY_PLACEHOLDERS = ("{{REPORT_BODY}}", "[[REPORT_BODY]]", "{{CUERPO_REPORTE}}")


def cm_to_dxa(width_cm: float) -> int:
    """Convert centimeters to Word twips/dxa."""
    return max(1, int(round(float(width_cm) * 1440 / 2.54)))


def usable_width_cm(document: Document) -> float:
    """Return the approximate usable width of the first section in centimeters."""
    try:
        section = document.sections[0]
        width = section.page_width - section.left_margin - section.right_margin
        return max(1.0, float(width.cm))
    except Exception:
        return 16.5


def _safe_xpath(element, xpath: str):
    try:
        return list(element.xpath(xpath))
    except Exception:
        return []


def _document_parts(document: Document, *, include_headers_footers: bool = True):
    yield document.element.body
    if include_headers_footers:
        for section in document.sections:
            for part in (section.header, section.first_page_header, section.even_page_header,
                         section.footer, section.first_page_footer, section.even_page_footer):
                try:
                    yield part._element
                except Exception:
                    continue


def remove_document_protection(document: Document) -> None:
    """Remove Word editing restrictions and editable-range markers.

    This keeps the document as a normal editable .docx. It intentionally does
    not alter institutional header/footer content; it only removes protection
    settings and permission markers that make editing feel locked.
    """
    settings_el = document.settings.element
    for tag in (
        './/w:documentProtection',
        './/w:writeProtection',
        './/w:readOnlyRecommended',
        './/w:formsDesign',
    ):
        for element in _safe_xpath(settings_el, tag):
            parent = element.getparent()
            if parent is not None:
                parent.remove(element)

    # Remove editable range locks in the body and in headers/footers.
    for part in _document_parts(document, include_headers_footers=True):
        for tag in ('.//w:permStart', './/w:permEnd'):
            for element in _safe_xpath(part, tag):
                parent = element.getparent()
                if parent is not None:
                    parent.remove(element)


def remove_leading_empty_paragraphs(document: Document) -> None:
    """Remove empty body paragraphs inherited from templates before adding content."""
    for paragraph in list(document.paragraphs):
        if paragraph.text.strip():
            break
        parent = paragraph._element.getparent()
        if parent is not None:
            parent.remove(paragraph._element)


def remove_report_body_placeholders(
    document: Document,
    placeholders: Sequence[str] = DEFAULT_REPORT_BODY_PLACEHOLDERS,
) -> None:
    """Remove report-body marker text from a template, if present.

    New templates may place {{REPORT_BODY}} or [[REPORT_BODY]] where the dynamic
    content conceptually starts. The current exporters still append the dynamic
    body at the document body level, but this function makes such templates
    clean and avoids leaving visible marker text in the final Word file.
    """
    placeholder_set = tuple(placeholders)
    for paragraph in list(document.paragraphs):
        original = paragraph.text
        if not any(marker in original for marker in placeholder_set):
            continue
        for run in paragraph.runs:
            text = run.text
            for marker in placeholder_set:
                text = text.replace(marker, "")
            run.text = text
        if not paragraph.text.strip():
            parent = paragraph._element.getparent()
            if parent is not None:
                parent.remove(paragraph._element)


def _set_tbl_layout_fixed(table) -> None:
    tbl_pr = table._tbl.tblPr
    layout = tbl_pr.find(qn('w:tblLayout'))
    if layout is None:
        layout = OxmlElement('w:tblLayout')
        tbl_pr.append(layout)
    layout.set(qn('w:type'), 'fixed')


def _set_tbl_width(table, width_cm: float) -> None:
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn('w:tblW'))
    if tbl_w is not None and tbl_w.get(qn('w:w')):
        # No sobrescribir anchos definidos por los generadores de reporte.
        # Esto permite que la tabla de geometría conserve su ancho compacto y
        # no se fuerce al ancho de la tabla de resultados.
        return
    if tbl_w is None:
        tbl_w = OxmlElement('w:tblW')
        tbl_pr.append(tbl_w)
    tbl_w.set(qn('w:type'), 'dxa')
    tbl_w.set(qn('w:w'), str(cm_to_dxa(width_cm)))


def _ensure_cell_widths(table, max_width_cm: float) -> None:
    if not table.rows:
        return
    try:
        column_count = max(len(row.cells) for row in table.rows) or 1
    except Exception:
        column_count = 1
    default_cell_width = max_width_cm / column_count
    for row in table.rows:
        for cell in row.cells:
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn('w:tcW'))
            if tc_w is None or not tc_w.get(qn('w:w')):
                tc_w = tc_w or OxmlElement('w:tcW')
                if tc_w.getparent() is None:
                    tc_pr.append(tc_w)
                tc_w.set(qn('w:type'), 'dxa')
                tc_w.set(qn('w:w'), str(cm_to_dxa(default_cell_width)))


def prevent_row_splitting(table) -> None:
    """Avoid row breaks across pages, which makes Word reports easier to edit."""
    for row in table.rows:
        tr_pr = row._tr.get_or_add_trPr()
        if tr_pr.find(qn('w:cantSplit')) is None:
            tr_pr.append(OxmlElement('w:cantSplit'))


def normalize_table_for_editing(table, *, max_width_cm: Optional[float] = None) -> None:
    """Keep a table as a real editable Word table with a stable fixed layout."""
    try:
        table.autofit = False
    except Exception:
        pass
    try:
        _set_tbl_layout_fixed(table)
        if max_width_cm:
            _set_tbl_width(table, max_width_cm)
            _ensure_cell_widths(table, max_width_cm)
        prevent_row_splitting(table)
    except Exception:
        # A cleanup function must never prevent report export.
        return


def iter_all_tables(document: Document, *, include_headers_footers: bool = True):
    for table in document.tables:
        yield table
    if include_headers_footers:
        for section in document.sections:
            for part in (section.header, section.first_page_header, section.even_page_header,
                         section.footer, section.first_page_footer, section.even_page_footer):
                for table in getattr(part, 'tables', []):
                    yield table


def convert_body_floating_images_to_inline(document: Document) -> int:
    """Convert floating drawing anchors in the document body to inline drawings.

    Header/footer logos are intentionally not touched because their placement is
    usually part of the institutional template. Generated report graphs are
    inserted inline by add_inline_picture().
    """
    converted = 0
    body = document.element.body
    for anchor in list(_safe_xpath(body, './/wp:anchor')):
        inline = OxmlElement('wp:inline')
        for attr in ('distT', 'distB', 'distL', 'distR'):
            value = anchor.get(qn(f'wp:{attr}')) or '0'
            inline.set(qn(f'wp:{attr}'), value)
        for child_tag in ('wp:extent', 'wp:effectExtent', 'wp:docPr', 'wp:cNvGraphicFramePr', 'a:graphic'):
            child = anchor.find(qn(child_tag))
            if child is not None:
                inline.append(copy.deepcopy(child))
        parent = anchor.getparent()
        if parent is not None and len(inline):
            parent.replace(anchor, inline)
            converted += 1
    return converted


def add_inline_picture(paragraph, image_path: str | Path, *, width_cm: float, center: bool = True):
    """Insert a picture as an inline Word image, never as a floating object."""
    if center:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    return run.add_picture(str(image_path), width=Cm(width_cm))


def uniquify_drawing_docpr_ids(document: Document) -> int:
    """Renumber all wp:docPr ids so Word does not repair the document.

    python-docx starts inserted images with id=1 in the body. Institutional
    templates may already contain header/footer images with the same id.
    Microsoft Word can open those files with the warning "contenido no
    legible" and repair the duplicate drawing properties. This final pass
    assigns unique sequential ids across body, headers and footers.
    """
    next_id = 1
    changed = 0
    seen: set[str] = set()
    for part in _document_parts(document, include_headers_footers=True):
        for doc_pr in _safe_xpath(part, './/wp:docPr'):
            new_value = str(next_id)
            old_value = doc_pr.get('id')
            if old_value != new_value or old_value in seen:
                doc_pr.set('id', new_value)
                changed += 1
            seen.add(new_value)
            next_id += 1
    return changed



def _rpr_font_names(r_pr) -> set[str]:
    names: set[str] = set()
    if r_pr is None:
        return names
    r_fonts = r_pr.find(qn("w:rFonts"))
    if r_fonts is None:
        return names
    for attr in ("ascii", "hAnsi", "eastAsia", "cs"):
        value = r_fonts.get(qn(f"w:{attr}"))
        if value:
            names.add(str(value).strip().lower())
    return names


def _set_rpr_calibri_body(r_pr) -> None:
    r_fonts = r_pr.find(qn("w:rFonts"))
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.insert(0, r_fonts)
    for attr in ("ascii", "hAnsi", "eastAsia", "cs"):
        r_fonts.set(qn(f"w:{attr}"), "Calibri")
    # Microsoft Word muestra esta combinación como Calibri (cuerpo).
    r_fonts.set(qn("w:asciiTheme"), "minorHAnsi")
    r_fonts.set(qn("w:hAnsiTheme"), "minorHAnsi")
    r_fonts.set(qn("w:eastAsiaTheme"), "minorEastAsia")
    r_fonts.set(qn("w:cstheme"), "minorBidi")


def _bump_rpr_font_size_one_point(r_pr) -> None:
    for tag in ("w:sz", "w:szCs"):
        size_el = r_pr.find(qn(tag))
        if size_el is None:
            continue
        raw = size_el.get(qn("w:val"))
        try:
            size_el.set(qn("w:val"), str(int(raw) + 2))  # OOXML usa medios puntos.
        except Exception:
            continue


def normalize_calibri_body_font(document: Document, *, bump_arial_points: bool = True) -> Document:
    """Fuerza Calibri (cuerpo) en reporte y sube +1 pt donde había Arial.

    Se aplica sobre cuerpo, encabezados y pies. Los runs generados por los
    exportadores históricos suelen llevar Arial explícito; esos son los únicos
    que reciben el incremento de tamaño solicitado. El resto del documento se
    normaliza a Calibri (cuerpo) sin alterar el tamaño.
    """
    try:
        for style in document.styles:
            try:
                old_name = str(style.font.name or "").strip().lower()
                old_size = style.font.size
                style.font.name = "Calibri"
                if bump_arial_points and old_name == "arial" and old_size is not None:
                    style.font.size = Pt(float(old_size.pt) + 1.0)
            except Exception:
                continue
    except Exception:
        pass

    for part in _document_parts(document, include_headers_footers=True):
        for run_el in _safe_xpath(part, './/w:r'):
            r_pr = run_el.find(qn("w:rPr"))
            if r_pr is None:
                r_pr = OxmlElement("w:rPr")
                run_el.insert(0, r_pr)
            names = _rpr_font_names(r_pr)
            if bump_arial_points and "arial" in names:
                _bump_rpr_font_size_one_point(r_pr)
            _set_rpr_calibri_body(r_pr)
    return document

def prepare_editable_document(document: Document) -> Document:
    """Prepare a template before adding dynamic report content."""
    remove_document_protection(document)
    remove_report_body_placeholders(document)
    remove_leading_empty_paragraphs(document)
    return document


def cleanup_editable_report(
    document: Document,
    *,
    max_table_width_cm: Optional[float] = None,
    normalize_headers_footers: bool = False,
    convert_floating_images: bool = False,
) -> Document:
    """Final pass before saving a report.

    The final Word file remains editable: no document protection, real tables
    with fixed layout, and rows protected from being split across pages.

    Importante: las plantillas institucionales pueden traer marcas de agua o
    fondos como imágenes flotantes. Convertir esos objetos automáticamente a
    inline puede producir un DOCX que Word abre con advertencia de reparación.
    Por eso la conversión queda desactivada por defecto; las gráficas generadas
    por LEMATZIUM ya se insertan como imágenes inline.
    """
    remove_document_protection(document)
    if convert_floating_images:
        convert_body_floating_images_to_inline(document)
    uniquify_drawing_docpr_ids(document)
    width_cm = max_table_width_cm or usable_width_cm(document)
    for table in iter_all_tables(document, include_headers_footers=normalize_headers_footers):
        normalize_table_for_editing(table, max_width_cm=width_cm)
    return document


__all__ = [
    'DEFAULT_REPORT_BODY_PLACEHOLDERS',
    'add_inline_picture',
    'cleanup_editable_report',
    'cm_to_dxa',
    'convert_body_floating_images_to_inline',
    'iter_all_tables',
    'normalize_calibri_body_font',
    'normalize_table_for_editing',
    'prepare_editable_document',
    'prevent_row_splitting',
    'remove_document_protection',
    'remove_leading_empty_paragraphs',
    'remove_report_body_placeholders',
    'uniquify_drawing_docpr_ids',
    'usable_width_cm',
]
