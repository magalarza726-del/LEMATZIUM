from __future__ import annotations

"""Utilidades comunes de interfaz para LEMATZIUM.

Este módulo agrupa textos, estilos y mensajes usados por los módulos de tracción
para que el analista encuentre la misma lógica visual y operacional en M1, M2 y
M3. No contiene lógica de cálculo.
"""

from dataclasses import dataclass
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any

FONT = ("Segoe UI", 10)
SMALL_FONT = ("Segoe UI", 9)
TITLE_FONT = ("Segoe UI Semibold", 10)
HEADER_FONT = ("Segoe UI Semibold", 16)
SUBHEADER_FONT = ("Segoe UI", 10)

TEXT_READY = "Listo. Importa un CSV para comenzar."
TEXT_IMPORT_CSV = "Importar CSV..."
TEXT_RELOAD = "Recargar"
TEXT_RECALCULATE = "Recalcular"
TEXT_AUTO_ADJUST = "Autoajustar gráfica"
TEXT_APPLY_VIEW = "Aplicar vista"
TEXT_EXPORT_PNG = "Exportar gráfica PNG..."
TEXT_EXPORT_WORD = "Exportar Word..."
TEXT_NO_FILE = "Sin archivo cargado"
TEXT_SPECIMEN = "Probeta:"
TEXT_INTERACTIVE_GRAPH = "Gráfica interactiva"
TEXT_GEOMETRY_SECTION = "E. Forma y geometría"
TEXT_RESULTS_SECTION = "F. Resultados actuales"
TEXT_ACTIONS_SECTION = "I. Acciones"

SUPPORTED_FILETYPES = [
    ("Archivos soportados", "*.csv *.txt *.tsv *.dat *.prn *.xlsx *.xls *.xlsb"),
    ("CSV", "*.csv"),
    ("Excel", "*.xlsx *.xls *.xlsb"),
    ("Todos", "*.*"),
]


@dataclass(frozen=True)
class ModuleHeader:
    title: str
    subtitle: str


def configure_standard_style(style: ttk.Style, *, bg: str, accent: str, accent_soft: str) -> None:
    """Aplica un estilo Tk/ttk común sin alterar temas personalizados de cada módulo."""
    style.configure("TFrame", font=FONT, background=bg)
    style.configure("TLabelframe", font=TITLE_FONT, background=bg, bordercolor="#d0d0d0")
    style.configure("TLabelframe.Label", font=TITLE_FONT, background=bg)
    style.configure("TLabel", font=FONT, background=bg)
    style.configure("Header.TLabel", font=HEADER_FONT, background=bg)
    style.configure("SubHeader.TLabel", font=SUBHEADER_FONT, background=bg)
    style.configure("TButton", font=("Segoe UI Semibold", 10), background=accent_soft, foreground="#0f172a", bordercolor=accent, focuscolor=accent, padding=6)
    style.map(
        "TButton",
        background=[("disabled", "#eef2f7"), ("active", accent)],
        foreground=[("disabled", "#6b7280"), ("active", "#ffffff")],
    )
    style.configure("Accent.TButton", font=("Segoe UI Semibold", 10), background=accent, foreground="#ffffff", bordercolor=accent, padding=6)
    style.map(
        "Accent.TButton",
        background=[("disabled", "#dbeafe"), ("active", accent_soft)],
        foreground=[("disabled", "#6b7280"), ("active", "#0f172a")],
    )
    style.configure("TCombobox", fieldbackground=accent_soft, background=accent_soft, foreground="#0f172a", arrowcolor="#0f172a", bordercolor=accent, lightcolor=accent, darkcolor=accent, padding=4)
    style.map("TCombobox", fieldbackground=[("readonly", accent_soft)], foreground=[("readonly", "#0f172a")], selectbackground=[("readonly", accent)], selectforeground=[("readonly", "#ffffff")])
    style.configure("Treeview", rowheight=22, font=SMALL_FONT)
    style.configure("Treeview.Heading", font=("Segoe UI Semibold", 9))


def show_import_error(exc: BaseException) -> None:
    messagebox.showerror(
        "Error al importar CSV",
        "No se pudo importar el archivo seleccionado.\n\n"
        "Revise que el archivo corresponda a una exportación válida de la máquina universal, "
        "que no esté abierto en Excel y que contenga geometría y datos de curva.\n\n"
        f"Detalle técnico:\n{exc}",
    )


def show_error(title: str, exc: BaseException | str) -> None:
    detail = str(exc)
    messagebox.showerror(title, f"No se pudo completar la operación.\n\nDetalle técnico:\n{detail}")


def show_warning(title: str, message: str) -> None:
    messagebox.showwarning(title, message)


def show_info(title: str, message: str) -> None:
    messagebox.showinfo(title, message)


def set_loaded_status(status_var: Any, file_path: str | Path, *, extra: str = "") -> None:
    suffix = f" {extra.strip()}" if extra else ""
    try:
        status_var.set(f"Archivo importado correctamente: {Path(file_path).name}.{suffix}")
    except Exception:
        pass


def warning_summary(dataset: Any) -> str:
    warnings = getattr(dataset, "warnings", None) or []
    count = len(warnings)
    if count == 0:
        return "Sin advertencias de importación."
    return f"Advertencias de importación: {count}. Revise el panel de advertencias antes de emitir el reporte."
