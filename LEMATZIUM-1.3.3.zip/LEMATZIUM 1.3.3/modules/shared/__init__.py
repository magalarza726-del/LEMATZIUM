"""Utilidades compartidas por los módulos de LEMATZIUM."""
