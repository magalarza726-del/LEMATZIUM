from __future__ import annotations

"""Tema visual común recibido desde el HUB LEMATZIUM."""

import json
import os
from pathlib import Path
from typing import Any

THEME_ALIASES = {
    "Azul electrico": "Azul eléctrico",
    "Rosa frances": "Rosa francés",
    "Blanco Moderno": "Blanco moderno",
    "Azul Eléctrico": "Azul eléctrico",
    "Rosa Francés": "Rosa francés",
    "Negro Premium": "Negro premium",
}

THEMES: dict[str, dict[str, str]] = {
    "Azul eléctrico": {
        "bg": "#041321",
        "panel": "#0b2138",
        "accent": "#4fb8ff",
        "accent_soft": "#66d9ff",
        "text": "#eaf8ff",
        "text_soft": "#bfe4ff",
        "field_bg": "#102c47",
        "field_text": "#eaf8ff",
        "plot_bg": "#173651",
        "grid": "#31597d",
        "curve": "#66d9ff",
        "yield": "#ffd166",
        "max": "#ff7b7b",
        "line": "#ffb347",
        "offset": "#caa6ff",
        "tree_bg": "#0e2740",
        "toolbar_bg": "#10263d",
    },
    "Rosa francés": {
        "bg": "#160815",
        "panel": "#2a1330",
        "accent": "#ff7ea9",
        "accent_soft": "#f9558c",
        "text": "#fff2f7",
        "text_soft": "#ffd5e4",
        "field_bg": "#3a1a42",
        "field_text": "#fff2f7",
        "plot_bg": "#341738",
        "grid": "#73536f",
        "curve": "#ff8eb6",
        "yield": "#ffd166",
        "max": "#ffb3c6",
        "line": "#ffc38a",
        "offset": "#f1b4ff",
        "tree_bg": "#251129",
        "toolbar_bg": "#26132a",
    },
    "Blanco moderno": {
        "bg": "#eef4fa",
        "panel": "#ffffff",
        "accent": "#6bbcff",
        "accent_soft": "#9ed8ff",
        "text": "#14212e",
        "text_soft": "#42637e",
        "field_bg": "#dff1ff",
        "field_text": "#18324a",
        "plot_bg": "#f7fbff",
        "grid": "#c7d9e8",
        "curve": "#2f8fd8",
        "yield": "#b17700",
        "max": "#c75252",
        "line": "#ff9f43",
        "offset": "#8f78ff",
        "tree_bg": "#edf6ff",
        "toolbar_bg": "#e4f0fb",
    },
    "Negro premium": {
        "bg": "#050507",
        "panel": "#11141d",
        "accent": "#a885ff",
        "accent_soft": "#d59bff",
        "text": "#f5ecff",
        "text_soft": "#d2c0ea",
        "field_bg": "#1a1f2b",
        "field_text": "#f5ecff",
        "plot_bg": "#171923",
        "grid": "#49485b",
        "curve": "#d59bff",
        "yield": "#ffd166",
        "max": "#ff8fa3",
        "line": "#ffbc6b",
        "offset": "#9ecbff",
        "tree_bg": "#151824",
        "toolbar_bg": "#161923",
    },
}


def config_path() -> Path | None:
    env_path = os.getenv("LEMATZIUM_THEME_FILE", "").strip()
    if env_path:
        return Path(env_path)
    local_app = os.getenv("LOCALAPPDATA")
    if local_app:
        candidate = Path(local_app) / "LEMATZIUM" / "lematzium_hub_config.json"
        if candidate.exists():
            return candidate
    return None


def _coerce_theme_name(name: Any, default: str) -> str:
    stored = str(name or default).strip()
    return THEME_ALIASES.get(stored, stored if stored in THEMES else default)


def load_theme_name(default: str = "Azul eléctrico") -> str:
    env_name = os.getenv("LEMATZIUM_THEME", "").strip() or os.getenv("LEMATZIUM_THEME_NAME", "").strip()
    if env_name:
        return _coerce_theme_name(env_name, default)
    path = config_path()
    if path and path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            # El launcher guarda el tema como "theme"; algunos módulos antiguos
            # leen "theme_name". Aceptar ambos mantiene la sincronización visual
            # incluso cuando el módulo se ejecuta directamente, fuera del HUB.
            return _coerce_theme_name(data.get("theme_name") or data.get("theme") or default, default)
        except Exception:
            pass
    return default


def load_runtime_theme(default: str = "Azul eléctrico") -> dict[str, str]:
    name = load_theme_name(default)
    palette = THEMES.get(name, THEMES[default]).copy()
    palette["name"] = name
    return palette


__all__ = ["THEME_ALIASES", "THEMES", "config_path", "load_runtime_theme", "load_theme_name"]
