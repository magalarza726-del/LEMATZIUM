from __future__ import annotations

"""Lector común de órdenes de trabajo PDF para informes LEMATZIUM."""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict

from pypdf import PdfReader


@dataclass
class OTSampleRow:
    specimen_id: str
    raw_text: str = ""
    description: str = ""
    received_date: str = ""
    additional_info: str = ""


@dataclass
class OTContext:
    ot_number: str = ""
    client_name: str = ""
    phone: str = ""
    address: str = ""
    email: str = ""
    contact: str = ""
    observations: str = ""
    sample_rows: Dict[str, OTSampleRow] = field(default_factory=dict)
    pdf_path: str = ""


_SPANISH_MONTHS = {
    "enero": 1,
    "febrero": 2,
    "marzo": 3,
    "abril": 4,
    "mayo": 5,
    "junio": 6,
    "julio": 7,
    "agosto": 8,
    "septiembre": 9,
    "setiembre": 9,
    "octubre": 10,
    "noviembre": 11,
    "diciembre": 12,
}


def _clean(value: str) -> str:
    value = value.replace("\r", "\n")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n{2,}", "\n", value)
    return value.strip()


def _flatten_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _search(pattern: str, text: str, flags: int = re.DOTALL) -> str:
    match = re.search(pattern, text, flags)
    return match.group(1).strip() if match else ""


def _to_iso_date(value: str) -> str:
    normalized = _flatten_spaces(value)
    if not normalized:
        return ""
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
        return normalized

    match = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})", normalized)
    if match:
        day, month, year = match.groups()
        if len(year) == 2:
            year = f"20{year}"
        return f"{int(year):04d}-{int(month):02d}-{int(day):02d}"

    match = re.search(
        r"(\d{1,2})\s+de\s+([A-Za-zÁÉÍÓÚáéíóúñÑ]+)\s+del?\s+(\d{4})",
        normalized,
        re.IGNORECASE,
    )
    if match:
        day, month_text, year = match.groups()
        month = _SPANISH_MONTHS.get(month_text.lower())
        if month:
            return f"{int(year):04d}-{month:02d}-{int(day):02d}"
    return normalized




def _extract_additional_info(value: str) -> str:
    """Extrae la columna Información Adicional de la OT.

    En las OT exportadas desde Word/PDF suele aparecer al final de cada fila como
    ``Informe por separado`` o ``No Informado``. Esta señal se usa para
    autoexportar informes consecutivos por grupo.
    """
    text = _flatten_spaces(value)
    match = re.search(r"\b(Informe\s+por\s+separado|No\s+Informado)\b", text, re.IGNORECASE)
    if not match:
        return ""
    found = match.group(1).strip()
    if re.search(r"informe\s+por\s+separado", found, re.IGNORECASE):
        return "Informe por separado"
    return "No Informado"


def _extract_description(body_before_date: str) -> str:
    description = body_before_date.strip()
    if not description:
        return ""

    marker_match = re.search(
        r"(?=(?:[A-Z]{2,}(?:-[A-Z0-9]+){2,}[^\n]*[;,]?)|(?:Identificaci[óo]n del lote\s*:)|(?:Lote\s*:))",
        description,
        re.IGNORECASE,
    )
    if marker_match:
        description = description[marker_match.start():].strip()

    lines = [line.strip() for line in description.splitlines() if line.strip()]
    while lines and re.match(
        r"^(?:Ensayo\s+de\s*:|PEE\b|ISO\b|ASTM\b|ASME\b|AWS\b|NTE\b|INEN\b)",
        lines[0],
        re.IGNORECASE,
    ):
        lines.pop(0)
    return "\n".join(lines).strip()


def _infer_year(text: str) -> str:
    """Infer the table year when PDF text places the year in another column."""
    for pattern in (
        r"FECHA INICIO DE TRABAJO[^:]*:\s*\d{1,2}\s+de\s+[A-Za-zÁÉÍÓÚáéíóúñÑ]+\s+del?\s+(\d{4})",
        r"PLAZO PREVISTO DEL INFORME:\s*\d{1,2}\s+de\s+[A-Za-zÁÉÍÓÚáéíóúñÑ]+\s+del?\s+(\d{4})",
        r"\b(20\d{2})\b\s+(?:Tubería|Varilla|Acero|Producto|Material)",
    ):
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1)
    match = re.search(r"\b(20\d{2})\b", text)
    return match.group(1) if match else ""


def _remove_date_prefix(value: str, inferred_year: str = "") -> tuple[str, str]:
    """Remove a Spanish date prefix and return (date_iso, remaining_text)."""
    text = _flatten_spaces(value)
    # Supports bad extraction like "31 de Marzo del26-0345" or "08 de Abril delRN-...".
    match = re.match(
        r"^(?P<date>\d{1,2}\s+de\s+[A-Za-zÁÉÍÓÚáéíóúñÑ]+\s+del?)(?P<year>\s*\d{4})?\s*(?P<rest>.*)$",
        text,
        re.IGNORECASE,
    )
    if not match:
        return "", text
    date_text = match.group("date")
    year = (match.group("year") or "").strip() or inferred_year
    if year:
        date_text = f"{date_text} {year}"
    return _to_iso_date(date_text), match.group("rest").strip()


def _strip_service_and_method(value: str) -> str:
    """Strip service/method fragments, leaving the client-provided description."""
    text = _flatten_spaces(value)
    text = re.sub(r"^Ensayo\s+de\s*:\s*Tensi[oó]n\*{0,2}\s*", "", text, flags=re.IGNORECASE)
    # Remove common method/standard prefixes. Stop after the method code, keeping the description.
    text = re.sub(r"^(?:PEE[-/A-Z0-9 ]+)?\s*(?:/\s*)?(?:ISO|ASTM|INEN|NTE|AWS|ASME)\s*[-A-Z0-9:/ .]*\s+", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^INEN\s*\d+\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^ASTM\s*[A-Z]\s*\d+[-A-Z0-9:/. ]*\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^ISO\s*\d+[-A-Z0-9:/. ]*\s*", "", text, flags=re.IGNORECASE)
    # Remove product/info fragments that belong to later columns if they were concatenated.
    text = re.sub(r"\b(?:Tubería|Tuberia|Varilla)\s+(?:cuadrada|rectangular|corrugada)\b.*$", "", text, flags=re.IGNORECASE).strip()
    text = re.sub(r"\b(?:Informe por separado|No Informado)\b.*$", "", text, flags=re.IGNORECASE).strip()
    text = text.strip(" -;,")
    if re.fullmatch(r"\d+(?:[.:/-]\d+)*", text):
        return ""
    if re.match(r"^(?:INEN|NTE|ISO|ASTM|PEE|AWS|ASME)\b", text, re.IGNORECASE):
        return ""
    return text


def _parse_sample_rows_from_misaligned_text(text: str) -> Dict[str, OTSampleRow]:
    """Fallback for OTs where PDF extraction moves the date/product columns.

    Some Word/PDF tables are extracted as lines like:
    "31 de Marzo del26-0345 Ensayo de: Tensión** INEN 2415 Sub-Lote:..."
    or even "08 de Abril delRN-...26-0384 Ensayo...". This routine reads those
    lines and reconstructs the sample description/date without OCR.
    """
    rows: Dict[str, OTSampleRow] = {}
    inferred_year = _infer_year(text)
    prefix_match = re.search(r"ORDEN DE TRABAJO\s+OT-\d{4}-(\d{2})", text)
    sample_prefix = prefix_match.group(1) if prefix_match else r"\d{2}"
    code_pattern = rf"{sample_prefix}-\d{{4}}(?:-\d+)?"
    for line in text.splitlines():
        if not re.search(code_pattern, line):
            continue
        # Ignore header/order lines that are not sample rows.
        if "ORDEN DE TRABAJO" in line.upper():
            continue
        for match in re.finditer(code_pattern, line):
            code = match.group(0)
            before = line[:match.start()]
            after = line[match.end():]
            received_date, before_rest = _remove_date_prefix(before, inferred_year)
            has_service_after = bool(re.search(r"Ensayo\s+de\s*:", after, re.IGNORECASE))
            # Avoid false positives from lot identifiers such as CN-100X100X28-1326-1-01
            # and RM numbers. A sample code is either followed by the service text
            # or is the first code immediately after a date prefix.
            if not has_service_after and (before_rest or not received_date):
                continue
            # If the date is directly before the code with no separator, before_rest is usually empty.
            before_desc = _strip_service_and_method(before_rest)
            after_desc = _strip_service_and_method(after)
            description = after_desc or before_desc
            # Some malformed lines place the description before the code and the method after it.
            if not description and before_desc:
                description = before_desc
            # If date was not before the code, search the full line.
            if not received_date:
                raw_date_match = re.search(
                    r"(\d{1,2}\s+de\s+[A-Za-zÁÉÍÓÚáéíóúñÑ]+\s+del?\s*(?:\d{4})?)",
                    line,
                    re.IGNORECASE,
                )
                if raw_date_match:
                    raw_date = raw_date_match.group(1)
                    if not re.search(r"\d{4}", raw_date) and inferred_year:
                        raw_date = f"{raw_date} {inferred_year}"
                    received_date = _to_iso_date(raw_date)
            if description or received_date:
                rows[code] = OTSampleRow(
                    specimen_id=code,
                    raw_text=_clean(line),
                    description=description,
                    received_date=received_date,
                    additional_info=_extract_additional_info(line),
                )
    return rows


def _parse_sample_rows(text: str) -> Dict[str, OTSampleRow]:
    table_text = _search(
        r"Información Adicional\s*\(Requerida en el\s*Informe\)\s*(.*?)\s*OBSERVACIONES GENERALES:",
        text,
    )
    if not table_text:
        table_text = _search(r"Informe\)\s*(.*?)\s*OBSERVACIONES GENERALES:", text)

    rows: Dict[str, OTSampleRow] = {}
    if not table_text:
        return _parse_sample_rows_from_misaligned_text(text)

    pattern = re.compile(
        r"(?P<code>\d{2}-\d{4}(?:-\d+)?)\s+(?P<body>.*?)(?=(?:\n\d{2}-\d{4}(?:-\d+)?\s)|\Z)",
        re.DOTALL,
    )
    for match in pattern.finditer(table_text):
        code = match.group("code").strip()
        body = _clean(match.group("body"))
        raw_date_match = re.search(
            r"(\d{1,2}\s+de\s+[A-Za-zÁÉÍÓÚáéíóúñÑ]+\s+del\s+\d{4})",
            body,
            re.IGNORECASE,
        )
        raw_date = raw_date_match.group(1) if raw_date_match else ""
        received_date = _to_iso_date(raw_date)
        body_before_date = body[: raw_date_match.start()].strip() if raw_date_match else body
        description = _extract_description(body_before_date)
        rows[code] = OTSampleRow(
            specimen_id=code,
            raw_text=body,
            description=description,
            received_date=received_date,
            additional_info=_extract_additional_info(body),
        )

    # Merge fallback rows. Prefer existing rich rows, but fill blanks when the
    # regular table extraction failed or when columns were shifted.
    fallback_rows = _parse_sample_rows_from_misaligned_text(text)
    for code, row in fallback_rows.items():
        current = rows.get(code)
        if current is None:
            rows[code] = row
        else:
            if not current.description and row.description:
                current.description = row.description
            if not current.received_date and row.received_date:
                current.received_date = row.received_date
            if not current.raw_text and row.raw_text:
                current.raw_text = row.raw_text
            if not current.additional_info and row.additional_info:
                current.additional_info = row.additional_info
    return rows


def parse_ot_pdf(path: str | Path) -> OTContext:
    pdf_path = Path(path)
    reader = PdfReader(str(pdf_path))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    text = _clean(text)

    context = OTContext(pdf_path=str(pdf_path))
    context.ot_number = _search(r"ORDEN DE TRABAJO\s+OT-(\d{4}-\d{2})", text)
    if context.ot_number:
        context.ot_number = f"OT-{context.ot_number}"
    context.client_name = _flatten_spaces(_search(r"DATOS DEL CLIENTE:\s*(.*?)\s*TEL[ÉE]FONO:", text))
    context.phone = _flatten_spaces(_search(r"TEL[ÉE]FONO:\s*(.*?)\s*DIRECCI[ÓO]N:", text))
    context.address = _flatten_spaces(_search(r"DIRECCI[ÓO]N:\s*(.*?)\s*FECHA INICIO DE TRABAJO", text))
    context.email = _flatten_spaces(
        _search(r"CORREO ELECTR[ÓO]NICO\s*:?\s*(.*?)\s*PLAZO PREVISTO DEL INFORME", text)
    )
    context.contact = _flatten_spaces(_search(r"CONTACTO:\s*(.*?)\s*_+", text))
    context.observations = _search(r"OBSERVACIONES GENERALES:\s*(.*?)\s*INFORMACI[ÓO]N ADICIONAL", text)
    context.sample_rows = _parse_sample_rows(text)
    return context


__all__ = ["OTContext", "OTSampleRow", "parse_ot_pdf"]
