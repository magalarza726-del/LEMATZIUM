from __future__ import annotations

"""Resolución común de plantillas institucionales y agregadas."""

import json
import os
import re
import shutil
import uuid
from pathlib import Path
from typing import Any, Mapping

ACCREDITATION_ACCREDITED = "accredited"
ACCREDITATION_NON_ACCREDITED = "non_accredited"
CUSTOM_TEMPLATE_PREFIX = "custom:"

_TEMPLATE_NAMES: Mapping[str, str] = {
    ACCREDITATION_ACCREDITED: "MC2202-08 Informe Ensayos acreditado.docx",
    ACCREDITATION_NON_ACCREDITED: "MC2201-06 Informe Ensayos Ed 6.docx",
}
_TEMPLATE_LABELS: Mapping[str, str] = {
    ACCREDITATION_ACCREDITED: "Acreditado (MC2202-08)",
    ACCREDITATION_NON_ACCREDITED: "No acreditado (MC2201-06)",
}

def package_root_from_reports_file(reports_file: str | Path) -> Path:
    return Path(reports_file).resolve().parent.parent

def templates_dir_from_reports_file(reports_file: str | Path) -> Path:
    return package_root_from_reports_file(reports_file) / "templates"

def report_template_mapping(reports_file: str | Path) -> dict[str, Path]:
    templates_dir = templates_dir_from_reports_file(reports_file)
    return {mode: templates_dir / filename for mode, filename in _TEMPLATE_NAMES.items()}

def suite_root_from_shared_file() -> Path:
    return Path(__file__).resolve().parents[2]

def _user_config_root() -> Path:
    if os.name == "nt":
        base = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA")
        if base:
            return Path(base) / "LEMATZIUM"
    return Path.home() / ".lematzium"

def _local_config_root() -> Path:
    return suite_root_from_shared_file() / "config"

def _config_root() -> Path:
    env_dir = os.environ.get("LEMATZIUM_CONFIG_DIR")
    candidates = [Path(env_dir)] if env_dir else []
    candidates += [_local_config_root(), _user_config_root()]
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write_test"
            probe.write_text("ok", encoding="utf-8")
            try: probe.unlink()
            except Exception: pass
            return candidate
        except Exception:
            continue
    fallback = _user_config_root(); fallback.mkdir(parents=True, exist_ok=True); return fallback

def custom_templates_dir() -> Path:
    path = _config_root() / "report_templates"
    path.mkdir(parents=True, exist_ok=True)
    return path

def custom_templates_manifest_path() -> Path:
    path = _config_root() / "custom_report_templates.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path

def _read_manifest() -> dict[str, Any]:
    path = custom_templates_manifest_path()
    if not path.exists(): return {"templates": []}
    try: data = json.loads(path.read_text(encoding="utf-8"))
    except Exception: return {"templates": []}
    if not isinstance(data, dict): return {"templates": []}
    if not isinstance(data.get("templates"), list): data["templates"] = []
    return data

def _write_manifest(data: dict[str, Any]) -> None:
    custom_templates_manifest_path().write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def _safe_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ._ -]+", "_", value or "plantilla")
    text = re.sub(r"\s+", " ", text).strip(" ._")
    return text or "plantilla"

def load_custom_report_templates() -> dict[str, dict[str, str]]:
    data = _read_manifest(); result: dict[str, dict[str, str]] = {}; changed = False
    for item in list(data.get("templates", [])):
        if not isinstance(item, dict): changed = True; continue
        key = str(item.get("id") or "")
        label = str(item.get("label") or key.replace(CUSTOM_TEMPLATE_PREFIX, "") or "Plantilla")
        path = Path(str(item.get("path") or ""))
        if not key.startswith(CUSTOM_TEMPLATE_PREFIX):
            key = f"{CUSTOM_TEMPLATE_PREFIX}{key}" if key else f"{CUSTOM_TEMPLATE_PREFIX}{uuid.uuid4().hex[:12]}"
            item["id"] = key; changed = True
        if path.exists() and path.suffix.lower() == ".docx":
            result[key] = {"label": label, "path": str(path)}
        else:
            changed = True
    if changed:
        data["templates"] = [{"id": k, "label": v["label"], "path": v["path"]} for k, v in result.items()]
        try: _write_manifest(data)
        except Exception: pass
    return result

def register_custom_report_template(source_path: str | Path, label: str | None = None) -> tuple[str, str, Path]:
    source = Path(source_path).expanduser().resolve()
    if not source.exists(): raise FileNotFoundError(f"No se encontró la plantilla seleccionada: {source}")
    if source.suffix.lower() != ".docx": raise ValueError("La plantilla debe ser un archivo Word .docx")
    visible_label = _safe_name(label or source.stem)
    key = f"{CUSTOM_TEMPLATE_PREFIX}{uuid.uuid4().hex[:12]}"
    filename = f"{_safe_name(visible_label)}_{key.replace(CUSTOM_TEMPLATE_PREFIX, '')}.docx"
    destination = custom_templates_dir() / filename
    shutil.copy2(source, destination)
    data = _read_manifest()
    entries = [item for item in data.get("templates", []) if isinstance(item, dict)]
    entries.append({"id": key, "label": visible_label, "path": str(destination)})
    data["templates"] = entries; _write_manifest(data)
    return key, visible_label, destination

def report_template_choices(reports_file: str | Path | None = None) -> list[tuple[str, str]]:
    choices = [(ACCREDITATION_ACCREDITED, _TEMPLATE_LABELS[ACCREDITATION_ACCREDITED]), (ACCREDITATION_NON_ACCREDITED, _TEMPLATE_LABELS[ACCREDITATION_NON_ACCREDITED])]
    for key, item in sorted(load_custom_report_templates().items(), key=lambda kv: kv[1]["label"].lower()):
        choices.append((key, f"Plantilla agregada · {item['label']}"))
    return choices

def get_report_template_path(reports_file: str | Path, accreditation_mode: str) -> Path:
    mode = str(accreditation_mode)
    if mode.startswith(CUSTOM_TEMPLATE_PREFIX):
        item = load_custom_report_templates().get(mode)
        if not item: raise FileNotFoundError(f"No se encontró la plantilla agregada: {mode}")
        path = Path(item["path"])
        if not path.exists(): raise FileNotFoundError(f"No se encontró el archivo de plantilla agregada: {path}")
        return path
    mapping = report_template_mapping(reports_file)
    try: return mapping[mode]
    except KeyError as exc: raise ValueError(f"Modo de acreditación no soportado: {mode}") from exc

__all__ = ["ACCREDITATION_ACCREDITED", "ACCREDITATION_NON_ACCREDITED", "CUSTOM_TEMPLATE_PREFIX", "get_report_template_path", "load_custom_report_templates", "package_root_from_reports_file", "register_custom_report_template", "report_template_choices", "report_template_mapping", "templates_dir_from_reports_file"]
