from __future__ import annotations

"""Arranque común para módulos LEMATZIUM.

Este módulo mantiene en un solo lugar las tareas repetidas de los launchers:
- agregar rutas locales al ``sys.path``;
- evitar uso de bytecode obsoleto en despliegues ZIP/portable;
- limpiar ``__pycache__`` antes de iniciar módulos con reportes Word;
- importar y ejecutar el ``main`` real del módulo.

No contiene lógica de cálculo ni de interfaz; solo prepara el entorno de ejecución.
"""

import importlib
import shutil
import sys
from pathlib import Path
from types import ModuleType
from typing import Iterable


def add_path(path: str | Path, *, must_exist: bool = True) -> None:
    """Agrega una ruta al inicio de ``sys.path`` si aún no está registrada."""
    candidate = Path(path).resolve()
    if must_exist and not candidate.exists():
        return
    text = str(candidate)
    if text not in sys.path:
        sys.path.insert(0, text)


def modules_dir_from_launcher(launcher_file: str | Path) -> Path:
    """Devuelve la carpeta ``modules`` a partir de un launcher ubicado dentro de ella."""
    return Path(launcher_file).resolve().parent.parent


def ensure_modules_path(launcher_file: str | Path) -> Path:
    """Registra la carpeta ``modules`` para permitir imports como ``shared``."""
    modules_dir = modules_dir_from_launcher(launcher_file)
    add_path(modules_dir)
    return modules_dir


def purge_pycache(root: str | Path) -> int:
    """Elimina carpetas ``__pycache__`` bajo ``root`` y devuelve cuántas eliminó."""
    root_path = Path(root).resolve()
    removed = 0
    for cache_dir in root_path.rglob("__pycache__"):
        shutil.rmtree(cache_dir, ignore_errors=True)
        removed += 1
    return removed


def disable_bytecode() -> None:
    """Evita generación de nuevos .pyc en instalaciones portables."""
    sys.dont_write_bytecode = True


def prepare_launcher_environment(
    launcher_file: str | Path,
    *,
    extra_paths: Iterable[str | Path] = (),
    purge_root: str | Path | None = None,
    purge_caches: bool = True,
) -> Path:
    """Prepara rutas y cache para un launcher de módulo.

    Parameters
    ----------
    launcher_file:
        Archivo ``launch_*.py`` que invoca el módulo.
    extra_paths:
        Rutas adicionales requeridas por adaptadores internos.
    purge_root:
        Carpeta desde donde se eliminará ``__pycache__``. Si no se indica,
        se usa la carpeta del launcher.
    purge_caches:
        Cuando es falso, conserva caches existentes.
    """
    modules_dir = ensure_modules_path(launcher_file)
    for path in extra_paths:
        add_path(path)
    disable_bytecode()
    if purge_caches:
        purge_pycache(purge_root or Path(launcher_file).resolve().parent)
    return modules_dir


def import_main(import_path: str):
    """Importa y devuelve la función ``main`` desde un módulo Python."""
    module: ModuleType = importlib.import_module(import_path)
    main = getattr(module, "main", None)
    if main is None:
        raise AttributeError(f"El módulo {import_path!r} no define una función main().")
    return main


def run_module_main(
    launcher_file: str | Path,
    import_path: str,
    *,
    extra_paths: Iterable[str | Path] = (),
    purge_root: str | Path | None = None,
    purge_caches: bool = True,
):
    """Prepara el entorno e invoca el ``main`` real del módulo."""
    prepare_launcher_environment(
        launcher_file,
        extra_paths=extra_paths,
        purge_root=purge_root,
        purge_caches=purge_caches,
    )
    return import_main(import_path)()


__all__ = [
    "add_path",
    "disable_bytecode",
    "ensure_modules_path",
    "import_main",
    "modules_dir_from_launcher",
    "prepare_launcher_environment",
    "purge_pycache",
    "run_module_main",
]
