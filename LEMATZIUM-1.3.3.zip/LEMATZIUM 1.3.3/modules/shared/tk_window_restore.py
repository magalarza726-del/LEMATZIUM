from __future__ import annotations

"""Utilidades Tk para restaurar ventanas LEMATZIUM en Windows.

Auditoría v21:
- El problema más consistente aparecía después de exportar, cuando un Toplevel
  modal podía conservar un ``grab`` activo y dejar a la ventana principal sin
  una ruta de restauración confiable desde la barra de tareas.
- Este helper evita restauraciones agresivas mientras la ventana está minimizada,
  libera ``topmost``/grabs huérfanos y expone una función explícita para llamar
  después de exportar o cerrar diálogos.
"""

import ctypes
import os
import tkinter as tk
from typing import Any


def set_windows_app_user_model_id(app_id: str) -> None:
    """Asigna un AppUserModelID estable para mejorar agrupación/restauración."""

    if os.name != "nt":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(str(app_id))
    except Exception:
        pass


def _safe_state(root: tk.Tk | tk.Toplevel) -> str:
    try:
        return str(root.state())
    except Exception:
        return "unknown"


def release_modal_state(root: tk.Tk | tk.Toplevel) -> None:
    """Libera estados que pueden bloquear la restauración de una ventana Tk.

    Es seguro llamar esta función aunque no exista ningún grab activo. Se usa
    después de exportar reportes y al cerrar diálogos para que la ventana del
    módulo vuelva a comportarse como una ventana normal de Windows.
    """

    try:
        grabbed = root.grab_current()
    except Exception:
        grabbed = None
    for widget in (grabbed, root):
        if widget is None:
            continue
        try:
            widget.grab_release()
        except Exception:
            pass
    try:
        root.attributes("-topmost", False)
    except Exception:
        pass


def _pulse_front(root: tk.Tk | tk.Toplevel, *, force_front_ms: int = 180) -> None:
    """Sube una ventana al frente por un instante, sin dejarla always-on-top."""

    release_modal_state(root)
    try:
        if _safe_state(root) == "iconic":
            root.state("normal")
    except Exception:
        pass
    try:
        root.deiconify()
    except Exception:
        pass
    try:
        root.update_idletasks()
    except Exception:
        pass
    try:
        root.lift()
    except Exception:
        pass
    if os.name == "nt":
        try:
            root.attributes("-topmost", True)
        except Exception:
            pass
    try:
        root.focus_force()
    except Exception:
        pass

    def _release() -> None:
        try:
            root.attributes("-topmost", False)
        except Exception:
            pass

    try:
        root.after(max(50, int(force_front_ms)), _release)
    except Exception:
        _release()


def install_window_restore_guard(
    root: tk.Tk | tk.Toplevel,
    *,
    force_front_ms: int = 180,
    app_id: str | None = None,
) -> None:
    """Instala un guardia ligero de restauración para una ventana Tk.

    No impide minimizar. Al mapear/restaurar normaliza ``iconic -> normal`` y
    aplica un pulso temporal de foco. Al minimizar libera ``topmost`` y cualquier
    ``grab`` modal que haya quedado activo por diálogos de exportación.
    """

    if app_id:
        set_windows_app_user_model_id(app_id)

    if getattr(root, "_lematzium_restore_guard_installed", False):
        return
    setattr(root, "_lematzium_restore_guard_installed", True)

    state: dict[str, Any] = {
        "last_geometry": None,
        "pulse_after_id": None,
        "restore_after_ids": [],
    }

    def _is_restorable_state() -> bool:
        return _safe_state(root) not in {"withdrawn", "unknown"}

    def _remember_geometry(_event: tk.Event | None = None) -> None:
        try:
            if _safe_state(root) == "normal" and bool(root.winfo_viewable()):
                geo = root.geometry()
                if "x" in geo and "+" in geo and not geo.startswith(("1x1", "0x0")):
                    state["last_geometry"] = geo
        except Exception:
            pass

    def _release_topmost() -> None:
        try:
            root.attributes("-topmost", False)
        except Exception:
            pass
        state["pulse_after_id"] = None

    def _cancel_restore_jobs() -> None:
        for after_id in list(state.get("restore_after_ids") or []):
            try:
                root.after_cancel(after_id)
            except Exception:
                pass
        state["restore_after_ids"] = []

    def _front_if_visible(_event: tk.Event | None = None) -> None:
        # No intente levantar una ventana que el usuario acaba de minimizar.
        if _safe_state(root) in {"iconic", "withdrawn", "unknown"}:
            return
        release_modal_state(root)
        try:
            old_after = state.get("pulse_after_id")
            if old_after:
                root.after_cancel(old_after)
        except Exception:
            pass
        try:
            root.update_idletasks()
        except Exception:
            pass
        try:
            root.lift()
        except Exception:
            pass
        if os.name == "nt":
            try:
                root.attributes("-topmost", True)
            except Exception:
                pass
        try:
            root.focus_force()
        except Exception:
            pass
        try:
            state["pulse_after_id"] = root.after(max(50, int(force_front_ms)), _release_topmost)
        except Exception:
            _release_topmost()

    def _restore_then_front(_event: tk.Event | None = None) -> None:
        try:
            if _safe_state(root) == "iconic":
                root.state("normal")
        except Exception:
            pass
        try:
            root.deiconify()
        except Exception:
            pass
        try:
            last_geo = state.get("last_geometry")
            if last_geo and _safe_state(root) == "normal":
                # Reaplicar geometría evita restauraciones degeneradas 1x1/0x0.
                root.geometry(str(last_geo))
        except Exception:
            pass
        _front_if_visible()

    def _schedule_restore_sequence() -> None:
        if not _is_restorable_state():
            return
        _cancel_restore_jobs()
        delays = (1, 35, 120, 260, 520)
        ids: list[str] = []
        for delay in delays:
            try:
                ids.append(root.after(delay, _restore_then_front))
            except Exception:
                pass
        state["restore_after_ids"] = ids

    def _on_map(event: tk.Event) -> None:
        if event.widget is root:
            _schedule_restore_sequence()

    def _on_visibility(event: tk.Event) -> None:
        if event.widget is root and _safe_state(root) == "normal":
            _schedule_restore_sequence()

    def _on_focus_in(event: tk.Event) -> None:
        if event.widget is root and _safe_state(root) == "normal":
            try:
                root.after(20, _front_if_visible)
            except Exception:
                _front_if_visible()

    def _on_unmap(event: tk.Event) -> None:
        if event.widget is root:
            _cancel_restore_jobs()
            release_modal_state(root)
            _release_topmost()

    root.bind("<Configure>", _remember_geometry, add="+")
    root.bind("<Map>", _on_map, add="+")
    root.bind("<Visibility>", _on_visibility, add="+")
    root.bind("<FocusIn>", _on_focus_in, add="+")
    root.bind("<Unmap>", _on_unmap, add="+")


def show_window_normally(root: tk.Tk | tk.Toplevel) -> None:
    """Muestra/restaura una ventana sin dejarla permanentemente topmost."""

    _pulse_front(root)


__all__ = [
    "install_window_restore_guard",
    "release_modal_state",
    "set_windows_app_user_model_id",
    "show_window_normally",
]
