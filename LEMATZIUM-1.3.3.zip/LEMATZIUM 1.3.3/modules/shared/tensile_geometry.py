from __future__ import annotations

import math
import unicodedata
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np


SHAPE_RECTANGULAR = "Rectangular"
SHAPE_CIRCULAR = "Circular"
SHAPE_IRREGULAR = "Irregular"
SHAPE_TUBULAR = "Tubería"
SHAPE_OPTIONS = [SHAPE_RECTANGULAR, SHAPE_CIRCULAR, SHAPE_TUBULAR, SHAPE_IRREGULAR]


_RECTANGULAR_ALIASES = {
    "rectangular",
    "rectangulo",
    "rectangular/plana",
    "plana",
    "flat",
    "sheet",
    "lamina",
    "lámina",
}
_CIRCULAR_ALIASES = {
    "circular",
    "redonda",
    "redondo",
    "cilindrica",
    "cilíndrica",
    "cilindrico",
    "cilíndrico",
    "varilla",
    "barra",
    "round",
    "rod",
}
_TUBULAR_ALIASES = {
    "tuberia",
    "tubería",
    "tubo",
    "tubular",
    "anular",
    "hueca",
    "hueco",
    "pipe",
    "tube",
}
_IRREGULAR_ALIASES = {
    "irregular",
    "area",
    "área",
    "area directa",
    "seccion irregular",
    "sección irregular",
    "manual",
}


def _clean_text(value: Any) -> str:
    text = "" if value is None else str(value).replace("\ufeff", "").strip().lower()
    text = text.replace(":", "").strip()
    return "".join(
        ch for ch in unicodedata.normalize("NFKD", text)
        if not unicodedata.combining(ch)
    )


def normalize_shape(shape: Any, default: str = SHAPE_RECTANGULAR) -> str:
    """Devuelve la forma canónica usada en UI y reportes.

    Acepta valores históricos como "rectangular"/"circular" y nombres de
    exportación de máquina como "Plana" o "Varilla".
    """
    cleaned = _clean_text(shape)
    if not cleaned:
        return default
    rectangular = {_clean_text(v) for v in _RECTANGULAR_ALIASES}
    circular = {_clean_text(v) for v in _CIRCULAR_ALIASES}
    tubular = {_clean_text(v) for v in _TUBULAR_ALIASES}
    irregular = {_clean_text(v) for v in _IRREGULAR_ALIASES}
    if cleaned in tubular:
        return SHAPE_TUBULAR
    if cleaned in circular:
        return SHAPE_CIRCULAR
    if cleaned in irregular:
        return SHAPE_IRREGULAR
    if cleaned in rectangular:
        return SHAPE_RECTANGULAR
    if "tuber" in cleaned or "anular" in cleaned or "huec" in cleaned or "pipe" in cleaned or "tube" in cleaned:
        return SHAPE_TUBULAR
    if "diam" in cleaned or "varilla" in cleaned or "redond" in cleaned:
        return SHAPE_CIRCULAR
    if "area" in cleaned or "irregular" in cleaned:
        return SHAPE_IRREGULAR
    return default


def shape_from_headers(headers: list[str], export_shape: Any = None) -> str:
    """Infiere forma desde encabezados de geometría y, si existe, desde Forma:."""
    normalized_headers = [_clean_text(h) for h in headers]
    joined = " ".join(normalized_headers)
    export_normalized = normalize_shape(export_shape) if export_shape is not None else None
    if export_normalized == SHAPE_TUBULAR or "tuber" in joined or "diametro interior" in joined or "diametro exterior" in joined or "diametro interno" in joined:
        return SHAPE_TUBULAR
    if "diam" in joined:
        return SHAPE_CIRCULAR
    if "espesor" in joined and ("anchura" in joined or "ancho" in joined):
        return SHAPE_RECTANGULAR
    if "area" in joined:
        return SHAPE_IRREGULAR
    return normalize_shape(export_shape)


def _valid_positive(value: Optional[float]) -> bool:
    try:
        return value is not None and np.isfinite(float(value)) and float(value) > 0
    except Exception:
        return False


@dataclass
class TensileGeometry:
    """Geometría común de probetas de tracción.

    Conserva las dimensiones originales y calcula el área solo al momento de
    usarla para esfuerzo/reportes. Mantiene compatibilidad con el código
    anterior mediante los campos side1_mm, side2_mm, diameter_mm y gauge_length_mm.
    """

    shape: str = SHAPE_RECTANGULAR
    side1_mm: Optional[float] = None
    side2_mm: Optional[float] = None
    diameter_mm: Optional[float] = None
    gauge_length_mm: Optional[float] = None
    area_mm2_manual: Optional[float] = None

    def __post_init__(self) -> None:
        self.shape = normalize_shape(self.shape)

    @property
    def is_rectangular(self) -> bool:
        return normalize_shape(self.shape) == SHAPE_RECTANGULAR

    @property
    def is_circular(self) -> bool:
        return normalize_shape(self.shape) == SHAPE_CIRCULAR

    @property
    def is_tubular(self) -> bool:
        return normalize_shape(self.shape) == SHAPE_TUBULAR

    @property
    def is_irregular(self) -> bool:
        return normalize_shape(self.shape) == SHAPE_IRREGULAR

    @property
    def area_mm2(self) -> Optional[float]:
        try:
            shape = normalize_shape(self.shape)
            if shape == SHAPE_CIRCULAR:
                if not _valid_positive(self.diameter_mm):
                    return None
                d = float(self.diameter_mm)
                value = math.pi * (d ** 2) / 4.0
            elif shape == SHAPE_TUBULAR:
                if not _valid_positive(self.side1_mm) or not _valid_positive(self.side2_mm):
                    return None
                di = float(self.side1_mm)
                de = float(self.side2_mm)
                if de <= di:
                    return None
                value = math.pi * ((de ** 2) - (di ** 2)) / 4.0
            elif shape == SHAPE_IRREGULAR:
                if not _valid_positive(self.area_mm2_manual):
                    return None
                value = float(self.area_mm2_manual)
            else:
                if not _valid_positive(self.side1_mm) or not _valid_positive(self.side2_mm):
                    return None
                value = float(self.side1_mm) * float(self.side2_mm)
        except Exception:
            return None
        return value if _valid_positive(value) else None

    def validate(self, require_gauge: bool = True) -> list[str]:
        errors: list[str] = []
        shape = normalize_shape(self.shape)
        if shape == SHAPE_RECTANGULAR:
            if not _valid_positive(self.side1_mm):
                errors.append("La geometría rectangular requiere espesor/lado 1 positivo.")
            if not _valid_positive(self.side2_mm):
                errors.append("La geometría rectangular requiere anchura/lado 2 positivo.")
        elif shape == SHAPE_CIRCULAR:
            if not _valid_positive(self.diameter_mm):
                errors.append("La geometría circular requiere diámetro positivo.")
        elif shape == SHAPE_TUBULAR:
            if not _valid_positive(self.side1_mm):
                errors.append("La geometría tubular requiere diámetro interior positivo.")
            if not _valid_positive(self.side2_mm):
                errors.append("La geometría tubular requiere diámetro exterior positivo.")
            if _valid_positive(self.side1_mm) and _valid_positive(self.side2_mm) and float(self.side2_mm) <= float(self.side1_mm):
                errors.append("El diámetro exterior debe ser mayor que el diámetro interior.")
        elif shape == SHAPE_IRREGULAR:
            if not _valid_positive(self.area_mm2_manual):
                errors.append("La geometría irregular requiere área positiva.")
        else:
            errors.append(f"Forma no soportada: {self.shape!r}.")
        if require_gauge and not _valid_positive(self.gauge_length_mm):
            errors.append("La geometría requiere longitud calibrada positiva.")
        return errors

    def set_values(
        self,
        *,
        shape: Any | None = None,
        side1_mm: Optional[float] = None,
        side2_mm: Optional[float] = None,
        diameter_mm: Optional[float] = None,
        gauge_length_mm: Optional[float] = None,
        area_mm2_manual: Optional[float] = None,
    ) -> None:
        if shape is not None:
            self.shape = normalize_shape(shape)
        self.side1_mm = side1_mm
        self.side2_mm = side2_mm
        self.diameter_mm = diameter_mm
        self.gauge_length_mm = gauge_length_mm
        self.area_mm2_manual = area_mm2_manual

    def copy(self) -> "TensileGeometry":
        return TensileGeometry(
            shape=self.shape,
            side1_mm=self.side1_mm,
            side2_mm=self.side2_mm,
            diameter_mm=self.diameter_mm,
            gauge_length_mm=self.gauge_length_mm,
            area_mm2_manual=self.area_mm2_manual,
        )
