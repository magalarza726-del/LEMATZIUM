from __future__ import annotations

"""Exportador Word unificado para reportes de tracción LEMATZIUM.

Esta capa es común para el nuevo módulo unificado. No reemplaza todavía los
exportadores históricos de módulo 1 ni módulo 2. Genera documentos editables
con tablas reales, gráficas inline y comentarios editables.
"""

from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping, Optional

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt

from shared.tensile_report_tables import build_geometry_table, _set_table_fixed_widths
from shared.word_report_utils import (
    add_inline_picture,
    cleanup_editable_report,
    prepare_editable_document,
    usable_width_cm,
)
from .analysis_config import METHOD_RP_OFFSET, METHOD_UPPER_YIELD, TensileAnalysisConfig
from .comment_templates import get_default_comment
from .geometry import TensileGeometry, normalize_shape
from .uncertainty import uncertainty_context_for_comment
from .models import TensileMethodResult, TensileReportContext

REPORT_TABLE_WIDTH_CM = 16.5
RESULT_WIDTHS_UPPER_YIELD_CM = [2.7, 3.6, 3.6, 4.1]
RESULT_WIDTHS_RP_OFFSET_CM = [2.7, 3.6, 3.6, 4.1, 2.5]
ARIAL = "Arial"
TABLE_FONT_SIZE_PT = 8


def _fmt(value: Any, ndigits: int = 2, *, unavailable: str = "No disponible") -> str:
    try:
        if value is None:
            return unavailable
        number = float(value)
        return f"{number:.{ndigits}f}"
    except Exception:
        return unavailable


def _fmt_modulus_mpa_from_gpa(value: Any, ndigits: int = 1, *, unavailable: str = "") -> str:
    try:
        if value is None:
            return unavailable
        number = float(value)
        return f"{number * 1000.0:.{ndigits}f}"
    except Exception:
        return unavailable


def _offset_parameter_label(result: Any) -> str:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    offset = diagnostics.get("offset_percent", 0.2)
    try:
        return f"{float(offset):g} %"
    except Exception:
        text = str(offset or "0.2").strip()
        return f"{text} %" if text else "0.2 %"


def _set_run_font(run, *, size_pt: int = TABLE_FONT_SIZE_PT, bold: bool = False) -> None:
    run.font.name = ARIAL
    run.font.size = Pt(size_pt)
    run.bold = bold


def _set_cell_text(cell, text: str, *, bold: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run(str(text))
    _set_run_font(run, bold=bold)


def _add_heading(document: Document, text: str, *, level: int = 1) -> None:
    paragraph = document.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = paragraph.add_run(text)
    _set_run_font(run, size_pt=9 if level > 1 else 10, bold=True)


def _rp_label_from_result(result: Any) -> str:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    label = diagnostics.get("rp_label")
    if label:
        return str(label)
    offset_percent = diagnostics.get("offset_percent", 0.2)
    try:
        return TensileAnalysisConfig(offset_percent=float(offset_percent)).rp_label
    except Exception:
        return "Rp0.2"


def _ab_points_label(result: Any) -> str:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    line_points = diagnostics.get("elastic_modulus_line_points") or {}

    def _stress(key: str) -> str:
        if isinstance(line_points, dict):
            point = line_points.get(key)
            if isinstance(point, dict):
                for name in ("y", "stress_MPa", "stress_mpa"):
                    try:
                        value = point.get(name)
                        if value is not None:
                            return _fmt(value, 0, unavailable="")
                    except Exception:
                        pass
        return ""

    a = _stress("a")
    b = _stress("b")
    return f"A: {a}, B: {b} MPa" if a and b else ""


def result_method_label(result: Any) -> str:
    """Etiqueta técnica del resultado para tablas de reporte."""
    method = getattr(result, "method", "")
    if method == METHOD_UPPER_YIELD:
        return "Esfuerzo de Fluencia Superior"
    if method == METHOD_RP_OFFSET:
        return f"Esfuerzo de Fluencia {_rp_label_from_result(result)}"
    return "Resultado de fluencia"


def build_results_table(document: Document, context_or_specimen: TensileReportContext | str, result: Any | None = None):
    """Crea la tabla editable de resultados con estructura institucional.

    La tabla usa cuatro filas para coincidir con los ejemplos Word:
    encabezados, parámetro, unidades y valores.
    """
    if isinstance(context_or_specimen, TensileReportContext):
        specimen_id = context_or_specimen.specimen_id
        method_result = context_or_specimen.method_result or result
    else:
        specimen_id = str(context_or_specimen)
        method_result = result

    if method_result is None:
        method_result = TensileMethodResult(method="manual_review", is_available=False)

    method = getattr(method_result, "method", "")
    if method == METHOD_RP_OFFSET:
        headers = ["Nombre", "Esfuerzo de Fluencia", "Esfuerzo Máximo", "Elongación luego de Rotura", "M . Elástico"]
        parameter = ["Parámetro", _offset_parameter_label(method_result), "", "", _ab_points_label(method_result)]
        units = ["Unidades", "MPa", "MPa", "%", "MPa"]
        values = [
            specimen_id,
            _fmt(getattr(method_result, "value_mpa", None), 0),
            _fmt(getattr(method_result, "max_stress_mpa", None), 0),
            _fmt(getattr(method_result, "elongation_after_break_pct", None), 1),
            _fmt_modulus_mpa_from_gpa(getattr(method_result, "elastic_modulus_gpa", None), 1),
        ]
    else:
        headers = ["Nombre", "Esfuerzo de Fluencia\nSuperior", "Esfuerzo Máximo", "Elongación luego de Rotura"]
        parameter = ["Parámetro", "1 Puntos", "", ""]
        units = ["Unidades", "MPa", "MPa", "%"]
        values = [
            specimen_id,
            _fmt(getattr(method_result, "value_mpa", None), 0),
            _fmt(getattr(method_result, "max_stress_mpa", None), 0),
            _fmt(getattr(method_result, "elongation_after_break_pct", None), 1),
        ]

    table = document.add_table(rows=4, cols=len(headers))
    table.style = "Table Grid"
    table.autofit = False
    _set_table_fixed_widths(table, RESULT_WIDTHS_RP_OFFSET_CM if method == METHOD_RP_OFFSET else RESULT_WIDTHS_UPPER_YIELD_CM)
    for row_index, row_values in enumerate((headers, parameter, units, values)):
        for col, text in enumerate(row_values):
            _set_cell_text(table.cell(row_index, col), text, bold=(row_index == 0))
    return table


def _coerce_geometry(geometry: Any) -> TensileGeometry:
    if isinstance(geometry, TensileGeometry):
        return geometry.copy()
    try:
        return TensileGeometry.from_legacy_geometry(geometry)
    except Exception:
        return TensileGeometry()


def _diagnostics_context(result: Any, extra_context: Optional[Mapping[str, Any]] = None) -> dict[str, Any]:
    diagnostics = dict(getattr(result, "diagnostics", {}) or {})
    context: dict[str, Any] = {
        "offset_percent": diagnostics.get("offset_percent", 0.2),
        "upper_yield_drop_mpa": diagnostics.get("upper_yield_drop_mpa", 1.0),
        "procedure_code": diagnostics.get("procedure_code", ""),
        "standard_label": diagnostics.get("standard_label", ""),
        "machine_label": diagnostics.get("machine_label", "MUE 600 kN"),
        "unc_esfuerzo_maximo_mpa": diagnostics.get("unc_esfuerzo_maximo_mpa", ""),
        "unc_fluencia_mpa": diagnostics.get("unc_fluencia_mpa", ""),
        "unc_elongacion_pct": diagnostics.get("unc_elongacion_pct", ""),
    }
    if extra_context:
        context.update(dict(extra_context))
    # Formato limpio para placeholders numéricos.
    for key in ("offset_percent", "upper_yield_drop_mpa"):
        try:
            context[key] = f"{float(context[key]):g}"
        except Exception:
            context[key] = str(context.get(key, "") or "")
    return context


def default_comment_for_context(
    context: TensileReportContext,
    *,
    placeholder_context: Optional[Mapping[str, Any]] = None,
) -> str:
    """Obtiene el comentario automático usando el motor de plantillas."""
    if context.comments.strip():
        return context.comments
    method = context.active_method
    if context.method_result is not None:
        method = context.method_result.method
    values = _diagnostics_context(context.method_result, placeholder_context)
    try:
        curve_proxy = SimpleNamespace(geometry=context.geometry.to_legacy_geometry())
        values.update(uncertainty_context_for_comment(curve_proxy, context.method_result))
    except Exception:
        pass
    return get_default_comment(context.geometry.geometry_type, method, values)


def _add_detection_block(document: Document, detection: Optional[Mapping[str, Any]]) -> None:
    if not detection:
        return
    _add_heading(document, "Detección automática", level=2)
    paragraph = document.add_paragraph()
    for label, key in (("Método sugerido: ", "suggested_method"), ("Confianza: ", "confidence")):
        run = paragraph.add_run(label)
        _set_run_font(run, bold=True)
        run = paragraph.add_run(str(detection.get(key, "") or ""))
        _set_run_font(run)
        paragraph.add_run("  ")
    reason = str(detection.get("reason", "") or "").strip()
    if reason:
        p = document.add_paragraph(reason)
        for run in p.runs:
            _set_run_font(run, size_pt=8)


def _add_comments_block(document: Document, comments: str) -> None:
    _add_heading(document, "Comentarios", level=2)
    lines = str(comments or "").splitlines() or [""]
    for line in lines:
        paragraph = document.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = paragraph.add_run(line)
        _set_run_font(run, size_pt=8)


def _load_document(template_path: str | Path | None = None) -> Document:
    if template_path:
        path = Path(template_path)
        if path.exists():
            return Document(str(path))
    return Document()


def export_tensile_report(
    output_path: str | Path,
    context: TensileReportContext,
    *,
    detection: Optional[Mapping[str, Any]] = None,
    source_path: str | Path | None = None,
    template_path: str | Path | None = None,
    placeholder_context: Optional[Mapping[str, Any]] = None,
    title_text: str = "INFORME DE ENSAYO DE TRACCIÓN - MÓDULO UNIFICADO",
) -> Path:
    """Genera un reporte Word unificado de tracción.

    El documento final queda editable: tablas reales, gráficos inline y sin
    restricciones de edición. ``context.comments`` puede venir ya editado por el
    usuario; si está vacío, se genera el comentario automático por geometría y
    método.
    """
    output = Path(output_path)
    document = prepare_editable_document(_load_document(template_path))
    usable = min(REPORT_TABLE_WIDTH_CM, max(1.0, usable_width_cm(document)))

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(title_text)
    _set_run_font(run, size_pt=11, bold=True)

    if source_path:
        paragraph = document.add_paragraph()
        run = paragraph.add_run("Archivo fuente: ")
        _set_run_font(run, size_pt=8, bold=True)
        run = paragraph.add_run(Path(source_path).name)
        _set_run_font(run, size_pt=8)

    _add_heading(document, "Geometría de la probeta", level=2)
    build_geometry_table(document, context.geometry, context.specimen_id, result_widths_cm=(RESULT_WIDTHS_RP_OFFSET_CM if getattr(context.method_result, "method", context.active_method) == METHOD_RP_OFFSET else RESULT_WIDTHS_UPPER_YIELD_CM))

    _add_heading(document, "Resultados", level=2)
    build_results_table(document, context)

    _add_detection_block(document, detection)

    if context.graph_path and Path(str(context.graph_path)).exists():
        _add_heading(document, "Gráfica", level=2)
        add_inline_picture(document.add_paragraph(), context.graph_path, width_cm=min(16.0, usable), center=True)

    comments = default_comment_for_context(context, placeholder_context=placeholder_context)
    _add_comments_block(document, comments)

    cleanup_editable_report(document, max_table_width_cm=usable)
    output.parent.mkdir(parents=True, exist_ok=True)
    document.save(output)
    return output


__all__ = [
    "REPORT_TABLE_WIDTH_CM",
    "build_results_table",
    "default_comment_for_context",
    "export_tensile_report",
    "result_method_label",
]
