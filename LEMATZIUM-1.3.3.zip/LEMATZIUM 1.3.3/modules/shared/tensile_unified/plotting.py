from __future__ import annotations

"""Graficacion compartida del modulo unificado de traccion.

La funcion publica de este archivo es deliberadamente independiente de las
interfaces de los modulos 1 y 2. Toma como referencia su comportamiento visual,
pero no importa ni modifica sus ventanas, calculadores ni reportes.
"""

from typing import Any, Iterable, Optional
import math
import copy

import numpy as np
from matplotlib.ticker import AutoMinorLocator, FuncFormatter, MultipleLocator

try:
    from .analysis_config import METHOD_AUTO, METHOD_RP_OFFSET, METHOD_UPPER_YIELD
except Exception:  # pragma: no cover - soporte para import directo en pruebas aisladas
    METHOD_AUTO = "auto"
    METHOD_RP_OFFSET = "rp_offset"
    METHOD_UPPER_YIELD = "upper_yield"


_METHOD_ALIASES = {
    "auto": METHOD_AUTO,
    "automatico": METHOD_AUTO,
    "automático": METHOD_AUTO,
    "fluencia superior": METHOD_UPPER_YIELD,
    "upper_yield": METHOD_UPPER_YIELD,
    "upper-yield": METHOD_UPPER_YIELD,
    "yp": METHOD_UPPER_YIELD,
    "rp offset": METHOD_RP_OFFSET,
    "rp_offset": METHOD_RP_OFFSET,
    "rp-offset": METHOD_RP_OFFSET,
    "offset": METHOD_RP_OFFSET,
    "rp": METHOD_RP_OFFSET,
    "rp0.2": METHOD_RP_OFFSET,
}


DEFAULT_COLORS = {
    "curve": "#38BDF8",
    "upper_yield_point": "#000000",
    "max_point": "#000000",
    "ab_line": "#ff0000",
    "offset_line": "#38BDF8",
    "rp_point": "#38BDF8",
    "point_a": "#ff0000",
    "point_b": "#ff0000",
}


def _safe_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        number = float(value)
        if not math.isfinite(number):
            return None
        return number
    except Exception:
        return None


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "si", "sí", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return default


def _geometry_area_mm2(curve: Any) -> Optional[float]:
    """Obtiene área efectiva solo para graficar, sin modificar cálculos.

    Algunos CSV reales exportan carga_kN + alargamiento_mm y el esfuerzo se
    calcula dinámicamente desde la geometría. Si por alguna razón la curva llega
    al graficador con ``raw_df`` sin ``stress_MPa``, este fallback evita dejar la
    gráfica vacía y usa la misma relación física usada por los módulos
    históricos: MPa = kN * 1000 / mm².
    """
    geometry = getattr(curve, "geometry", None)
    if geometry is None:
        return None

    # Modelos legacy compartidos.
    for attr in ("area_mm2", "effective_area_mm2", "area_mm2_manual"):
        try:
            value = getattr(geometry, attr, None)
            if callable(value):
                value = value()
            number = _safe_float(value)
            if number is not None and number > 0:
                return number
        except Exception:
            pass

    # Fallback conservador por si el área no está expuesta como propiedad.
    side1 = _safe_float(getattr(geometry, "side1_mm", None) or getattr(geometry, "thickness_mm", None))
    side2 = _safe_float(getattr(geometry, "side2_mm", None) or getattr(geometry, "width_mm", None))
    if side1 is not None and side2 is not None and side1 > 0 and side2 > 0:
        return side1 * side2

    diameter = _safe_float(getattr(geometry, "diameter_mm", None))
    if diameter is not None and diameter > 0:
        return math.pi * diameter ** 2 / 4.0

    return None


def _graph_y_axis_factor_and_label(curve: Any, config: dict[str, Any]) -> tuple[float, str, str]:
    """Devuelve factor para convertir MPa al eje Y visible y su etiqueta.

    Internamente el análisis sigue trabajando en MPa. Solo la gráfica usa el
    factor: MPa→kPa/Pa o MPa→kN/N mediante el área de la probeta.
    """
    y_axis = str(config.get("y_axis_type") or config.get("graph_y_axis") or "stress").strip().lower()
    if "load" in y_axis or "carga" in y_axis:
        unit = str(config.get("load_unit") or "kN").strip()
        unit = "N" if unit.lower() in {"n", "newton", "newtons"} else "kN"
        area = _geometry_area_mm2(curve)
        area_f = _safe_float(area)
        if area_f is None or area_f <= 0:
            raise ValueError("Para graficar Carga vs alargamiento se requiere un área de probeta válida.")
        factor = area_f if unit == "N" else area_f / 1000.0
        return float(factor), f"Carga ({unit})", unit
    unit = str(config.get("stress_unit") or "MPa").strip()
    mapping = {"mpa": (1.0, "MPa"), "kpa": (1000.0, "kPa"), "pa": (1000000.0, "Pa")}
    factor, normalized = mapping.get(unit.lower(), (1.0, "MPa"))
    return float(factor), f"Esfuerzo ({normalized})", normalized


def _scale_nested_y_values(value: Any, factor: float) -> Any:
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if str(key).lower() == "y":
                number = _safe_float(item)
                out[key] = number * factor if number is not None else item
            else:
                out[key] = _scale_nested_y_values(item, factor)
        return out
    if isinstance(value, list):
        return [_scale_nested_y_values(item, factor) for item in value]
    return value


def _scaled_analysis_result_for_y_axis(analysis_result: Any, factor: float) -> Any:
    try:
        factor_f = float(factor)
    except Exception:
        return analysis_result
    if abs(factor_f - 1.0) <= 1e-12:
        return analysis_result
    try:
        result = copy.deepcopy(analysis_result)
    except Exception:
        return analysis_result

    seen: set[int] = set()
    for attr_name in ("selected_result", "upper_yield_result", "rp_offset_result"):
        sub = getattr(result, attr_name, None)
        if sub is None or id(sub) in seen:
            continue
        seen.add(id(sub))
        for value_attr in ("value_mpa", "max_stress_mpa"):
            number = _safe_float(getattr(sub, value_attr, None))
            if number is not None:
                try:
                    setattr(sub, value_attr, number * factor_f)
                except Exception:
                    pass
        diagnostics = getattr(sub, "diagnostics", None)
        if isinstance(diagnostics, dict):
            for key in ("elastic_modulus_slope_mpa_per_mm", "elastic_line_intercept_mpa"):
                number = _safe_float(diagnostics.get(key))
                if number is not None:
                    diagnostics[key] = number * factor_f
            if isinstance(diagnostics.get("elastic_modulus_line_points"), dict):
                diagnostics["elastic_modulus_line_points"] = _scale_nested_y_values(diagnostics.get("elastic_modulus_line_points"), factor_f)
    return result


def _get_curve_df(curve: Any):
    if curve is None:
        raise ValueError("No hay curva para graficar.")

    df = None
    for attr in ("df", "raw_df", "data", "dataframe"):
        try:
            value = getattr(curve, attr, None)
        except Exception:
            continue
        if callable(value):
            try:
                value = value()
            except Exception:
                continue
        if value is not None:
            df = value
            break

    if df is None:
        raise ValueError("La curva no contiene DataFrame graficable.")

    df = df.copy()
    if "elongation_mm" not in df.columns:
        raise ValueError("La curva no contiene la columna elongation_mm.")

    if "stress_MPa" not in df.columns:
        if "load_kN" not in df.columns:
            raise ValueError("La curva no contiene stress_MPa ni load_kN para calcular esfuerzo.")
        area_mm2 = _geometry_area_mm2(curve)
        if area_mm2 is None or area_mm2 <= 0:
            raise ValueError("La curva tiene load_kN, pero no hay área válida para calcular stress_MPa.")
        df["stress_MPa"] = np.asarray(df["load_kN"], dtype=float) * 1000.0 / float(area_mm2)

    return df.copy()


def _series_to_float_array(series: Any) -> np.ndarray:
    try:
        return np.asarray(series, dtype=float)
    except Exception:
        return np.asarray([], dtype=float)


def _finite_xy(x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mask = np.isfinite(x) & np.isfinite(y)
    return x[mask], y[mask]


def _get_result_for_method(analysis_result: Any, method: str) -> Any:
    if method == METHOD_UPPER_YIELD:
        return getattr(analysis_result, "upper_yield_result", None)
    if method == METHOD_RP_OFFSET:
        return getattr(analysis_result, "rp_offset_result", None)
    return getattr(analysis_result, "selected_result", None)


def _normalize_method_name(value: Any) -> str:
    """Normaliza nombres internos y etiquetas visibles de metodo.

    La UI del modulo unificado trabaja con etiquetas en espanol, mientras que el
    analizador devuelve constantes internas. Esta funcion evita que el
    graficador dependa de una sola representacion textual.
    """
    text = str(value or METHOD_AUTO).strip().lower()
    return _METHOD_ALIASES.get(text, text)


def _selected_method(analysis_result: Any, active_method: str) -> str:
    method = _normalize_method_name(active_method)
    if method == METHOD_AUTO:
        selected = getattr(analysis_result, "selected_result", None)
        method = _normalize_method_name(getattr(selected, "method", METHOD_AUTO))
    return method


def _result_diagnostics(result: Any) -> dict[str, Any]:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    return diagnostics if isinstance(diagnostics, dict) else {}


def _analysis_diagnostics(analysis_result: Any) -> dict[str, Any]:
    diagnostics = getattr(analysis_result, "diagnostics", {}) or {}
    return diagnostics if isinstance(diagnostics, dict) else {}


def _nice_step(max_value: float, target_steps: int = 8) -> float:
    max_value = max(float(max_value), 1e-9)
    raw = max_value / max(target_steps, 1)
    exponent = math.floor(math.log10(raw)) if raw > 0 else 0
    fraction = raw / (10 ** exponent)
    if fraction <= 1:
        nice = 1
    elif fraction <= 2:
        nice = 2
    elif fraction <= 2.5:
        nice = 2.5
    elif fraction <= 5:
        nice = 5
    else:
        nice = 10
    return nice * (10 ** exponent)


def _ceil_to_step(value: float, step: float) -> float:
    if step <= 0:
        return value
    return math.ceil(value / step) * step


def _candidate_integer_steps(reference: float) -> list[float]:
    reference = max(float(reference), 1e-9)
    exponent = math.floor(math.log10(reference)) if reference > 0 else 0
    bases = (1, 2, 3, 4, 5, 6, 7, 8, 10)
    candidates: set[float] = set()
    for exp in range(exponent - 2, exponent + 3):
        scale = 10.0 ** exp
        for base in bases:
            step = float(base * scale)
            if reference >= 1.0 and step < 1.0:
                continue
            candidates.add(step)
    return sorted(step for step in candidates if step > 0)


def _auto_axis_scale(data_max: float, *, headroom: float = 0.06, target_intervals: int = 9) -> tuple[float, float]:
    data_max = max(float(data_max), 1e-9)
    desired_max = max(data_max * (1.0 + max(float(headroom), 0.0)), data_max + 1e-9)
    reference_step = desired_max / max(int(target_intervals), 1)
    best: tuple[float, float, float] | None = None
    for step in _candidate_integer_steps(reference_step):
        axis_max = _ceil_to_step(desired_max, step)
        intervals = max(axis_max / step, 1.0)
        if not (6.0 <= intervals <= 14.0):
            continue
        blank_ratio = max(axis_max - desired_max, 0.0) / desired_max
        score = abs(intervals - float(target_intervals)) * 0.65 + blank_ratio * 10.0
        candidate = (score, float(step), float(axis_max))
        if best is None or candidate[0] < best[0]:
            best = candidate
    if best is not None:
        return best[1], best[2]
    fallback_step = _nice_step(desired_max, target_steps=max(target_intervals, 1))
    return float(fallback_step), float(_ceil_to_step(desired_max, fallback_step))


def _configure_decimal_formatters(ax: Any) -> None:
    def _integer_if_close(value: float) -> Optional[str]:
        try:
            number = float(value)
            rounded = round(number)
            if abs(number - rounded) <= 1e-9:
                return str(int(rounded))
        except Exception:
            return None
        return None

    def smart_fmt_x(value: float, _pos: Any = None) -> str:
        integer = _integer_if_close(value)
        if integer is not None:
            return integer
        x0, x1 = ax.get_xlim()
        span = abs(x1 - x0)
        if span <= 0.01:
            return f"{value:.5f}"
        if span <= 0.10:
            return f"{value:.4f}"
        if span <= 1.0:
            return f"{value:.3f}"
        if span <= 10.0:
            return f"{value:.2f}"
        return f"{value:.1f}"

    def smart_fmt_y(value: float, _pos: Any = None) -> str:
        integer = _integer_if_close(value)
        if integer is not None:
            return integer
        y0, y1 = ax.get_ylim()
        span = abs(y1 - y0)
        if span <= 1.0:
            return f"{value:.4f}"
        if span <= 10.0:
            return f"{value:.3f}"
        if span <= 100.0:
            return f"{value:.2f}"
        return f"{value:.1f}"

    ax.xaxis.set_major_formatter(FuncFormatter(smart_fmt_x))
    ax.yaxis.set_major_formatter(FuncFormatter(smart_fmt_y))
    ax.format_coord = lambda x, y: f"x={x:.4f} mm | y={y:.4f}"

def _apply_axes_config(ax: Any, graph_config: dict[str, Any], x: np.ndarray, y: np.ndarray) -> None:
    x_data_min = float(np.nanmin(x)) if len(x) else 0.0
    y_data_min = float(np.nanmin(y)) if len(y) else 0.0
    x_data_max = max(float(np.nanmax(x)) if len(x) else 1.0, 1e-6)
    y_data_max = max(float(np.nanmax(y)) if len(y) else 1.0, 1e-6)
    axis_mode = str(graph_config.get("axis_mode", "auto")).lower().strip()
    anchor_origin = _as_bool(graph_config.get("anchor_origin"), default=True)
    headroom = _safe_float(graph_config.get("axis_headroom_fraction"))
    if headroom is None:
        headroom = 0.06

    supplied_x_grid = _safe_float(graph_config.get("grid_x"))
    supplied_y_grid = _safe_float(graph_config.get("grid_y"))

    if axis_mode == "manual":
        x_grid = supplied_x_grid or _nice_step(max(abs(x_data_max - x_data_min), x_data_max, 1e-6), target_steps=10)
        y_grid = supplied_y_grid or _nice_step(max(abs(y_data_max - y_data_min), y_data_max, 1e-6), target_steps=10)
        x_min = _safe_float(graph_config.get("x_min"))
        x_max = _safe_float(graph_config.get("x_max"))
        y_min = _safe_float(graph_config.get("y_min"))
        y_max = _safe_float(graph_config.get("y_max"))
        if anchor_origin:
            x_min = 0.0 if x_min is None else x_min
            y_min = 0.0 if y_min is None else y_min
        else:
            x_min = x_data_min if x_min is None else x_min
            y_min = y_data_min if y_min is None else y_min
        x_max = _ceil_to_step(x_data_max * (1.0 + max(float(headroom), 0.0)), x_grid) if x_max is None else x_max
        y_max = _ceil_to_step(y_data_max * (1.0 + max(float(headroom), 0.0)), y_grid) if y_max is None else y_max
    else:
        x_min = 0.0 if anchor_origin else min(0.0, x_data_min)
        y_min = 0.0 if anchor_origin else min(0.0, y_data_min)
        if supplied_x_grid is not None and supplied_x_grid > 0:
            x_grid = supplied_x_grid
            x_max = _ceil_to_step(x_data_max * (1.0 + max(float(headroom), 0.0)), x_grid)
        else:
            x_grid, x_max = _auto_axis_scale(x_data_max, headroom=float(headroom), target_intervals=9)
        if supplied_y_grid is not None and supplied_y_grid > 0:
            y_grid = supplied_y_grid
            y_max = _ceil_to_step(y_data_max * (1.0 + max(float(headroom), 0.0)), y_grid)
        else:
            y_grid, y_max = _auto_axis_scale(y_data_max, headroom=float(headroom), target_intervals=9)

    if x_max <= x_min:
        x_max = x_min + max(float(x_grid), 1e-6)
    if y_max <= y_min:
        y_max = y_min + max(float(y_grid), 1e-6)
    ax.set_xlim(float(x_min), float(x_max))
    ax.set_ylim(float(y_min), float(y_max))
    if x_grid > 0:
        ax.xaxis.set_major_locator(MultipleLocator(float(x_grid)))
        ax.xaxis.set_minor_locator(MultipleLocator(float(x_grid) / 2.0))
    else:
        ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    if y_grid > 0:
        ax.yaxis.set_major_locator(MultipleLocator(float(y_grid)))
        ax.yaxis.set_minor_locator(MultipleLocator(float(y_grid) / 2.0))
    else:
        ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    _configure_decimal_formatters(ax)

def _dedupe_legend_entries(handles: Iterable[Any], labels: Iterable[str]) -> tuple[list[Any], list[str]]:
    unique_handles: list[Any] = []
    unique_labels: list[str] = []
    seen: set[str] = set()
    for handle, label in zip(handles, labels):
        if not label or str(label).startswith("_") or label in seen:
            continue
        seen.add(label)
        unique_handles.append(handle)
        unique_labels.append(label)
    return unique_handles, unique_labels


def _apply_legend(ax: Any, graph_config: dict[str, Any]) -> None:
    # legend_mode tiene prioridad sobre mode para permitir que la interfaz use
    # modo pantalla con leyenda externa, y modo reporte con leyenda protegida.
    mode = str(graph_config.get("legend_mode", graph_config.get("mode", "screen"))).lower().strip()
    handles, labels = _dedupe_legend_entries(*ax.get_legend_handles_labels())
    existing = ax.get_legend()
    if existing is not None:
        existing.remove()
    if not handles:
        return

    single_label = str(graph_config.get("legend_single_label") or "").strip()
    if single_label:
        handles = [handles[0]]
        labels = [single_label]

    fig = getattr(ax, "figure", None)
    if mode in {"report_right", "outside_report", "report_outside"}:
        if fig is not None:
            fig.subplots_adjust(left=0.075, right=0.855, bottom=0.16, top=0.955)
        legend = ax.legend(
            handles,
            labels,
            loc="upper left",
            bbox_to_anchor=(1.022, 1.0),
            borderaxespad=0.0,
            fontsize=8.5,
            frameon=True,
            fancybox=False,
            framealpha=1.0,
            facecolor="#FFFFFF",
            edgecolor="#555555",
            borderpad=0.48,
            labelspacing=0.34,
            handlelength=2.10,
        )
        try:
            legend.get_frame().set_linewidth(0.9)
        except Exception:
            pass
        return

    if mode in {"report", "inside", "inside_report"}:
        legend = ax.legend(
            handles,
            labels,
            loc="best",
            fontsize=8.5,
            frameon=True,
            fancybox=False,
            framealpha=1.0,
            facecolor="#FFFFFF",
            edgecolor="#555555",
            borderpad=0.48,
            labelspacing=0.34,
            handlelength=2.10,
        )
        try:
            legend.get_frame().set_linewidth(0.9)
        except Exception:
            pass
        if fig is not None:
            fig.subplots_adjust(left=0.085, right=0.985, bottom=0.16, top=0.955)
        return

    if fig is not None:
        fig.subplots_adjust(left=0.085, right=0.855, bottom=0.16, top=0.955)
    legend = ax.legend(
        handles,
        labels,
        loc="upper left",
        bbox_to_anchor=(1.022, 1.0),
        borderaxespad=0.0,
        fontsize=8.5,
        frameon=True,
        fancybox=False,
        framealpha=1.0,
        facecolor="#FFFFFF",
        edgecolor="#555555",
        borderpad=0.48,
        labelspacing=0.34,
        handlelength=2.10,
    )
    try:
        legend.get_frame().set_linewidth(0.9)
    except Exception:
        pass

def _line_points_for_visible_box(m: float, b: float, xlim: Any, ylim: Any, overscan: float = 0.20) -> tuple[tuple[float, float], tuple[float, float]]:
    x0, x1 = float(xlim[0]), float(xlim[1])
    y0, y1 = float(ylim[0]), float(ylim[1])
    dx = max(abs(x1 - x0), 1e-9)
    dy = max(abs(y1 - y0), 1e-9)
    x0e, x1e = x0 - dx * overscan, x1 + dx * overscan
    y0e, y1e = y0 - dy * overscan, y1 + dy * overscan

    pts: list[tuple[float, float]] = []
    for px in (x0e, x1e):
        py = m * px + b
        if y0e <= py <= y1e:
            pts.append((px, py))

    if abs(m) < 1e-12:
        if y0e <= b <= y1e:
            pts.extend([(x0e, b), (x1e, b)])
    else:
        for py in (y0e, y1e):
            px = (py - b) / m
            if x0e <= px <= x1e:
                pts.append((px, py))

    unique: list[tuple[float, float]] = []
    for px, py in pts:
        if not any(abs(px - ux) < 1e-9 and abs(py - uy) < 1e-9 for ux, uy in unique):
            unique.append((px, py))

    if len(unique) >= 2:
        best_pair = (unique[0], unique[1])
        best_dist = -1.0
        for i in range(len(unique)):
            for j in range(i + 1, len(unique)):
                dist = (unique[i][0] - unique[j][0]) ** 2 + (unique[i][1] - unique[j][1]) ** 2
                if dist > best_dist:
                    best_dist = dist
                    best_pair = (unique[i], unique[j])
        return best_pair

    xline = np.array([x0e, x1e], dtype=float)
    yline = m * xline + b
    return (float(xline[0]), float(yline[0])), (float(xline[1]), float(yline[1]))


def _point_from_index(df: Any, index: Any) -> tuple[Optional[float], Optional[float]]:
    try:
        idx = int(index)
    except Exception:
        return None, None
    if idx < 0 or idx >= len(df):
        return None, None
    row = df.iloc[idx]
    return _safe_float(row.get("elongation_mm")), _safe_float(row.get("stress_MPa"))


def _plot_scatter(
    ax: Any,
    x: Any,
    y: Any,
    *,
    label: str,
    color: str,
    marker_size: float = 48,
    annotate: Optional[str] = None,
    show_marker: bool = True,
    annotation_offset: tuple[float, float] = (5, -7),
) -> None:
    px = _safe_float(x)
    py = _safe_float(y)
    if px is None or py is None:
        return
    if not show_marker:
        return
    ax.scatter([px], [py], s=marker_size, zorder=6, color=color, edgecolors="white", linewidths=0.8, label=label)
    if annotate:
        ax.annotate(annotate, (px, py), textcoords="offset points", xytext=annotation_offset, fontsize=9, color=color)


def _max_point(df: Any, analysis_result: Any, result: Any) -> tuple[Optional[float], Optional[float]]:
    diagnostics = _analysis_diagnostics(analysis_result)
    x = _safe_float(diagnostics.get("max_elongation_mm"))
    y = _safe_float(getattr(result, "max_stress_mpa", None))
    if x is not None and y is not None:
        return x, y
    try:
        stresses = np.asarray(df["stress_MPa"], dtype=float)
        if len(stresses):
            idx = int(np.nanargmax(stresses))
            row = df.iloc[idx]
            return _safe_float(row.get("elongation_mm")), _safe_float(row.get("stress_MPa"))
    except Exception:
        pass
    return x, y


def _draw_upper_yield(
    ax: Any,
    df: Any,
    analysis_result: Any,
    colors: dict[str, str],
    *,
    show_annotations: bool = True,
    show_points: bool = True,
    show_max: bool = True,
    show_yp_point: bool = True,
    show_max_point: bool = True,
) -> None:
    result = _get_result_for_method(analysis_result, METHOD_UPPER_YIELD)
    diagnostics = _result_diagnostics(result)
    yp_x = _safe_float(diagnostics.get("point_x_mm"))
    yp_y = _safe_float(getattr(result, "value_mpa", None))
    if yp_x is None or yp_y is None:
        idx_x, idx_y = _point_from_index(df, diagnostics.get("point_index"))
        yp_x = yp_x if yp_x is not None else idx_x
        yp_y = yp_y if yp_y is not None else idx_y
    max_x, max_y = _max_point(df, analysis_result, result)
    yp_offset = (5, -7)
    max_offset = (5, -7)
    try:
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        x_span = max(abs(float(xlim[1]) - float(xlim[0])), 1e-12)
        y_span = max(abs(float(ylim[1]) - float(ylim[0])), 1e-12)
        f_yp_x = _safe_float(yp_x)
        f_yp_y = _safe_float(yp_y)
        f_max_x = _safe_float(max_x)
        f_max_y = _safe_float(max_y)
        if None not in (f_yp_x, f_yp_y, f_max_x, f_max_y):
            distance = ((f_yp_x - f_max_x) / x_span) ** 2 + ((f_yp_y - f_max_y) / y_span) ** 2
            if distance <= 0.0016:
                yp_offset = (6, 9)
                max_offset = (6, -15)
    except Exception:
        pass
    _plot_scatter(
        ax,
        yp_x,
        yp_y,
        label="Fluencia superior",
        color=colors["upper_yield_point"],
        marker_size=56,
        annotate="YP" if show_annotations else None,
        show_marker=show_points and show_yp_point,
        annotation_offset=yp_offset,
    )
    if show_max:
        _plot_scatter(
            ax,
            max_x,
            max_y,
            label="Máximo",
            color=colors["max_point"],
            marker_size=48,
            annotate="MÁX" if show_annotations else None,
            show_marker=show_points and show_max_point,
            annotation_offset=max_offset,
        )

def _line_from_ab(df: Any, diagnostics: dict[str, Any]) -> tuple[Optional[float], Optional[float], Optional[float], Optional[float], Optional[float], Optional[float]]:
    indices = diagnostics.get("elastic_modulus_line_indices") or {}
    line_points = diagnostics.get("elastic_modulus_line_points") or {}

    def _line_point(key: str, idx_key: str) -> tuple[Optional[float], Optional[float]]:
        point = line_points.get(key) if isinstance(line_points, dict) else None
        if isinstance(point, dict):
            px = _safe_float(point.get("x"))
            py = _safe_float(point.get("y"))
            if px is not None and py is not None:
                return px, py
        idx = indices.get(idx_key) if isinstance(indices, dict) else None
        return _point_from_index(df, idx)

    ax_mm, ay_mpa = _line_point("a", "a")
    bx_mm, by_mpa = _line_point("b", "b")
    slope = _safe_float(diagnostics.get("elastic_modulus_slope_mpa_per_mm"))
    intercept = _safe_float(diagnostics.get("elastic_line_intercept_mpa"))
    if ax_mm is None or ay_mpa is None or bx_mm is None or by_mpa is None:
        return None, None, None, None, None, None
    if slope is None:
        dx = bx_mm - ax_mm
        if abs(dx) < 1e-12:
            return None, None, None, None, None, None
        slope = (by_mpa - ay_mpa) / dx
    if intercept is None:
        intercept = ay_mpa - slope * ax_mm
    return slope, intercept, ax_mm, ay_mpa, bx_mm, by_mpa


def _draw_rp_offset(
    ax: Any,
    df: Any,
    analysis_result: Any,
    colors: dict[str, str],
    *,
    show_annotations: bool = True,
    show_points: bool = True,
    show_max: bool = True,
    show_max_annotation: bool = True,
    show_ab_points: bool = True,
    show_rp_point: bool = True,
    show_point_a: bool = True,
    show_point_b: bool = True,
    show_max_point: bool = True,
    show_rp_lines: bool = True,
) -> None:
    result = _get_result_for_method(analysis_result, METHOD_RP_OFFSET)
    diagnostics = _result_diagnostics(result)
    line = _line_from_ab(df, diagnostics)
    slope, intercept, ax_mm, ay_mpa, bx_mm, by_mpa = line
    rp_label = str(diagnostics.get("rp_label") or "Rp")

    if show_rp_lines and slope is not None and intercept is not None:
        p1, p2 = _line_points_for_visible_box(slope, intercept, ax.get_xlim(), ax.get_ylim(), overscan=0.35)
        ax.plot(
            [p1[0], p2[0]],
            [p1[1], p2[1]],
            color=colors["ab_line"],
            linewidth=1.8,
            linestyle="-",
            label="Recta elástica A-B",
        )
        offset_mm = _safe_float(diagnostics.get("offset_mm"))
        if offset_mm is not None:
            offset_intercept = intercept - slope * offset_mm
            op1, op2 = _line_points_for_visible_box(slope, offset_intercept, ax.get_xlim(), ax.get_ylim(), overscan=0.35)
            ax.plot(
                [op1[0], op2[0]],
                [op1[1], op2[1]],
                color=colors["offset_line"],
                linewidth=1.8,
                linestyle="--",
                label=f"Recta offset {rp_label}",
            )

    _plot_scatter(
        ax,
        ax_mm,
        ay_mpa,
        label="Punto A",
        color=colors["point_a"],
        marker_size=38,
        annotate="A" if show_annotations else None,
        show_marker=show_points and show_ab_points and show_point_a,
    )
    _plot_scatter(
        ax,
        bx_mm,
        by_mpa,
        label="Punto B",
        color=colors["point_b"],
        marker_size=38,
        annotate="B" if show_annotations else None,
        show_marker=show_points and show_ab_points and show_point_b,
    )
    rp_x = _safe_float(diagnostics.get("point_x_mm"))
    rp_y = _safe_float(getattr(result, "value_mpa", None))
    if rp_x is None or rp_y is None:
        idx_x, idx_y = _point_from_index(df, diagnostics.get("point_index"))
        rp_x = rp_x if rp_x is not None else idx_x
        rp_y = rp_y if rp_y is not None else idx_y
    _plot_scatter(
        ax,
        rp_x,
        rp_y,
        label=rp_label,
        color=colors["rp_point"],
        marker_size=58,
        annotate=rp_label if show_annotations else None,
        show_marker=show_points and show_rp_point,
    )
    if show_max:
        max_x, max_y = _max_point(df, analysis_result, result)
        _plot_scatter(
            ax,
            max_x,
            max_y,
            label="Máximo",
            color=colors["max_point"],
            marker_size=48,
            annotate="MÁX" if show_max_annotation else None,
            show_marker=show_max_point,
        )


def _result_has_point(result: Any) -> bool:
    diagnostics = _result_diagnostics(result)
    return (
        _safe_float(getattr(result, "value_mpa", None)) is not None
        or diagnostics.get("point_index") is not None
        or _safe_float(diagnostics.get("point_x_mm")) is not None
    )


def _rp_has_reference(result: Any) -> bool:
    diagnostics = _result_diagnostics(result)
    indices = diagnostics.get("elastic_modulus_line_indices") or {}
    has_line = isinstance(indices, dict) and (indices.get("a") is not None or indices.get("b") is not None)
    return has_line or _result_has_point(result)


def _draw_max_marker(
    ax: Any,
    df: Any,
    analysis_result: Any,
    colors: dict[str, str],
    *,
    show_annotations: bool = True,
    show_max_point: bool = True,
) -> None:
    selected = getattr(analysis_result, "selected_result", None)
    if selected is None:
        selected = getattr(analysis_result, "upper_yield_result", None) or getattr(analysis_result, "rp_offset_result", None)
    max_x, max_y = _max_point(df, analysis_result, selected)
    _plot_scatter(
        ax,
        max_x,
        max_y,
        label="Máximo",
        color=colors["max_point"],
        marker_size=50,
        annotate="MÁX" if show_annotations else None,
        show_marker=show_max_point,
    )


def _draw_all_reference_overlays(
    ax: Any,
    df: Any,
    analysis_result: Any,
    colors: dict[str, str],
    *,
    show_annotations: bool = True,
    show_yp_point: bool = True,
    show_rp_point: bool = False,
    show_point_a: bool = False,
    show_point_b: bool = False,
    show_max_point: bool = True,
    show_rp_lines: bool = True,
) -> None:
    """Dibuja siempre referencias disponibles, independientemente del cursor.

    La cruz de precisión se crea en la capa de la UI, después del redibujado de
    la gráfica. Los puntos YP/MÁX y las rectas Rp se dibujan aquí con zorder
    menor; no se eliminan ni dependen de la visibilidad de la cruz.
    """
    upper = getattr(analysis_result, "upper_yield_result", None)
    rp = getattr(analysis_result, "rp_offset_result", None)
    if _result_has_point(upper):
        _draw_upper_yield(
            ax,
            df,
            analysis_result,
            colors,
            show_annotations=show_annotations,
            show_points=True,
            show_max=False,
            show_yp_point=show_yp_point,
            show_max_point=show_max_point,
        )
    if _rp_has_reference(rp):
        _draw_rp_offset(
            ax,
            df,
            analysis_result,
            colors,
            show_annotations=show_annotations,
            show_points=True,
            show_max=False,
            show_max_annotation=show_annotations,
            show_ab_points=True,
            show_rp_point=show_rp_point,
            show_point_a=show_point_a,
            show_point_b=show_point_b,
            show_max_point=show_max_point,
            show_rp_lines=show_rp_lines,
        )
    _draw_max_marker(ax, df, analysis_result, colors, show_annotations=show_annotations, show_max_point=show_max_point)


def draw_unified_tensile_curve(ax: Any, curve: Any, analysis_result: Any, active_method: str, graph_config: dict[str, Any] | None = None) -> None:
    """Dibuja la curva del modulo unificado segun el metodo activo.

    Parameters
    ----------
    ax:
        Eje Matplotlib destino.
    curve:
        Curva de traccion con ``df`` o ``raw_df`` y columnas ``elongation_mm`` y
        ``stress_MPa``.
    analysis_result:
        Resultado devuelto por ``shared.tensile_unified.analyze_curve``.
    active_method:
        ``upper_yield``, ``rp_offset`` o ``auto``. Tambien acepta las etiquetas
        visibles ``Fluencia superior``, ``Rp offset`` y ``Automático``. En
        ``auto`` se usa el metodo seleccionado por el analizador.
    graph_config:
        Diccionario opcional. Claves soportadas: ``mode`` (``screen`` o
        ``report``), ``legend_mode``, ``axis_mode``, ``x_max``, ``y_max``,
        ``grid_x``, ``grid_y``, ``colors`` y ``comparison_mode``.
    """
    config: dict[str, Any] = dict(graph_config or {})
    colors = dict(DEFAULT_COLORS)
    colors.update(config.get("colors") or {})

    clear_axes = _as_bool(config.get("clear_axes"), default=True)
    configure_axes = _as_bool(config.get("configure_axes"), default=True)
    apply_legend = _as_bool(config.get("apply_legend"), default=True)
    draw_labels = _as_bool(config.get("draw_labels"), default=clear_axes)
    if clear_axes:
        ax.clear()
    df = config.get("_precomputed_df")
    if df is None:
        df = _get_curve_df(curve)
    df = df.copy()
    y_factor, y_label, y_unit = _graph_y_axis_factor_and_label(curve, config)
    plot_result = _scaled_analysis_result_for_y_axis(analysis_result, y_factor)
    df["stress_MPa"] = _series_to_float_array(df["stress_MPa"]) * float(y_factor)
    x = _series_to_float_array(df["elongation_mm"])
    y = _series_to_float_array(df["stress_MPa"])
    x, y = _finite_xy(x, y)
    if len(x) == 0 or len(y) == 0:
        raise ValueError("No hay datos numericos finitos para graficar.")

    specimen_id = str(getattr(curve, "specimen_id", "") or "Curva")
    method = _selected_method(plot_result, active_method)

    report_clean = _as_bool(config.get("report_clean"), default=False)
    ax.set_facecolor(config.get("facecolor", "#fbfcfd"))
    curve_label = str(config.get("curve_label") or specimen_id or "Curva esfuerzo-alargamiento")
    plot_kwargs = {"linewidth": float(config.get("curve_linewidth", 1.25)), "label": curve_label}
    if not _as_bool(config.get("use_axes_color_cycle"), default=False):
        plot_kwargs["color"] = colors["curve"]
    ax.plot(x, y, **plot_kwargs)
    if draw_labels:
        ax.set_xlabel("Alargamiento (mm)")
        ax.set_ylabel(y_label)
        # Por requerimiento de reporte/PNG, la gráfica no debe llevar título.
        # Se deja una opción explícita por compatibilidad interna, desactivada por defecto.
        if _as_bool(config.get("show_title"), default=False):
            ax.set_title(f"Curva esfuerzo-alargamiento: {specimen_id}", fontsize=12)
        else:
            ax.set_title("")
    if configure_axes:
        _apply_axes_config(ax, config, x, y)
    elif clear_axes:
        _configure_decimal_formatters(ax)

    if report_clean:
        # Estilo específico de reporte: líneas principales continuas y
        # secundarias punteadas. Se usa un punteado más contrastado porque la
        # rasterización PNG + el reescalado de Word atenuaban la cuadrícula
        # secundaria hasta volverla casi imperceptible en el informe final.
        ax.set_axisbelow(True)
        ax.grid(True, which="major", color="#777777", linestyle="-", linewidth=0.82, alpha=0.98)
        ax.grid(True, which="minor", color="#737373", linestyle=(0, (1.35, 2.15)), linewidth=0.82, alpha=1.0)
        tick_label_size = int(_safe_float(config.get("report_tick_label_size")) or 7)
        ax.tick_params(axis="both", which="major", labelsize=tick_label_size)
        ax.tick_params(axis="both", which="minor", labelsize=max(5, tick_label_size - 1))
    else:
        ax.grid(True, which="major", color="#8fa1b5", linestyle="--", linewidth=0.85, alpha=0.96)
        ax.grid(True, which="minor", color="#c8d3df", linestyle=":", linewidth=0.60, alpha=0.86)

    # Dibuja únicamente las referencias correspondientes al método vigente.
    # Visibilidad por defecto solicitada para interfaz y reporte:
    # YP y MÁX visibles; A, B y R2P/Rp ocultos salvo activación manual.
    show_yp_point = _as_bool(config.get("show_point_yp", config.get("show_yp_point")), default=True)
    show_rp_point = _as_bool(config.get("show_point_rp", config.get("show_rp_point")), default=False)
    show_point_a = _as_bool(config.get("show_point_a", config.get("show_a_point")), default=False)
    show_point_b = _as_bool(config.get("show_point_b", config.get("show_b_point")), default=False)
    show_max_point = _as_bool(config.get("show_point_max", config.get("show_max_point")), default=True)
    show_rp_lines = _as_bool(config.get("show_r2p_lines", config.get("show_rp_lines")), default=True)
    # En modo Automático, method ya viene resuelto por _selected_method() a partir
    # de la clasificación de la curva. La cruz de precisión se dibuja después en
    # la UI y no debe eliminar ni sustituir estos artistas.
    show_overlay_legend = _as_bool(config.get("overlay_legend"), default=True)
    if method == METHOD_UPPER_YIELD:
        _draw_upper_yield(
            ax,
            df,
            plot_result,
            colors,
            show_annotations=True,
            show_points=True,
            show_max=show_max_point,
            show_yp_point=show_yp_point,
            show_max_point=show_max_point,
        )
    elif method == METHOD_RP_OFFSET:
        _draw_rp_offset(
            ax,
            df,
            plot_result,
            colors,
            show_annotations=True,
            show_points=True,
            show_max=True,
            show_max_annotation=True,
            show_ab_points=True,
            show_rp_point=show_rp_point,
            show_point_a=show_point_a,
            show_point_b=show_point_b,
            show_max_point=show_max_point,
            show_rp_lines=show_rp_lines,
        )
    else:
        _draw_max_marker(ax, df, plot_result, colors, show_annotations=True, show_max_point=show_max_point)

    if not show_overlay_legend:
        try:
            curve_label_keep = str(config.get("curve_label") or specimen_id or "Curva esfuerzo-alargamiento")
            for artist in list(getattr(ax, "lines", [])) + list(getattr(ax, "collections", [])):
                label = str(getattr(artist, "get_label", lambda: "")() or "")
                if label and label != curve_label_keep and not label.startswith("_"):
                    artist.set_label("_nolegend_")
        except Exception:
            pass

    try:
        ax.format_coord = lambda x, y: f"x={x:.4f} mm | y={y:.4f} {y_unit}"
    except Exception:
        pass

    if apply_legend:
        _apply_legend(ax, config)


__all__ = ["DEFAULT_COLORS", "draw_unified_tensile_curve"]
