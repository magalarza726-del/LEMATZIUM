from __future__ import annotations

"""Adaptadores de compatibilidad para migración progresiva.

Este módulo conecta los controladores históricos de módulo 1 y módulo 2 con el
motor común ``shared.tensile_unified.analyzer`` sin reemplazar todavía sus
algoritmos internos ni cambiar los flujos existentes.

Principio de esta fase:
- el cálculo histórico sigue ejecutándose primero;
- el motor común se ejecuta después, con método preconfigurado;
- el resultado unificado se guarda como diagnóstico/adaptador;
- no se borran funciones antiguas ni se cambian rutas públicas.
"""

from typing import Any, Optional

from .analysis_config import METHOD_AUTO, METHOD_RP_OFFSET, METHOD_UPPER_YIELD, TensileAnalysisConfig


LEGACY_UNIFIED_ATTR = "unified_analysis"


def module1_config(upper_yield_drop_mpa: Optional[float] = None) -> TensileAnalysisConfig:
    """Configuración predefinida para módulo 1: Fluencia superior.

    ``method_locked`` permanece en False para que la migración futura permita al
    analista cambiar método sin romper la compatibilidad actual.
    """
    return TensileAnalysisConfig(
        active_method=METHOD_UPPER_YIELD,
        upper_yield_drop_mpa=1.0 if upper_yield_drop_mpa is None else upper_yield_drop_mpa,
        offset_percent=0.2,
        allow_manual_override=True,
        method_locked=False,
    )


def module2_config(offset_percent: Optional[float] = None) -> TensileAnalysisConfig:
    """Configuración predefinida para módulo 2: Rp offset."""
    return TensileAnalysisConfig(
        active_method=METHOD_RP_OFFSET,
        upper_yield_drop_mpa=1.0,
        offset_percent=0.2 if offset_percent is None else offset_percent,
        allow_manual_override=True,
        method_locked=False,
    )


def unified_auto_config(
    *,
    upper_yield_drop_mpa: float = 1.0,
    offset_percent: float = 0.2,
) -> TensileAnalysisConfig:
    """Configuración predefinida para el módulo unificado: automático."""
    return TensileAnalysisConfig(
        active_method=METHOD_AUTO,
        upper_yield_drop_mpa=upper_yield_drop_mpa,
        offset_percent=offset_percent,
        allow_manual_override=True,
        method_locked=False,
    )


def _store_unified_result(curve: Any, result: Any, *, bridge_name: str) -> Any:
    """Guarda el resultado del motor común en la curva histórica."""
    try:
        setattr(curve, LEGACY_UNIFIED_ATTR, result)
    except Exception:
        pass

    diagnostics = getattr(curve, "diagnostics", None)
    if isinstance(diagnostics, dict):
        diagnostics["unified_bridge"] = bridge_name
        diagnostics["unified_selected_method"] = getattr(result, "selected_method", None)
        diagnostics["unified_method_detection"] = dict(getattr(result, "method_detection", {}) or {})
        diagnostics["unified_upper_yield_available"] = bool(getattr(result.upper_yield_result, "is_available", False))
        diagnostics["unified_rp_offset_available"] = bool(getattr(result.rp_offset_result, "is_available", False))
        if getattr(result.selected_result, "value_mpa", None) is not None:
            diagnostics["unified_selected_value_mpa"] = result.selected_result.value_mpa
        if getattr(result.selected_result, "elastic_modulus_gpa", None) is not None:
            diagnostics["unified_elastic_modulus_gpa"] = result.selected_result.elastic_modulus_gpa
    return result


def apply_unified_analysis_for_module1(curve: Any, settings: Any = None) -> Any:
    """Ejecuta motor común para una curva del módulo 1.

    No altera ``chosen_yield`` ni ``chosen_max``; solo registra el resultado
    unificado para comparación y migración progresiva.
    """
    drop = getattr(settings, "upper_yield_drop_mpa", None)
    from .analyzer import analyze_curve

    if drop is None:
        drop = getattr(settings, "min_required_drop_mpa", 1.0)
    result = analyze_curve(curve, getattr(curve, "geometry", None), module1_config(drop))
    return _store_unified_result(curve, result, bridge_name="module_1_upper_yield")


def apply_unified_analysis_for_module2(curve: Any) -> Any:
    """Ejecuta motor común para una curva del módulo 2.

    No altera ``visual_state`` ni puntos A/B; solo registra el resultado común
    con método activo Rp offset.
    """
    offset = getattr(curve, "offset_percent", 0.2)
    from .analyzer import analyze_curve

    result = analyze_curve(curve, getattr(curve, "geometry", None), module2_config(offset))
    return _store_unified_result(curve, result, bridge_name="module_2_rp_offset")


__all__ = [
    "LEGACY_UNIFIED_ATTR",
    "module1_config",
    "module2_config",
    "unified_auto_config",
    "apply_unified_analysis_for_module1",
    "apply_unified_analysis_for_module2",
]
