from __future__ import annotations

"""Motor común inicial para análisis unificado de tracción.

Esta fase NO reemplaza a los módulos 1 y 2. El objetivo es ofrecer una
función común ``analyze_curve(curve, geometry, config)`` que intente reutilizar
la lógica existente de:

- Módulo 1: fluencia superior con caída configurable.
- Módulo 2: Rp con offset configurable y módulo elástico.

El motor trabaja como adaptador: crea curvas temporales compatibles con los
módulos existentes, captura errores y devuelve diagnósticos legibles en lugar
de propagar tracebacks al usuario.
"""

from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional
import sys

import numpy as np
import pandas as pd

from .analysis_config import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from .geometry import TensileGeometry
from .models import TensileMethodResult, TensileUnifiedResult


NO_DISPONIBLE = "No disponible"


def _ensure_legacy_module_paths() -> None:
    """Permite importar lematzium_modulo1 y lematzium_modulo2 desde shared.

    Los launchers históricos agregan rutas de forma particular. Este adaptador
    solo inserta rutas cuando se analiza una curva, sin cambiar launchers ni
    módulos existentes.
    """
    modules_dir = Path(__file__).resolve().parents[2]
    for child in ("module_1_drop1mpa", "module_2_offset02"):
        candidate = modules_dir / child
        if candidate.exists() and str(candidate) not in sys.path:
            sys.path.insert(0, str(candidate))


def _coerce_config(config: Optional[TensileAnalysisConfig]) -> TensileAnalysisConfig:
    if isinstance(config, TensileAnalysisConfig):
        return config.copy()
    return TensileAnalysisConfig()


def _coerce_geometry(geometry: Any, curve: Any = None) -> TensileGeometry:
    if isinstance(geometry, TensileGeometry):
        return geometry.copy()
    if geometry is None and curve is not None:
        geometry = getattr(curve, "geometry", None)
    if isinstance(geometry, TensileGeometry):
        return geometry.copy()
    if geometry is not None:
        try:
            return TensileGeometry.from_legacy_geometry(geometry)
        except Exception:
            pass
    curve_geometry = getattr(curve, "geometry", None) if curve is not None else None
    if curve_geometry is not None:
        try:
            return TensileGeometry.from_legacy_geometry(curve_geometry)
        except Exception:
            pass
    return TensileGeometry()


def _safe_float(value: Any) -> Optional[float]:
    try:
        number = float(value)
    except Exception:
        return None
    if not np.isfinite(number):
        return None
    return number


def _finite_positive(value: Any) -> bool:
    number = _safe_float(value)
    return number is not None and number > 0


def _specimen_id(curve: Any) -> str:
    return str(getattr(curve, "specimen_id", "") or getattr(curve, "name", "") or "curva")


def _block_id(curve: Any) -> str:
    return str(getattr(curve, "block_id", "") or _specimen_id(curve))


def _extract_raw_dataframe(curve: Any, geometry: TensileGeometry) -> pd.DataFrame:
    """Obtiene un DataFrame de trabajo sin modificar la curva original."""
    source = None
    for attr in ("raw_df", "df", "data", "dataframe"):
        try:
            value = getattr(curve, attr)
        except Exception:
            continue
        if callable(value):
            continue
        if isinstance(value, pd.DataFrame):
            source = value
            break
    if source is None:
        raise ValueError("La curva no contiene un DataFrame compatible.")

    df = source.copy()
    if "elongation_mm" not in df.columns:
        raise ValueError("La curva no contiene la columna elongation_mm.")

    if "stress_MPa" not in df.columns:
        if "load_kN" not in df.columns:
            raise ValueError("La curva no contiene stress_MPa ni load_kN para calcular esfuerzo.")
        area = geometry.effective_area_mm2
        if not _finite_positive(area):
            raise ValueError("No existe área válida para calcular esfuerzo.")
        df["stress_MPa"] = pd.to_numeric(df["load_kN"], errors="coerce") * 1000.0 / float(area)
    else:
        df["stress_MPa"] = pd.to_numeric(df["stress_MPa"], errors="coerce")

    df["elongation_mm"] = pd.to_numeric(df["elongation_mm"], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=["elongation_mm", "stress_MPa"]).reset_index(drop=True)
    if df.empty:
        raise ValueError("La curva queda vacía después de limpiar datos no numéricos.")
    return df


def _reported_elongation_pct(curve: Any, df: pd.DataFrame, geometry: TensileGeometry) -> tuple[Optional[float], str]:
    for attr in ("reported_elong_after_fracture_pct", "elongation_after_break_pct"):
        value = _safe_float(getattr(curve, attr, None))
        if value is not None:
            return value, attr
    gauge = geometry.gauge_length_mm
    if _finite_positive(gauge) and "elongation_mm" in df.columns and not df.empty:
        value = _safe_float(df["elongation_mm"].iloc[-1])
        if value is not None:
            return float(value) / float(gauge) * 100.0, "estimado_desde_ultimo_alargamiento"
    return None, "no_disponible"


def _maximum_result(df: pd.DataFrame, curve: Any, geometry: TensileGeometry) -> tuple[Optional[float], dict[str, Any]]:
    diagnostics: dict[str, Any] = {}
    reported = _safe_float(getattr(curve, "reported_max_mpa", None))
    if reported is not None:
        diagnostics["max_source"] = "reported_max_mpa"
        return reported, diagnostics
    if df.empty or "stress_MPa" not in df.columns:
        diagnostics["max_source"] = "no_disponible"
        return None, diagnostics
    idx = int(pd.to_numeric(df["stress_MPa"], errors="coerce").idxmax())
    row = df.iloc[idx]
    diagnostics.update(
        {
            "max_source": "calculated_global_maximum",
            "max_index": idx,
            "max_elongation_mm": _safe_float(row.get("elongation_mm")),
        }
    )
    return _safe_float(row.get("stress_MPa")), diagnostics


def _unavailable(method: str, message: str, diagnostics: Optional[dict[str, Any]] = None) -> TensileMethodResult:
    return TensileMethodResult(
        method=method,
        is_available=False,
        value_mpa=None,
        diagnostics=diagnostics or {},
        warning_message=message or NO_DISPONIBLE,
    )


def _legacy_geometry(geometry: TensileGeometry):
    return geometry.to_legacy_geometry()


def _calculate_upper_yield(
    original_curve: Any,
    df: pd.DataFrame,
    geometry: TensileGeometry,
    config: TensileAnalysisConfig,
    max_stress_mpa: Optional[float],
    elongation_after_break_pct: Optional[float],
) -> TensileMethodResult:
    diagnostics: dict[str, Any] = {
        "upper_yield_drop_mpa": config.upper_yield_drop_mpa,
        "adapter": "module_1_drop1mpa",
    }
    try:
        _ensure_legacy_module_paths()
        from lematzium_modulo1.assays.tensile_drop_1mpa.contracts import (  # type: ignore
            CurveState as DropCurveState,
            DetectionSettings,
        )
        from lematzium_modulo1.assays.tensile_drop_1mpa.detection import (  # type: ignore
            detect_upper_yield_by_drop,
        )

        temp_curve = DropCurveState(
            specimen_id=_specimen_id(original_curve),
            block_id=_block_id(original_curve),
            geometry=_legacy_geometry(geometry),
            raw_df=df.copy(),
            reported_elong_after_fracture_pct=elongation_after_break_pct,
            reported_max_mpa=max_stress_mpa,
        )
        settings = DetectionSettings(upper_yield_drop_mpa=config.upper_yield_drop_mpa)
        point = detect_upper_yield_by_drop(
            temp_curve,
            upper_yield_drop_mpa=config.upper_yield_drop_mpa,
            settings=settings,
        )
        value = _safe_float(getattr(point, "y", None))
        note = str(getattr(point, "note", "") or "")
        diagnostics.update(
            {
                "upper_yield_stress_mpa": value,
                "detection_message": note or ("Fluencia superior detectada." if value is not None else NO_DISPONIBLE),
                "point_index": getattr(point, "index", None),
                "point_x_mm": getattr(point, "x", None),
                "point_source": getattr(point, "source", None),
            }
        )
        if value is None:
            return _unavailable(METHOD_UPPER_YIELD, note or NO_DISPONIBLE, diagnostics)
        return TensileMethodResult(
            method=METHOD_UPPER_YIELD,
            is_available=True,
            value_mpa=value,
            max_stress_mpa=max_stress_mpa,
            elongation_after_break_pct=elongation_after_break_pct,
            diagnostics=diagnostics,
            warning_message="",
        )
    except Exception as exc:
        diagnostics["exception"] = f"{type(exc).__name__}: {exc}"
        diagnostics["detection_message"] = NO_DISPONIBLE
        return _unavailable(METHOD_UPPER_YIELD, NO_DISPONIBLE, diagnostics)


def _calculate_rp_offset(
    original_curve: Any,
    df: pd.DataFrame,
    geometry: TensileGeometry,
    config: TensileAnalysisConfig,
    max_stress_mpa: Optional[float],
    elongation_after_break_pct: Optional[float],
) -> TensileMethodResult:
    diagnostics: dict[str, Any] = {
        "offset_percent": config.offset_percent,
        "rp_label": config.rp_label,
        "adapter": "module_2_offset02",
    }
    if not _finite_positive(geometry.gauge_length_mm):
        diagnostics["offset_mm"] = None
        diagnostics["detection_message"] = "No hay longitud calibrada válida para calcular Rp."
        return _unavailable(METHOD_RP_OFFSET, NO_DISPONIBLE, diagnostics)

    try:
        _ensure_legacy_module_paths()
        from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_calculator import (  # type: ignore
            format_rp_label,
            recalculate_tensile_offset02_curve,
            set_tensile_offset02_offset_percent,
        )
        from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_models import (  # type: ignore
            TensileOffset02CurveData,
            TensileOffset02Geometry,
        )

        legacy = _legacy_geometry(geometry)
        temp_geometry = TensileOffset02Geometry(
            shape=getattr(legacy, "shape", None),
            side1_mm=getattr(legacy, "side1_mm", None),
            side2_mm=getattr(legacy, "side2_mm", None),
            diameter_mm=getattr(legacy, "diameter_mm", None),
            gauge_length_mm=getattr(legacy, "gauge_length_mm", None),
            area_mm2_manual=getattr(legacy, "area_mm2_manual", None),
        )
        temp_curve = TensileOffset02CurveData(
            specimen_id=_specimen_id(original_curve),
            block_id=_block_id(original_curve),
            geometry=temp_geometry,
            raw_df=df.copy(),
            offset_percent=config.offset_percent,
            reported_elong_after_fracture_pct=elongation_after_break_pct,
            reported_max_mpa=max_stress_mpa,
        )
        set_tensile_offset02_offset_percent(temp_curve, config.offset_percent)
        recalculate_tensile_offset02_curve(temp_curve)
        point = temp_curve.visual_state.chosen_yield
        value = _safe_float(getattr(point, "y_mpa", None))
        max_point = temp_curve.visual_state.chosen_max
        max_from_rp = _safe_float(getattr(max_point, "y_mpa", None)) or max_stress_mpa
        elastic = _safe_float(temp_curve.diagnostics.get("elastic_modulus_gpa"))
        rp_label = temp_curve.diagnostics.get("rp_label") or format_rp_label(config.offset_percent)
        diagnostics.update(temp_curve.diagnostics)
        try:
            indices = diagnostics.get("elastic_modulus_line_indices") or {}
            line_points: dict[str, Any] = {}
            for key in ("a", "b"):
                idx = indices.get(key) if isinstance(indices, dict) else None
                if idx is None:
                    continue
                idx = int(idx)
                if 0 <= idx < len(temp_curve.df):
                    row = temp_curve.df.iloc[idx]
                    line_points[key] = {
                        "index": idx,
                        "x": float(row.get("elongation_mm")),
                        "y": float(row.get("stress_MPa")),
                    }
            if line_points:
                diagnostics["elastic_modulus_line_points"] = line_points
        except Exception:
            pass
        diagnostics.update(
            {
                "offset_percent": config.offset_percent,
                "rp_label": rp_label,
                "offset_mm": temp_curve.diagnostics.get("offset_mm"),
                "elastic_modulus_gpa": elastic,
                "point_index": getattr(point, "index", None),
                "point_x_mm": getattr(point, "x_mm", None),
                "point_source": getattr(point, "source", None),
                "detection_message": getattr(point, "note", "") or (f"{rp_label} calculado." if value is not None else NO_DISPONIBLE),
            }
        )
        if value is None:
            return _unavailable(METHOD_RP_OFFSET, getattr(point, "note", "") or NO_DISPONIBLE, diagnostics)
        return TensileMethodResult(
            method=METHOD_RP_OFFSET,
            is_available=True,
            value_mpa=value,
            elastic_modulus_gpa=elastic,
            max_stress_mpa=max_from_rp,
            elongation_after_break_pct=elongation_after_break_pct,
            diagnostics=diagnostics,
            warning_message="",
        )
    except Exception as exc:
        diagnostics["exception"] = f"{type(exc).__name__}: {exc}"
        diagnostics["detection_message"] = NO_DISPONIBLE
        return _unavailable(METHOD_RP_OFFSET, NO_DISPONIBLE, diagnostics)


def _select_result(
    config: TensileAnalysisConfig,
    upper_yield_result: TensileMethodResult,
    rp_offset_result: TensileMethodResult,
    curve: Any = None,
    geometry: Any = None,
) -> tuple[TensileMethodResult, dict[str, Any]]:
    """Selecciona resultado activo usando el detector automático común."""
    try:
        from .method_detector import detect_method

        detection = detect_method(curve, geometry, upper_yield_result, rp_offset_result, config)
    except Exception as exc:  # defensa: el motor común no debe propagar errores de detección
        detection = {
            "suggested_method": METHOD_MANUAL_REVIEW,
            "confidence": "low",
            "reason": f"No fue posible ejecutar el detector automático: {type(exc).__name__}.",
        }

    suggested = detection.get("suggested_method")
    if suggested == METHOD_UPPER_YIELD:
        return upper_yield_result, detection
    if suggested == METHOD_RP_OFFSET:
        return rp_offset_result, detection

    selected = _unavailable(METHOD_MANUAL_REVIEW, detection.get("reason", "Revisión manual requerida."))
    return selected, detection


def analyze_curve(
    curve: Any,
    geometry: Any = None,
    config: Optional[TensileAnalysisConfig] = None,
) -> TensileUnifiedResult:
    """Analiza una curva de tracción con ambos métodos disponibles.

    Parámetros:
    - curve: curva histórica de módulo 1, módulo 2 o un objeto compatible con
      ``raw_df``/``df`` y ``geometry``.
    - geometry: geometría unificada o histórica. Si es ``None``, se toma desde
      ``curve.geometry``.
    - config: configuración de análisis. Defaults: fluencia superior por caída
      1.0 MPa y Rp0.2.

    La función nunca debe propagar errores operativos al usuario. Si una curva
    es inválida, devuelve resultados ``is_available=False`` y diagnósticos.
    """
    cfg = _coerce_config(config)
    geom = _coerce_geometry(geometry, curve)
    diagnostics: dict[str, Any] = {
        "specimen_id": _specimen_id(curve),
        "active_method": cfg.active_method,
        "upper_yield_drop_mpa": cfg.upper_yield_drop_mpa,
        "offset_percent": cfg.offset_percent,
        "rp_label": cfg.rp_label,
    }

    try:
        df = _extract_raw_dataframe(curve, geom)
        diagnostics["points_count"] = int(len(df))
        diagnostics["geometry_validation_errors"] = geom.validate(require_gauge=False)
    except Exception as exc:
        diagnostics["exception"] = f"{type(exc).__name__}: {exc}"
        upper = _unavailable(METHOD_UPPER_YIELD, NO_DISPONIBLE, {"reason": str(exc)})
        rp = _unavailable(METHOD_RP_OFFSET, NO_DISPONIBLE, {"reason": str(exc)})
        selected, detection = _select_result(cfg, upper, rp, curve=curve, geometry=geom)
        diagnostics["method_detection"] = detection
        return TensileUnifiedResult(
            upper_yield_result=upper,
            rp_offset_result=rp,
            selected_result=selected,
            method_detection=detection,
            diagnostics=diagnostics,
        )

    max_stress_mpa, max_diag = _maximum_result(df, curve, geom)
    elongation_after_break_pct, elong_source = _reported_elongation_pct(curve, df, geom)
    diagnostics.update(max_diag)
    diagnostics["elongation_after_break_source"] = elong_source
    diagnostics["elongation_after_break_pct"] = elongation_after_break_pct

    upper = _calculate_upper_yield(curve, df, geom, cfg, max_stress_mpa, elongation_after_break_pct)
    rp = _calculate_rp_offset(curve, df, geom, cfg, max_stress_mpa, elongation_after_break_pct)

    # Completa máximos comunes si el adaptador específico no los pudo llenar.
    for result in (upper, rp):
        if result.max_stress_mpa is None:
            result.max_stress_mpa = max_stress_mpa
        if result.elongation_after_break_pct is None:
            result.elongation_after_break_pct = elongation_after_break_pct

    selected, detection = _select_result(cfg, upper, rp, curve=curve, geometry=geom)
    diagnostics["method_detection"] = detection
    diagnostics["upper_yield_available"] = upper.is_available
    diagnostics["rp_offset_available"] = rp.is_available

    return TensileUnifiedResult(
        upper_yield_result=upper,
        rp_offset_result=rp,
        selected_result=selected,
        method_detection=detection,
        diagnostics=diagnostics,
    )
