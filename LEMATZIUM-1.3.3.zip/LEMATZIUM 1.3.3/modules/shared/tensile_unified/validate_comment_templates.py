from __future__ import annotations

"""Validación mínima del motor de comentarios automáticos editables.

Ejecutar desde la raíz del proyecto con:
    python modules/shared/tensile_unified/validate_comment_templates.py
"""

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
MODULES = ROOT / "modules"
if str(MODULES) not in sys.path:
    sys.path.insert(0, str(MODULES))

from shared.tensile_unified import METHOD_RP_OFFSET, METHOD_UPPER_YIELD  # noqa: E402
from shared.tensile_unified.comment_templates import (  # noqa: E402
    REQUIRED_TEMPLATE_KEYS,
    extract_placeholders,
    get_default_comment,
    get_template_key,
    load_comment_templates,
    missing_required_templates,
    render_comment_template,
    save_user_templates,
)


def main() -> int:
    templates = load_comment_templates()
    assert not missing_required_templates(templates), "Faltan llaves requeridas"
    for key in REQUIRED_TEMPLATE_KEYS:
        assert key in templates and templates[key].strip(), f"Plantilla ausente: {key}"

    assert get_template_key("Irregular", METHOD_UPPER_YIELD) == "IRREGULAR_UPPER_YIELD"
    assert get_template_key("Rectangular", METHOD_RP_OFFSET) == "RECTANGULAR_RP_OFFSET"
    assert get_template_key("Circular", METHOD_RP_OFFSET) == "CIRCULAR_RP_OFFSET"
    assert get_template_key("Rectangular", METHOD_UPPER_YIELD) == "RECTANGULAR_UPPER_YIELD"
    assert get_template_key("Circular", METHOD_UPPER_YIELD) == "CIRCULAR_UPPER_YIELD"

    comment = get_default_comment(
        "Rectangular",
        METHOD_RP_OFFSET,
        {
            "offset_percent": "0.5",
            "unc_esfuerzo_maximo_mpa": "28",
            "unc_fluencia_mpa": "30",
            "unc_elongacion_pct": "4.3",
        },
        templates=templates,
    )
    assert "0.5 %" in comment
    assert "28 MPa" in comment

    incomplete = render_comment_template(
        "Incertidumbre: {unc_esfuerzo_maximo_mpa} MPa / {dato_faltante}",
        {"unc_esfuerzo_maximo_mpa": "16"},
    )
    assert incomplete == "Incertidumbre: 16 MPa / "

    placeholders = extract_placeholders(templates["RECTANGULAR_RP_OFFSET"])
    assert "offset_percent" in placeholders
    assert "unc_fluencia_mpa" in placeholders

    with tempfile.TemporaryDirectory() as tmp:
        local_path = Path(tmp) / "report_comment_templates.local.json"
        save_user_templates({"RECTANGULAR_RP_OFFSET": "Comentario local {offset_percent}"}, local_path)
        local_templates = load_comment_templates(local_path=local_path)
        assert local_templates["RECTANGULAR_RP_OFFSET"] == "Comentario local {offset_percent}"

    print("OK - motor de comentarios automáticos validado correctamente.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
