from __future__ import annotations

"""Modelos de geometría para el futuro motor unificado de tracción.

Este archivo no reemplaza todavía a ``shared.tensile_geometry``. Se crea como
base estable para integrar gradualmente los módulos 1 y 2 sin cambiar su
comportamiento actual.
"""

import math
import unicodedata
from dataclasses import dataclass
from typing import Any, Optional

# Constantes locales para no importar módulos existentes durante la carga.
# Esto mantiene la base nueva aislada y evita efectos secundarios en los módulos 1 y 2.
GEOMETRY_RECTANGULAR = "Rectangular"
GEOMETRY_CIRCULAR = "Circular"
GEOMETRY_IRREGULAR = "Irregular"
GEOMETRY_TUBULAR = "Tubería"
GEOMETRY_OPTIONS = (GEOMETRY_RECTANGULAR, GEOMETRY_CIRCULAR, GEOMETRY_TUBULAR, GEOMETRY_IRREGULAR)


def _clean_text(value: Any) -> str:
    text = "" if value is None else str(value).replace("\ufeff", "").strip().lower()
    text = text.replace(":", "").strip()
    return "".join(
        ch for ch in unicodedata.normalize("NFKD", text)
        if not unicodedata.combining(ch)
    )


def normalize_shape(value: Any, default: str = GEOMETRY_RECTANGULAR) -> str:
    """Normaliza nombres históricos y de máquina a la forma canónica."""
    text = _clean_text(value)
    if not text:
        return default
    if text in {"circular", "redonda", "redondo", "cilindrica", "cilindrico", "varilla", "barra", "round", "rod"}:
        return GEOMETRY_CIRCULAR
    if text in {"tuberia", "tubería", "tubo", "tubular", "anular", "hueca", "hueco", "pipe", "tube"}:
        return GEOMETRY_TUBULAR
    if text in {"irregular", "area", "area directa", "seccion irregular", "manual", "nominal"}:
        return GEOMETRY_IRREGULAR
    if text in {"rectangular", "rectangulo", "rectangular/plana", "plana", "flat", "sheet", "lamina"}:
        return GEOMETRY_RECTANGULAR
    if "tuber" in text or "anular" in text or "huec" in text or "pipe" in text or "tube" in text:
        return GEOMETRY_TUBULAR
    if "diam" in text or "redond" in text or "varilla" in text:
        return GEOMETRY_CIRCULAR
    if "area" in text or "irregular" in text or "nominal" in text:
        return GEOMETRY_IRREGULAR
    return default


AREA_SOURCE_CALCULATED = "calculated"
AREA_SOURCE_NOMINAL = "nominal"
AREA_SOURCE_MANUAL = "manual"
AREA_SOURCE_CSV = "csv"
AREA_SOURCE_OPTIONS = (
    AREA_SOURCE_CALCULATED,
    AREA_SOURCE_NOMINAL,
    AREA_SOURCE_MANUAL,
    AREA_SOURCE_CSV,
)


def _to_float(value: Any) -> Optional[float]:
    """Convierte valores numéricos comunes a float, aceptando coma decimal."""
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip().replace(" ", "").replace(",", ".")
        if not text:
            return None
        value = text
    try:
        number = float(value)
    except Exception:
        return None
    if not math.isfinite(number):
        return None
    return number


def _is_positive(value: Any) -> bool:
    number = _to_float(value)
    return number is not None and number > 0


@dataclass
class TensileGeometry:
    """Geometría común para análisis de tracción unificado.

    Campos principales solicitados:
    - geometry_type: Rectangular, Circular o Irregular.
    - thickness_mm, width_mm, diameter_mm, area_mm2, gauge_length_mm.
    - area_source: calculated, nominal, manual o csv.

    El campo ``area_mm2`` conserva el valor importado/manual cuando exista. Para
    geometrías rectangulares o circulares, el área efectiva se calcula desde las
    dimensiones siempre que estén disponibles.
    """

    geometry_type: str = GEOMETRY_RECTANGULAR
    thickness_mm: Optional[float] = None
    width_mm: Optional[float] = None
    diameter_mm: Optional[float] = None
    area_mm2: Optional[float] = None
    gauge_length_mm: Optional[float] = None
    area_source: str = AREA_SOURCE_CALCULATED

    def __post_init__(self) -> None:
        self.geometry_type = normalize_shape(self.geometry_type)
        if self.area_source not in AREA_SOURCE_OPTIONS:
            self.area_source = AREA_SOURCE_CSV if self.area_mm2 is not None else AREA_SOURCE_CALCULATED
        self.thickness_mm = _to_float(self.thickness_mm)
        self.width_mm = _to_float(self.width_mm)
        self.diameter_mm = _to_float(self.diameter_mm)
        self.area_mm2 = _to_float(self.area_mm2)
        self.gauge_length_mm = _to_float(self.gauge_length_mm)

    @property
    def is_rectangular(self) -> bool:
        return self.geometry_type == GEOMETRY_RECTANGULAR

    @property
    def is_circular(self) -> bool:
        return self.geometry_type == GEOMETRY_CIRCULAR

    @property
    def is_tubular(self) -> bool:
        return self.geometry_type == GEOMETRY_TUBULAR

    @property
    def is_irregular(self) -> bool:
        return self.geometry_type == GEOMETRY_IRREGULAR

    @property
    def effective_area_mm2(self) -> Optional[float]:
        """Área que debe usarse para calcular esfuerzo."""
        if self.is_rectangular:
            if _is_positive(self.thickness_mm) and _is_positive(self.width_mm):
                return float(self.thickness_mm) * float(self.width_mm)
            return self.area_mm2 if _is_positive(self.area_mm2) else None
        if self.is_circular:
            if _is_positive(self.diameter_mm):
                return math.pi * float(self.diameter_mm) ** 2 / 4.0
            return self.area_mm2 if _is_positive(self.area_mm2) else None
        if self.is_tubular:
            if _is_positive(self.thickness_mm) and _is_positive(self.width_mm) and float(self.width_mm) > float(self.thickness_mm):
                return math.pi * (float(self.width_mm) ** 2 - float(self.thickness_mm) ** 2) / 4.0
            return self.area_mm2 if _is_positive(self.area_mm2) else None
        if self.is_irregular:
            return self.area_mm2 if _is_positive(self.area_mm2) else None
        return None

    def validate(self, *, require_gauge: bool = True) -> list[str]:
        """Valida requisitos mínimos de la geometría activa."""
        errors: list[str] = []
        self.geometry_type = normalize_shape(self.geometry_type)

        if self.is_rectangular:
            if not _is_positive(self.thickness_mm):
                errors.append("La geometría rectangular requiere espesor positivo.")
            if not _is_positive(self.width_mm):
                errors.append("La geometría rectangular requiere anchura positiva.")
        elif self.is_circular:
            if not _is_positive(self.diameter_mm):
                errors.append("La geometría circular requiere diámetro positivo.")
        elif self.is_tubular:
            if not _is_positive(self.thickness_mm):
                errors.append("La geometría tubular requiere diámetro interior positivo.")
            if not _is_positive(self.width_mm):
                errors.append("La geometría tubular requiere diámetro exterior positivo.")
            if _is_positive(self.thickness_mm) and _is_positive(self.width_mm) and float(self.width_mm) <= float(self.thickness_mm):
                errors.append("El diámetro exterior debe ser mayor que el diámetro interior.")
        elif self.is_irregular:
            if not _is_positive(self.area_mm2):
                errors.append("La geometría irregular requiere área positiva.")
        else:
            errors.append(f"Tipo de geometría no soportado: {self.geometry_type!r}.")

        if require_gauge and not _is_positive(self.gauge_length_mm):
            errors.append("La geometría requiere longitud calibrada positiva.")
        return errors

    def copy(self) -> "TensileGeometry":
        return TensileGeometry(
            geometry_type=self.geometry_type,
            thickness_mm=self.thickness_mm,
            width_mm=self.width_mm,
            diameter_mm=self.diameter_mm,
            area_mm2=self.area_mm2,
            gauge_length_mm=self.gauge_length_mm,
            area_source=self.area_source,
        )

    @classmethod
    def rectangular(
        cls,
        *,
        thickness_mm: Any,
        width_mm: Any,
        gauge_length_mm: Any,
        area_source: str = AREA_SOURCE_CALCULATED,
    ) -> "TensileGeometry":
        return cls(
            geometry_type=GEOMETRY_RECTANGULAR,
            thickness_mm=thickness_mm,
            width_mm=width_mm,
            gauge_length_mm=gauge_length_mm,
            area_source=area_source,
        )

    @classmethod
    def circular(
        cls,
        *,
        diameter_mm: Any,
        gauge_length_mm: Any,
        area_source: str = AREA_SOURCE_CALCULATED,
    ) -> "TensileGeometry":
        return cls(
            geometry_type=GEOMETRY_CIRCULAR,
            diameter_mm=diameter_mm,
            gauge_length_mm=gauge_length_mm,
            area_source=area_source,
        )

    @classmethod
    def tubular(
        cls,
        *,
        inner_diameter_mm: Any,
        outer_diameter_mm: Any,
        gauge_length_mm: Any,
        area_source: str = AREA_SOURCE_CALCULATED,
    ) -> "TensileGeometry":
        return cls(
            geometry_type=GEOMETRY_TUBULAR,
            thickness_mm=inner_diameter_mm,
            width_mm=outer_diameter_mm,
            gauge_length_mm=gauge_length_mm,
            area_source=area_source,
        )

    @classmethod
    def irregular(
        cls,
        *,
        area_mm2: Any,
        gauge_length_mm: Any,
        area_source: str = AREA_SOURCE_NOMINAL,
    ) -> "TensileGeometry":
        return cls(
            geometry_type=GEOMETRY_IRREGULAR,
            area_mm2=area_mm2,
            gauge_length_mm=gauge_length_mm,
            area_source=area_source,
        )

    def to_legacy_geometry(self):
        """Convierte al modelo histórico shared.tensile_geometry.TensileGeometry.

        Es útil para futuras fases de integración sin obligar a modificar ahora
        los módulos 1 y 2. La importación se hace solo cuando se llama esta
        función para evitar efectos secundarios en la carga de modelos nuevos.
        """
        try:
            from shared.tensile_geometry import TensileGeometry as LegacyGeometry
        except Exception as exc:  # pragma: no cover
            raise RuntimeError("No se pudo importar shared.tensile_geometry.TensileGeometry") from exc

        return LegacyGeometry(
            shape=self.geometry_type,
            side1_mm=self.thickness_mm,
            side2_mm=self.width_mm,
            diameter_mm=self.diameter_mm,
            gauge_length_mm=self.gauge_length_mm,
            area_mm2_manual=self.area_mm2,
        )

    @classmethod
    def from_legacy_geometry(cls, legacy: Any) -> "TensileGeometry":
        """Crea geometría unificada desde un objeto histórico compatible."""
        geometry_type = normalize_shape(getattr(legacy, "shape", None))
        area = getattr(legacy, "area_mm2_manual", None)
        return cls(
            geometry_type=geometry_type,
            thickness_mm=getattr(legacy, "side1_mm", None),
            width_mm=getattr(legacy, "side2_mm", None),
            diameter_mm=getattr(legacy, "diameter_mm", None),
            area_mm2=area,
            gauge_length_mm=getattr(legacy, "gauge_length_mm", None),
            area_source=AREA_SOURCE_MANUAL if area is not None else AREA_SOURCE_CALCULATED,
        )
