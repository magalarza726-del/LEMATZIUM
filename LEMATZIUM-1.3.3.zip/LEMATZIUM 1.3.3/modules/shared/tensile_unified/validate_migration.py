from __future__ import annotations

"""Validación mínima de la migración progresiva al motor común.

No modifica archivos ni datos. Puede ejecutarse desde la raíz del proyecto:

    python modules/shared/tensile_unified/validate_migration.py OT-4676-26.csv
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[3]
MODULES_DIR = PROJECT_ROOT / "modules"
for path in (MODULES_DIR, MODULES_DIR / "module_1_drop1mpa", MODULES_DIR / "module_2_offset02"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from shared.tensile_unified import METHOD_AUTO, METHOD_RP_OFFSET, METHOD_UPPER_YIELD, TensileAnalysisConfig, analyze_curve
from lematzium_modulo1.assays.tensile_drop_1mpa.controller import TensileDrop1MPaController
from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_controller import TensileOffset02Controller


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def validate(csv_path: str) -> None:
    path = Path(csv_path)
    _assert(path.exists(), f"No existe CSV de prueba: {path}")

    m1 = TensileDrop1MPaController()
    ds1 = m1.load_file(str(path))
    _assert(len(ds1.curves) > 0, "Módulo 1 no cargó curvas.")
    c1 = ds1.curves[0]
    _assert(hasattr(c1, "unified_analysis"), "Módulo 1 no registró unified_analysis.")
    _assert(c1.unified_analysis.selected_method == METHOD_UPPER_YIELD, "Módulo 1 no quedó preconfigurado en upper_yield.")
    _assert(c1.chosen_max.y is not None, "Módulo 1 perdió máximo histórico.")

    auto1 = analyze_curve(c1, c1.geometry, TensileAnalysisConfig(active_method=METHOD_AUTO))
    _assert(auto1.selected_result.method in {METHOD_UPPER_YIELD, METHOD_RP_OFFSET, "manual_review"}, "Modo automático inválido.")

    m2 = TensileOffset02Controller()
    ds2 = m2.load_file(str(path))
    _assert(len(ds2.curves) > 0, "Módulo 2 no cargó curvas.")
    c2 = ds2.curves[0]
    _assert(hasattr(c2, "unified_analysis"), "Módulo 2 no registró unified_analysis.")
    _assert(c2.unified_analysis.selected_method == METHOD_RP_OFFSET, "Módulo 2 no quedó preconfigurado en rp_offset.")
    _assert(c2.visual_state.chosen_max.y_mpa is not None, "Módulo 2 perdió máximo histórico.")
    _assert(c2.diagnostics.get("rp_label") == "Rp0.2", "Módulo 2 no conservó Rp0.2 predeterminado.")

    print("OK - migración progresiva validada.")
    print(f"CSV: {path.name}")
    print(f"Módulo 1 curvas: {len(ds1.curves)} | método común: {c1.unified_analysis.selected_method}")
    print(f"Módulo 2 curvas: {len(ds2.curves)} | método común: {c2.unified_analysis.selected_method}")


if __name__ == "__main__":
    default_csv = PROJECT_ROOT.parent / "OT-4676-26.csv"
    csv_arg = sys.argv[1] if len(sys.argv) > 1 else str(default_csv)
    validate(csv_arg)
