from __future__ import annotations

"""Modelos comunes del futuro motor unificado de tracción.

Estos dataclasses no modifican el comportamiento actual de los módulos 1 y 2.
Sirven como contrato estable para fases posteriores de integración.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

try:
    from .analysis_config import METHOD_AUTO, METHOD_OPTIONS
    from .geometry import TensileGeometry
except Exception:  # pragma: no cover - soporte para import directo en pruebas aisladas
    from analysis_config import METHOD_AUTO, METHOD_OPTIONS  # type: ignore
    from geometry import TensileGeometry  # type: ignore


@dataclass
class TensileMethodResult:
    """Resultado de un método específico de análisis de tracción."""

    method: str
    is_available: bool = False
    value_mpa: Optional[float] = None
    elastic_modulus_gpa: Optional[float] = None
    max_stress_mpa: Optional[float] = None
    elongation_after_break_pct: Optional[float] = None
    diagnostics: dict[str, Any] = field(default_factory=dict)
    warning_message: str = ""

    def __post_init__(self) -> None:
        if self.method not in METHOD_OPTIONS:
            # No forzar a auto si luego aparecen métodos internos; pero sí registrar advertencia.
            self.diagnostics.setdefault("unknown_method", self.method)
        self.is_available = bool(self.is_available)
        if self.warning_message is None:
            self.warning_message = ""

    @property
    def display_value(self) -> str:
        if not self.is_available or self.value_mpa is None:
            return "No disponible"
        try:
            return f"{float(self.value_mpa):.2f} MPa"
        except Exception:
            return "No disponible"


@dataclass
class TensileReportContext:
    """Contexto mínimo para construir reportes de tracción en fases futuras."""

    specimen_id: str
    geometry: TensileGeometry
    active_method: str = METHOD_AUTO
    method_result: Optional[TensileMethodResult] = None
    graph_path: Optional[str | Path] = None
    comments: str = ""

    def __post_init__(self) -> None:
        self.specimen_id = "" if self.specimen_id is None else str(self.specimen_id)
        if self.active_method not in METHOD_OPTIONS:
            self.active_method = METHOD_AUTO
        if self.graph_path is not None:
            self.graph_path = str(self.graph_path)
        if self.comments is None:
            self.comments = ""

    def validate(self) -> list[str]:
        errors = self.geometry.validate(require_gauge=False)
        if not self.specimen_id.strip():
            errors.append("El contexto de reporte requiere identificador de probeta.")
        if self.method_result is not None and self.method_result.method != self.active_method:
            errors.append("El método activo no coincide con el método del resultado seleccionado.")
        return errors


@dataclass
class TensileUnifiedResult:
    """Salida común del motor unificado de análisis de tracción.

    Contiene siempre los resultados de ambos métodos, aunque alguno no sea
    aplicable. ``selected_result`` representa el resultado activo según la
    configuración o la selección automática básica.
    """

    upper_yield_result: TensileMethodResult
    rp_offset_result: TensileMethodResult
    selected_result: TensileMethodResult
    method_detection: dict[str, Any] = field(default_factory=dict)
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def available_methods(self) -> list[str]:
        methods: list[str] = []
        if self.upper_yield_result.is_available:
            methods.append(self.upper_yield_result.method)
        if self.rp_offset_result.is_available:
            methods.append(self.rp_offset_result.method)
        return methods

    @property
    def selected_method(self) -> str:
        return self.selected_result.method
