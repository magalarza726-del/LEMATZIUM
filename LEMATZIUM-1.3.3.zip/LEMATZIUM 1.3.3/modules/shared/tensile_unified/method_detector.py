from __future__ import annotations

"""Detector automático de método para el motor unificado de tracción.

Esta fase NO modifica cálculos existentes, reportes ni UI. El detector solo
lee resultados ya calculados por el motor común y devuelve una recomendación
legible para el analista.
"""

from typing import Any, Optional

import numpy as np
import pandas as pd

from .analysis_config import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from .geometry import TensileGeometry
from .models import TensileMethodResult

CONF_HIGH = "high"
CONF_MEDIUM = "medium"
CONF_LOW = "low"
NO_DISPONIBLE = "No disponible"

# Criterios conservadores del detector comun. No cambian los calculos
# historicos; solo evitan seleccionar automaticamente fluencia superior cuando
# el punto detectado pertenece al maximo global o a la caida final de rotura.
MIN_POINTS_AFTER_CANDIDATE = 2
LOCAL_DROP_WINDOW_FRACTION = 0.08
LOCAL_DROP_WINDOW_MIN_POINTS = 4
LOCAL_DROP_WINDOW_MAX_POINTS = 80
EARLY_CURVE_FRACTION_LIMIT = 0.75
MAX_PROXIMITY_FRACTION_LIMIT = 0.95
LOCAL_PEAK_WINDOW = 3
LOCAL_PEAK_TOLERANCE_MPA = 1e-9


def _safe_float(value: Any) -> Optional[float]:
    try:
        number = float(value)
    except Exception:
        return None
    if not np.isfinite(number):
        return None
    return number


def _positive(value: Any) -> bool:
    number = _safe_float(value)
    return number is not None and number > 0


def _result_available(result: Any) -> bool:
    return bool(getattr(result, "is_available", False)) and _safe_float(getattr(result, "value_mpa", None)) is not None


def _result_diagnostics(result: Any) -> dict[str, Any]:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    return diagnostics if isinstance(diagnostics, dict) else {}


def _coerce_config(config: Optional[TensileAnalysisConfig]) -> TensileAnalysisConfig:
    if isinstance(config, TensileAnalysisConfig):
        return config.copy()
    return TensileAnalysisConfig()


def _coerce_geometry(geometry: Any, curve: Any = None) -> TensileGeometry:
    if isinstance(geometry, TensileGeometry):
        return geometry.copy()
    if geometry is None and curve is not None:
        geometry = getattr(curve, "geometry", None)
    if isinstance(geometry, TensileGeometry):
        return geometry.copy()
    if geometry is not None:
        try:
            return TensileGeometry.from_legacy_geometry(geometry)
        except Exception:
            pass
    return TensileGeometry()


def _dataframe_from_curve(curve: Any, geometry: TensileGeometry) -> Optional[pd.DataFrame]:
    """Obtiene datos mínimos para diagnosticar ruido/caída sin modificar la curva."""
    source = None
    for attr in ("raw_df", "df", "data", "dataframe"):
        try:
            value = getattr(curve, attr)
        except Exception:
            continue
        if callable(value):
            continue
        if isinstance(value, pd.DataFrame):
            source = value
            break
    if source is None:
        return None

    df = source.copy()
    if "elongation_mm" not in df.columns:
        return None
    if "stress_MPa" not in df.columns:
        if "load_kN" not in df.columns:
            return None
        area = geometry.effective_area_mm2
        if not _positive(area):
            return None
        df["stress_MPa"] = pd.to_numeric(df["load_kN"], errors="coerce") * 1000.0 / float(area)
    else:
        df["stress_MPa"] = pd.to_numeric(df["stress_MPa"], errors="coerce")
    df["elongation_mm"] = pd.to_numeric(df["elongation_mm"], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=["elongation_mm", "stress_MPa"]).reset_index(drop=True)
    return df if not df.empty else None


def _estimate_noise_level(df: Optional[pd.DataFrame]) -> tuple[str, float]:
    """Clasifica ruido de forma conservadora para decidir si requiere revisión manual.

    El indicador usa la mediana de cambios absolutos de esfuerzo respecto al
    rango total. No intenta validar el ensayo; solo evita recomendaciones
    automáticas cuando la curva es demasiado irregular o corta.
    """
    if df is None or len(df) < 8:
        return "insufficient", 1.0
    stress = pd.to_numeric(df["stress_MPa"], errors="coerce").dropna().to_numpy(dtype=float)
    if len(stress) < 8:
        return "insufficient", 1.0
    stress_range = float(np.nanmax(stress) - np.nanmin(stress))
    if not np.isfinite(stress_range) or stress_range <= 0:
        return "high", 1.0
    diffs = np.diff(stress)
    local_noise = float(np.nanmedian(np.abs(diffs))) / stress_range
    sign_changes = float(np.mean(np.diff(np.sign(diffs)) != 0)) if len(diffs) > 1 else 0.0
    score = local_noise + 0.05 * sign_changes
    if score > 0.12:
        return "high", score
    if score > 0.06:
        return "medium", score
    return "low", score


def _coerce_index(value: Any, length: int) -> Optional[int]:
    try:
        idx = int(value)
    except Exception:
        return None
    if 0 <= idx < length:
        return idx
    return None


def _candidate_index_from_result(
    upper_yield_result: TensileMethodResult,
    df: Optional[pd.DataFrame],
) -> Optional[int]:
    diagnostics = _result_diagnostics(upper_yield_result)
    if df is not None:
        idx = _coerce_index(diagnostics.get("point_index"), len(df))
        if idx is not None:
            return idx

        point_x = _safe_float(diagnostics.get("point_x_mm"))
        if point_x is not None and "elongation_mm" in df.columns and not df.empty:
            elong = pd.to_numeric(df["elongation_mm"], errors="coerce").to_numpy(dtype=float)
            if len(elong):
                nearest = int(np.nanargmin(np.abs(elong - point_x)))
                if 0 <= nearest < len(df):
                    return nearest

    raw_idx = diagnostics.get("point_index")
    try:
        return int(raw_idx) if raw_idx is not None else None
    except Exception:
        return None


def _global_max_index_from_df(df: Optional[pd.DataFrame]) -> Optional[int]:
    if df is None or df.empty or "stress_MPa" not in df.columns:
        return None
    stress = pd.to_numeric(df["stress_MPa"], errors="coerce")
    if stress.dropna().empty:
        return None
    try:
        return int(stress.idxmax())
    except Exception:
        return None


def _is_local_peak(stress: np.ndarray, candidate_idx: int) -> bool:
    if len(stress) < 3 or candidate_idx <= 0 or candidate_idx >= len(stress) - 1:
        return False
    start = max(0, candidate_idx - LOCAL_PEAK_WINDOW)
    end = min(len(stress), candidate_idx + LOCAL_PEAK_WINDOW + 1)
    neighborhood = stress[start:end]
    if len(neighborhood) < 3:
        return False
    candidate_stress = float(stress[candidate_idx])
    if not np.isfinite(candidate_stress):
        return False
    return candidate_stress + LOCAL_PEAK_TOLERANCE_MPA >= float(np.nanmax(neighborhood))


def _local_drop_after_candidate(
    df: Optional[pd.DataFrame],
    candidate_idx: Optional[int],
    global_max_idx: Optional[int],
) -> Optional[float]:
    """Calcula la caida posterior local sin usar la cola de rotura.

    La version anterior inferia la caida con el minimo de todo lo posterior al
    punto detectado. Eso podia tomar la caida final despues del esfuerzo maximo.
    Este calculo se limita a una ventana local entre el candidato y el maximo
    global para evaluar una caida temprana real.
    """
    if df is None or candidate_idx is None or global_max_idx is None:
        return None
    if candidate_idx < 0 or candidate_idx >= len(df) - MIN_POINTS_AFTER_CANDIDATE:
        return None
    if global_max_idx <= candidate_idx + MIN_POINTS_AFTER_CANDIDATE:
        return None

    stress = pd.to_numeric(df["stress_MPa"], errors="coerce").to_numpy(dtype=float)
    candidate_stress = _safe_float(stress[candidate_idx])
    if candidate_stress is None:
        return None

    window_points = int(round(len(df) * LOCAL_DROP_WINDOW_FRACTION))
    window_points = max(LOCAL_DROP_WINDOW_MIN_POINTS, min(LOCAL_DROP_WINDOW_MAX_POINTS, window_points))
    # No incluir puntos posteriores al maximo global: esos pueden pertenecer a
    # estriccion/rotura y no a fluencia superior.
    end = min(len(df), global_max_idx + 1, candidate_idx + 1 + window_points)
    if end <= candidate_idx + MIN_POINTS_AFTER_CANDIDATE:
        return None

    after = stress[candidate_idx + 1 : end]
    after = after[np.isfinite(after)]
    if len(after) < MIN_POINTS_AFTER_CANDIDATE:
        return None
    return max(0.0, float(candidate_stress) - float(np.nanmin(after)))


def _legacy_drop_from_diagnostics(
    upper_yield_result: TensileMethodResult,
    config: TensileAnalysisConfig,
) -> Optional[float]:
    diagnostics = _result_diagnostics(upper_yield_result)
    for key in ("drop_value_mpa", "actual_drop_mpa", "detected_drop_mpa", "sustained_drop_mpa"):
        value = _safe_float(diagnostics.get(key))
        if value is not None:
            return max(0.0, value)
    if _result_available(upper_yield_result):
        # Solo como referencia diagnostica. No se usa para validar region,
        # porque puede provenir de una cola posterior a la rotura.
        return float(config.upper_yield_drop_mpa)
    return None


def _upper_yield_region_diagnostics(
    df: Optional[pd.DataFrame],
    upper_yield_result: TensileMethodResult,
    config: TensileAnalysisConfig,
) -> dict[str, Any]:
    candidate_idx = _candidate_index_from_result(upper_yield_result, df)
    global_max_idx = _global_max_index_from_df(df)
    local_drop = _local_drop_after_candidate(df, candidate_idx, global_max_idx)
    legacy_drop = _legacy_drop_from_diagnostics(upper_yield_result, config)

    reason = "No hay datos suficientes para validar la region de la caida."
    region_valid = False
    local_peak_valid: Optional[bool] = None
    candidate_fraction: Optional[float] = None
    candidate_to_max_fraction: Optional[float] = None

    if df is not None and len(df) > 1 and candidate_idx is not None:
        candidate_fraction = candidate_idx / float(len(df) - 1)
    if global_max_idx is not None and global_max_idx > 0 and candidate_idx is not None:
        candidate_to_max_fraction = candidate_idx / float(global_max_idx)

    if df is not None and candidate_idx is not None and 0 <= candidate_idx < len(df):
        stress = pd.to_numeric(df["stress_MPa"], errors="coerce").to_numpy(dtype=float)
        local_peak_valid = _is_local_peak(stress, candidate_idx)

    if df is None or len(df) < 8:
        reason = "Datos insuficientes para validar si la caida es temprana."
    elif candidate_idx is None:
        reason = "El resultado de fluencia superior no informa un indice de candidato valido."
    elif global_max_idx is None:
        reason = "No fue posible identificar el esfuerzo maximo global para ubicar la caida."
    elif candidate_idx >= global_max_idx:
        reason = "El candidato de fluencia coincide con el maximo global o aparece despues; probable caida final."
    elif candidate_idx >= len(df) - MIN_POINTS_AFTER_CANDIDATE:
        reason = "El candidato de fluencia esta al final de la curva; probable rotura, no fluencia superior."
    elif candidate_fraction is not None and candidate_fraction > EARLY_CURVE_FRACTION_LIMIT:
        reason = "El candidato aparece demasiado tarde en la curva para sugerir fluencia superior automaticamente."
    elif candidate_to_max_fraction is not None and candidate_to_max_fraction > MAX_PROXIMITY_FRACTION_LIMIT:
        reason = "El candidato esta demasiado cerca del maximo global; no se usa la caida final como fluencia superior."
    elif local_peak_valid is False:
        reason = "El candidato no se comporta como pico local temprano seguido de caida."
    elif local_drop is None:
        reason = "No hay ventana local suficiente entre el candidato y el maximo global para confirmar la caida."
    elif local_drop < float(config.upper_yield_drop_mpa):
        reason = f"La caida local temprana es {local_drop:.3g} MPa, menor que el umbral de {config.upper_yield_drop_mpa:g} MPa."
    else:
        region_valid = True
        reason = f"Caida local temprana valida antes del maximo global: {local_drop:.3g} MPa."

    return {
        "upper_yield_candidate_index": candidate_idx,
        "global_max_index": global_max_idx,
        "drop_region_is_valid": region_valid,
        "drop_value_mpa": local_drop,
        # Compatibilidad: se conserva la llave antigua, pero ahora representa
        # una caida local temprana validada por region cuando es posible.
        "actual_drop_mpa": local_drop,
        "legacy_drop_value_mpa": legacy_drop,
        "upper_yield_candidate_fraction": candidate_fraction,
        "upper_yield_candidate_to_global_max_fraction": candidate_to_max_fraction,
        "upper_yield_local_peak_valid": local_peak_valid,
        "drop_region_reason": reason,
    }


def _infer_actual_drop_mpa(
    curve: Any,
    geometry: TensileGeometry,
    upper_yield_result: TensileMethodResult,
    config: TensileAnalysisConfig,
) -> Optional[float]:
    """Compatibilidad para llamadas externas antiguas.

    Devuelve la caida local temprana cuando se puede validar con datos de la
    curva. Si no hay datos, usa el valor historico disponible solo como ultimo
    recurso, igual que antes.
    """
    df = _dataframe_from_curve(curve, geometry)
    region = _upper_yield_region_diagnostics(df, upper_yield_result, config)
    value = _safe_float(region.get("drop_value_mpa"))
    if value is not None:
        return value
    return _legacy_drop_from_diagnostics(upper_yield_result, config)


def _is_fallback_upper_yield(upper_yield_result: TensileMethodResult) -> bool:
    diagnostics = _result_diagnostics(upper_yield_result)
    text = " ".join(
        str(diagnostics.get(key, ""))
        for key in ("detection_message", "point_source", "warning_message")
    ).lower()
    text += " " + str(getattr(upper_yield_result, "warning_message", "") or "").lower()
    return "fallback" in text or "no se encontró primer máximo" in text


def _forced_detection(config: TensileAnalysisConfig, upper_available: bool, rp_available: bool) -> Optional[dict[str, Any]]:
    base_diagnostics = {
        "upper_yield_available": upper_available,
        "rp_offset_available": rp_available,
        "rp_available": rp_available,
        "upper_yield_candidate_index": None,
        "global_max_index": None,
        "drop_region_is_valid": None,
        "drop_value_mpa": None,
    }
    if config.active_method == METHOD_AUTO:
        return None
    if config.active_method == METHOD_UPPER_YIELD:
        reason = "Método forzado por configuración: Fluencia superior." if upper_available else "Método forzado por configuración: Fluencia superior, pero el resultado no está disponible."
        return {
            "suggested_method": METHOD_UPPER_YIELD,
            "confidence": CONF_HIGH if upper_available else CONF_LOW,
            "reason": reason,
            "forced": True,
            **base_diagnostics,
        }
    if config.active_method == METHOD_RP_OFFSET:
        reason = f"Método forzado por configuración: {config.rp_label}." if rp_available else f"Método forzado por configuración: {config.rp_label}, pero el resultado no está disponible."
        return {
            "suggested_method": METHOD_RP_OFFSET,
            "confidence": CONF_HIGH if rp_available else CONF_LOW,
            "reason": reason,
            "forced": True,
            **base_diagnostics,
        }
    if config.active_method == METHOD_MANUAL_REVIEW:
        reason = "La configuración solicita revisión manual del método de análisis."
        return {
            "suggested_method": METHOD_MANUAL_REVIEW,
            "confidence": CONF_HIGH,
            "reason": reason,
            "forced": True,
            **base_diagnostics,
        }
    return None


def detect_method(
    curve: Any,
    geometry: Any,
    upper_yield_result: TensileMethodResult,
    rp_offset_result: TensileMethodResult,
    config: Optional[TensileAnalysisConfig] = None,
) -> dict[str, Any]:
    """Sugiere el método de análisis aplicable para una curva de tracción.

    Retorna siempre un diccionario con:
    - suggested_method: ``upper_yield``, ``rp_offset`` o ``manual_review``.
    - confidence: ``high``, ``medium`` o ``low``.
    - reason: explicación breve para el analista.

    La función no modifica la curva ni recalcula resultados. Solo interpreta
    resultados ya disponibles y metadatos mínimos de curva/geometría.
    """
    cfg = _coerce_config(config)
    geom = _coerce_geometry(geometry, curve)
    upper_available = _result_available(upper_yield_result)
    rp_available = _result_available(rp_offset_result)
    gauge_available = _positive(getattr(geom, "gauge_length_mm", None))

    forced = _forced_detection(cfg, upper_available, rp_available)
    if forced is not None:
        return forced

    df = _dataframe_from_curve(curve, geom)
    noise_level, noise_score = _estimate_noise_level(df)
    region_diagnostics = _upper_yield_region_diagnostics(df, upper_yield_result, cfg)
    diagnostics: dict[str, Any] = {
        "noise_level": noise_level,
        "noise_score": noise_score,
        "upper_yield_available": upper_available,
        "rp_offset_available": rp_available,
        "rp_available": rp_available,
        "gauge_available": gauge_available,
        "upper_yield_drop_mpa": cfg.upper_yield_drop_mpa,
        "offset_percent": cfg.offset_percent,
        "rp_label": cfg.rp_label,
        **region_diagnostics,
    }

    if noise_level == "insufficient":
        return {
            "suggested_method": METHOD_MANUAL_REVIEW,
            "confidence": CONF_LOW,
            "reason": "Datos insuficientes para seleccionar automáticamente el método de análisis.",
            **diagnostics,
        }
    if noise_level == "high":
        return {
            "suggested_method": METHOD_MANUAL_REVIEW,
            "confidence": CONF_LOW,
            "reason": "La curva presenta alta irregularidad/ruido; se requiere revisión manual del método.",
            **diagnostics,
        }

    fallback_upper = _is_fallback_upper_yield(upper_yield_result)
    diagnostics["upper_yield_fallback"] = fallback_upper

    drop_value = _safe_float(region_diagnostics.get("drop_value_mpa"))
    drop_region_is_valid = bool(region_diagnostics.get("drop_region_is_valid"))
    drop_ok = upper_available and drop_region_is_valid and drop_value is not None and drop_value >= float(cfg.upper_yield_drop_mpa)
    clear_drop = drop_ok and drop_value >= max(float(cfg.upper_yield_drop_mpa) * 1.5, float(cfg.upper_yield_drop_mpa) + 0.5)

    if drop_ok:
        if fallback_upper and rp_available and gauge_available:
            return {
                "suggested_method": METHOD_MANUAL_REVIEW,
                "confidence": CONF_MEDIUM,
                "reason": "Se obtuvo fluencia superior por criterio secundario y también existe Rp; conviene revisión manual.",
                **diagnostics,
            }
        if rp_available and gauge_available and not clear_drop and noise_level == "medium":
            return {
                "suggested_method": METHOD_MANUAL_REVIEW,
                "confidence": CONF_MEDIUM,
                "reason": "La fluencia superior y Rp son posibles, pero la caída local temprana no es suficientemente clara frente al ruido.",
                **diagnostics,
            }
        return {
            "suggested_method": METHOD_UPPER_YIELD,
            "confidence": CONF_HIGH if clear_drop and noise_level == "low" else CONF_MEDIUM,
            "reason": f"Se detectó fluencia superior como pico local temprano con caída ≥ {cfg.upper_yield_drop_mpa:g} MPa antes del esfuerzo máximo global.",
            **diagnostics,
        }

    if rp_available and gauge_available:
        return {
            "suggested_method": METHOD_RP_OFFSET,
            "confidence": CONF_HIGH if noise_level == "low" else CONF_MEDIUM,
            "reason": f"No se confirmó una caída temprana válida de fluencia superior ({region_diagnostics.get('drop_region_reason')}); se sugiere {cfg.rp_label}.",
            **diagnostics,
        }

    if rp_available and not gauge_available:
        return {
            "suggested_method": METHOD_MANUAL_REVIEW,
            "confidence": CONF_LOW,
            "reason": "Existe resultado Rp, pero falta longitud calibrada válida; no se sugiere Rp automáticamente.",
            **diagnostics,
        }

    if upper_available:
        return {
            "suggested_method": METHOD_MANUAL_REVIEW,
            "confidence": CONF_LOW if not drop_region_is_valid else CONF_MEDIUM,
            "reason": f"Hay resultado de fluencia superior, pero no se confirmó que la caída pertenezca a la zona temprana de la curva: {region_diagnostics.get('drop_region_reason')}",
            **diagnostics,
        }

    return {
        "suggested_method": METHOD_MANUAL_REVIEW,
        "confidence": CONF_LOW,
        "reason": "No fue posible seleccionar automáticamente Fluencia superior ni Rp con los datos disponibles.",
        **diagnostics,
    }
