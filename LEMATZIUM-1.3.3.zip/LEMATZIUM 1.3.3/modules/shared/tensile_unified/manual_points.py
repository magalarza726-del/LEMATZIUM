from __future__ import annotations

"""Utilidades de puntos manuales para el módulo unificado.

No modifica cálculos históricos. Solo ofrece helpers para mapear modos de UI a
índices de curva y seleccionar el punto más cercano.
"""

from typing import Any
import math
import numpy as np

MODE_TO_POINT_KEY = {
    "yield": "upper_yield_index",
    "max": "max_index",
    "rp_a": "rp_a_index",
    "rp_b": "rp_b_index",
    "rp": "rp_index",
}

POINT_KEY_TO_LABEL = {
    "upper_yield_index": "Fluencia superior",
    "max_index": "Máximo",
    "rp_a_index": "Punto A Rp",
    "rp_b_index": "Punto B Rp",
    "rp_index": "Punto Rp",
}


def nearest_curve_index(df: Any, xdata: float, ydata: float | None = None) -> int | None:
    """Devuelve el índice de curva más cercano al punto del cursor."""
    try:
        xs = np.asarray(df["elongation_mm"], dtype=float)
        if len(xs) == 0:
            return None
        x_span = max(float(np.nanmax(xs) - np.nanmin(xs)), 1e-12)
        if ydata is not None and "stress_MPa" in getattr(df, "columns", []):
            ys = np.asarray(df["stress_MPa"], dtype=float)
            y_span = max(float(np.nanmax(ys) - np.nanmin(ys)), 1e-12)
            scores = ((xs - float(xdata)) / x_span) ** 2 + ((ys - float(ydata)) / y_span) ** 2
        else:
            scores = np.abs(xs - float(xdata))
        finite = np.isfinite(scores)
        if not finite.any():
            return None
        return int(np.nanargmin(scores))
    except Exception:
        return None


def point_key_for_mode(mode: str) -> str | None:
    return MODE_TO_POINT_KEY.get(str(mode or "").strip())


__all__ = ["MODE_TO_POINT_KEY", "POINT_KEY_TO_LABEL", "nearest_curve_index", "point_key_for_mode"]
