from __future__ import annotations

"""Validación mínima de importación y comportamiento de modelos unificados.

Ejecutar desde la raíz del proyecto con:
    python modules/shared/tensile_unified/validate_models.py
"""

import math
import sys
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
MODULES = ROOT / "modules"
if str(MODULES) not in sys.path:
    sys.path.insert(0, str(MODULES))

from shared.tensile_unified import (  # noqa: E402
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
    TensileGeometry,
    TensileMethodResult,
    TensileReportContext,
    analyze_curve,
    detect_method,
)


def _assert_close(value: float | None, expected: float, tol: float = 1e-9) -> None:
    assert value is not None, "Valor inesperadamente None"
    assert abs(value - expected) <= tol, f"{value!r} != {expected!r}"


def main() -> int:
    rectangular = TensileGeometry.rectangular(thickness_mm=2.0, width_mm=10.0, gauge_length_mm=50.0)
    assert rectangular.validate() == []
    _assert_close(rectangular.effective_area_mm2, 20.0)

    circular = TensileGeometry.circular(diameter_mm=10.0, gauge_length_mm=50.0)
    assert circular.validate() == []
    _assert_close(circular.effective_area_mm2, math.pi * 100.0 / 4.0)

    irregular = TensileGeometry.irregular(area_mm2=80.0, gauge_length_mm=200.0)
    assert irregular.validate() == []
    _assert_close(irregular.effective_area_mm2, 80.0)

    config = TensileAnalysisConfig(active_method=METHOD_RP_OFFSET, offset_percent=0.2)
    assert config.rp_label == "Rp0.2"
    assert abs(config.offset_fraction - 0.002) < 1e-12

    result = TensileMethodResult(method=METHOD_UPPER_YIELD, is_available=True, value_mpa=350.0)
    context = TensileReportContext(
        specimen_id="P-01",
        geometry=rectangular,
        active_method=METHOD_UPPER_YIELD,
        method_result=result,
        comments="Comentario editable",
    )
    assert context.validate() == []

    # Validación mínima del motor común sin depender de UI ni reportes.
    df = pd.DataFrame(
        {
            "elongation_mm": [0, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70],
            "stress_MPa": [0, 100, 200, 300, 360, 355, 370, 390, 410, 405],
        }
    )
    curve = SimpleNamespace(specimen_id="P-01", block_id="B-01", raw_df=df, geometry=rectangular)
    unified = analyze_curve(curve, rectangular, TensileAnalysisConfig())
    assert unified.upper_yield_result.method == METHOD_UPPER_YIELD
    assert unified.rp_offset_result.method == METHOD_RP_OFFSET
    assert unified.selected_result is not None
    assert "upper_yield_drop_mpa" in unified.diagnostics
    assert "offset_percent" in unified.diagnostics
    assert unified.method_detection["suggested_method"] in {METHOD_UPPER_YIELD, METHOD_RP_OFFSET, "manual_review"}
    assert unified.method_detection["confidence"] in {"high", "medium", "low"}
    assert unified.method_detection["reason"]

    forced_detection = detect_method(
        curve,
        rectangular,
        unified.upper_yield_result,
        unified.rp_offset_result,
        TensileAnalysisConfig(active_method=METHOD_RP_OFFSET),
    )
    assert forced_detection["suggested_method"] == METHOD_RP_OFFSET
    assert forced_detection["confidence"] in {"high", "medium", "low"}
    assert forced_detection["reason"]

    print("OK - modelos, analyzer y method_detector tensile_unified importan y validan correctamente.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
