from __future__ import annotations

"""Validación mínima del exportador Word unificado.

Uso local:
    python modules/shared/tensile_unified/validate_word_report.py
"""

from pathlib import Path
import tempfile
import sys

ROOT = Path(__file__).resolve().parents[3]
MODULES = ROOT / "modules"
if str(MODULES) not in sys.path:
    sys.path.insert(0, str(MODULES))

from shared.tensile_unified import (  # noqa: E402
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileGeometry,
    TensileMethodResult,
    TensileReportContext,
)
from shared.tensile_unified.word_report import export_tensile_report  # noqa: E402


def _make_context(method: str, geometry: TensileGeometry, specimen_id: str) -> TensileReportContext:
    if method == METHOD_RP_OFFSET:
        result = TensileMethodResult(
            method=METHOD_RP_OFFSET,
            is_available=True,
            value_mpa=250.0,
            elastic_modulus_gpa=70.0,
            max_stress_mpa=310.0,
            elongation_after_break_pct=12.5,
            diagnostics={"rp_label": "Rp0.2", "offset_percent": 0.2},
        )
    else:
        result = TensileMethodResult(
            method=METHOD_UPPER_YIELD,
            is_available=True,
            value_mpa=420.0,
            max_stress_mpa=550.0,
            elongation_after_break_pct=18.0,
            diagnostics={"upper_yield_drop_mpa": 1.0},
        )
    return TensileReportContext(
        specimen_id=specimen_id,
        geometry=geometry,
        active_method=method,
        method_result=result,
        comments="",
    )


def main() -> int:
    cases = [
        _make_context(METHOD_RP_OFFSET, TensileGeometry.rectangular(thickness_mm=1.5, width_mm=12.3, gauge_length_mm=50), "RECT-RP"),
        _make_context(METHOD_RP_OFFSET, TensileGeometry.circular(diameter_mm=10, gauge_length_mm=50), "CIRC-RP"),
        _make_context(METHOD_UPPER_YIELD, TensileGeometry.rectangular(thickness_mm=2.0, width_mm=10, gauge_length_mm=50), "RECT-FS"),
        _make_context(METHOD_UPPER_YIELD, TensileGeometry.circular(diameter_mm=8, gauge_length_mm=50), "CIRC-FS"),
        _make_context(METHOD_UPPER_YIELD, TensileGeometry.irregular(area_mm2=78.5, gauge_length_mm=200), "IRR-FS"),
    ]
    with tempfile.TemporaryDirectory(prefix="lematzium_word_report_") as tmp:
        for context in cases:
            out = Path(tmp) / f"{context.specimen_id}.docx"
            export_tensile_report(out, context, detection={"suggested_method": context.active_method, "confidence": "high", "reason": "Validación."})
            if not out.exists() or out.stat().st_size <= 0:
                raise RuntimeError(f"No se generó reporte válido para {context.specimen_id}")
    print("OK - exportador Word unificado validado correctamente.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
