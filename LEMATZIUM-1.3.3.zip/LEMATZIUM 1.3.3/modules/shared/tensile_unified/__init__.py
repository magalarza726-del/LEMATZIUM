"""Base común para la futura unificación de análisis de tracción LEMATZIUM.

No reemplaza todavía a los módulos 1 y 2. Expone modelos reutilizables para
integración progresiva y compatible.

Nota: ``analyze_curve`` y ``detect_method`` se importan de forma diferida para
que utilidades livianas, como comentarios automáticos, puedan cargarse sin
inicializar dependencias pesadas de análisis numérico.
"""

from .analysis_config import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_OPTIONS,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from .comment_templates import (
    REQUIRED_TEMPLATE_KEYS,
    TEMPLATE_CIRCULAR_RP_OFFSET,
    TEMPLATE_CIRCULAR_UPPER_YIELD,
    TEMPLATE_TUBULAR_RP_OFFSET,
    TEMPLATE_TUBULAR_UPPER_YIELD,
    TEMPLATE_IRREGULAR_UPPER_YIELD,
    TEMPLATE_RECTANGULAR_RP_OFFSET,
    TEMPLATE_RECTANGULAR_UPPER_YIELD,
    get_default_comment,
    get_template_key,
    load_comment_templates,
    render_comment_template,
    save_user_templates,
)
from .geometry import (
    AREA_SOURCE_CALCULATED,
    AREA_SOURCE_CSV,
    AREA_SOURCE_MANUAL,
    AREA_SOURCE_NOMINAL,
    AREA_SOURCE_OPTIONS,
    GEOMETRY_CIRCULAR,
    GEOMETRY_IRREGULAR,
    GEOMETRY_OPTIONS,
    GEOMETRY_RECTANGULAR,
    GEOMETRY_TUBULAR,
    TensileGeometry,
)
from .models import TensileMethodResult, TensileReportContext, TensileUnifiedResult

from .uncertainty import (
    DEFAULT_UNCERTAINTY_CONFIG,
    ensure_default_uncertainty_config_file,
    load_uncertainty_config,
    save_user_uncertainty_config,
    uncertainty_context_for_comment,
    uncertainty_values_for_curve,
)

from .compat import (
    LEGACY_UNIFIED_ATTR,
    apply_unified_analysis_for_module1,
    apply_unified_analysis_for_module2,
    module1_config,
    module2_config,
    unified_auto_config,
)


def analyze_curve(*args, **kwargs):
    """Wrapper diferido para mantener importación liviana del paquete."""
    from .analyzer import analyze_curve as _analyze_curve

    return _analyze_curve(*args, **kwargs)


def detect_method(*args, **kwargs):
    """Wrapper diferido para mantener importación liviana del paquete."""
    from .method_detector import detect_method as _detect_method

    return _detect_method(*args, **kwargs)


def export_tensile_report(*args, **kwargs):
    """Wrapper diferido para evitar cargar python-docx fuera de exportación."""
    from .word_report import export_tensile_report as _export_tensile_report

    return _export_tensile_report(*args, **kwargs)


def build_results_table(*args, **kwargs):
    """Wrapper diferido para construir tablas Word solo cuando se exporta."""
    from .word_report import build_results_table as _build_results_table

    return _build_results_table(*args, **kwargs)


def default_comment_for_context(*args, **kwargs):
    """Wrapper diferido para el comentario por contexto de reporte."""
    from .word_report import default_comment_for_context as _default_comment_for_context

    return _default_comment_for_context(*args, **kwargs)


def result_method_label(*args, **kwargs):
    """Wrapper diferido para la etiqueta técnica de método de reporte."""
    from .word_report import result_method_label as _result_method_label

    return _result_method_label(*args, **kwargs)


__all__ = [
    "AREA_SOURCE_CALCULATED",
    "AREA_SOURCE_CSV",
    "AREA_SOURCE_MANUAL",
    "AREA_SOURCE_NOMINAL",
    "AREA_SOURCE_OPTIONS",
    "GEOMETRY_CIRCULAR",
    "GEOMETRY_IRREGULAR",
    "GEOMETRY_OPTIONS",
    "GEOMETRY_RECTANGULAR",
    "METHOD_AUTO",
    "METHOD_MANUAL_REVIEW",
    "METHOD_OPTIONS",
    "METHOD_RP_OFFSET",
    "METHOD_UPPER_YIELD",
    "REQUIRED_TEMPLATE_KEYS",
    "TEMPLATE_CIRCULAR_RP_OFFSET",
    "TEMPLATE_CIRCULAR_UPPER_YIELD",
    "TEMPLATE_IRREGULAR_UPPER_YIELD",
    "TEMPLATE_RECTANGULAR_RP_OFFSET",
    "TEMPLATE_RECTANGULAR_UPPER_YIELD",
    "TEMPLATE_TUBULAR_UPPER_YIELD",
    "TEMPLATE_TUBULAR_RP_OFFSET",
    "GEOMETRY_TUBULAR",
    "TensileAnalysisConfig",
    "TensileGeometry",
    "TensileMethodResult",
    "TensileReportContext",
    "TensileUnifiedResult",
    "LEGACY_UNIFIED_ATTR",
    "apply_unified_analysis_for_module1",
    "apply_unified_analysis_for_module2",
    "module1_config",
    "module2_config",
    "unified_auto_config",
    "analyze_curve",
    "detect_method",
    "get_default_comment",
    "get_template_key",
    "load_comment_templates",
    "render_comment_template",
    "save_user_templates",
    "result_method_label",
    "export_tensile_report",
    "default_comment_for_context",
    "DEFAULT_UNCERTAINTY_CONFIG",
    "ensure_default_uncertainty_config_file",
    "load_uncertainty_config",
    "save_user_uncertainty_config",
    "uncertainty_context_for_comment",
    "uncertainty_values_for_curve",
    "build_results_table",
]
