from __future__ import annotations

"""Cálculo de incertidumbre de tracción metálica replicado desde hojas LEMAT.

El motor replica las fórmulas de las hojas históricas de incertidumbre para
probetas rectangulares/plancha, circulares y tubulares/anulares. Las fuentes se
cargan desde JSON editable, manteniendo un respaldo embebido para que el módulo
funcione aunque todavía no exista configuración local.
"""

import copy
import json
import math
import unicodedata
from pathlib import Path
from typing import Any, Mapping, Optional

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "uncertainty_sources.json"
LOCAL_CONFIG_PATH = PROJECT_ROOT / "user_config" / "uncertainty_sources.local.json"

SQRT3 = math.sqrt(3.0)
SQRT12 = math.sqrt(12.0)

# Valores cacheados de las hojas entregadas por LEMAT. Las tres geometrías
# comparten fuerza y área; las fuentes de repetibilidad/reproducibilidad se
# mantienen separadas por tipo de geometría para permitir edición independiente.
DEFAULT_UNCERTAINTY_CONFIG: dict[str, Any] = {
    "version": 1,
    "shared": {
        "force": {
            "cells": {
                "12": {"uncertainty_kN": 0.021, "resolution_kN": 0.00001, "drift_kN": 0.044, "correction_kN": 0.05},
                "30": {"uncertainty_kN": 0.06, "resolution_kN": 0.00001, "drift_kN": 0.11, "correction_kN": 0.06},
                "60": {"uncertainty_kN": 0.072, "resolution_kN": 0.00001, "drift_kN": 0.236, "correction_kN": 0.07},
                "120": {"uncertainty_kN": 0.14, "resolution_kN": 0.00001, "drift_kN": 0.532, "correction_kN": 0.22},
                "300": {"uncertainty_kN": 0.36, "resolution_kN": 0.00001, "drift_kN": 1.315, "correction_kN": 0.40},
                "600": {"uncertainty_kN": 0.78, "resolution_kN": 0.00001, "drift_kN": 2.370, "correction_kN": 0.30},
            }
        },
        "area": {
            "instruments": {
                "micrometro_caras_planas_a_im_221": {
                    "label": "Micrómetro de caras planas (A-IM-221)",
                    "resolution_mm": 0.001,
                    "certificate_um": 1.4,
                    "drift_mm": 0.004,
                    "correction_mm": -0.001,
                },
                "micrometro_tuberias_a_im_116": {
                    "label": "Micrómetro de tuberías (A-IM-116)",
                    "resolution_mm": 0.001,
                    "certificate_um": 1.3,
                    "drift_mm": 0.00248,
                    "correction_mm": 0.0001,
                },
                "pie_de_rey_a_im_230": {
                    "label": "Pie de Rey (A-IM-230)",
                    "resolution_mm": 0.01,
                    "certificate_um": 20.0,
                    "drift_mm": 0.0101,
                    "correction_mm": 0.0,
                },
                "pie_de_rey_a_im_231": {
                    "label": "Pie de Rey (A-IM-231)",
                    "resolution_mm": 0.01,
                    "certificate_um": 20.0,
                    "drift_mm": 0.01,
                    "correction_mm": 0.01,
                },
            },
            "rounding_mm": {
                "ge_5": 0.02,
                "between_2_5_and_5": 0.01,
                "lt_2_5": 0.002,
            },
        },
    },
    "geometries": {
        "rectangular": {
            "label": "Plancha / rectangular",
            "force_cell": "auto",
            "thickness_instrument": "micrometro_caras_planas_a_im_221",
            "width_instrument": "pie_de_rey_a_im_230",
            "elongation_instrument": "pie_de_rey_a_im_230",
            "repeatability_yield_mpa": 12.29,
            "reproducibility_yield_mpa": 17.38,
            "repeatability_max_mpa": 4.61,
            "reproducibility_max_mpa": 10.12,
            "repeatability_elongation_pct": 2.65,
            "reproducibility_elongation_pct": 1.64,
        },
        "circular": {
            "label": "Circular",
            "force_cell": "auto",
            "diameter_instrument": "pie_de_rey_a_im_230",
            "elongation_instrument": "pie_de_rey_a_im_230",
            "repeatability_yield_mpa": 12.29,
            "reproducibility_yield_mpa": 17.38,
            "repeatability_max_mpa": 4.61,
            "reproducibility_max_mpa": 10.12,
            "repeatability_elongation_pct": 2.65,
            "reproducibility_elongation_pct": 1.64,
        },
        "tubular": {
            "label": "Tubería / anular",
            "force_cell": "auto",
            "inner_diameter_instrument": "pie_de_rey_a_im_230",
            "outer_diameter_instrument": "pie_de_rey_a_im_230",
            "yield_inner_diameter_instrument": "pie_de_rey_a_im_231",
            "yield_outer_diameter_instrument": "pie_de_rey_a_im_231",
            "elongation_instrument": "pie_de_rey_a_im_230",
            "repeatability_yield_mpa": 12.29,
            "reproducibility_yield_mpa": 17.38,
            "dimension_repeatability_max_mpa": 4.61,
            "dimension_reproducibility_max_mpa": 10.12,
            "repeatability_max_mpa": 6.1981,
            "reproducibility_max_mpa": 9.4068,
            "repeatability_elongation_pct": 2.65,
            "reproducibility_elongation_pct": 1.64,
        },
        "irregular": {
            "label": "Área nominal / irregular",
            "force_cell": "auto",
            "area_source": "nominal",
            "elongation_instrument": "pie_de_rey_a_im_230",
            "repeatability_yield_mpa": 12.29,
            "reproducibility_yield_mpa": 17.38,
            "repeatability_max_mpa": 4.61,
            "reproducibility_max_mpa": 10.12,
            "repeatability_elongation_pct": 2.65,
            "reproducibility_elongation_pct": 1.64,
        },
    },
}


def _read_json(path: Path) -> dict[str, Any]:
    try:
        if not path.exists():
            return {}
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_json(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")


def _deep_merge(base: Any, override: Any) -> Any:
    if isinstance(base, dict) and isinstance(override, Mapping):
        merged = copy.deepcopy(base)
        for key, value in override.items():
            merged[str(key)] = _deep_merge(merged.get(str(key)), value)
        return merged
    if override is None:
        return copy.deepcopy(base)
    return copy.deepcopy(override)


def ensure_default_uncertainty_config_file(path: str | Path | None = None) -> Path:
    target = Path(path) if path is not None else DEFAULT_CONFIG_PATH
    if not target.exists():
        _write_json(target, DEFAULT_UNCERTAINTY_CONFIG)
    return target


def load_uncertainty_config(
    default_path: str | Path | None = None,
    local_path: str | Path | None = None,
) -> dict[str, Any]:
    defaults_file = Path(default_path) if default_path is not None else DEFAULT_CONFIG_PATH
    local_file = Path(local_path) if local_path is not None else LOCAL_CONFIG_PATH
    config = copy.deepcopy(DEFAULT_UNCERTAINTY_CONFIG)
    config = _deep_merge(config, _read_json(defaults_file))
    config = _deep_merge(config, _read_json(local_file))
    return config


def save_user_uncertainty_config(
    config: Mapping[str, Any],
    local_path: str | Path | None = None,
    *,
    merge_existing: bool = False,
) -> Path:
    target = Path(local_path) if local_path is not None else LOCAL_CONFIG_PATH
    data: dict[str, Any] = _read_json(target) if merge_existing else {}
    data = _deep_merge(data, config)
    _write_json(target, data)
    return target


def _clean_text(value: Any) -> str:
    text = "" if value is None else str(value).replace("\ufeff", "").strip().lower()
    text = text.replace(":", "").strip()
    return "".join(
        ch for ch in unicodedata.normalize("NFKD", text)
        if not unicodedata.combining(ch)
    )


def _float(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None:
            return default
        if isinstance(value, str):
            value = value.strip().replace(" ", "").replace(",", ".")
            if not value:
                return default
        number = float(value)
        return number if math.isfinite(number) else default
    except Exception:
        return default


def _positive(value: Any) -> bool:
    number = _float(value)
    return number is not None and number > 0


def _roundup(value: float, digits: int = 0) -> float:
    factor = 10.0 ** int(digits)
    if value >= 0:
        return math.ceil(value * factor - 1e-12) / factor
    return math.floor(value * factor + 1e-12) / factor


def _format_int_like(value: Optional[float]) -> str:
    if value is None:
        return ""
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    return f"{value:.2f}".rstrip("0").rstrip(".")


def _format_decimal(value: Optional[float], ndigits: int = 2) -> str:
    if value is None:
        return ""
    return f"{value:.{ndigits}f}".rstrip("0").rstrip(".")


def _format_fixed_decimal(value: Optional[float], ndigits: int = 1) -> str:
    if value is None:
        return ""
    try:
        return f"{float(value):.{int(ndigits)}f}"
    except Exception:
        return ""


def _geometry_key(shape: Any) -> str:
    text = _clean_text(shape)
    if any(token in text for token in ("tuber", "anular", "huec", "pipe", "tube")):
        return "tubular"
    if any(token in text for token in ("circ", "redond", "diam", "varilla", "barra", "round", "rod")):
        return "circular"
    if any(token in text for token in ("irregular", "manual", "nominal", "area")):
        return "irregular"
    return "rectangular"


def _area_mm2(geometry: Any, key: str) -> Optional[float]:
    if geometry is None:
        return None
    if key == "circular":
        d = _float(getattr(geometry, "diameter_mm", None))
        if not _positive(d):
            return _float(getattr(geometry, "area_mm2", getattr(geometry, "area_mm2_manual", None)))
        return math.pi * float(d) ** 2 / 4.0
    if key == "tubular":
        di = _float(getattr(geometry, "side1_mm", None))
        de = _float(getattr(geometry, "side2_mm", None))
        if _positive(di) and _positive(de) and float(de) > float(di):
            return math.pi * (float(de) ** 2 - float(di) ** 2) / 4.0
        return _float(getattr(geometry, "area_mm2", getattr(geometry, "area_mm2_manual", None)))
    if key == "irregular":
        return _float(getattr(geometry, "area_mm2", getattr(geometry, "area_mm2_manual", None)))
    t = _float(getattr(geometry, "side1_mm", None))
    w = _float(getattr(geometry, "side2_mm", None))
    if _positive(t) and _positive(w):
        return float(t) * float(w)
    return _float(getattr(geometry, "area_mm2", getattr(geometry, "area_mm2_manual", None)))


def _force_sources(config: Mapping[str, Any]) -> dict[str, Any]:
    return dict(((config.get("shared") or {}).get("force") or {}).get("cells") or {})


def _instrument_sources(config: Mapping[str, Any]) -> dict[str, Any]:
    return dict(((config.get("shared") or {}).get("area") or {}).get("instruments") or {})


def _instrument(config: Mapping[str, Any], instrument_key: str | None) -> Mapping[str, Any]:
    instruments = _instrument_sources(config)
    item = instruments.get(str(instrument_key or ""))
    if isinstance(item, Mapping):
        return item
    fallback = instruments.get("pie_de_rey_a_im_230") or {}
    return fallback if isinstance(fallback, Mapping) else {}


def _force_cell_for_load(load_kN: Optional[float], geometry_config: Mapping[str, Any], config: Mapping[str, Any]) -> str:
    configured = str(geometry_config.get("force_cell") or "auto").strip().lower()
    cells = _force_sources(config)
    available = sorted((_float(k) for k in cells.keys()), key=lambda x: 0 if x is None else float(x))
    available = [float(x) for x in available if x is not None and x > 0]
    if configured and configured != "auto":
        try:
            return str(int(float(configured)))
        except Exception:
            return configured
    if load_kN is not None and available:
        for cell in available:
            if load_kN <= cell + 1e-12:
                return str(int(cell))
        return str(int(available[-1]))
    return "12"


def _force(config: Mapping[str, Any], cell: str) -> Mapping[str, Any]:
    cells = _force_sources(config)
    item = cells.get(str(cell))
    if isinstance(item, Mapping):
        return item
    return cells.get("12") or {}


def _rounding_mm(value_mm: Any, config: Mapping[str, Any]) -> float:
    number = _float(value_mm, 0.0) or 0.0
    rounding = (((config.get("shared") or {}).get("area") or {}).get("rounding_mm") or {})
    if number >= 5:
        return float(_float(rounding.get("ge_5"), 0.02) or 0.02)
    if number < 2.5:
        return float(_float(rounding.get("lt_2_5"), 0.002) or 0.002)
    return float(_float(rounding.get("between_2_5_and_5"), 0.01) or 0.01)


def _certificate_mm(instrument: Mapping[str, Any]) -> float:
    return float(_float(instrument.get("certificate_um"), 0.0) or 0.0) / 1000.0


def _selected_method_result(analysis_result: Any) -> Any:
    return getattr(analysis_result, "selected_result", None) or analysis_result


def _stress_uncertainty_rectangular(
    *,
    stress_mpa: float,
    geometry: Any,
    geometry_config: Mapping[str, Any],
    config: Mapping[str, Any],
    repeatability_key: str,
    reproducibility_key: str,
) -> Optional[dict[str, float | str]]:
    t = _float(getattr(geometry, "side1_mm", None))
    w = _float(getattr(geometry, "side2_mm", None))
    if not (_positive(t) and _positive(w)):
        return None
    t = float(t)
    w = float(w)
    area = t * w
    load = stress_mpa * area / 1000.0
    force_cell = _force_cell_for_load(load, geometry_config, config)
    force = _force(config, force_cell)
    inst_t = _instrument(config, str(geometry_config.get("thickness_instrument") or "micrometro_caras_planas_a_im_221"))
    inst_w = _instrument(config, str(geometry_config.get("width_instrument") or "pie_de_rey_a_im_230"))

    c_load = 1000.0 / area
    c_t = -(load / ((t ** 2) * w)) * 1000.0
    c_w = -(load / ((w ** 2) * t)) * 1000.0
    contribs = [
        (float(_float(force.get("resolution_kN"), 0.0) or 0.0) / SQRT12) * c_load,
        (float(_float(inst_t.get("resolution_mm"), 0.0) or 0.0) / SQRT12) * c_t,
        (float(_float(inst_w.get("resolution_mm"), 0.0) or 0.0) / SQRT12) * c_w,
        (float(_float(geometry_config.get(repeatability_key), 0.0) or 0.0) / SQRT3),
        (float(_float(geometry_config.get(reproducibility_key), 0.0) or 0.0) / SQRT3),
        (float(_float(force.get("uncertainty_kN"), 0.0) or 0.0) / 2.0) * c_load,
        (_certificate_mm(inst_t) / 2.0) * c_t,
        (_certificate_mm(inst_w) / 2.0) * c_w,
        (float(_float(force.get("drift_kN"), 0.0) or 0.0) / SQRT3) * c_load,
        (float(_float(inst_t.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_t,
        (float(_float(inst_w.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_w,
        (_rounding_mm(t, config) / SQRT3) * c_t,
        (_rounding_mm(w, config) / SQRT3) * c_w,
        (1.0 / SQRT3),
    ]
    corrections = abs(float(_float(force.get("correction_kN"), 0.0) or 0.0) * c_load) + abs(float(_float(inst_t.get("correction_mm"), 0.0) or 0.0) * c_t) + abs(float(_float(inst_w.get("correction_mm"), 0.0) or 0.0) * c_w)
    uc = math.sqrt(sum(value * value for value in contribs))
    u = 2.0 * uc + corrections
    return {"value": u, "rounded": _roundup(u, 0), "force_cell": force_cell, "load_kN": load, "area_mm2": area}


def _stress_uncertainty_circular(
    *,
    stress_mpa: float,
    geometry: Any,
    geometry_config: Mapping[str, Any],
    config: Mapping[str, Any],
    repeatability_key: str,
    reproducibility_key: str,
) -> Optional[dict[str, float | str]]:
    d = _float(getattr(geometry, "diameter_mm", None))
    if not _positive(d):
        return None
    d = float(d)
    area = math.pi * d * d / 4.0
    load = stress_mpa * area / 1000.0
    force_cell = _force_cell_for_load(load, geometry_config, config)
    force = _force(config, force_cell)
    inst_d = _instrument(config, str(geometry_config.get("diameter_instrument") or "pie_de_rey_a_im_230"))
    c_load = 4.0 / (math.pi * d * d) * 1000.0
    c_d = (-8.0 * load / (math.pi * d ** 3)) * 1000.0
    contribs = [
        (float(_float(force.get("resolution_kN"), 0.0) or 0.0) / SQRT12) * c_load,
        (float(_float(inst_d.get("resolution_mm"), 0.0) or 0.0) / SQRT12) * c_d,
        (float(_float(geometry_config.get(repeatability_key), 0.0) or 0.0) / SQRT3),
        (float(_float(geometry_config.get(reproducibility_key), 0.0) or 0.0) / SQRT3),
        (float(_float(force.get("uncertainty_kN"), 0.0) or 0.0) / 2.0) * c_load,
        (_certificate_mm(inst_d) / 2.0) * c_d,
        (float(_float(force.get("drift_kN"), 0.0) or 0.0) / SQRT3) * c_load,
        (float(_float(inst_d.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_d,
        (_rounding_mm(d, config) / SQRT3) * c_d,
        (1.0 / SQRT3),
    ]
    corrections = abs(float(_float(force.get("correction_kN"), 0.0) or 0.0) * c_load) + abs(float(_float(inst_d.get("correction_mm"), 0.0) or 0.0) * c_d)
    uc = math.sqrt(sum(value * value for value in contribs))
    u = 2.0 * uc + corrections
    return {"value": u, "rounded": _roundup(u, 0), "force_cell": force_cell, "load_kN": load, "area_mm2": area}


def _stress_uncertainty_tubular(
    *,
    stress_mpa: float,
    geometry: Any,
    geometry_config: Mapping[str, Any],
    config: Mapping[str, Any],
    repeatability_key: str,
    reproducibility_key: str,
) -> Optional[dict[str, float | str]]:
    inner = _float(getattr(geometry, "side1_mm", None))
    outer = _float(getattr(geometry, "side2_mm", None))
    if not (_positive(inner) and _positive(outer) and float(outer) > float(inner)):
        return None
    di = float(inner)
    de = float(outer)
    area = math.pi * (de * de - di * di) / 4.0
    load = stress_mpa * area / 1000.0
    force_cell = _force_cell_for_load(load, geometry_config, config)
    force = _force(config, force_cell)
    is_max = repeatability_key == "repeatability_max_mpa"
    if is_max:
        inst_i = _instrument(config, str(geometry_config.get("inner_diameter_instrument") or "pie_de_rey_a_im_230"))
        inst_o = _instrument(config, str(geometry_config.get("outer_diameter_instrument") or "pie_de_rey_a_im_230"))
        dim_i_resolution = float(_float(geometry_config.get("dimension_repeatability_max_mpa"), 4.61) or 4.61)
        dim_o_resolution = float(_float(geometry_config.get("dimension_reproducibility_max_mpa"), 10.12) or 10.12)
    else:
        inst_i = _instrument(config, str(geometry_config.get("yield_inner_diameter_instrument") or geometry_config.get("inner_diameter_instrument") or "pie_de_rey_a_im_231"))
        inst_o = _instrument(config, str(geometry_config.get("yield_outer_diameter_instrument") or geometry_config.get("outer_diameter_instrument") or "pie_de_rey_a_im_231"))
        dim_i_resolution = float(_float(inst_i.get("resolution_mm"), 0.0) or 0.0)
        dim_o_resolution = float(_float(inst_o.get("resolution_mm"), 0.0) or 0.0)

    # Fórmulas replicadas tal como están cacheadas en la hoja Tubería entregada.
    c_load = 1000.0 / area
    c_i = -(load / ((di ** 2) * de)) * 1000.0
    c_o = -(load / ((de ** 2) * di)) * 1000.0
    contribs = [
        (float(_float(force.get("resolution_kN"), 0.0) or 0.0) / SQRT12) * c_load,
        (dim_i_resolution / SQRT12) * c_i,
        (dim_o_resolution / SQRT12) * c_o,
        (float(_float(geometry_config.get(repeatability_key), 0.0) or 0.0) / SQRT3),
        (float(_float(geometry_config.get(reproducibility_key), 0.0) or 0.0) / SQRT3),
        (float(_float(force.get("uncertainty_kN"), 0.0) or 0.0) / 2.0) * c_load,
        (_certificate_mm(inst_i) / 2.0) * c_i,
        (_certificate_mm(inst_o) / 2.0) * c_o,
        (float(_float(force.get("drift_kN"), 0.0) or 0.0) / SQRT3) * c_load,
        (float(_float(inst_i.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_i,
        (float(_float(inst_o.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_o,
        (_rounding_mm(di, config) / SQRT3) * c_i,
        (_rounding_mm(de, config) / SQRT3) * c_o,
        (1.0 / SQRT3),
    ]
    corrections = abs(float(_float(force.get("correction_kN"), 0.0) or 0.0) * c_load) + abs(float(_float(inst_i.get("correction_mm"), 0.0) or 0.0) * c_i) + abs(float(_float(inst_o.get("correction_mm"), 0.0) or 0.0) * c_o)
    uc = math.sqrt(sum(value * value for value in contribs))
    u = 2.0 * uc + corrections
    return {"value": u, "rounded": _roundup(u, 0), "force_cell": force_cell, "load_kN": load, "area_mm2": area}


def _stress_uncertainty_irregular(
    *,
    stress_mpa: float,
    geometry: Any,
    geometry_config: Mapping[str, Any],
    config: Mapping[str, Any],
    repeatability_key: str,
    reproducibility_key: str,
) -> Optional[dict[str, float | str]]:
    area = _area_mm2(geometry, "irregular")
    if not _positive(area):
        return None
    area = float(area)
    load = stress_mpa * area / 1000.0
    force_cell = _force_cell_for_load(load, geometry_config, config)
    force = _force(config, force_cell)
    c_load = 1000.0 / area
    contribs = [
        (float(_float(force.get("resolution_kN"), 0.0) or 0.0) / SQRT12) * c_load,
        (float(_float(geometry_config.get(repeatability_key), 0.0) or 0.0) / SQRT3),
        (float(_float(geometry_config.get(reproducibility_key), 0.0) or 0.0) / SQRT3),
        (float(_float(force.get("uncertainty_kN"), 0.0) or 0.0) / 2.0) * c_load,
        (float(_float(force.get("drift_kN"), 0.0) or 0.0) / SQRT3) * c_load,
        (1.0 / SQRT3),
    ]
    corrections = abs(float(_float(force.get("correction_kN"), 0.0) or 0.0) * c_load)
    uc = math.sqrt(sum(value * value for value in contribs))
    u = 2.0 * uc + corrections
    return {"value": u, "rounded": _roundup(u, 0), "force_cell": force_cell, "load_kN": load, "area_mm2": area}


def calculate_stress_uncertainty(
    *,
    stress_mpa: Any,
    geometry: Any,
    stress_kind: str,
    config: Optional[Mapping[str, Any]] = None,
) -> Optional[dict[str, float | str]]:
    number = _float(stress_mpa)
    if number is None:
        return None
    cfg = load_uncertainty_config() if config is None else dict(config)
    key = _geometry_key(getattr(geometry, "shape", getattr(geometry, "geometry_type", None)))
    geometry_config = ((cfg.get("geometries") or {}).get(key) or {})
    rep_key = "repeatability_max_mpa" if stress_kind == "max" else "repeatability_yield_mpa"
    repro_key = "reproducibility_max_mpa" if stress_kind == "max" else "reproducibility_yield_mpa"
    if key == "circular":
        return _stress_uncertainty_circular(stress_mpa=float(number), geometry=geometry, geometry_config=geometry_config, config=cfg, repeatability_key=rep_key, reproducibility_key=repro_key)
    if key == "tubular":
        return _stress_uncertainty_tubular(stress_mpa=float(number), geometry=geometry, geometry_config=geometry_config, config=cfg, repeatability_key=rep_key, reproducibility_key=repro_key)
    if key == "irregular":
        return _stress_uncertainty_irregular(stress_mpa=float(number), geometry=geometry, geometry_config=geometry_config, config=cfg, repeatability_key=rep_key, reproducibility_key=repro_key)
    return _stress_uncertainty_rectangular(stress_mpa=float(number), geometry=geometry, geometry_config=geometry_config, config=cfg, repeatability_key=rep_key, reproducibility_key=repro_key)


def calculate_elongation_uncertainty(
    *,
    elongation_pct: Any,
    geometry: Any,
    config: Optional[Mapping[str, Any]] = None,
) -> Optional[dict[str, float | str]]:
    elong = _float(elongation_pct)
    lo = _float(getattr(geometry, "gauge_length_mm", None))
    if elong is None or not _positive(lo):
        return None
    lo = float(lo)
    lf = lo * (1.0 + float(elong) / 100.0)
    cfg = load_uncertainty_config() if config is None else dict(config)
    key = _geometry_key(getattr(geometry, "shape", getattr(geometry, "geometry_type", None)))
    geometry_config = ((cfg.get("geometries") or {}).get(key) or {})
    inst = _instrument(cfg, str(geometry_config.get("elongation_instrument") or "pie_de_rey_a_im_230"))
    c_lf = 100.0 / lo
    c_lo = -(lf * 100.0 / (lo ** 2))
    contribs = [
        (float(_float(inst.get("resolution_mm"), 0.0) or 0.0) / SQRT12) * c_lf,
        (float(_float(inst.get("resolution_mm"), 0.0) or 0.0) / SQRT12) * c_lo,
        (float(_float(geometry_config.get("repeatability_elongation_pct"), 0.0) or 0.0) / SQRT3),
        (float(_float(geometry_config.get("reproducibility_elongation_pct"), 0.0) or 0.0) / SQRT3),
        (_certificate_mm(inst) / 2.0) * c_lf,
        (_certificate_mm(inst) / 2.0) * c_lo,
        (0.1 / SQRT3),
        (float(_float(inst.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_lf,
        (float(_float(inst.get("drift_mm"), 0.0) or 0.0) / SQRT3) * c_lo,
    ]
    corrections = abs(float(_float(inst.get("correction_mm"), 0.0) or 0.0) * c_lf) + abs(float(_float(inst.get("correction_mm"), 0.0) or 0.0) * c_lo)
    uc = math.sqrt(sum(value * value for value in contribs))
    u = 2.0 * uc + corrections
    return {"value": u, "rounded": _roundup(u, 2), "lo_mm": lo, "lf_mm": lf}


def uncertainty_values_for_curve(
    curve: Any,
    analysis_result: Any,
    config: Optional[Mapping[str, Any]] = None,
) -> dict[str, Any]:
    geometry = getattr(curve, "geometry", None) if curve is not None else None
    selected = _selected_method_result(analysis_result)
    if geometry is None or selected is None:
        return {}
    cfg = load_uncertainty_config() if config is None else dict(config)
    max_stress = getattr(selected, "max_stress_mpa", None)
    yield_stress = getattr(selected, "value_mpa", None)
    elongation = getattr(selected, "elongation_after_break_pct", None)
    out: dict[str, Any] = {}
    max_u = calculate_stress_uncertainty(stress_mpa=max_stress, geometry=geometry, stress_kind="max", config=cfg)
    yield_u = calculate_stress_uncertainty(stress_mpa=yield_stress, geometry=geometry, stress_kind="yield", config=cfg)
    elong_u = calculate_elongation_uncertainty(elongation_pct=elongation, geometry=geometry, config=cfg)
    if max_u:
        out["max"] = max_u
    if yield_u:
        out["yield"] = yield_u
    if elong_u:
        out["elongation"] = elong_u
    return out


def uncertainty_context_for_comment(
    curve: Any,
    analysis_result: Any,
    config: Optional[Mapping[str, Any]] = None,
) -> dict[str, str]:
    values = uncertainty_values_for_curve(curve, analysis_result, config=config)
    return {
        "unc_esfuerzo_maximo_mpa": _format_int_like((values.get("max") or {}).get("rounded") if isinstance(values.get("max"), Mapping) else None),
        "unc_fluencia_mpa": _format_int_like((values.get("yield") or {}).get("rounded") if isinstance(values.get("yield"), Mapping) else None),
        "unc_elongacion_pct": _format_fixed_decimal((values.get("elongation") or {}).get("rounded") if isinstance(values.get("elongation"), Mapping) else None, 1),
    }


__all__ = [
    "DEFAULT_UNCERTAINTY_CONFIG",
    "DEFAULT_CONFIG_PATH",
    "LOCAL_CONFIG_PATH",
    "ensure_default_uncertainty_config_file",
    "load_uncertainty_config",
    "save_user_uncertainty_config",
    "calculate_stress_uncertainty",
    "calculate_elongation_uncertainty",
    "uncertainty_values_for_curve",
    "uncertainty_context_for_comment",
]
