from __future__ import annotations

"""Resumen consolidado por probeta para el módulo unificado de tracción.

Este archivo no cambia cálculos. Solo transforma los resultados existentes en
filas legibles para la interfaz y validación previa a reportes.
"""

from typing import Any, Iterable

try:
    from .analysis_config import METHOD_AUTO, METHOD_RP_OFFSET, METHOD_UPPER_YIELD, METHOD_MANUAL_REVIEW
except Exception:  # pragma: no cover
    METHOD_AUTO = "auto"
    METHOD_RP_OFFSET = "rp_offset"
    METHOD_UPPER_YIELD = "upper_yield"
    METHOD_MANUAL_REVIEW = "manual_review"

METHOD_LABEL_BY_VALUE = {
    METHOD_AUTO: "Automático",
    METHOD_UPPER_YIELD: "Fluencia superior",
    METHOD_RP_OFFSET: "Rp offset",
    METHOD_MANUAL_REVIEW: "Revisión manual",
    "upper_yield": "Fluencia superior",
    "rp_offset": "Rp offset",
    "manual_review": "Revisión manual",
    "auto": "Automático",
}
CONFIDENCE_LABEL_BY_VALUE = {
    "high": "Alta",
    "medium": "Media",
    "low": "Baja",
    "alta": "Alta",
    "media": "Media",
    "baja": "Baja",
}
SHAPE_LABEL_BY_VALUE = {
    "rectangular": "Rectangular",
    "circular": "Circular",
    "irregular": "Irregular",
    "flat": "Plana",
    "plana": "Plana",
}


def safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        number = float(value)
        return number if number == number else None
    except Exception:
        return None


def fmt(value: Any, ndigits: int = 2, suffix: str = "") -> str:
    number = safe_float(value)
    if number is None:
        return "-"
    return f"{number:.{ndigits}f}{suffix}"


def display_method(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    return METHOD_LABEL_BY_VALUE.get(text, METHOD_LABEL_BY_VALUE.get(text.lower(), text or "-"))


def display_confidence(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    return CONFIDENCE_LABEL_BY_VALUE.get(text.lower(), text or "-")


def geometry_label(curve: Any) -> str:
    geometry = getattr(curve, "geometry", None)
    raw = str(getattr(geometry, "shape", "") or "").strip().lower()
    return SHAPE_LABEL_BY_VALUE.get(raw, raw.capitalize() if raw else "-")


def rp_label_from_result(analysis_result: Any, default: str = "Rp") -> str:
    rp = getattr(analysis_result, "rp_offset_result", None)
    diagnostics = getattr(rp, "diagnostics", {}) or {}
    return str(diagnostics.get("rp_label") or default)


def build_summary_row(curve: Any, analysis_result: Any, *, active_method_label: str = "") -> dict[str, str]:
    """Construye una fila de resumen sin modificar resultados.

    Devuelve strings listos para Treeview/JSON. No lanza excepción: cualquier
    dato faltante se representa con "-".
    """
    selected = getattr(analysis_result, "selected_result", None)
    detection = getattr(analysis_result, "method_detection", {}) or {}
    upper = getattr(analysis_result, "upper_yield_result", None)
    rp = getattr(analysis_result, "rp_offset_result", None)
    rp_label = rp_label_from_result(analysis_result, "Rp")
    method = getattr(selected, "method", None)
    status = "OK" if bool(getattr(selected, "is_available", False)) else "Revisar"
    reason = str(detection.get("reason", "") or getattr(selected, "warning_message", "") or "")
    if detection.get("suggested_method") == METHOD_MANUAL_REVIEW:
        status = "Revisión manual"
    elif reason and any(token in reason.lower() for token in ("no se detect", "insuf", "manual", "longitud")):
        status = "Advertencia"

    return {
        "specimen": str(getattr(curve, "specimen_id", "") or "-"),
        "geometry": geometry_label(curve),
        "suggested": display_method(detection.get("suggested_method", "-")),
        "active": active_method_label or display_method(method),
        "confidence": display_confidence(detection.get("confidence", "-")),
        "upper_yield": fmt(getattr(upper, "value_mpa", None), 2),
        "rp": fmt(getattr(rp, "value_mpa", None), 2),
        "selected_yield": fmt(getattr(selected, "value_mpa", None), 2),
        "selected_method": str(method or ""),
        "rp_label": rp_label,
        "modulus": fmt(getattr(rp, "elastic_modulus_gpa", None), 2),
        "max": fmt(getattr(selected, "max_stress_mpa", None), 2),
        "elongation": fmt(getattr(selected, "elongation_after_break_pct", None), 2),
        "status": status,
    }


def build_unified_summary_rows(curves: Iterable[Any], result_provider: Any, *, active_method_label: str = "") -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for curve in curves or []:
        try:
            result = result_provider(curve)
            rows.append(build_summary_row(curve, result, active_method_label=active_method_label))
        except Exception as exc:
            rows.append({
                "specimen": str(getattr(curve, "specimen_id", "") or "-"),
                "geometry": geometry_label(curve),
                "suggested": "-",
                "active": active_method_label or "-",
                "confidence": "-",
                "upper_yield": "-",
                "rp": "-",
                "selected_yield": "-",
                "selected_method": "",
                "rp_label": "Rp",
                "modulus": "-",
                "max": "-",
                "elongation": "-",
                "status": f"Error: {exc}",
            })
    return rows


__all__ = [
    "build_summary_row",
    "build_unified_summary_rows",
    "display_method",
    "display_confidence",
]
