from __future__ import annotations

"""Configuración común para el futuro motor unificado de tracción."""

from dataclasses import dataclass
from typing import Any

METHOD_AUTO = "auto"
METHOD_UPPER_YIELD = "upper_yield"
METHOD_RP_OFFSET = "rp_offset"
METHOD_MANUAL_REVIEW = "manual_review"
METHOD_OPTIONS = (METHOD_AUTO, METHOD_UPPER_YIELD, METHOD_RP_OFFSET, METHOD_MANUAL_REVIEW)


def _safe_float(value: Any, default: float) -> float:
    try:
        number = float(value)
    except Exception:
        return default
    return number if number > 0 else default


@dataclass
class TensileAnalysisConfig:
    """Parámetros de análisis compartidos entre módulo 1, módulo 2 y futuro módulo unificado."""

    active_method: str = METHOD_AUTO
    upper_yield_drop_mpa: float = 1.0
    offset_percent: float = 0.2
    allow_manual_override: bool = True
    # Fase de migración: permite que los accesos históricos fijen un método
    # predeterminado sin impedir que el analista lo cambie en interfaces futuras.
    method_locked: bool = False

    def __post_init__(self) -> None:
        if self.active_method not in METHOD_OPTIONS:
            self.active_method = METHOD_AUTO
        self.upper_yield_drop_mpa = _safe_float(self.upper_yield_drop_mpa, 1.0)
        self.offset_percent = _safe_float(self.offset_percent, 0.2)
        self.allow_manual_override = bool(self.allow_manual_override)
        self.method_locked = bool(self.method_locked)

    @property
    def rp_label(self) -> str:
        """Etiqueta visible del método Rp según el offset configurado."""
        value = f"{self.offset_percent:g}"
        return f"Rp{value}"

    @property
    def offset_fraction(self) -> float:
        """Offset como fracción de la longitud calibrada."""
        return self.offset_percent / 100.0

    def copy(self) -> "TensileAnalysisConfig":
        return TensileAnalysisConfig(
            active_method=self.active_method,
            upper_yield_drop_mpa=self.upper_yield_drop_mpa,
            offset_percent=self.offset_percent,
            allow_manual_override=self.allow_manual_override,
            method_locked=self.method_locked,
        )
