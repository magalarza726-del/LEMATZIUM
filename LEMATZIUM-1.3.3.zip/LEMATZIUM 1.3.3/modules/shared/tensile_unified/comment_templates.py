from __future__ import annotations

"""Motor de comentarios automáticos editables para reportes de tracción.

Esta capa no modifica cálculos, interfaz ni exportadores existentes. Solo
centraliza la carga, selección, renderizado y guardado de comentarios por
geometría y método para el futuro módulo unificado.
"""

import json
import re
import string
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Optional

from .analysis_config import METHOD_RP_OFFSET, METHOD_UPPER_YIELD
from .geometry import (
    GEOMETRY_CIRCULAR,
    GEOMETRY_IRREGULAR,
    GEOMETRY_RECTANGULAR,
    GEOMETRY_TUBULAR,
    normalize_shape,
)

TEMPLATE_IRREGULAR_UPPER_YIELD = "IRREGULAR_UPPER_YIELD"
TEMPLATE_RECTANGULAR_RP_OFFSET = "RECTANGULAR_RP_OFFSET"
TEMPLATE_CIRCULAR_RP_OFFSET = "CIRCULAR_RP_OFFSET"
TEMPLATE_RECTANGULAR_UPPER_YIELD = "RECTANGULAR_UPPER_YIELD"
TEMPLATE_CIRCULAR_UPPER_YIELD = "CIRCULAR_UPPER_YIELD"
TEMPLATE_TUBULAR_RP_OFFSET = "TUBULAR_RP_OFFSET"
TEMPLATE_TUBULAR_UPPER_YIELD = "TUBULAR_UPPER_YIELD"

REQUIRED_TEMPLATE_KEYS = (
    TEMPLATE_IRREGULAR_UPPER_YIELD,
    TEMPLATE_RECTANGULAR_RP_OFFSET,
    TEMPLATE_CIRCULAR_RP_OFFSET,
    TEMPLATE_RECTANGULAR_UPPER_YIELD,
    TEMPLATE_CIRCULAR_UPPER_YIELD,
    TEMPLATE_TUBULAR_RP_OFFSET,
    TEMPLATE_TUBULAR_UPPER_YIELD,
)

DEFAULT_PLACEHOLDERS: dict[str, str] = {
    "offset_percent": "0.2",
    "upper_yield_drop_mpa": "1.0",
    "unc_esfuerzo_maximo_mpa": "",
    "unc_fluencia_mpa": "",
    "unc_elongacion_pct": "",
    "procedure_code": "",
    "standard_label": "",
    "machine_label": "",
}

DEFAULT_COMMENT_TEMPLATES: dict[str, str] = {
    TEMPLATE_IRREGULAR_UPPER_YIELD: (
        "El área corresponde al área nominal de la muestra.\n"
        "El esfuerzo de fluencia registrado corresponde al esfuerzo de fluencia superior de acuerdo a la norma ISO 6892-1:2016.\n"
        "La probeta ensayada fue de tipo no proporcional y no maquinada.\n"
        "La muestra y la información de la misma fue proporcionada por el cliente.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales de la MUE 600 kN.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura = {unc_elongacion_pct} %.\n"
        "PEE0303-01"
    ),
    TEMPLATE_RECTANGULAR_RP_OFFSET: (
        "La muestra y la información de la misma fueron proporcionadas por el cliente.\n"
        "El esfuerzo de fluencia reportado fue calculado con el método del {offset_percent} % de la longitud calibrada y el mismo es un valor aproximado.\n"
        "Las dimensiones reportadas corresponden a las dimensiones de la probeta previo al ensayo de tensión.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales del equipo.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura= {unc_elongacion_pct} %.\n"
        "PEE0201-01"
    ),
    TEMPLATE_CIRCULAR_RP_OFFSET: (
        "La muestra y la información de la misma fueron proporcionadas por el cliente.\n"
        "El esfuerzo de fluencia reportado fue calculado con el método del {offset_percent} % de la longitud calibrada y el mismo es un valor aproximado.\n"
        "Las dimensiones reportadas corresponden a las dimensiones de la probeta previo al ensayo de tensión.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales del equipo.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura= {unc_elongacion_pct} %.\n"
        "PEE0201-01"
    ),
    TEMPLATE_TUBULAR_RP_OFFSET: (
        "La muestra y la información de la misma fueron proporcionadas por el cliente.\n"
        "El esfuerzo de fluencia reportado fue calculado con el método del {offset_percent} % de la longitud calibrada y el mismo es un valor aproximado.\n"
        "Las dimensiones reportadas corresponden a las dimensiones de la probeta tubular previo al ensayo de tensión.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales del equipo.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura= {unc_elongacion_pct} %.\n"
        "PEE0201-01"
    ),
    TEMPLATE_RECTANGULAR_UPPER_YIELD: (
        "La muestra y la información de la misma fueron proporcionadas por el cliente.\n"
        "El esfuerzo de fluencia reportado corresponde al esfuerzo de fluencia superior de acuerdo con la norma ASTM E8:2021.\n"
        "Las dimensiones reportadas corresponden a las dimensiones de la probeta previo al ensayo de tensión.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales del equipo.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura= {unc_elongacion_pct} %.\n"
        "PEE0201-01"
    ),
    TEMPLATE_CIRCULAR_UPPER_YIELD: (
        "La muestra y la información de la misma fueron proporcionadas por el cliente.\n"
        "El esfuerzo de fluencia reportado corresponde al esfuerzo de fluencia superior de acuerdo con la norma ASTM E8:2021.\n"
        "Las dimensiones reportadas corresponden a las dimensiones de la probeta previo al ensayo de tensión.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales del equipo.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura= {unc_elongacion_pct} %.\n"
        "PEE0201-01"
    ),
    TEMPLATE_TUBULAR_UPPER_YIELD: (
        "La muestra y la información de la misma fueron proporcionadas por el cliente.\n"
        "El esfuerzo de fluencia reportado corresponde al esfuerzo de fluencia superior de acuerdo con la norma ASTM E8:2021.\n"
        "Las dimensiones reportadas corresponden a las dimensiones de la probeta tubular previo al ensayo de tensión.\n"
        "El alargamiento registrado corresponde al desplazamiento de los cabezales del equipo.\n"
        "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
        "Incertidumbre de la medición en: Esfuerzo Máximo= {unc_esfuerzo_maximo_mpa} MPa. Esfuerzo de Fluencia= {unc_fluencia_mpa} MPa. Porcentaje de Elongación luego de la rotura= {unc_elongacion_pct} %.\n"
        "PEE0201-01"
    ),
}

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "report_comment_templates.json"
LOCAL_CONFIG_PATH = PROJECT_ROOT / "user_config" / "report_comment_templates.local.json"


class SafeFormatDict(dict):
    """Mapeo tolerante: placeholders faltantes se renderizan como vacío."""

    def __missing__(self, key: str) -> str:
        return ""


def _read_json(path: Path) -> dict[str, Any]:
    try:
        if not path.exists():
            return {}
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_json(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(dict(data), fh, ensure_ascii=False, indent=2)
        fh.write("\n")


def ensure_default_templates_file(path: str | Path | None = None) -> Path:
    """Crea el JSON base si no existe y devuelve su ruta."""
    target = Path(path) if path is not None else DEFAULT_CONFIG_PATH
    if not target.exists():
        _write_json(target, DEFAULT_COMMENT_TEMPLATES)
    return target


def load_comment_templates(
    default_path: str | Path | None = None,
    local_path: str | Path | None = None,
) -> dict[str, str]:
    """Carga plantillas predeterminadas y sobreescrituras locales editables.

    Prioridad:
    1. ``DEFAULT_COMMENT_TEMPLATES`` embebido como respaldo seguro.
    2. ``config/report_comment_templates.json`` si existe.
    3. ``user_config/report_comment_templates.local.json`` si existe.
    """
    defaults_file = Path(default_path) if default_path is not None else DEFAULT_CONFIG_PATH
    local_file = Path(local_path) if local_path is not None else LOCAL_CONFIG_PATH

    templates: dict[str, str] = dict(DEFAULT_COMMENT_TEMPLATES)
    file_defaults = _read_json(defaults_file)
    for key, value in file_defaults.items():
        if isinstance(value, str):
            templates[str(key)] = value
    local_overrides = _read_json(local_file)
    for key, value in local_overrides.items():
        if isinstance(value, str):
            templates[str(key)] = value
    return templates


def save_user_templates(
    templates: Mapping[str, str],
    local_path: str | Path | None = None,
    *,
    merge_existing: bool = True,
) -> Path:
    """Guarda cambios editables del usuario sin tocar el JSON predeterminado."""
    target = Path(local_path) if local_path is not None else LOCAL_CONFIG_PATH
    data: dict[str, str] = {}
    if merge_existing:
        for key, value in _read_json(target).items():
            if isinstance(value, str):
                data[str(key)] = value
    for key, value in templates.items():
        if isinstance(value, str):
            data[str(key)] = value
    _write_json(target, data)
    return target


def _normalize_method(method: Any) -> str:
    text = "" if method is None else str(method).strip().lower()
    if text in {METHOD_UPPER_YIELD, "upper yield", "fluencia superior", "fluencia_superior", "yield_upper"}:
        return METHOD_UPPER_YIELD
    if text in {METHOD_RP_OFFSET, "rp", "rp02", "rp0.2", "r2p", "offset", "rp offset"}:
        return METHOD_RP_OFFSET
    return text


def get_template_key(geometry_type: Any, method: Any) -> Optional[str]:
    """Devuelve la llave de comentario para geometría + método."""
    geometry = normalize_shape(geometry_type)
    normalized_method = _normalize_method(method)
    if geometry == GEOMETRY_IRREGULAR and normalized_method == METHOD_UPPER_YIELD:
        return TEMPLATE_IRREGULAR_UPPER_YIELD
    if geometry == GEOMETRY_RECTANGULAR and normalized_method == METHOD_RP_OFFSET:
        return TEMPLATE_RECTANGULAR_RP_OFFSET
    if geometry == GEOMETRY_CIRCULAR and normalized_method == METHOD_RP_OFFSET:
        return TEMPLATE_CIRCULAR_RP_OFFSET
    if geometry == GEOMETRY_TUBULAR and normalized_method == METHOD_RP_OFFSET:
        return TEMPLATE_TUBULAR_RP_OFFSET
    if geometry == GEOMETRY_RECTANGULAR and normalized_method == METHOD_UPPER_YIELD:
        return TEMPLATE_RECTANGULAR_UPPER_YIELD
    if geometry == GEOMETRY_CIRCULAR and normalized_method == METHOD_UPPER_YIELD:
        return TEMPLATE_CIRCULAR_UPPER_YIELD
    if geometry == GEOMETRY_TUBULAR and normalized_method == METHOD_UPPER_YIELD:
        return TEMPLATE_TUBULAR_UPPER_YIELD
    return None


def _mapping_from_context(context: Any = None, **kwargs: Any) -> dict[str, Any]:
    values: dict[str, Any] = dict(DEFAULT_PLACEHOLDERS)
    if context is not None:
        if isinstance(context, Mapping):
            values.update(dict(context))
        elif is_dataclass(context):
            values.update(asdict(context))
        else:
            for name in dir(context):
                if name.startswith("_"):
                    continue
                try:
                    value = getattr(context, name)
                except Exception:
                    continue
                if callable(value):
                    continue
                values[name] = value
    values.update(kwargs)
    # Normaliza None a cadena vacía para que el comentario quede editable y no falle.
    for key, value in list(values.items()):
        if value is None:
            values[key] = ""
    return values


def render_comment_template(template: str, context: Any = None, **kwargs: Any) -> str:
    """Renderiza una plantilla con placeholders seguros.

    Si falta un valor de incertidumbre u otro placeholder, se deja vacío y no se
    genera excepción. Los placeholders desconocidos también quedan vacíos.
    """
    if template is None:
        return ""
    values = SafeFormatDict(_mapping_from_context(context, **kwargs))
    try:
        return str(template).format_map(values)
    except Exception:
        # Fallback defensivo para plantillas editadas con llaves incompletas.
        formatter = string.Formatter()
        rendered_parts: list[str] = []
        try:
            for literal_text, field_name, format_spec, conversion in formatter.parse(str(template)):
                rendered_parts.append(literal_text)
                if field_name is not None:
                    value = values.get(field_name, "")
                    rendered_parts.append(str(value))
            return "".join(rendered_parts)
        except Exception:
            return str(template)


def get_default_comment(
    geometry_type: Any,
    method: Any,
    context: Any = None,
    *,
    templates: Optional[Mapping[str, str]] = None,
) -> str:
    """Selecciona y renderiza el comentario predeterminado para geometría + método."""
    key = get_template_key(geometry_type, method)
    if not key:
        return ""
    source = dict(templates) if templates is not None else load_comment_templates()
    template = source.get(key, "")
    return render_comment_template(template, context)


def missing_required_templates(templates: Optional[Mapping[str, str]] = None) -> list[str]:
    """Lista llaves requeridas ausentes o vacías."""
    source = dict(templates) if templates is not None else load_comment_templates()
    return [key for key in REQUIRED_TEMPLATE_KEYS if not str(source.get(key, "")).strip()]


def extract_placeholders(template: str) -> set[str]:
    """Extrae placeholders simples de una plantilla para futuras pantallas de edición."""
    if not template:
        return set()
    return set(re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", str(template)))
