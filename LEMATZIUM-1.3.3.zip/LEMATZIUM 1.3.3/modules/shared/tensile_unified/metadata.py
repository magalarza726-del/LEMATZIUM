from __future__ import annotations

"""Helpers de metadatos del ensayo para el módulo unificado."""

from typing import Any

META_FIELD_SPECS = (
    ("procedure", "Procedimiento", ("Procedure", "Procedimiento")),
    ("standard", "Norma de referencia", ("Reference Standard", "Norma de Referencia", "Norma de referencia")),
    ("machine", "Equipo utilizado", ("Used Device", "Equipo Utilizado", "Equipo utilizado")),
    ("material", "Material", ("Material",)),
    ("speed", "Velocidad de ensayo", ("Test Speed", "Velocidad de Ensayo", "Velocidad de ensayo")),
    ("humidity", "Humedad Máx/Mín", ("Humidity Max/Min", "Humedad Máx/Min", "Humedad Máx/Mín")),
    ("temperature", "Temperatura Máx/Mín", ("Temperature Max/Min", "Temperatura Máx/Mín", "Temperatura Max/Min")),
    ("control", "Control de velocidad", ("Speed Control", "Control de Velocidad", "Control de velocidad")),
    ("order", "Número de orden", ("Order No", "Número de Orden", "N° orden", "Numero de orden")),
    ("sample_description", "Descripción de la muestra", ("Descripción de la muestra", "Descripcion de la muestra", "Sample Description", "Description")),
    ("received_date", "Fecha de recepción de muestras", ("Fecha de Recepción", "Fecha Recepción", "Fecha de recepción de muestras", "Reception Date", "Received Date")),
    ("test_date", "Fecha de ensayo", ("Fecha de Ensayo", "Fecha Ensayo", "Test Date")),
)

CANONICAL_META_KEYS = {
    "procedure": "Procedure",
    "standard": "Reference Standard",
    "machine": "Used Device",
    "material": "Material",
    "speed": "Test Speed",
    "humidity": "Humidity Max/Min",
    "temperature": "Temperature Max/Min",
    "control": "Speed Control",
    "order": "Order No",
    "sample_description": "Descripción de la muestra",
    "received_date": "Fecha de Recepción",
    "test_date": "Fecha de Ensayo",
}


def read_meta_value(meta: dict[str, Any], field_name: str) -> str:
    for name, _label, keys in META_FIELD_SPECS:
        if name == field_name:
            for key in keys:
                if key in meta and meta.get(key) is not None:
                    return str(meta.get(key) or "")
    return ""


def write_meta_values(meta: dict[str, Any], values: dict[str, Any]) -> dict[str, Any]:
    for name, value in values.items():
        key = CANONICAL_META_KEYS.get(name, name)
        meta[key] = "" if value is None else str(value)
    return meta


def apply_meta_to_curve(curve: Any, meta: dict[str, Any]) -> None:
    try:
        curve_meta = getattr(curve, "meta", None)
        if curve_meta is None:
            curve.meta = {}
            curve_meta = curve.meta
        curve_meta.update(meta)
    except Exception:
        pass


__all__ = ["META_FIELD_SPECS", "CANONICAL_META_KEYS", "read_meta_value", "write_meta_values", "apply_meta_to_curve"]
