from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODULE_DIR = Path(__file__).resolve().parent
for path in (ROOT / "modules", MODULE_DIR, ROOT / "modules" / "module_1_drop1mpa", ROOT / "modules" / "module_2_offset02"):
    text = str(path)
    if text not in sys.path:
        sys.path.insert(0, text)

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from shared.tensile_unified import TensileAnalysisConfig, METHOD_AUTO
from lematzium_traccion_plasticos.iso527_analysis import analyze_plastic_curve

EXPECTED = {"TIPO A.csv": "A", "TIPO B.csv": "B", "TIPO C.csv": "C", "TIPO D.csv": "D"}


def main() -> int:
    ok = True
    for filename, expected in EXPECTED.items():
        path = MODULE_DIR / "resources" / filename
        dataset = load_dataset(path)
        if not dataset.curves:
            print(f"ERROR {filename}: no se cargaron curvas")
            ok = False
            continue
        dataset.source_path = path
        curve = dataset.curves[0]
        curve.source_path = path
        curve.dataset = dataset
        try:
            setattr(curve.raw_df, "source_path", str(path))
            curve.raw_df.attrs["source_path"] = str(path)
        except Exception:
            pass
        cfg = TensileAnalysisConfig(active_method=METHOD_AUTO, offset_percent=100.0)
        result = analyze_plastic_curve(curve, curve.geometry, cfg)
        diag = result.selected_result.diagnostics
        applied = diag.get("plastic_type")
        points = diag.get("plastic_points") or []
        scalar = diag.get("plastic_scalar") or {}
        if applied != expected or not points or not result.selected_result.is_available:
            ok = False
            print(f"ERROR {filename}: esperado Tipo {expected}, obtenido Tipo {applied}; puntos={len(points)}")
            continue
        print(f"OK {filename}: Tipo {applied}; resultado={result.selected_result.value_mpa:.3f} MPa; puntos={len(points)}; claves={sorted(scalar.keys())}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
