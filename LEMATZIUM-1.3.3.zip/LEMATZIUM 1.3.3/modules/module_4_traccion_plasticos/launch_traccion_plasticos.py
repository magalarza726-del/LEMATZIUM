from __future__ import annotations

"""Launcher independiente del Módulo 2 - Tracción plásticos 1.0.0."""

from pathlib import Path
import sys

MODULES_DIR = Path(__file__).resolve().parents[1]
if str(MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(MODULES_DIR))

from shared.bootstrap import run_module_main  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
MODULES_DIR = ROOT / "modules"


def main():
    return run_module_main(
        __file__,
        "lematzium_traccion_plasticos.app.main",
        extra_paths=(
            MODULES_DIR / "module_4_traccion_plasticos",
            MODULES_DIR / "module_1_drop1mpa",
            MODULES_DIR / "module_2_offset02",
        ),
        purge_caches=False,
    )


if __name__ == "__main__":
    raise SystemExit(main())
