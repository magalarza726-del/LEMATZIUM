@echo off
cd /d "%~dp0"
python launch_traccion_plasticos.py
pause
