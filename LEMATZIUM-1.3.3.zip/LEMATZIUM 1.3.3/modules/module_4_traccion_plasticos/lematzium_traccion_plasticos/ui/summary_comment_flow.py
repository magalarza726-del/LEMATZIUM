from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import copy
import math
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

from matplotlib.figure import Figure

from shared.tk_ui_standard import (
    TEXT_EXPORT_WORD,
    TEXT_RECALCULATE,
    SUPPORTED_FILETYPES,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
)
from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from lematzium_traccion_plasticos.plastic_plotting import draw_plastic_tensile_curve as draw_unified_tensile_curve
from shared.tensile_unified.summary import build_unified_summary_rows
from shared.tensile_unified.manual_points import MODE_TO_POINT_KEY, nearest_curve_index

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_traccion_plasticos.iso527_analysis import analyze_plastic_curve as analyze_curve, get_plastic_default_comment as get_default_comment, plastic_comment
from lematzium_traccion_plasticos.reports.exporter import export_unified_report
from lematzium_traccion_plasticos.ui.export_dialog import ReportExportDialog
from lematzium_traccion_plasticos.ui.presentation import (
    GEOMETRY_LABEL_BY_VALUE,
    GEOMETRY_MAP,
    MANUAL_DRAG_LABELS,
    META_FIELDS,
    METHOD_LABEL_ALIASES,
    METHOD_LABEL_BY_VALUE,
    display_confidence as _display_confidence,
    display_method as _display_method,
    display_reason as _display_reason,
    fmt as _fmt,
    result_value_label as _result_value_label,
    safe_float as _safe_float,
)


class SummaryCommentFlowMixin:
    def _curve_comment_key(self, curve: Any = None) -> str:
        curve = curve if curve is not None else self.current_curve
        if curve is None:
            return ""
        try:
            if self.dataset and getattr(self.dataset, "curves", None):
                for index, item in enumerate(self.dataset.curves):
                    if item is curve:
                        return f"idx:{index}"
        except Exception:
            pass
        return f"obj:{id(curve)}"

    def _active_curve_index(self) -> Optional[int]:
        try:
            if self.dataset and self.current_curve is not None:
                for index, curve in enumerate(self.dataset.curves):
                    if curve is self.current_curve:
                        return int(index)
        except Exception:
            pass
        return None

    def _summary_iid(self, index: int) -> str:
        return f"row_{int(index)}"

    def _summary_index_from_iid(self, iid: Any) -> Optional[int]:
        text = str(iid or "")
        try:
            if text.startswith("row_"):
                return int(text.split("_", 1)[1])
            return int(text)
        except Exception:
            return None

    def _selected_multigraph_indices(self) -> list[int]:
        indices = set(getattr(self, "_summary_multigraph_indices", set()) or set())
        active = self._active_curve_index()
        if active is not None:
            indices.add(active)
        if not self.dataset:
            return []
        max_index = len(getattr(self.dataset, "curves", []) or []) - 1
        return sorted(index for index in indices if 0 <= int(index) <= max_index)

    def _has_simultaneous_graphs(self) -> bool:
        active = self._active_curve_index()
        selected = self._selected_multigraph_indices()
        if active is None:
            return len(selected) > 1
        return any(index != active for index in selected)

    def _on_comment_modified(self, _event: Any = None) -> None:
        try:
            modified = bool(self.comment_text.edit_modified())
            self.comment_text.edit_modified(False)
        except Exception:
            modified = True
        if modified and not self._comment_update_in_progress:
            self._comment_dirty = True
            self.comment_notice_var.set(
                "Comentario editado manualmente. No se sobrescribirá al recalcular; use ‘Actualizar comentario predeterminado’ para regenerarlo."
            )

    def _active_method_label(self) -> str:
        return METHOD_LABEL_BY_VALUE.get(self._current_active_method_value(), self.method_var.get() or "Automático ISO 527")

    def _summary_result_for_curve(self, curve: Any) -> Any:
        try:
            config = self._config_for_curve(curve) if hasattr(self, "_config_for_curve") else self._current_config()
            result = self._analysis_result_for_curve_cached(curve, config)
        except Exception:
            config = self._config_for_curve(curve) if hasattr(self, "_config_for_curve") else self._current_config()
            result = analyze_curve(curve, getattr(curve, "geometry", None), config)
        try:
            if self.current_curve is curve:
                return self._effective_result(result)
        except Exception:
            pass
        return result

    def _summary_fmt_value(self, value: Any, ndigits: int = 2) -> str:
        try:
            if value is None:
                return "-"
            number = float(value)
            if not math.isfinite(number):
                return "-"
            return f"{number:.{ndigits}f}"
        except Exception:
            return "-"

    def _plastic_summary_values_for_curve(self, curve: Any) -> tuple[str, ...]:
        """Fila resumida para ISO 527 A/B/C/D.

        Se muestran todos los parámetros posibles; los que no aplican para el
        tipo detectado quedan en blanco técnico ("-").
        """
        try:
            result = self._summary_result_for_curve(curve)
            diag = getattr(result, "diagnostics", {}) or {}
            scalar = dict(diag.get("plastic_scalar") or {})
            detection = getattr(result, "method_detection", {}) or {}
            ptype = str(detection.get("applied_type") or scalar.get("applied_type") or diag.get("plastic_type") or "-").upper()
            specimen = str(getattr(curve, "specimen_id", "-") or "-")
            return (
                specimen,
                ptype if ptype in {"A", "B", "C", "D"} else "-",
                "",
                self._summary_fmt_value(scalar.get("yield_stress_mpa")),
                self._summary_fmt_value(scalar.get("max_stress_mpa")),
                self._summary_fmt_value(scalar.get("break_stress_mpa")),
                self._summary_fmt_value(scalar.get("break_strain_pct")),
                self._summary_fmt_value(scalar.get("modulus_gpa"), 3),
                self._summary_fmt_value(scalar.get("sigma1_stress_mpa")),
                self._summary_fmt_value(scalar.get("sigma2_stress_mpa")),
                self._summary_fmt_value(scalar.get("sigmax_stress_mpa")),
                self._summary_fmt_value(scalar.get("sigma_m_or_b_stress_mpa")),
            )
        except Exception:
            specimen = str(getattr(curve, "specimen_id", "-") or "-")
            return (specimen, "-", "", "-", "-", "-", "-", "-", "-", "-", "-", "-")

    def _clear_summary_color_swatches(self) -> None:
        swatches = getattr(self, "_summary_color_swatches", {}) or {}
        for widget in list(swatches.values()):
            try:
                widget.destroy()
            except Exception:
                pass
        self._summary_color_swatches = {}

    def _refresh_summary_color_swatches(self) -> None:
        tree = getattr(self, "summary_tree", None)
        if tree is None or not self.dataset:
            self._clear_summary_color_swatches()
            return
        self._clear_summary_color_swatches()
        try:
            for iid in tree.get_children():
                index = self._summary_index_from_iid(iid)
                if index is None:
                    continue
                bbox = tree.bbox(iid, "#4")
                if not bbox:
                    continue
                x, y, width, height = bbox
                color_hex = self._curve_color_for_index(index) if hasattr(self, "_curve_color_for_index") else "#2563eb"
                swatch = tk.Frame(tree, bg=color_hex, bd=1, relief="solid", cursor="hand2")
                swatch.place(x=x + 9, y=y + 5, width=max(14, min(30, width - 18)), height=max(10, height - 10))

                def _select_row(_event: Any = None, row_iid: str = iid) -> str:
                    try:
                        tree.selection_set(row_iid)
                        tree.focus(row_iid)
                    except Exception:
                        pass
                    return "break"

                def _edit_color(_event: Any = None, row_index: int = index) -> str:
                    self._choose_summary_curve_color(row_index)
                    return "break"

                swatch.bind("<Button-1>", _select_row)
                swatch.bind("<Double-Button-1>", _edit_color)
                self._summary_color_swatches[str(iid)] = swatch
        except Exception:
            self._clear_summary_color_swatches()

    def _refresh_summary_table(self) -> None:
        tree = getattr(self, "summary_tree", None)
        if tree is None:
            return
        try:
            self._clear_summary_color_swatches()
            for item in tree.get_children():
                tree.delete(item)
            if not self.dataset or not getattr(self.dataset, "curves", None):
                return
            try:
                tree.tag_configure("current", background="#dbeafe")
            except Exception:
                pass
            active_index = self._active_curve_index()
            selected_multi = set(getattr(self, "_summary_multigraph_indices", set()) or set())
            for index, curve in enumerate(self.dataset.curves):
                iid = self._summary_iid(index)
                checked = "☑" if index in selected_multi else "☐"
                values = (checked, *self._plastic_summary_values_for_curve(curve))
                tags = ("current",) if active_index == index else ()
                tree.insert("", "end", iid=iid, values=values, tags=tags)
            if active_index is not None:
                iid = self._summary_iid(active_index)
                if tree.exists(iid):
                    tree.selection_set(iid)
                    tree.focus(iid)
                    tree.see(iid)
            try:
                self.after_idle(self._refresh_summary_color_swatches)
            except Exception:
                pass
        except Exception as exc:
            self.status_var.set(f"No se pudo actualizar resumen: {exc}")

    def _on_summary_selected(self, _event: Any = None) -> None:
        tree = getattr(self, "summary_tree", None)
        if tree is None or self._is_updating_specimen_combo:
            return
        selected = tree.selection()
        if not selected:
            return
        index = self._summary_index_from_iid(selected[0])
        if index is None:
            return
        active = self._active_curve_index()
        if active == index:
            return
        if self.dataset and 0 <= index < len(self.dataset.curves):
            self._set_active_curve_by_index(index)
            self._refresh_summary_table()

    def _on_summary_tree_click(self, event: Any) -> None:
        tree = getattr(self, "summary_tree", None)
        if tree is None or not self.dataset:
            return
        try:
            region = tree.identify("region", event.x, event.y)
            column = tree.identify_column(event.x)
            iid = tree.identify_row(event.y)
        except Exception:
            return
        if region != "cell" or column != "#1" or not iid:
            return
        index = self._summary_index_from_iid(iid)
        if index is None:
            return
        selected = set(getattr(self, "_summary_multigraph_indices", set()) or set())
        if index in selected:
            selected.remove(index)
        else:
            selected.add(index)
        self._summary_multigraph_indices = selected
        self._refresh_summary_table()
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), preserve_view=False)
        self.status_var.set("Visualización simultánea actualizada. La exportación Word permanece independiente por probeta.")

    def _on_summary_tree_double_click(self, event: Any) -> str | None:
        tree = getattr(self, "summary_tree", None)
        if tree is None or not self.dataset:
            return None
        try:
            region = tree.identify("region", event.x, event.y)
            column = tree.identify_column(event.x)
            iid = tree.identify_row(event.y)
        except Exception:
            return None
        if region != "cell" or column not in {"#2", "#4"} or not iid:
            return None
        index = self._summary_index_from_iid(iid)
        if index is None or index < 0 or index >= len(self.dataset.curves):
            return "break"
        if column == "#4":
            self._choose_summary_curve_color(index)
            return "break"
        self._start_summary_code_edit(iid, index)
        return "break"

    def _choose_summary_curve_color(self, index: int) -> None:
        try:
            current = self._curve_color_for_index(index) if hasattr(self, "_curve_color_for_index") else "#2563eb"
            selected = colorchooser.askcolor(color=current, title="Seleccionar color de probeta", parent=self.winfo_toplevel())
            color_hex = selected[1] if selected else None
        except Exception:
            color_hex = None
        if not color_hex:
            return
        try:
            self._set_curve_color_for_index(index, color_hex)
            if index == self._active_curve_index():
                self._curve_color = color_hex
        except Exception:
            pass
        self._refresh_summary_table()
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), preserve_view=True)
        self.status_var.set(f"Color actualizado para la probeta {index + 1}.")

    def _start_summary_code_edit(self, iid: str, index: int) -> None:
        tree = getattr(self, "summary_tree", None)
        if tree is None:
            return
        try:
            if self._summary_edit_entry is not None:
                self._summary_edit_entry.destroy()
        except Exception:
            pass
        try:
            bbox = tree.bbox(iid, "#2")
        except Exception:
            bbox = None
        if not bbox:
            return
        x, y, width, height = bbox
        current_name = str(getattr(self.dataset.curves[index], "specimen_id", f"Probeta {index + 1}"))
        edit_var = tk.StringVar(value=current_name)
        entry = ttk.Entry(tree, textvariable=edit_var)
        entry.place(x=x, y=y, width=width, height=height)
        entry.focus_set()
        entry.select_range(0, tk.END)
        self._summary_edit_entry = entry

        def commit(_event: Any = None) -> None:
            name = edit_var.get().strip() or f"Probeta {index + 1}"
            try:
                setattr(self.dataset.curves[index], "specimen_id", name)
            except Exception:
                pass
            try:
                entry.destroy()
            except Exception:
                pass
            self._summary_edit_entry = None
            self._populate_specimens()
            active = self._active_curve_index()
            if active is not None:
                self._is_updating_specimen_combo = True
                try:
                    self.specimen_combo.current(active)
                    self.specimen_var.set(str(getattr(self.dataset.curves[active], "specimen_id", f"Probeta {active + 1}")))
                finally:
                    self._is_updating_specimen_combo = False
            self._refresh_summary_table()
            if self.current_result is not None:
                self._draw_graph(self._effective_result(self.current_result), preserve_view=False)
            self.status_var.set("Código de probeta actualizado.")

        def cancel(_event: Any = None) -> None:
            try:
                entry.destroy()
            except Exception:
                pass
            self._summary_edit_entry = None

        entry.bind("<Return>", commit)
        entry.bind("<FocusOut>", commit)
        entry.bind("<Escape>", cancel)

    def reset_summary_table(self) -> None:
        if not self.dataset or not getattr(self.dataset, "curves", None):
            return
        originals = list(getattr(self, "_summary_original_specimen_ids", []) or [])
        for index, curve in enumerate(self.dataset.curves):
            default_name = originals[index] if index < len(originals) else f"Probeta {index + 1}"
            try:
                setattr(curve, "specimen_id", default_name)
            except Exception:
                pass
        self._summary_multigraph_indices = set()
        try:
            self._curve_colors_by_index = {}
        except Exception:
            pass
        self._populate_specimens()
        active = self._active_curve_index() or 0
        try:
            self._is_updating_specimen_combo = True
            self.specimen_combo.current(active)
            self.specimen_var.set(str(getattr(self.dataset.curves[active], "specimen_id", f"Probeta {active + 1}")))
        finally:
            self._is_updating_specimen_combo = False
        self._refresh_summary_table()
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), preserve_view=False)
        self.status_var.set("Tabla reiniciada.")

    def _update_result_panel(self, unified_result: Any) -> None:
        selected = unified_result.selected_result
        detection = unified_result.method_detection or {}
        config = self._current_config()
        rp_label = str(getattr(unified_result.rp_offset_result, "diagnostics", {}).get("rp_label", config.rp_label))
        selected_method = getattr(selected, "method", METHOD_AUTO)

        self.detection_method_var.set(_display_method(detection.get("suggested_method", "-")))
        self.detection_confidence_var.set(_display_confidence(detection.get("confidence", "-")))
        self.detection_reason_var.set(_display_reason(detection.get("reason", "-")))
        self.analysis_message_var.set(self._analysis_message_for_result(unified_result))

        self.result_value_label_var.set(_result_value_label(selected_method, rp_label))
        self.result_max_label_var.set("Esfuerzo máximo:")
        self.result_elong_label_var.set("Elongación luego de rotura:")
        self.result_e_label_var.set("Módulo elástico:")
        self.rp_label_text_var.set("Parámetro ISO 527 activo:")

        value = getattr(selected, "value_mpa", None)
        max_stress = getattr(selected, "max_stress_mpa", None)
        elongation = getattr(selected, "elongation_after_break_pct", None)
        modulus = getattr(selected, "elastic_modulus_gpa", None)
        self.result_value_var.set(f"{_fmt(value, 2)} MPa" if value is not None else "No disponible")
        self.result_max_var.set(f"{_fmt(max_stress, 2)} MPa" if max_stress is not None else "No disponible")
        self.result_elong_var.set(f"{_fmt(elongation, 2)} %" if elongation is not None else "No disponible")
        self.result_e_var.set(f"{_fmt(modulus, 2)} GPa" if modulus is not None else "No disponible")
        self.rp_label_var.set(rp_label)
        self._update_export_button_state()

    def _analysis_message_for_result(self, unified_result: Any) -> str:
        detection = unified_result.method_detection or {}
        diagnostics = getattr(unified_result, "diagnostics", {}) or {}
        scalar = diagnostics.get("plastic_scalar") or {}
        selected = getattr(unified_result, "selected_result", None)
        ptype = str(detection.get("applied_type") or scalar.get("applied_type") or "-").upper()
        reason = _display_reason(detection.get("reason", ""))
        if selected is None or not bool(getattr(selected, "is_available", False)):
            return "Curva insuficiente o requiere revisión manual."
        if ptype in {"A", "B", "C", "D"}:
            prefix = f"Curva Tipo {ptype} detectada automáticamente."
            return f"{prefix} {reason}" if reason and reason != "-" else prefix
        return reason or "Análisis ISO 527 actualizado."

    def _update_comment(self, unified_result: Any, *, force: bool = False) -> None:
        current_key = self._curve_comment_key()
        curve_changed = current_key != self._last_comment_curve_key
        if self._comment_dirty and not curve_changed and not force:
            self.comment_notice_var.set(
                "Comentario editado manualmente. Se conserva sin sobrescribir; puede actualizarlo con el botón predeterminado."
            )
            return

        geometry = getattr(self.current_curve, "geometry", None)
        selected = unified_result.selected_result
        method = getattr(selected, "method", METHOD_AUTO)
        shape = normalize_shape(getattr(geometry, "shape", None))
        config = self._current_config()
        context = {
            "offset_percent": f"{config.offset_percent:g}",
            "upper_yield_drop_mpa": f"{config.upper_yield_drop_mpa:g}",
            "procedure_code": "",
            "standard_label": "",
            "machine_label": "MUE 600 kN",
        }
        comment = get_default_comment(shape, method, context)
        try:
            self._comment_update_in_progress = True
            self.comment_text.delete("1.0", tk.END)
            self.comment_text.insert("1.0", comment)
            self.comment_text.edit_modified(False)
        finally:
            self._comment_update_in_progress = False
        self._comment_dirty = False
        self._last_comment_curve_key = current_key
        self.comment_notice_var.set("")

    def _mark_comment_default_available(self, message: str) -> None:
        if self._comment_dirty:
            self.comment_notice_var.set(
                f"{message} El comentario manual se conserva. Use ‘Actualizar comentario predeterminado’ si desea regenerarlo."
            )

    def restore_default_comment(self) -> None:
        if self.current_result is None:
            show_warning("Sin resultados", "Importe un CSV y calcule una probeta antes de actualizar el comentario.")
            return
        self._update_comment(self.current_result, force=True)
        self.status_var.set("Comentario predeterminado actualizado.")

