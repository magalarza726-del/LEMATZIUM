from __future__ import annotations

"""Textos, etiquetas y formateadores para Tracción plásticos ISO 527."""

from typing import Any, Optional

from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR
from lematzium_traccion_plasticos.iso527_analysis import (
    PLASTIC_AUTO, PLASTIC_TYPE_A, PLASTIC_TYPE_B, PLASTIC_TYPE_C, PLASTIC_TYPE_D,
    TYPE_LABEL,
)

METHOD_LABELS = {
    "Automático ISO 527": PLASTIC_AUTO,
    "Tipo A - sin fluencia: σM/σB y módulo": PLASTIC_TYPE_A,
    "Tipo B - fluencia y máximo posterior": PLASTIC_TYPE_B,
    "Tipo C - fluencia y rotura a menor esfuerzo": PLASTIC_TYPE_C,
    "Tipo D - alta deformación: σ1/σ2/σx": PLASTIC_TYPE_D,
}

METHOD_LABEL_ALIASES = {
    **METHOD_LABELS,
    "Automático": PLASTIC_AUTO,
    "Automatico": PLASTIC_AUTO,
    "auto": PLASTIC_AUTO,
    PLASTIC_AUTO: PLASTIC_AUTO,
    PLASTIC_TYPE_A: PLASTIC_TYPE_A,
    PLASTIC_TYPE_B: PLASTIC_TYPE_B,
    PLASTIC_TYPE_C: PLASTIC_TYPE_C,
    PLASTIC_TYPE_D: PLASTIC_TYPE_D,
    "A": PLASTIC_TYPE_A,
    "B": PLASTIC_TYPE_B,
    "C": PLASTIC_TYPE_C,
    "D": PLASTIC_TYPE_D,
}

METHOD_LABEL_BY_VALUE = {
    PLASTIC_AUTO: "Automático ISO 527",
    PLASTIC_TYPE_A: "Tipo A",
    PLASTIC_TYPE_B: "Tipo B",
    PLASTIC_TYPE_C: "Tipo C",
    PLASTIC_TYPE_D: "Tipo D",
    "manual_review": "Revisión manual",
}

CONFIDENCE_LABEL_BY_VALUE = {
    "high": "Alta", "medium": "Media", "low": "Baja",
    "alta": "Alta", "media": "Media", "baja": "Baja",
    "Alta": "Alta", "Media": "Media", "Baja": "Baja",
}

GEOMETRY_LABELS = ["Rectangular", "Circular", "Irregular / área nominal"]
GEOMETRY_ALIASES = {
    "Rectangular": SHAPE_RECTANGULAR,
    "Circular": SHAPE_CIRCULAR,
    "Irregular / área nominal": SHAPE_IRREGULAR,
    "Irregular / area nominal": SHAPE_IRREGULAR,
}
GEOMETRY_MAP = GEOMETRY_ALIASES
GEOMETRY_LABEL_BY_VALUE = {
    SHAPE_RECTANGULAR: "Rectangular",
    SHAPE_CIRCULAR: "Circular",
    SHAPE_IRREGULAR: "Irregular / área nominal",
}

META_FIELDS = (
    ("procedure", "Procedimiento", ("Procedure", "Procedimiento")),
    ("standard", "Norma de referencia", ("Reference Standard", "Norma de Referencia", "Norma de referencia")),
    ("machine", "Equipo utilizado", ("Used Device", "Equipo Utilizado", "Equipo utilizado")),
    ("material", "Material", ("Material",)),
    ("speed", "Velocidad de ensayo", ("Test Speed", "Velocidad de Ensayo", "Velocidad de ensayo")),
    ("humidity", "Humedad Máx/Mín", ("Humidity Max/Min", "Humedad Máx/Min", "Humedad Máx/Mín")),
    ("temperature", "Temperatura Máx/Mín", ("Temperature Max/Min", "Temperatura Máx/Mín", "Temperatura Max/Min")),
    ("control", "Control de velocidad", ("Speed Control", "Control de Velocidad", "Control de velocidad")),
    ("order", "Número de orden", ("Order No", "Número de Orden", "N° orden", "Numero de orden")),
    ("sample_description", "Descripción de la muestra", ("Descripción de la muestra", "Descripcion de la muestra", "Sample Description", "Description")),
    ("received_date", "Fecha de recepción de muestras", ("Fecha de Recepción", "Fecha Recepción", "Fecha de recepción de muestras", "Reception Date", "Received Date")),
    ("test_date", "Fecha de ensayo", ("Fecha de Ensayo", "Fecha Ensayo", "Test Date")),
)

MANUAL_DRAG_LABELS = {
    "none": "Sin arrastre",
    "yield": "σY",
    "max": "σM / σm",
    "break": "σB",
    "sigma1": "σ1",
    "sigma2": "σ2",
    "sigmax": "σx",
    "mod_e1": "ε1 módulo",
    "mod_e2": "ε2 módulo",
}


def safe_float(text: Any) -> Optional[float]:
    try:
        if text is None:
            return None
        value = str(text).strip().replace(",", ".")
        if not value:
            return None
        number = float(value)
        return number if number > 0 else None
    except Exception:
        return None


def fmt(value: Any, ndigits: int = 2) -> str:
    try:
        if value is None:
            return "No disponible"
        return f"{float(value):.{ndigits}f}"
    except Exception:
        return "No disponible"


def display_method(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    if not text or text == "-":
        return "-"
    if text in METHOD_LABEL_BY_VALUE:
        return METHOD_LABEL_BY_VALUE[text]
    if text in TYPE_LABEL:
        return TYPE_LABEL[text]
    return METHOD_LABEL_BY_VALUE.get(text.lower(), text)


def display_confidence(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    if not text or text == "-":
        return "-"
    return CONFIDENCE_LABEL_BY_VALUE.get(text, CONFIDENCE_LABEL_BY_VALUE.get(text.lower(), text))


def display_reason(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    if not text or text == "-":
        return "-"
    for raw, visible in METHOD_LABEL_BY_VALUE.items():
        text = text.replace(str(raw), visible)
    return text


def result_value_label(method: Any, rp_label: str = "") -> str:
    labels = {
        PLASTIC_TYPE_A: "Esfuerzo máximo σM:",
        PLASTIC_TYPE_B: "Esfuerzo de fluencia σY:",
        PLASTIC_TYPE_C: "Esfuerzo de fluencia σY:",
        PLASTIC_TYPE_D: "Esfuerzo máximo/rotura σm/σb:",
        PLASTIC_AUTO: "Esfuerzo principal ISO 527:",
    }
    return labels.get(method, "Esfuerzo principal ISO 527:")


__all__ = [
    "CONFIDENCE_LABEL_BY_VALUE", "GEOMETRY_ALIASES", "GEOMETRY_LABELS", "GEOMETRY_LABEL_BY_VALUE", "GEOMETRY_MAP",
    "MANUAL_DRAG_LABELS", "META_FIELDS", "METHOD_LABEL_ALIASES", "METHOD_LABEL_BY_VALUE", "METHOD_LABELS",
    "display_confidence", "display_method", "display_reason", "fmt", "result_value_label", "safe_float",
]
