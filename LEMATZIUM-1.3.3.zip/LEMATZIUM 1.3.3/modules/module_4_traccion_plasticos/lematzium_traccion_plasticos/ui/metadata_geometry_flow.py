from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import copy
import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from matplotlib.figure import Figure

from shared.tk_ui_standard import (
    TEXT_EXPORT_WORD,
    TEXT_RECALCULATE,
    SUPPORTED_FILETYPES,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
)
from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from lematzium_traccion_plasticos.plastic_plotting import draw_plastic_tensile_curve as draw_unified_tensile_curve
from shared.tensile_unified.summary import build_unified_summary_rows
from shared.tensile_unified.manual_points import MODE_TO_POINT_KEY, nearest_curve_index

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_traccion_plasticos.iso527_analysis import analyze_plastic_curve as analyze_curve, get_plastic_default_comment as get_default_comment, plastic_comment
from lematzium_traccion_plasticos.reports.exporter import export_unified_report
from lematzium_traccion_plasticos.ui.export_dialog import ReportExportDialog
from lematzium_traccion_plasticos.ui.presentation import (
    GEOMETRY_LABEL_BY_VALUE,
    GEOMETRY_MAP,
    MANUAL_DRAG_LABELS,
    META_FIELDS,
    METHOD_LABEL_ALIASES,
    METHOD_LABEL_BY_VALUE,
    display_confidence as _display_confidence,
    display_method as _display_method,
    display_reason as _display_reason,
    fmt as _fmt,
    result_value_label as _result_value_label,
    safe_float as _safe_float,
)


class MetadataGeometryFlowMixin:
    def _load_meta_from_dataset(self) -> None:
        meta = getattr(self.dataset, "meta", {}) or {}
        for name, _label, keys in META_FIELDS:
            value = ""
            for key in keys:
                if key in meta and meta.get(key) is not None:
                    value = str(meta.get(key) or "")
                    break
            self.meta_vars[name].set(value)
        # Si no se especifica fecha de ensayo, se usa por defecto la fecha de recepción.
        try:
            if not self.meta_vars.get("test_date").get().strip():
                received = self.meta_vars.get("received_date").get().strip()
                if received:
                    self.meta_vars.get("test_date").set(received)
        except Exception:
            pass

    def _save_metadata_from_ui(self, _event: Any = None) -> None:
        if self.dataset is None:
            return
        meta = getattr(self.dataset, "meta", None)
        if meta is None:
            try:
                self.dataset.meta = {}
                meta = self.dataset.meta
            except Exception:
                return
        received_date = self.meta_vars.get("received_date", tk.StringVar(value="")).get().strip()
        test_date = self.meta_vars.get("test_date", tk.StringVar(value="")).get().strip() or received_date
        try:
            if test_date and self.meta_vars.get("test_date") is not None:
                self.meta_vars["test_date"].set(test_date)
        except Exception:
            pass
        sample_description = self.meta_vars.get("sample_description", tk.StringVar(value="")).get().strip()
        updates = {
            "Procedure": self.meta_vars["procedure"].get().strip(),
            "Reference Standard": self.meta_vars["standard"].get().strip(),
            "Used Device": self.meta_vars["machine"].get().strip(),
            "Material": self.meta_vars["material"].get().strip(),
            "Test Speed": self.meta_vars["speed"].get().strip(),
            "Humidity Max/Min": self.meta_vars["humidity"].get().strip(),
            "Temperature Max/Min": self.meta_vars["temperature"].get().strip(),
            "Speed Control": self.meta_vars["control"].get().strip(),
            "Order No": self.meta_vars["order"].get().strip(),
            "Descripción de la muestra": sample_description,
            "Sample Description": sample_description,
            "Fecha de Recepción": received_date,
            "Fecha Recepción": received_date,
            "Fecha de Ensayo": test_date,
            "Fecha Ensayo": test_date,
        }
        try:
            meta.update(updates)
            # Copias por probeta para que el bloque institucional DATOS DE LA MUESTRA
            # pueda llenar descripción/fechas aunque no se cargue OT PDF.
            if sample_description and getattr(self.dataset, "curves", None):
                for curve in getattr(self.dataset, "curves", []) or []:
                    specimen_id = str(getattr(curve, "specimen_id", "") or "")
                    if specimen_id:
                        meta[f"description_{specimen_id}"] = sample_description
                    try:
                        raw_df = getattr(curve, "raw_df", None)
                        if raw_df is not None:
                            raw_df.attrs["description"] = sample_description
                    except Exception:
                        pass
        except Exception:
            pass

    def restore_metadata_from_dataset(self) -> None:
        if self.dataset is None:
            show_warning("Sin datos", "Importe un CSV antes de restaurar datos del ensayo.")
            return
        self._load_meta_from_dataset()
        self.status_var.set("Datos del ensayo restaurados desde el CSV/meta disponible.")

    def apply_metadata_to_all_curves(self) -> None:
        if self.dataset is None or not getattr(self.dataset, "curves", None):
            show_warning("Sin datos", "Importe un CSV antes de aplicar metadatos.")
            return
        if not messagebox.askyesno("Aplicar datos del ensayo", "¿Aplicar los datos del ensayo actuales a todas las probetas del archivo?", parent=self):
            return
        self._save_metadata_from_ui()
        meta = dict(getattr(self.dataset, "meta", {}) or {})
        for curve in getattr(self.dataset, "curves", []) or []:
            try:
                curve_meta = getattr(curve, "meta", None)
                if curve_meta is None:
                    curve.meta = {}
                    curve_meta = curve.meta
                curve_meta.update(meta)
            except Exception:
                pass
        self.status_var.set("Datos del ensayo aplicados a todas las probetas.")

    def _apply_meta_lock_state(self) -> None:
        state = "normal" if self.unlock_meta_var.get() else "disabled"
        for entry in getattr(self, "meta_entries", []):
            try:
                entry.configure(state=state)
            except Exception:
                pass

    def _apply_geometry_lock_state(self) -> None:
        unlocked = bool(self.unlock_geometry_var.get())
        entry_state = "normal" if unlocked else "disabled"
        combo_state = "readonly" if unlocked else "disabled"
        for widget in getattr(self, "geometry_widgets", []):
            try:
                if isinstance(widget, ttk.Combobox):
                    widget.configure(state=combo_state)
                else:
                    widget.configure(state=entry_state)
            except Exception:
                pass
        for pair in getattr(self, "rectangular_rows", []) + getattr(self, "circular_rows", []) + getattr(self, "irregular_rows", []):
            for widget in pair:
                try:
                    if isinstance(widget, ttk.Entry):
                        widget.configure(state=entry_state)
                except Exception:
                    pass

    def _load_geometry_to_ui(self, geometry: Any) -> None:
        if geometry is None:
            return
        self._geometry_ui_loading = True
        try:
            shape = normalize_shape(getattr(geometry, "shape", None))
            self.geometry_var.set(GEOMETRY_LABEL_BY_VALUE.get(shape, "Rectangular"))
            self.thickness_var.set(_fmt(getattr(geometry, "side1_mm", None), 4).replace("No disponible", ""))
            self.width_var.set(_fmt(getattr(geometry, "side2_mm", None), 4).replace("No disponible", ""))
            self.diameter_var.set(_fmt(getattr(geometry, "diameter_mm", None), 4).replace("No disponible", ""))
            self.area_var.set(_fmt(getattr(geometry, "area_mm2_manual", None), 4).replace("No disponible", ""))
            self.gauge_var.set(_fmt(getattr(geometry, "gauge_length_mm", None), 4).replace("No disponible", ""))
            self._refresh_geometry_fields()
        finally:
            self._geometry_ui_loading = False

    def _on_geometry_changed(self) -> None:
        self._refresh_geometry_fields()
        self._mark_comment_default_available("La geometría cambió.")
        self._schedule_geometry_update_from_ui()

    def _on_method_changed(self) -> None:
        if getattr(self, "_method_ui_loading", False):
            return
        self._save_method_config_for_current()
        self._refresh_method_parameter_state()
        self._mark_comment_default_available("El método de análisis cambió.")
        self.recalculate()

    def _current_active_method_value(self) -> str:
        """Devuelve el método activo interno aunque la UI muestre etiquetas en español."""
        return METHOD_LABEL_ALIASES.get(self.method_var.get(), METHOD_AUTO)

    def _refresh_method_parameter_state(self) -> None:
        active_method = self._current_active_method_value()
        drop_entry = getattr(self, "upper_yield_drop_entry", None)
        offset_entry = getattr(self, "offset_percent_entry", None)
        if drop_entry is None or offset_entry is None:
            return

        if active_method == METHOD_UPPER_YIELD:
            drop_entry.configure(state="normal")
            offset_entry.configure(state="disabled")
            self.status_var.set("Modo Tipo B/C: se identificará σY y σM según ISO 527.")
        elif active_method == METHOD_RP_OFFSET:
            drop_entry.configure(state="disabled")
            offset_entry.configure(state="normal")
            self.status_var.set("Modo Tipo A/D: se usarán los puntos característicos ISO 527.")
        else:
            drop_entry.configure(state="normal")
            offset_entry.configure(state="normal")
            self.status_var.set("Modo Automático ISO 527: se clasifica la curva como A, B, C o D.")

    def restore_automatic_method(self) -> None:
        self.method_var.set("Automático ISO 527")
        self.upper_yield_drop_var.set("1.0")
        self.offset_percent_var.set("100")
        self.modulus_e1_var.set("0.05")
        self.modulus_e2_var.set("0.25")
        self.break_drop_percent_var.set("10")
        self._refresh_method_parameter_state()
        self._mark_comment_default_available("Se restauró el flujo automático.")
        self.recalculate()

    def _method_config_key(self, curve: Any = None) -> str:
        return self._curve_comment_key(curve if curve is not None else self.current_curve)

    def _snapshot_method_config_from_ui(self) -> dict[str, str]:
        return {
            "method_label": str(self.method_var.get() or "Automático ISO 527"),
            "upper_yield_drop": str(self.upper_yield_drop_var.get() or "1.0"),
            "offset_percent": str(self.offset_percent_var.get() or "100"),
            "modulus_e1_pct": str(self.modulus_e1_var.get() or "0.05"),
            "modulus_e2_pct": str(self.modulus_e2_var.get() or "0.25"),
            "break_drop_percent": str(self.break_drop_percent_var.get() or "10"),
        }

    def _save_method_config_for_current(self) -> None:
        if getattr(self, "_method_ui_loading", False):
            return
        try:
            if bool(self.apply_method_all_var.get()):
                config = self._snapshot_method_config_from_ui()
                for curve in getattr(self.dataset, "curves", []) or []:
                    key = self._method_config_key(curve)
                    if key:
                        self._analysis_config_by_specimen[key] = dict(config)
                return
            key = self._method_config_key(self.current_curve)
            if key:
                self._analysis_config_by_specimen[key] = self._snapshot_method_config_from_ui()
        except Exception:
            pass

    def _load_method_config_for_curve(self, curve: Any) -> None:
        if bool(getattr(self, "apply_method_all_var", tk.BooleanVar(value=False)).get()):
            return
        key = self._method_config_key(curve)
        config = (getattr(self, "_analysis_config_by_specimen", {}) or {}).get(key)
        if not config:
            config = self._snapshot_method_config_from_ui()
            if key:
                self._analysis_config_by_specimen[key] = dict(config)
        self._method_ui_loading = True
        try:
            self.method_var.set(str(config.get("method_label") or "Automático"))
            self.upper_yield_drop_var.set(str(config.get("upper_yield_drop") or "1.0"))
            self.offset_percent_var.set(str(config.get("offset_percent") or "100"))
            self.modulus_e1_var.set(str(config.get("modulus_e1_pct") or "0.05"))
            self.modulus_e2_var.set(str(config.get("modulus_e2_pct") or "0.25"))
            self.break_drop_percent_var.set(str(config.get("break_drop_percent") or "10"))
        finally:
            self._method_ui_loading = False
        self._refresh_method_parameter_state()

    def _config_for_curve(self, curve: Any = None) -> TensileAnalysisConfig:
        curve = curve if curve is not None else self.current_curve
        if curve is self.current_curve or bool(getattr(self, "apply_method_all_var", tk.BooleanVar(value=False)).get()):
            return self._current_config()
        config = (getattr(self, "_analysis_config_by_specimen", {}) or {}).get(self._method_config_key(curve)) or {}
        method_label = str(config.get("method_label") or self.method_var.get() or "Automático ISO 527")
        active = METHOD_LABEL_ALIASES.get(method_label, METHOD_AUTO)
        cfg = TensileAnalysisConfig(
            active_method=METHOD_AUTO,
            upper_yield_drop_mpa=_safe_float(config.get("upper_yield_drop")) or 1.0,
            offset_percent=_safe_float(config.get("offset_percent")) or 100.0,
            allow_manual_override=True,
        )
        cfg.active_method = active
        cfg.plastic_yield_drop_percent = _safe_float(config.get("upper_yield_drop")) or 1.0
        cfg.plastic_modulus_e1_pct = _safe_float(config.get("modulus_e1_pct")) or 0.05
        cfg.plastic_modulus_e2_pct = _safe_float(config.get("modulus_e2_pct")) or 0.25
        cfg.plastic_break_drop_percent = _safe_float(config.get("break_drop_percent")) or 10.0
        return cfg

    def _on_apply_method_all_changed(self) -> None:
        self._save_method_config_for_current()
        if bool(self.apply_method_all_var.get()):
            try:
                config = self._snapshot_method_config_from_ui()
                for curve in getattr(self.dataset, "curves", []) or []:
                    key = self._method_config_key(curve)
                    if key:
                        self._analysis_config_by_specimen[key] = dict(config)
                self._analysis_result_cache = {}
                self._effective_result_cache = {}
            except Exception:
                pass
            self.status_var.set("Configuración de método aplicada a todas las probetas.")
        elif self.current_curve is not None:
            self._load_method_config_for_curve(self.current_curve)
            self.status_var.set("Configuración de método independiente por probeta.")
        if self.current_curve is not None:
            self.recalculate()

    def _refresh_geometry_fields(self) -> None:
        shape = GEOMETRY_MAP.get(self.geometry_var.get(), SHAPE_RECTANGULAR)
        for pair in self.rectangular_rows + self.circular_rows + self.irregular_rows:
            for widget in pair:
                widget.grid_remove()
        if shape == SHAPE_RECTANGULAR:
            rows = self.rectangular_rows
        elif shape == SHAPE_CIRCULAR:
            rows = self.circular_rows
        else:
            rows = self.irregular_rows
        for label, entry in rows:
            label.grid()
            entry.grid()

        self._update_geometry_area_label()

    def _update_geometry_area_label(self) -> None:
        try:
            shape = GEOMETRY_MAP.get(self.geometry_var.get(), SHAPE_RECTANGULAR)
            area = None
            if shape == SHAPE_RECTANGULAR:
                t = _safe_float(self.thickness_var.get())
                w = _safe_float(self.width_var.get())
                if t is not None and w is not None:
                    area = t * w
            elif shape == SHAPE_CIRCULAR:
                d = _safe_float(self.diameter_var.get())
                if d is not None:
                    area = math.pi * d * d / 4.0
            else:
                area = _safe_float(self.area_var.get())
            if area is None:
                self.geometry_area_label_var.set("Área calculada: —")
            else:
                self.geometry_area_label_var.set(f"Área calculada: {area:.4f} mm²")
        except Exception:
            try:
                self.geometry_area_label_var.set("Área calculada: —")
            except Exception:
                pass

    def _current_config(self) -> TensileAnalysisConfig:
        active_method = self._current_active_method_value()
        cfg = TensileAnalysisConfig(
            active_method=METHOD_AUTO,
            upper_yield_drop_mpa=_safe_float(self.upper_yield_drop_var.get()) or 1.0,
            offset_percent=_safe_float(self.offset_percent_var.get()) or 100.0,
            allow_manual_override=True,
        )
        cfg.active_method = active_method
        cfg.plastic_yield_drop_percent = _safe_float(self.upper_yield_drop_var.get()) or 1.0
        cfg.plastic_modulus_e1_pct = _safe_float(self.modulus_e1_var.get()) or 0.05
        cfg.plastic_modulus_e2_pct = _safe_float(self.modulus_e2_var.get()) or 0.25
        cfg.plastic_break_drop_percent = _safe_float(self.break_drop_percent_var.get()) or 10.0
        return cfg

    def _geometry_snapshot(self, geometry: Any) -> Any:
        if geometry is None:
            return None
        try:
            return geometry.copy()
        except Exception:
            return {
                "shape": getattr(geometry, "shape", None),
                "side1_mm": getattr(geometry, "side1_mm", None),
                "side2_mm": getattr(geometry, "side2_mm", None),
                "diameter_mm": getattr(geometry, "diameter_mm", None),
                "area_mm2_manual": getattr(geometry, "area_mm2_manual", None),
                "gauge_length_mm": getattr(geometry, "gauge_length_mm", None),
            }

    def _remember_original_geometry(self, curve: Any) -> None:
        try:
            key = self._curve_comment_key(curve)
            if key and key not in self._original_geometry_by_specimen:
                self._original_geometry_by_specimen[key] = self._geometry_snapshot(getattr(curve, "geometry", None))
        except Exception:
            pass

    def _restore_geometry_snapshot_to_curve(self, curve: Any, snapshot: Any) -> None:
        geometry = getattr(curve, "geometry", None)
        if geometry is None or snapshot is None:
            return
        source = snapshot
        if isinstance(snapshot, dict):
            values = snapshot
        else:
            values = {
                "shape": getattr(source, "shape", None),
                "side1_mm": getattr(source, "side1_mm", None),
                "side2_mm": getattr(source, "side2_mm", None),
                "diameter_mm": getattr(source, "diameter_mm", None),
                "area_mm2_manual": getattr(source, "area_mm2_manual", None),
                "gauge_length_mm": getattr(source, "gauge_length_mm", None),
            }
        if hasattr(geometry, "set_values"):
            geometry.set_values(
                shape=values.get("shape"),
                side1_mm=values.get("side1_mm"),
                side2_mm=values.get("side2_mm"),
                diameter_mm=values.get("diameter_mm"),
                area_mm2_manual=values.get("area_mm2_manual"),
                gauge_length_mm=values.get("gauge_length_mm"),
            )
        else:
            for attr, value in values.items():
                try:
                    setattr(geometry, attr, value)
                except Exception:
                    pass

    def reset_geometry_values(self) -> None:
        if not self.current_curve:
            show_warning("Sin datos", "Importe un CSV y seleccione una probeta antes de restablecer geometría.")
            return
        key = self._curve_comment_key(self.current_curve)
        snapshot = self._original_geometry_by_specimen.get(key)
        if snapshot is None:
            show_warning("Sin valores iniciales", "No se encontraron valores iniciales de geometría para esta probeta.")
            return
        try:
            self._restore_geometry_snapshot_to_curve(self.current_curve, snapshot)
            self._load_geometry_to_ui(getattr(self.current_curve, "geometry", None))
            self._mark_comment_default_available("Se restableció la geometría.")
            self.recalculate()
            self.status_var.set("Geometría restablecida a los valores iniciales.")
        except Exception as exc:
            show_error("Error al restablecer geometría", exc)

    def _schedule_geometry_update_from_ui(self) -> None:
        if getattr(self, "_geometry_ui_loading", False):
            return
        self._refresh_geometry_fields()
        if not self.current_curve:
            return
        try:
            if self._geometry_update_after_id is not None:
                self.after_cancel(self._geometry_update_after_id)
        except Exception:
            pass
        self._geometry_update_after_id = self.after(350, self._run_scheduled_geometry_update)

    def _run_scheduled_geometry_update(self) -> None:
        self._geometry_update_after_id = None
        if not self.current_curve:
            return
        try:
            self._apply_geometry_to_curve(self.current_curve)
            try:
                self._effective_result_cache = {}
            except Exception:
                pass
            self._mark_comment_default_available("La geometría aplicada cambió los datos de análisis.")
            self.recalculate()
        except Exception as exc:
            self.status_var.set(f"No se pudo actualizar geometría: {exc}")

    def _apply_geometry_to_curve(self, curve: Any) -> None:
        geometry = getattr(curve, "geometry", None)
        if geometry is None:
            return
        shape = GEOMETRY_MAP.get(self.geometry_var.get(), SHAPE_RECTANGULAR)
        side1 = _safe_float(self.thickness_var.get())
        side2 = _safe_float(self.width_var.get())
        diameter = _safe_float(self.diameter_var.get())
        area = _safe_float(self.area_var.get())
        gauge = _safe_float(self.gauge_var.get())
        if hasattr(geometry, "set_values"):
            geometry.set_values(
                shape=shape,
                side1_mm=side1,
                side2_mm=side2,
                diameter_mm=diameter,
                area_mm2_manual=area,
                gauge_length_mm=gauge,
            )
        else:
            geometry.shape = shape
            geometry.side1_mm = side1
            geometry.side2_mm = side2
            geometry.diameter_mm = diameter
            geometry.area_mm2_manual = area
            geometry.gauge_length_mm = gauge

    def apply_geometry_from_ui(self) -> None:
        if not self.current_curve:
            show_warning("Sin datos", "Importe un CSV y seleccione una probeta antes de aplicar geometría.")
            return
        try:
            if self.apply_geometry_all_var.get() and self.dataset:
                if not messagebox.askyesno("Aplicar geometría", "¿Aplicar esta geometría a todas las probetas del archivo?", parent=self):
                    return
                for curve in self.dataset.curves:
                    self._apply_geometry_to_curve(curve)
            else:
                self._apply_geometry_to_curve(self.current_curve)
            try:
                self._effective_result_cache = {}
            except Exception:
                pass
            self._mark_comment_default_available("La geometría aplicada cambió los datos de análisis.")
            self.recalculate()
        except Exception as exc:
            show_error("Error al aplicar geometría", exc)

    def recalculate(self) -> None:
        if not self.current_curve:
            self.current_result = None
            self.analysis_message_var.set("Curva insuficiente para análisis.")
            self._update_export_button_state()
            return
        try:
            self._save_method_config_for_current()
            self._refresh_method_parameter_state()
            self._apply_geometry_to_curve(self.current_curve)
            config = self._config_for_curve(self.current_curve)
            try:
                result = self._analysis_result_for_curve_cached(self.current_curve, config, force=True)
            except Exception:
                result = analyze_curve(self.current_curve, getattr(self.current_curve, "geometry", None), config)
            self.current_result = result
            try:
                for _name in ("_curve_df_cache", "_curve_xy_cache"):
                    getattr(self, _name).clear()
            except Exception:
                pass
            effective_result = self._effective_result(result)
            self.current_detection = dict(effective_result.method_detection or {})
            self._update_result_panel(effective_result)
            self._update_comment(effective_result)
            self._draw_graph(effective_result, preserve_view=True)
            self._refresh_summary_table()
            self.status_var.set("Análisis actualizado.")
        except Exception as exc:
            self.current_result = None
            self.analysis_message_var.set("Curva insuficiente para análisis o parámetros no válidos.")
            self._update_export_button_state()
            show_error("Error al recalcular", exc)
            self.status_var.set("No se pudo recalcular la curva.")

