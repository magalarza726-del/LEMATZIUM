from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import copy
import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from matplotlib.figure import Figure

from shared.tk_ui_standard import (
    TEXT_EXPORT_WORD,
    TEXT_RECALCULATE,
    SUPPORTED_FILETYPES,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
)
from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from lematzium_traccion_plasticos.plastic_plotting import draw_plastic_tensile_curve as draw_unified_tensile_curve
from shared.tensile_unified.summary import build_unified_summary_rows
from shared.tensile_unified.manual_points import MODE_TO_POINT_KEY, nearest_curve_index

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_traccion_plasticos.iso527_analysis import analyze_plastic_curve as analyze_curve, get_plastic_default_comment as get_default_comment, plastic_comment
from lematzium_traccion_plasticos.reports.exporter import export_unified_report
from lematzium_traccion_plasticos.ui.export_dialog import ReportExportDialog
from lematzium_traccion_plasticos.ui.presentation import (
    GEOMETRY_LABEL_BY_VALUE,
    GEOMETRY_MAP,
    MANUAL_DRAG_LABELS,
    META_FIELDS,
    METHOD_LABEL_ALIASES,
    METHOD_LABEL_BY_VALUE,
    display_confidence as _display_confidence,
    display_method as _display_method,
    display_reason as _display_reason,
    fmt as _fmt,
    result_value_label as _result_value_label,
    safe_float as _safe_float,
)


class ExportFlowMixin:
    def _has_valid_export_data(self) -> bool:
        result = self.current_result
        if self.current_curve is None or result is None:
            return False
        selected = getattr(result, "selected_result", None)
        if selected is None or not bool(getattr(selected, "is_available", False)):
            return False
        return getattr(selected, "value_mpa", None) is not None or getattr(selected, "max_stress_mpa", None) is not None

    def _update_export_button_state(self) -> None:
        state = "normal" if self._has_valid_export_data() else "disabled"
        for name in ("export_word_button", "export_word_top_button", "export_png_button", "export_png_button_h", "export_png_top_button"):
            button = getattr(self, name, None)
            if button is not None:
                try:
                    button.configure(state=state)
                except Exception:
                    pass

    def export_graph_png(self) -> None:
        if not self.current_curve or self.current_result is None:
            show_warning("Sin gráfica", "Importe un CSV y calcule una probeta antes de exportar PNG.")
            return
        method_label = self._active_method_label().replace(" ", "_").replace("/", "_")
        specimen_id = str(getattr(self.current_curve, "specimen_id", "probeta") or "probeta")
        if self._has_simultaneous_graphs():
            initial_name = f"Grafica_traccion_simultanea_{method_label}.png"
        else:
            initial_name = f"Grafica_traccion_{specimen_id}_{method_label}.png"
        output = filedialog.asksaveasfilename(
            title="Guardar gráfica PNG",
            defaultextension=".png",
            filetypes=[("Imagen PNG", "*.png")],
            initialfile=initial_name,
        )
        if not output:
            return
        try:
            current_xlim = self.ax.get_xlim()
            current_ylim = self.ax.get_ylim()
            self.figure.savefig(output, dpi=220, bbox_inches="tight", pad_inches=0.16)
            try:
                self.ax.set_xlim(current_xlim)
                self.ax.set_ylim(current_ylim)
                self.canvas.draw_idle()
            except Exception:
                pass
            show_info("PNG exportado", f"Gráfica guardada correctamente:\n{output}")
            show_info("PNG exportado", f"Gráfica guardada correctamente:\n{output}")
            self.status_var.set(f"PNG exportado: {Path(output).name}")
        except Exception as exc:
            show_error("Error al exportar PNG", exc)

    def _save_graph_png(self) -> Optional[Path]:
        if not self.current_curve:
            return None
        path = Path(self._tempdir.name) / f"{self.current_curve.specimen_id}_grafica.png"
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), graph_mode="report", draw_idle=False, preserve_view=False)
        self.figure.savefig(path, dpi=180, bbox_inches="tight", pad_inches=0.15)
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), graph_mode="screen", draw_idle=True, preserve_view=True)
        self.current_graph_path = path
        return path

    def _export_result_for_curve(self, curve: Any) -> Any:
        """Devuelve el análisis a usar en reportes por grupos.

        Si la probeta exportada es la probeta activa, conserva los overrides
        manuales vigentes mediante ``_effective_result``. Para las demás probetas
        se calcula con la misma configuración activa de la UI, sin tocar los
        cálculos históricos ni los módulos originales.
        """
        config = self._config_for_curve(curve) if hasattr(self, "_config_for_curve") else self._current_config()
        result = analyze_curve(curve, getattr(curve, "geometry", None), config)
        try:
            if self.current_curve is curve:
                return self._effective_result(result)
        except Exception:
            pass
        return result

    def _export_comment_for_curve(self, curve: Any, analysis_result: Any) -> str:
        try:
            if self.current_curve is curve:
                current_comment = self.comment_text.get("1.0", tk.END).strip()
                if current_comment:
                    return current_comment
        except Exception:
            pass

        selected = getattr(analysis_result, "selected_result", None)
        method = getattr(selected, "method", METHOD_AUTO)
        geometry = getattr(curve, "geometry", None)
        shape = normalize_shape(getattr(geometry, "shape", None))
        config = self._config_for_curve(curve) if hasattr(self, "_config_for_curve") else self._current_config()
        context = {
            "offset_percent": f"{float(config.offset_percent):g}",
            "upper_yield_drop_mpa": f"{float(config.upper_yield_drop_mpa):g}",
            "procedure_code": self.meta_vars.get("procedure", tk.StringVar(value="")).get(),
            "standard_label": self.meta_vars.get("standard", tk.StringVar(value="")).get(),
            "machine_label": self.meta_vars.get("machine", tk.StringVar(value="MUE 600 kN")).get() or "MUE 600 kN",
        }
        return get_default_comment(shape, method, context)

    def export_word_simple(self) -> None:
        """Exportador simple heredado de la primera versión del módulo Tracción plásticos.

        Se conserva como wrapper para compatibilidad interna. La acción visible
        ``Exportar Word`` abre ahora el diálogo completo por grupos.
        """
        if not self.current_curve or not self.current_result:
            show_warning("Sin resultados", "Importe un CSV, seleccione una probeta y recalcule antes de exportar.")
            return
        output = filedialog.asksaveasfilename(
            title="Guardar reporte Word",
            defaultextension=".docx",
            filetypes=[("Documento Word", "*.docx")],
            initialfile=f"Reporte_traccion_{self.current_curve.specimen_id}.docx",
        )
        if not output:
            return
        try:
            graph_path = self._save_graph_png()
            comment = self.comment_text.get("1.0", tk.END).strip()
            export_unified_report(
                output,
                specimen_id=self.current_curve.specimen_id,
                geometry=getattr(self.current_curve, "geometry", None),
                result=self._effective_result(self.current_result).selected_result,
                detection=self.current_detection,
                comment=comment,
                graph_path=graph_path,
                source_path=getattr(self.dataset, "source_path", "") if self.dataset else "",
            )
            show_info("Reporte exportado", f"Reporte guardado correctamente:\n{output}")
            self.status_var.set(f"Reporte exportado: {Path(output).name}")
        except Exception as exc:
            show_error("Error al exportar Word", exc)

    def export_word(self) -> None:
        if not self.dataset or not getattr(self.dataset, "curves", None):
            show_warning("Sin datos", "Importe un CSV antes de exportar informes.")
            return
        if not self.current_result:
            self.recalculate()
        try:
            # Antes de abrir el diálogo se guardan los metadatos visibles en la UI
            # para que el bloque institucional DATOS DE LA MUESTRA tome
            # descripción, fecha de recepción y fecha de ensayo por defecto.
            try:
                self._save_metadata_from_ui()
            except Exception:
                pass
            # Validación previa conservadora: no bloquea el flujo, pero advierte
            # si existen probetas que podrían requerir revisión antes del Word.
            warning_rows = []
            if self.dataset and getattr(self.dataset, "curves", None):
                rows = build_unified_summary_rows(self.dataset.curves, self._summary_result_for_curve, active_method_label=self._active_method_label())
                warning_rows = [row for row in rows if row.get("status") not in {"OK", "-"}]
            if warning_rows:
                names = ", ".join(row.get("specimen", "-") for row in warning_rows[:8])
                if len(warning_rows) > 8:
                    names += ", ..."
                if not messagebox.askyesno(
                    "Validación antes de exportar",
                    f"Hay probetas con advertencias o revisión manual: {names}.\n\n¿Desea continuar con la exportación?",
                    parent=self,
                ):
                    return
            default_order = self.meta_vars.get("order", tk.StringVar(value="")).get().strip()
            default_comment = ""
            try:
                default_comment = self.comment_text.get("1.0", tk.END).strip()
            except Exception:
                default_comment = ""
            ReportExportDialog(
                self,
                dataset=self.dataset,
                analysis_config=self._current_config(),
                default_order_number=default_order,
                default_comment=default_comment,
                result_provider=self._export_result_for_curve,
                comment_provider=self._export_comment_for_curve,
                graph_config=self._graph_y_selection_config(),
            )
        except Exception as exc:
            show_error("Error al abrir exportación Word", exc)

