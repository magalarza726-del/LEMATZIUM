from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import math
import copy

import numpy as np
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

from matplotlib.figure import Figure
from matplotlib.ticker import AutoMinorLocator, FuncFormatter, MultipleLocator

from shared.runtime_theme import load_runtime_theme
from shared.tk_ui_standard import (
    TEXT_EXPORT_WORD,
    TEXT_RECALCULATE,
    SUPPORTED_FILETYPES,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
)
from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
)
from lematzium_traccion_plasticos.plastic_plotting import (
    draw_plastic_tensile_curve as draw_unified_tensile_curve,
    get_plastic_plot_series,
)
from shared.tensile_unified.summary import build_unified_summary_rows
from shared.tensile_unified.manual_points import MODE_TO_POINT_KEY, nearest_curve_index

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_traccion_plasticos.iso527_analysis import analyze_plastic_curve as analyze_curve, get_plastic_default_comment as get_default_comment, plastic_comment
from lematzium_traccion_plasticos.reports.exporter import export_unified_report
from lematzium_traccion_plasticos.ui.export_dialog import ReportExportDialog
from lematzium_traccion_plasticos.ui.presentation import (
    GEOMETRY_LABEL_BY_VALUE,
    GEOMETRY_MAP,
    MANUAL_DRAG_LABELS,
    META_FIELDS,
    METHOD_LABEL_ALIASES,
    METHOD_LABEL_BY_VALUE,
    display_confidence as _display_confidence,
    display_method as _display_method,
    display_reason as _display_reason,
    fmt as _fmt,
    result_value_label as _result_value_label,
    safe_float as _safe_float,
)


PLASTIC_MODE_TO_POINT_KEY = {
    **MODE_TO_POINT_KEY,
    "yield": "upper_yield_index",
    "max": "max_index",
    "break": "plastic_break_index",
    "sigma1": "plastic_sigma1_index",
    "sigma2": "plastic_sigma2_index",
    "sigmax": "plastic_sigmax_index",
    "mod_e1": "plastic_mod_e1_index",
    "mod_e2": "plastic_mod_e2_index",
}


def _plastic_key_for_mode(mode: str) -> str | None:
    return PLASTIC_MODE_TO_POINT_KEY.get(str(mode or "").strip())


class GraphFlowMixin:
    def _axis_spacing_value(self, axis: str, *, initialize: bool = True) -> Optional[float]:
        """Devuelve el espaciamiento principal configurado para un eje.

        xspace/yspace sustituyen a wspace/hspace. wspace/hspace solo separan
        subplots y en este módulo, que usa una sola gráfica, no cambian la
        escala visible. Estos valores controlan MultipleLocator en X/Y.
        """
        attr = "_xspace" if axis == "x" else "_yspace"
        value = _safe_float(getattr(self, attr, None))
        if value is not None and value > 0:
            return float(value)
        if not initialize:
            return None
        try:
            if axis == "x":
                upper = _safe_float(self.x_max_var.get())
                if upper is None or upper <= 0:
                    upper, _unused = self._best_auto_limits()
                value = self._nice_axis_step(float(upper), target_intervals=8)
            else:
                upper = _safe_float(self.y_max_var.get())
                if upper is None or upper <= 0:
                    _unused, upper = self._best_auto_limits()
                value = self._nice_axis_step(float(upper), target_intervals=8)
        except Exception:
            value = 1.0
        value = max(float(value or 1.0), 1e-9)
        setattr(self, attr, value)
        return value

    def _round_up_to_spacing(self, value: float, spacing: Optional[float]) -> float:
        try:
            value_f = float(value)
            spacing_f = float(spacing) if spacing is not None else 0.0
        except Exception:
            return float(value or 0.0)
        if spacing_f <= 0:
            return value_f
        return math.ceil(value_f / spacing_f) * spacing_f

    def _axis_formatter_for_step(self, step: Optional[float], *, axis: str) -> FuncFormatter:
        """Formateador que aumenta decimales cuando el zoom requiere más detalle."""
        def _decimals(value: float) -> int:
            try:
                step_abs = abs(float(value))
            except Exception:
                step_abs = 1.0
            if step_abs <= 0 or not math.isfinite(step_abs):
                return 4
            return max(0, min(7, int(math.ceil(-math.log10(step_abs))) + 1))

        decimals = _decimals(step)
        if axis == "x":
            decimals = max(decimals, 3)
        else:
            decimals = max(decimals, 2)

        def _fmt(value: float, _pos: Any = None) -> str:
            try:
                number = float(value)
            except Exception:
                return ""
            text = f"{number:.{decimals}f}"
            if "." in text:
                text = text.rstrip("0").rstrip(".")
            return text if text not in {"-0", ""} else "0"

        return FuncFormatter(_fmt)

    def _axis_cursor_decimals(self, axis: str) -> int:
        try:
            if axis == "x":
                lo, hi = self.ax.get_xlim()
            else:
                lo, hi = self.ax.get_ylim()
            span = abs(float(hi) - float(lo))
        except Exception:
            span = 1.0
        if span <= 0.001:
            return 7
        if span <= 0.01:
            return 6
        if span <= 0.10:
            return 5
        if span <= 1.0:
            return 4
        return 4 if axis == "x" else 3

    def _selected_graph_y_mode(self) -> str:
        text = str(getattr(getattr(self, "graph_type_var", None), "get", lambda: "")() or "").strip().lower()
        return "load" if ("carga" in text or "load" in text or "fuerza" in text) else "stress"

    def _selected_stress_unit(self) -> str:
        text = str(getattr(getattr(self, "stress_unit_var", None), "get", lambda: "MPa")() or "MPa").strip().lower().replace(" ", "")
        if text in {"pa", "pascal", "pascales"}:
            return "Pa"
        if text in {"kpa", "kilopascal", "kilopascales", "kilopascals"}:
            return "kPa"
        return "MPa"

    def _selected_load_unit(self) -> str:
        text = str(getattr(getattr(self, "load_unit_var", None), "get", lambda: "kN")() or "kN").strip().lower().replace(" ", "")
        return "N" if text in {"n", "newton", "newtons"} else "kN"

    def _graph_y_unit(self) -> str:
        return self._selected_load_unit() if self._selected_graph_y_mode() == "load" else self._selected_stress_unit()

    def _graph_y_axis_label(self) -> str:
        return f"Carga ({self._selected_load_unit()})" if self._selected_graph_y_mode() == "load" else f"Esfuerzo ({self._selected_stress_unit()})"

    def _graph_y_selection_config(self) -> dict[str, Any]:
        return {
            "y_mode": self._selected_graph_y_mode(),
            "stress_unit": self._selected_stress_unit(),
            "load_unit": self._selected_load_unit(),
            "y_axis_label": self._graph_y_axis_label(),
        }

    def _refresh_graph_unit_state(self) -> None:
        try:
            mode = self._selected_graph_y_mode()
            if hasattr(self, "stress_unit_combo"):
                self.stress_unit_combo.configure(state="readonly" if mode == "stress" else "disabled")
            if hasattr(self, "load_unit_combo"):
                self.load_unit_combo.configure(state="readonly" if mode == "load" else "disabled")
        except Exception:
            pass

    def _on_graph_axis_changed(self) -> None:
        try:
            self._refresh_graph_unit_state()
            self._graph_has_valid_view = False
            self._xspace = None
            self._yspace = None
            self._plot_limits_update_in_progress = True
            self.x_min_var.set("0")
            self.y_min_var.set("0")
            self.x_max_var.set("")
            self.y_max_var.set("")
        except Exception:
            pass
        finally:
            try:
                self._plot_limits_update_in_progress = False
            except Exception:
                pass
        if self.current_result is not None:
            try:
                self._draw_graph(self._effective_result(self.current_result), graph_mode="screen", draw_idle=True, preserve_view=False)
            except Exception:
                pass
        else:
            try:
                self.ax.set_ylabel(self._graph_y_axis_label())
                self.canvas.draw_idle()
            except Exception:
                pass
        try:
            self.status_var.set(f"Gráfica actualizada: {self._graph_y_axis_label()} vs Alargamiento (mm).")
        except Exception:
            pass

    def _format_graph_xy(self, x: float, y: float) -> str:
        try:
            xd = self._axis_cursor_decimals("x")
            yd = self._axis_cursor_decimals("y")
            return f"{float(x):.{xd}f} mm | {float(y):.{yd}f} {self._graph_y_unit()}"
        except Exception:
            return f"{x:.4f} mm | {y:.4f} {self._graph_y_unit()}"

    def _apply_axis_spacing(self, *, dynamic_to_view: bool = False) -> None:
        try:
            try:
                x0, x1 = self.ax.get_xlim()
                y0, y1 = self.ax.get_ylim()
                x_span = max(abs(float(x1) - float(x0)), 1e-12)
                y_span = max(abs(float(y1) - float(y0)), 1e-12)
                x_min_spacing = max(x_span / 500.0, 1e-12)
                y_min_spacing = max(y_span / 500.0, 1e-12)
            except Exception:
                x_span = y_span = 1.0
                x_min_spacing = y_min_spacing = 1e-9

            if dynamic_to_view:
                # Durante zoom/pan la grilla se recalcula con el rango visible,
                # de modo que al acercarse aparezcan divisiones más finas y
                # etiquetas con más decimales sin modificar los datos originales.
                xspace = max(self._nice_axis_step(x_span, target_intervals=8), x_min_spacing)
                yspace = max(self._nice_axis_step(y_span, target_intervals=8), y_min_spacing)
            else:
                xspace = self._axis_spacing_value("x", initialize=False)
                yspace = self._axis_spacing_value("y", initialize=False)
                if xspace is not None and xspace > 0:
                    xspace = max(float(xspace), x_min_spacing)
                    self._xspace = xspace
                if yspace is not None and yspace > 0:
                    yspace = max(float(yspace), y_min_spacing)
                    self._yspace = yspace

            if xspace is not None and xspace > 0:
                self.ax.xaxis.set_major_locator(MultipleLocator(float(xspace)))
                self.ax.xaxis.set_major_formatter(self._axis_formatter_for_step(float(xspace), axis="x"))
            if yspace is not None and yspace > 0:
                self.ax.yaxis.set_major_locator(MultipleLocator(float(yspace)))
                self.ax.yaxis.set_major_formatter(self._axis_formatter_for_step(float(yspace), axis="y"))
            try:
                self.ax.xaxis.set_minor_locator(AutoMinorLocator(5))
                self.ax.yaxis.set_minor_locator(AutoMinorLocator(5))
            except Exception:
                pass
            self.ax.format_coord = lambda x, y: f"x={self._format_graph_xy(x, y).replace(' | ', ' | y=')}"
            self.ax.grid(True, which="major", color="#8fa1b5", linestyle="--", linewidth=0.85, alpha=0.96)
            self.ax.grid(True, which="minor", color="#c8d3df", linestyle=":", linewidth=0.60, alpha=0.86)
        except Exception:
            pass

    def _nice_axis_step(self, max_value: float, target_intervals: int = 8) -> float:
        try:
            value = abs(float(max_value))
        except Exception:
            value = 1.0
        value = max(value, 1e-9)
        raw = value / max(int(target_intervals), 1)
        exponent = math.floor(math.log10(raw)) if raw > 0 else 0
        fraction = raw / (10 ** exponent)
        if fraction <= 1.0:
            nice_fraction = 1.0
        elif fraction <= 2.0:
            nice_fraction = 2.0
        elif fraction <= 2.5:
            nice_fraction = 2.5
        elif fraction <= 5.0:
            nice_fraction = 5.0
        else:
            nice_fraction = 10.0
        return nice_fraction * (10 ** exponent)

    def _nice_axis_upper(self, max_value: float, target_intervals: int = 8) -> float:
        try:
            value = max(float(max_value), 1e-9)
        except Exception:
            value = 1.0
        step = self._nice_axis_step(value, target_intervals=target_intervals)
        return math.ceil(value / step) * step

    def _on_r2p_lines_visibility_changed(self) -> None:
        try:
            if self.current_result is not None:
                self._draw_graph(self._effective_result(self.current_result), preserve_view=True)
            else:
                self.canvas.draw_idle()
            state = "visibles" if bool(self.show_r2p_lines_var.get()) else "ocultas"
            self.status_var.set(f"Rectas R2P/σx {state}.")
        except Exception:
            pass

    def _compact_axis_upper(self, max_value: float, *, padding_ratio: float) -> float:
        """Límite superior compacto para autoajuste visual.

        Evita dos extremos: que la curva toque el techo y que el redondeo por
        espaciamiento de grilla la deje demasiado baja. Se redondea con dos
        cifras significativas, por ejemplo 638 -> 640 y 61.8 -> 62.
        """
        try:
            data_max = max(float(max_value), 1e-9)
        except Exception:
            data_max = 1.0
        target = data_max * (1.0 + max(float(padding_ratio), 0.0))
        if target <= 0 or not math.isfinite(target):
            return 1.0
        exponent = math.floor(math.log10(abs(target)))
        unit = 10 ** (exponent - 1)
        unit = max(float(unit), 1e-12)
        upper = math.ceil(target / unit) * unit
        if upper <= data_max:
            upper = data_max + unit
        return float(upper)

    def _reset_graph_scale_for_new_csv(self) -> None:
        """Reinicia escala y grilla al importar un CSV nuevo."""
        self._graph_has_valid_view = False
        self._xspace = None
        self._yspace = None
        try:
            if self._plot_update_after_id is not None:
                self.after_cancel(self._plot_update_after_id)
        except Exception:
            pass
        self._plot_update_after_id = None
        try:
            self._plot_limits_update_in_progress = True
            self.x_min_var.set("0")
            self.y_min_var.set("0")
            self.x_max_var.set("")
            self.y_max_var.set("")
        except Exception:
            pass
        finally:
            self._plot_limits_update_in_progress = False
        try:
            nav_stack = getattr(self.toolbar, "_nav_stack", None)
            if nav_stack is not None and hasattr(nav_stack, "clear"):
                nav_stack.clear()
            if hasattr(self.toolbar, "set_history_buttons"):
                self.toolbar.set_history_buttons()
        except Exception:
            pass

    def _curves_for_auto_limits(self) -> list[Any]:
        curves: list[Any] = []
        try:
            if self.dataset and self._has_simultaneous_graphs():
                for index in self._selected_multigraph_indices():
                    if 0 <= int(index) < len(self.dataset.curves):
                        curves.append(self.dataset.curves[int(index)])
        except Exception:
            curves = []
        if not curves and self.current_curve is not None:
            curves = [self.current_curve]
        return curves

    def _best_auto_limits(self, curves: Optional[list[Any]] = None) -> tuple[float, float]:
        x_max_data, y_max_data = 1.0, 1.0
        try:
            source_curves = curves if curves is not None else self._curves_for_auto_limits()
            for curve in source_curves:
                df = self._curve_plot_dataframe(curve)
                _df_plot, xs, ys, _ylabel, _ymode, _yunit = get_plastic_plot_series(
                    curve,
                    {**self._graph_y_selection_config(), "_precomputed_df": df},
                )
                xs = xs[np.isfinite(xs)]
                ys = ys[np.isfinite(ys)]
                if len(xs):
                    x_max_data = max(x_max_data, float(np.nanmax(xs)))
                if len(ys):
                    y_max_data = max(y_max_data, float(np.nanmax(ys)))
        except Exception:
            x_max_data, y_max_data = max(x_max_data, 1.0), max(y_max_data, 1.0)
        x_max_data = max(float(x_max_data), 1e-6)
        y_max_data = max(float(y_max_data), 1e-6)
        # Margen visual compacto: suficiente para que la curva no toque el techo,
        # pero sin redondear hasta el siguiente bloque grande de la grilla
        # (caso típico: 580 MPa ya no se escala hasta 800 MPa).
        x_upper = self._compact_axis_upper(x_max_data, padding_ratio=0.05)
        y_upper = self._compact_axis_upper(y_max_data, padding_ratio=0.10)
        return x_upper, y_upper

    def _graph_config(self, graph_mode: str) -> dict[str, Any]:
        specimen_id = str(getattr(self.current_curve, "specimen_id", "") or "Muestra")
        auto_curves = None
        if graph_mode == "screen" and self._has_simultaneous_graphs():
            auto_curves = self._curves_for_auto_limits()
        elif self.current_curve is not None:
            auto_curves = [self.current_curve]
        auto_x_max, auto_y_max = self._best_auto_limits(auto_curves)
        xspace = self._axis_spacing_value("x", initialize=True)
        yspace = self._axis_spacing_value("y", initialize=True)
        x_max_manual = _safe_float(self.x_max_var.get())
        y_max_manual = _safe_float(self.y_max_var.get())
        # El límite superior automático ya incluye margen compacto. No se vuelve
        # a redondear con X/Y space porque eso puede inflar la escala y dejar la
        # curva innecesariamente baja. X/Y space solo controla la grilla.
        auto_x_final = float(auto_x_max)
        auto_y_final = float(auto_y_max)
        if self._has_simultaneous_graphs():
            x_max = max(float(x_max_manual), auto_x_final) if x_max_manual is not None and x_max_manual > 0 else auto_x_final
            y_max = max(float(y_max_manual), auto_y_final) if y_max_manual is not None and y_max_manual > 0 else auto_y_final
        else:
            x_max = x_max_manual if x_max_manual is not None and x_max_manual > 0 else auto_x_final
            y_max = y_max_manual if y_max_manual is not None and y_max_manual > 0 else auto_y_final
        try:
            show_r2p_lines = bool(self.show_r2p_lines_var.get())
        except Exception:
            show_r2p_lines = True
        try:
            theme = getattr(self, "_ui_theme", None) or load_runtime_theme()
        except Exception:
            theme = {}
        return {
            "mode": graph_mode,
            "legend_mode": "outside" if graph_mode == "screen" else "report_right",
            "legend_single_label": "",
            "overlay_legend": False,
            "curve_label": specimen_id,
            "axis_mode": "manual",
            "anchor_origin": True,
            "x_min": 0.0,
            "x_max": x_max,
            "y_min": 0.0,
            "y_max": y_max,
            "grid_x": xspace,
            "grid_y": yspace,
            "curve_linewidth": 1.35,
            "show_r2p_lines": show_r2p_lines,
            **self._graph_y_selection_config(),
            "colors": {
                "curve": self._curve_color_for_index(self._active_curve_index()),
                "upper_yield_point": str(theme.get("yield") or "#000000"),
                "max_point": str(theme.get("max") or "#000000"),
                "ab_line": str(theme.get("line") or "#ff0000"),
                "offset_line": str(theme.get("offset") or theme.get("accent") or "#2563eb"),
                "reference_line": str(theme.get("offset") or theme.get("accent_soft") or "#64748b"),
            },
        }

    def _default_curve_color_for_index(self, index: Optional[int]) -> str:
        try:
            theme = getattr(self, "_ui_theme", None) or load_runtime_theme()
        except Exception:
            theme = {}
        # Paleta sincronizada con el tema activo del HUB. Se priorizan los mismos
        # tonos visibles del programa principal y se completan con colores estables
        # para mantener curvas simultáneas claramente diferenciadas.
        candidates = [
            theme.get("curve"),
            theme.get("accent"),
            theme.get("accent_soft"),
            theme.get("yield"),
            theme.get("max"),
            theme.get("line"),
            theme.get("offset"),
            "#16a34a", "#f97316", "#0891b2", "#9333ea", "#dc2626",
        ]
        palette: list[str] = []
        for value in candidates:
            text = str(value or "").strip()
            if text and text not in palette:
                palette.append(text)
        if not palette:
            palette = ["#2563eb"]
        try:
            return palette[int(index or 0) % len(palette)]
        except Exception:
            return str(palette[0])

    def _legend_gap_axes_fraction(self, gap_cm: float = 0.10) -> float:
        """Convierte una separación física en cm a coordenadas del eje X.

        Se usa para dejar 0,1 cm entre el borde de la gráfica y el código de
        probeta sin mover ni reescalar la gráfica.
        """
        try:
            fig_width_in = float(self.figure.get_figwidth())
            bbox = self.ax.get_position()
            axes_width_in = max(float(bbox.width) * fig_width_in, 1e-9)
            return max((float(gap_cm) / 2.54) / axes_width_in, 0.0)
        except Exception:
            return 0.004

    def _curve_color_for_index(self, index: Optional[int]) -> str:
        try:
            colors = getattr(self, "_curve_colors_by_index", None)
            if colors is None:
                colors = {}
                self._curve_colors_by_index = colors
            idx = int(index or 0)
            if idx not in colors:
                colors[idx] = self._default_curve_color_for_index(idx)
            return str(colors[idx])
        except Exception:
            return "#2563eb"

    def _set_curve_color_for_index(self, index: Optional[int], color_hex: str) -> None:
        try:
            if index is None:
                return
            colors = getattr(self, "_curve_colors_by_index", None)
            if colors is None:
                colors = {}
                self._curve_colors_by_index = colors
            colors[int(index)] = str(color_hex)
            if int(index) == (self._active_curve_index() if self._active_curve_index() is not None else -1):
                self._curve_color = str(color_hex)
        except Exception:
            pass

    def change_graph_color(self) -> None:
        current = getattr(self, "_curve_color", "#2563eb")
        try:
            selected = colorchooser.askcolor(color=current, title="Seleccionar color de gráfica", parent=self.winfo_toplevel())
            color_hex = selected[1] if selected else None
        except Exception:
            color_hex = None
        if not color_hex:
            return
        self._set_curve_color_for_index(self._active_curve_index(), color_hex)
        self._curve_color = color_hex
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), preserve_view=True)
        else:
            self.canvas.draw_idle()
        self.status_var.set(f"Color de gráfica actualizado: {color_hex}")

    def _ensure_crosshair_artists(self) -> None:
        vline = getattr(self, "_crosshair_vline", None)
        if vline is None or getattr(vline, "axes", None) is not self.ax or vline not in list(getattr(self.ax, "lines", [])):
            self._crosshair_vline = self.ax.axvline(0.0, color="#64748b", linestyle=":", linewidth=0.8, visible=False, zorder=20)
        hline = getattr(self, "_crosshair_hline", None)
        if hline is None or getattr(hline, "axes", None) is not self.ax or hline not in list(getattr(self.ax, "lines", [])):
            self._crosshair_hline = self.ax.axhline(0.0, color="#64748b", linestyle=":", linewidth=0.8, visible=False, zorder=20)
        text = getattr(self, "_crosshair_text", None)
        if text is None or getattr(text, "axes", None) is not self.ax or text not in list(getattr(self.ax, "texts", [])):
            self._crosshair_text = self.ax.text(
                0.012,
                0.985,
                "",
                transform=self.ax.transAxes,
                ha="left",
                va="top",
                fontsize=9,
                color="#0f172a",
                bbox={"boxstyle": "round,pad=0.22", "facecolor": "#ffffff", "edgecolor": "#cbd5e1", "alpha": 0.92},
                visible=False,
                zorder=21,
            )

    def _set_crosshair_visible(self, visible: bool, *, x: Optional[float] = None, y: Optional[float] = None) -> None:
        self._ensure_crosshair_artists()
        try:
            state = (bool(visible), None if x is None else round(float(x), 7), None if y is None else round(float(y), 7))
            if getattr(self, "_crosshair_last_state", None) == state:
                return
            self._crosshair_last_state = state
            self._crosshair_vline.set_visible(visible)
            self._crosshair_hline.set_visible(visible)
            self._crosshair_text.set_visible(visible)
            if visible and x is not None and y is not None:
                self._crosshair_vline.set_xdata([x, x])
                self._crosshair_hline.set_ydata([y, y])
                self._crosshair_text.set_text("X=" + self._format_graph_xy(float(x), float(y)).replace(" | ", " | Y="))
            self.canvas.draw_idle()
        except Exception:
            pass

    def _geometry_cache_signature(self, curve: Any) -> tuple[Any, ...]:
        geometry = getattr(curve, "geometry", None)
        if geometry is None:
            return ()
        parts: list[Any] = []
        for name in ("shape", "side1_mm", "side2_mm", "thickness_mm", "width_mm", "diameter_mm", "area_mm2_manual", "gauge_length_mm"):
            try:
                value = getattr(geometry, name, None)
                if callable(value):
                    value = value()
            except Exception:
                value = None
            parts.append(value)
        return tuple(parts)

    def _curve_cache_key(self, curve: Optional[Any] = None) -> tuple[Any, ...]:
        curve = curve or self.current_curve
        if curve is None:
            return (None,)
        df_obj = None
        df_len = None
        for attr in ("raw_df", "df", "data", "dataframe"):
            try:
                value = getattr(curve, attr, None)
                if callable(value):
                    value = value()
            except Exception:
                value = None
            if value is not None:
                df_obj = value
                try:
                    df_len = len(value)
                except Exception:
                    df_len = None
                break
        return (id(curve), id(df_obj), df_len, self._geometry_cache_signature(curve))

    def _clear_fast_caches(self) -> None:
        for name in ("_curve_df_cache", "_curve_xy_cache", "_analysis_result_cache", "_effective_result_cache"):
            try:
                getattr(self, name).clear()
            except Exception:
                setattr(self, name, {})

    def _curve_plot_dataframe(self, curve: Optional[Any] = None):
        # Cachea el DataFrame graficable: evita copias y conversiones en cada movimiento de mouse.
        curve = curve or self.current_curve
        if curve is None:
            raise ValueError("No hay curva activa.")
        cache = getattr(self, "_curve_df_cache", None)
        if cache is None:
            cache = {}
            self._curve_df_cache = cache
        key = self._curve_cache_key(curve)
        if key in cache:
            return cache[key]
        from shared.tensile_unified import plotting as _plotting  # import local para evitar acoplamientos al arrancar
        df = _plotting._get_curve_df(curve)
        # En ISO 527 Tipo D algunos CSV legacy traen carga en N aunque la columna
        # se llama load_kN. El analizador corrige raw_df y df; este bloque fuerza
        # la gráfica a usar esa corrección si el DataFrame elegido por el helper
        # legacy todavía quedó inflado.
        try:
            raw_df = getattr(curve, "raw_df", None)
            if raw_df is not None and "stress_MPa" in raw_df and len(raw_df) == len(df):
                raw_max = float(np.nanmax(np.asarray(raw_df["stress_MPa"], dtype=float)))
                df_max = float(np.nanmax(np.asarray(df["stress_MPa"], dtype=float)))
                if np.isfinite(raw_max) and np.isfinite(df_max) and raw_max > 0 and df_max / raw_max > 100.0:
                    df = df.copy()
                    df["stress_MPa"] = np.asarray(raw_df["stress_MPa"], dtype=float)
        except Exception:
            pass
        if len(cache) > 128:
            cache.clear()
        cache[key] = df
        return df

    def _curve_xy_arrays(self, curve: Optional[Any] = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        curve = curve or self.current_curve
        if curve is None:
            return np.asarray([], dtype=float), np.asarray([], dtype=float), np.asarray([], dtype=int)
        cache = getattr(self, "_curve_xy_cache", None)
        if cache is None:
            cache = {}
            self._curve_xy_cache = cache
        key = self._curve_cache_key(curve)
        if key in cache:
            return cache[key]
        df = self._curve_plot_dataframe(curve)
        xs = np.asarray(df["elongation_mm"], dtype=float)
        ys = np.asarray(df["stress_MPa"], dtype=float)
        mask = np.isfinite(xs) & np.isfinite(ys)
        indices = np.flatnonzero(mask).astype(int)
        result = (xs[mask], ys[mask], indices)
        if len(cache) > 128:
            cache.clear()
        cache[key] = result
        return result

    def _nearest_curve_index(self, xdata: float, ydata: Optional[float] = None) -> Optional[int]:
        record = self._nearest_curve_point_record(xdata, ydata)
        idx = self._manual_record_index(record)
        if idx is not None:
            return idx
        if self.current_curve is None:
            return None
        try:
            return nearest_curve_index(self._curve_plot_dataframe(), float(xdata), None if ydata is None else float(ydata))
        except Exception:
            return None

    def _manual_record_index(self, record: Any) -> Optional[int]:
        try:
            if isinstance(record, dict):
                value = record.get("index")
            else:
                value = record
            if value is None:
                return None
            return int(value)
        except Exception:
            return None

    def _manual_record_xy(self, df: Any, record: Any) -> tuple[Optional[float], Optional[float]]:
        try:
            if isinstance(record, dict):
                x = _safe_float(record.get("x"))
                y = _safe_float(record.get("y"))
                if x is not None and y is not None:
                    return x, y
                idx = self._manual_record_index(record)
                return self._row_xy(df, idx) if idx is not None else (None, None)
            idx = self._manual_record_index(record)
            return self._row_xy(df, idx) if idx is not None else (None, None)
        except Exception:
            return None, None

    def _manual_record_signature(self, record: Any) -> tuple[Any, ...]:
        try:
            if isinstance(record, dict):
                idx = self._manual_record_index(record)
                x = _safe_float(record.get("x"))
                y = _safe_float(record.get("y"))
                return (idx, round(float(x), 9) if x is not None else None, round(float(y), 9) if y is not None else None)
            idx = self._manual_record_index(record)
            return (idx, None, None)
        except Exception:
            return (None, None, None)

    def _nearest_curve_point_record(self, xdata: float, ydata: Optional[float] = None) -> Optional[dict[str, float | int]]:
        """Punto manual continuo sobre la curva, interpolado entre datos reales.

        El CSV no se modifica ni se re-muestrea. Para que el arrastre sea más
        sensible, el cursor se proyecta sobre el segmento visible de la curva
        más cercano en coordenadas de pantalla; así el marcador no salta de un
        dato al siguiente cuando hay mucho zoom.
        """
        if self.current_curve is None:
            return None
        try:
            xs, ys, indices = self._curve_xy_arrays(self.current_curve)
            if len(xs) == 0:
                return None
            x_value = float(xdata)
            y_value = float(ydata) if ydata is not None else None
            if len(xs) == 1 or y_value is None:
                idx = int(indices[int(np.nanargmin(np.abs(xs - x_value)))])
                px, py = self._row_xy(self._curve_plot_dataframe(), idx)
                if px is None or py is None:
                    return None
                return {"index": idx, "x": float(px), "y": float(py)}

            # Reducir candidatos a la ventana visible + margen para mantener el
            # arrastre rápido incluso con CSV densos.
            try:
                x0, x1 = self.ax.get_xlim()
                xmin, xmax = sorted((float(x0), float(x1)))
                pad = max((xmax - xmin) * 0.25, 1e-12)
                visible = np.flatnonzero((xs >= xmin - pad) & (xs <= xmax + pad))
            except Exception:
                visible = np.asarray([], dtype=int)
            if len(visible) < 2:
                if len(xs) > 4 and bool(np.all(np.diff(xs) >= -1e-12)):
                    pos = int(np.searchsorted(xs, x_value))
                    lo = max(0, pos - 64)
                    hi = min(len(xs), pos + 65)
                    visible = np.arange(lo, hi, dtype=int)
                else:
                    visible = np.arange(len(xs), dtype=int)

            if len(visible) < 2:
                i = int(visible[0]) if len(visible) else int(np.nanargmin(np.abs(xs - x_value)))
                return {"index": int(indices[i]), "x": float(xs[i]), "y": float(ys[i])}

            # Proyección al segmento más cercano en píxeles. Esto respeta la
            # escala actual y evita saltos al trabajar con mucho acercamiento.
            pts = np.column_stack([xs[visible], ys[visible]])
            pixel_pts = self.ax.transData.transform(pts)
            cursor = self.ax.transData.transform([[x_value, y_value]])[0]
            p0 = pixel_pts[:-1]
            p1 = pixel_pts[1:]
            seg = p1 - p0
            denom = np.einsum("ij,ij->i", seg, seg)
            valid = np.isfinite(denom) & (denom > 1e-12)
            if not np.any(valid):
                distances = np.sum((pixel_pts - cursor) ** 2, axis=1)
                i = int(visible[int(np.nanargmin(distances))])
                return {"index": int(indices[i]), "x": float(xs[i]), "y": float(ys[i])}
            rel = np.zeros(len(seg), dtype=float)
            rel[valid] = np.clip(np.einsum("ij,ij->i", cursor - p0, seg) [valid] / denom[valid], 0.0, 1.0)
            proj = p0 + rel[:, None] * seg
            d2 = np.sum((proj - cursor) ** 2, axis=1)
            d2[~valid] = np.inf
            best_local = int(np.nanargmin(d2))
            left = int(visible[best_local])
            right = int(visible[min(best_local + 1, len(visible) - 1)])
            t = float(rel[best_local])
            px = float(xs[left] + t * (xs[right] - xs[left]))
            py = float(ys[left] + t * (ys[right] - ys[left]))
            # Se conserva el índice inferior para trazabilidad, pero los valores
            # x/y son continuos sobre el segmento real de curva.
            return {"index": int(indices[left]), "x": px, "y": py}
        except Exception:
            return None

    def _manual_points(self) -> dict[str, int]:
        key = self._curve_comment_key()
        if key not in self._manual_points_by_specimen:
            self._manual_points_by_specimen[key] = {}
        return self._manual_points_by_specimen[key]

    def _set_manual_point_from_event(self, mode: str, event: Any, *, redraw: bool = True) -> None:
        record = self._nearest_curve_point_record(float(event.xdata), float(event.ydata) if event.ydata is not None else None)
        if record is None:
            return
        points = self._manual_points()
        key = _plastic_key_for_mode(mode)
        if key is None:
            return
        points[key] = record
        if redraw and self.current_result is not None:
            effective = self._effective_result(self.current_result)
            self._update_result_panel(effective)
            self._draw_graph(effective, preserve_view=True)

    def clear_active_manual_point(self) -> None:
        mode = str(self.drag_mode_var.get() or "none")
        key = _plastic_key_for_mode(mode)
        if key is None:
            show_warning("Sin punto seleccionado", "Seleccione primero el tipo de punto manual que desea limpiar.")
            return
        self._manual_points().pop(key, None)
        if self.current_result is not None:
            effective = self._effective_result(self.current_result)
            self._update_result_panel(effective)
            self._draw_graph(effective, preserve_view=True)
        self.status_var.set("Punto manual limpiado.")

    def clear_all_manual_points(self) -> None:
        self._manual_points_by_specimen[self._curve_comment_key()] = {}
        if self.current_result is not None:
            effective = self._effective_result(self.current_result)
            self._update_result_panel(effective)
            self._draw_graph(effective, preserve_view=True)
        self.status_var.set("Puntos manuales limpiados para la probeta activa.")

    def _row_xy(self, df: Any, idx: int) -> tuple[Optional[float], Optional[float]]:
        try:
            if idx < 0 or idx >= len(df):
                return None, None
            row = df.iloc[int(idx)]
            return _safe_float(row.get("elongation_mm")), _safe_float(row.get("stress_MPa"))
        except Exception:
            return None, None

    def _manual_rp_from_line(self, df: Any, a_record: Any, b_record: Any, offset_mm: float, rp_manual_record: Any = None) -> tuple[Optional[int], Optional[float], Optional[float], Optional[float], Optional[float], dict[str, Any]]:
        ax_mm, ay = self._manual_record_xy(df, a_record)
        bx_mm, by = self._manual_record_xy(df, b_record)
        line_points: dict[str, Any] = {}
        a_idx = self._manual_record_index(a_record)
        b_idx = self._manual_record_index(b_record)
        if ax_mm is not None and ay is not None:
            line_points["a"] = {"index": a_idx, "x": float(ax_mm), "y": float(ay)}
        if bx_mm is not None and by is not None:
            line_points["b"] = {"index": b_idx, "x": float(bx_mm), "y": float(by)}
        if ax_mm is None or ay is None or bx_mm is None or by is None or abs(bx_mm - ax_mm) < 1e-12:
            return None, None, None, None, None, line_points
        slope = (by - ay) / (bx_mm - ax_mm)
        intercept = ay - slope * ax_mm
        if rp_manual_record is not None:
            rx, ry = self._manual_record_xy(df, rp_manual_record)
            return self._manual_record_index(rp_manual_record), rx, ry, slope, intercept, line_points
        try:
            xs = df["elongation_mm"].astype(float).to_numpy()
            ys = df["stress_MPa"].astype(float).to_numpy()
            offset_line = slope * (xs - float(offset_mm)) + intercept
            diff = ys - offset_line
            idx_values = [idx for idx in (a_idx, b_idx) if idx is not None]
            start = min(len(diff) - 2, max(int(max(idx_values)) if idx_values else 1, 1))
            hit = None
            for i in range(start, len(diff) - 1):
                if not (math.isfinite(diff[i]) and math.isfinite(diff[i + 1])):
                    continue
                # La intersección Rp se toma cuando la curva pasa de estar por
                # encima de la recta offset a quedar por debajo de ella.
                if diff[i] >= 0 >= diff[i + 1]:
                    hit = i
                    break
            if hit is None:
                finite_indices = [i for i in range(start, len(diff)) if math.isfinite(diff[i])]
                if not finite_indices:
                    finite_indices = [i for i, value in enumerate(diff) if math.isfinite(value)]
                if not finite_indices:
                    return None, None, None, slope, intercept, line_points
                hit = min(finite_indices, key=lambda i: abs(float(diff[i])))
                rx, ry = xs[hit], ys[hit]
                return int(hit), float(rx), float(ry), slope, intercept, line_points
            i = int(hit)
            x1, x2 = xs[i], xs[i + 1]
            y1, y2 = ys[i], ys[i + 1]
            d1, d2 = diff[i], diff[i + 1]
            if d2 != d1:
                t = -d1 / (d2 - d1)
                rx = x1 + t * (x2 - x1)
                ry = y1 + t * (y2 - y1)
            else:
                rx, ry = x1, y1
            return i, float(rx), float(ry), slope, intercept, line_points
        except Exception:
            return None, None, None, slope, intercept, line_points

    def _analysis_cache_key(self, curve: Any, config: Optional[Any] = None) -> tuple[Any, ...]:
        cfg = config or self._current_config()
        return (
            self._curve_cache_key(curve),
            getattr(cfg, "active_method", None),
            float(getattr(cfg, "upper_yield_drop_mpa", 1.0) or 1.0),
            float(getattr(cfg, "offset_percent", 0.2) or 0.2),
            bool(getattr(cfg, "allow_manual_override", True)),
        )

    def _analysis_result_for_curve_cached(self, curve: Any, config: Optional[Any] = None, *, force: bool = False) -> Any:
        cache = getattr(self, "_analysis_result_cache", None)
        if cache is None:
            cache = {}
            self._analysis_result_cache = cache
        cfg = config or self._current_config()
        key = self._analysis_cache_key(curve, cfg)
        if not force and key in cache:
            return cache[key]
        result = analyze_curve(curve, getattr(curve, "geometry", None), cfg)
        # El análisis ISO 527 recalcula stress_MPa según unidad real y geometría.
        # Invalidar cachés de gráfica para que no se dibujen esfuerzos anteriores.
        try:
            for _name in ("_curve_df_cache", "_curve_xy_cache"):
                getattr(self, _name).clear()
        except Exception:
            pass
        if len(cache) > 256:
            cache.clear()
        cache[key] = result
        return result

    def _manual_points_signature(self) -> tuple[tuple[str, tuple[Any, ...]], ...]:
        try:
            points = self._manual_points_by_specimen.get(self._curve_comment_key(), {})
            return tuple(sorted((str(k), self._manual_record_signature(v)) for k, v in points.items()))
        except Exception:
            return ()

    def _effective_result(self, result: Any) -> Any:
        if result is None or self.current_curve is None:
            return result
        try:
            points = dict(self._manual_points_by_specimen.get(self._curve_comment_key(), {}))
            label_revision = int(getattr(self, "_point_label_revision", 0) or 0)
            cache = getattr(self, "_effective_result_cache", None)
            if cache is None:
                cache = {}
                self._effective_result_cache = cache
            cache_key = (
                id(result),
                self._analysis_cache_key(self.current_curve, self._current_config()),
                self._manual_points_signature(),
                label_revision,
            )
            if cache_key in cache:
                return cache[cache_key]

            effective = copy.deepcopy(result)
            df = self._curve_plot_dataframe()
            geometry = getattr(self.current_curve, "geometry", None)
            gauge = _safe_float(getattr(geometry, "gauge_length_mm", None)) or _safe_float(self.gauge_var.get()) or 50.0

            diag = getattr(effective, "diagnostics", {}) or {}
            scalar = dict(diag.get("plastic_scalar") or {})
            plastic_points = [dict(p) for p in (diag.get("plastic_points") or [])]

            try:
                label_map = self._point_label_map()
            except Exception:
                label_map = {}

            def label_for(mode: str) -> str:
                value = str(label_map.get(mode) or "").strip()
                if value:
                    return value
                return {"yield": "σY", "max": "σM", "break": "σB", "sigma1": "σ1", "sigma2": "σ2", "sigmax": "σx", "mod_e1": "ε1", "mod_e2": "ε2"}.get(mode, mode)

            def record_for_mode(mode: str) -> Any:
                key = _plastic_key_for_mode(mode)
                if key and key in points:
                    return points.get(key)
                return None

            def xy_for_mode(mode: str) -> tuple[Optional[int], Optional[float], Optional[float], Optional[float]]:
                record = record_for_mode(mode)
                if record is None:
                    return None, None, None, None
                x, y = self._manual_record_xy(df, record)
                idx = self._manual_record_index(record)
                strain = (float(x) / float(gauge) * 100.0) if x is not None and gauge else None
                return idx, x, y, strain

            def update_point(mode: str, *, stress_key: str | None = None, strain_key: str | None = None) -> None:
                idx, x, y, strain = xy_for_mode(mode)
                if x is None or y is None:
                    return
                found = False
                for pnt in plastic_points:
                    if str(pnt.get("mode") or "") == mode:
                        pnt.update({"index": idx, "x_mm": float(x), "stress_mpa": float(y), "source": "manual", "label": label_for(mode)})
                        if strain is not None:
                            pnt["strain_pct"] = float(strain)
                        found = True
                if not found:
                    payload = {"label": label_for(mode), "mode": mode, "index": idx, "x_mm": float(x), "stress_mpa": float(y), "source": "manual"}
                    if strain is not None:
                        payload["strain_pct"] = float(strain)
                    plastic_points.append(payload)
                if stress_key:
                    scalar[stress_key] = float(y)
                if strain_key and strain is not None:
                    scalar[strain_key] = float(strain)

            update_point("yield", stress_key="yield_stress_mpa", strain_key="yield_strain_pct")
            update_point("max", stress_key="max_stress_mpa", strain_key="max_strain_pct")
            update_point("break", stress_key="break_stress_mpa", strain_key="break_strain_pct")
            update_point("sigma1", stress_key="sigma1_stress_mpa", strain_key="sigma1_strain_pct")
            update_point("sigma2", stress_key="sigma2_stress_mpa", strain_key="sigma2_strain_pct")
            update_point("sigmax", stress_key="sigmax_stress_mpa", strain_key="sigmax_strain_pct")
            update_point("mod_e1")
            update_point("mod_e2")

            # Aplicar etiquetas editables incluso cuando no hay arrastre manual.
            for pnt in plastic_points:
                mode = str(pnt.get("mode") or "")
                if mode:
                    pnt["label"] = label_for(mode)

            # Recalcular módulo entre ε1 y ε2 si esos puntos fueron arrastrados.
            try:
                mod_points = {str(p.get("mode")): p for p in plastic_points}
                p1 = mod_points.get("mod_e1")
                p2 = mod_points.get("mod_e2")
                if p1 and p2:
                    e1 = _safe_float(p1.get("strain_pct"))
                    e2 = _safe_float(p2.get("strain_pct"))
                    s1 = _safe_float(p1.get("stress_mpa"))
                    s2 = _safe_float(p2.get("stress_mpa"))
                    if None not in (e1, e2, s1, s2) and abs(float(e2) - float(e1)) > 1e-12:
                        modulus_mpa = (float(s2) - float(s1)) / ((float(e2) - float(e1)) / 100.0)
                        scalar["modulus_mpa"] = modulus_mpa
                        scalar["modulus_gpa"] = modulus_mpa / 1000.0
            except Exception:
                pass

            if "max_stress_mpa" in scalar:
                if str(scalar.get("applied_type") or "").upper() == "D":
                    scalar["sigma_m_or_b_stress_mpa"] = scalar.get("max_stress_mpa")
                    scalar["sigma_m_or_b_strain_pct"] = scalar.get("max_strain_pct")
                if str(scalar.get("primary_mode") or "") == "max":
                    scalar["primary_stress_mpa"] = scalar.get("max_stress_mpa")

            primary_mode = str(scalar.get("primary_mode") or "")
            if primary_mode == "yield" and "yield_stress_mpa" in scalar:
                scalar["primary_stress_mpa"] = scalar.get("yield_stress_mpa")
            elif primary_mode == "sigmax" and "sigmax_stress_mpa" in scalar:
                scalar["primary_stress_mpa"] = scalar.get("sigmax_stress_mpa")

            diag["plastic_points"] = plastic_points
            diag["plastic_scalar"] = scalar
            diag["label_override"] = bool(label_map)
            if points:
                diag["manual_override"] = True
            for pnt in plastic_points:
                if str(pnt.get("mode") or "") == "max":
                    diag["max_index"] = pnt.get("index")
                    diag["max_elongation_mm"] = pnt.get("x_mm")
                    break
            effective.diagnostics = diag

            def apply_to_method(method_result: Any) -> None:
                try:
                    method_result.max_stress_mpa = scalar.get("max_stress_mpa", method_result.max_stress_mpa)
                    method_result.elastic_modulus_gpa = scalar.get("modulus_gpa", method_result.elastic_modulus_gpa)
                    method_result.elongation_after_break_pct = scalar.get("break_strain_pct") or scalar.get("sigma_m_or_b_strain_pct") or method_result.elongation_after_break_pct
                    method_result.diagnostics["plastic_points"] = plastic_points
                    method_result.diagnostics["plastic_scalar"] = scalar
                    if points:
                        method_result.diagnostics["manual_override"] = True
                except Exception:
                    pass

            for method_result in (effective.upper_yield_result, effective.rp_offset_result, effective.selected_result):
                apply_to_method(method_result)

            selected = effective.selected_result
            try:
                selected.value_mpa = scalar.get("primary_stress_mpa", selected.value_mpa)
                selected.max_stress_mpa = scalar.get("max_stress_mpa", selected.max_stress_mpa)
                for pnt in plastic_points:
                    if str(pnt.get("mode") or "") == primary_mode:
                        selected.diagnostics.update({"point_index": pnt.get("index"), "point_x_mm": pnt.get("x_mm"), "point_source": "manual" if points else "auto"})
                        break
            except Exception:
                pass

            try:
                if "yield_stress_mpa" in scalar:
                    effective.upper_yield_result.value_mpa = scalar.get("yield_stress_mpa")
                if "max_stress_mpa" in scalar:
                    effective.rp_offset_result.value_mpa = scalar.get("max_stress_mpa")
            except Exception:
                pass

            if len(cache) > 128:
                cache.clear()
            cache[cache_key] = effective
            return effective
        except Exception:
            return result

    def _active_method_for_graph(self) -> str:
        # Wrapper explícito para conectar la UI con draw_unified_tensile_curve(...).
        # En Automático se envía "auto" para que el graficador use selected_result.
        return self._current_active_method_value()

    def _curve_df_for(self, curve: Any):
        return self._curve_plot_dataframe(curve)

    def _draw_simultaneous_graph(
        self,
        unified_result: Any,
        *,
        graph_mode: str = "screen",
        draw_idle: bool = True,
        preserve_view: bool = True,
    ) -> None:
        if self.current_curve is None or not self.dataset:
            return
        old_xlim = self.ax.get_xlim()
        old_ylim = self.ax.get_ylim()
        # En multigráfica se prioriza mostrar todas las curvas completas cada vez
        # que cambia la selección. El zoom manual sigue disponible después del
        # redibujado, pero no debe recortar curvas recién activadas.
        should_restore_view = False
        try:
            selected_indices = self._selected_multigraph_indices()
            active_index = self._active_curve_index()
            if active_index is not None and active_index not in selected_indices:
                selected_indices.insert(0, active_index)
            selected_indices = [i for i in selected_indices if 0 <= int(i) < len(self.dataset.curves)]
            if not selected_indices:
                selected_indices = [active_index or 0]

            base_config = self._graph_config(graph_mode)
            active_label = str(getattr(self.current_curve, "specimen_id", "") or "Curva")
            base_config.update({
                "curve_label": active_label,
                "legend_single_label": "",
                "apply_legend": False,
                "overlay_legend": False,
                "_precomputed_df": self._curve_plot_dataframe(self.current_curve),
                "colors": {**(base_config.get("colors") or {}), "curve": self._curve_color_for_index(active_index)},
            })
            draw_unified_tensile_curve(
                self.ax,
                self.current_curve,
                unified_result,
                active_method=self._active_method_for_graph(),
                graph_config=base_config,
            )
            # Superpone curvas adicionales con sus propios puntos YP/MÁX y rectas Rp.
            labels_seen = {active_label}
            for index in selected_indices:
                curve = self.dataset.curves[index]
                if curve is self.current_curve:
                    continue
                try:
                    label = str(getattr(curve, "specimen_id", f"Probeta {index + 1}"))
                    labels_seen.add(label)
                    result = self._analysis_result_for_curve_cached(curve, self._current_config())
                    extra_config = dict(base_config)
                    extra_config.update({
                        "clear_axes": False,
                        "configure_axes": False,
                        "apply_legend": False,
                        "overlay_legend": False,
                        "draw_labels": False,
                        "curve_label": label,
                        "legend_single_label": "",
                        "curve_linewidth": 1.10,
                        "use_axes_color_cycle": False,
                        "_precomputed_df": self._curve_plot_dataframe(curve),
                        "colors": {**(base_config.get("colors") or {}), "curve": self._curve_color_for_index(index)},
                    })
                    draw_unified_tensile_curve(
                        self.ax,
                        curve,
                        result,
                        active_method=self._active_method_for_graph(),
                        graph_config=extra_config,
                    )
                except Exception:
                    continue
            if should_restore_view:
                self.ax.set_xlim(old_xlim)
                self.ax.set_ylim(old_ylim)
            self._apply_axis_spacing(dynamic_to_view=bool(should_restore_view and graph_mode == "screen"))
            try:
                legend = self.ax.get_legend()
                if legend is not None:
                    legend.remove()
                handles, labels = self.ax.get_legend_handles_labels()
                selected_code_labels = []
                for idx in selected_indices:
                    try:
                        selected_code_labels.append(str(getattr(self.dataset.curves[int(idx)], "specimen_id", f"Probeta {int(idx) + 1}")))
                    except Exception:
                        pass
                legend_handles = []
                legend_labels = []
                for handle, label in zip(handles, labels):
                    text = str(label or "")
                    if not text or text.startswith("_"):
                        continue
                    if text in selected_code_labels:
                        legend_handles.append(handle)
                        legend_labels.append(text)
                if legend_handles:
                    self.figure.subplots_adjust(left=0.10, right=0.86, bottom=0.13, top=0.90)
                    gap = self._legend_gap_axes_fraction(0.10)
                    self.ax.legend(
                        legend_handles,
                        legend_labels,
                        loc="upper left",
                        bbox_to_anchor=(1.0 + gap, 1.0),
                        borderaxespad=0.0,
                        handletextpad=0.35,
                        fontsize=8,
                        frameon=True,
                        framealpha=0.92,
                    )
            except Exception:
                pass
            if graph_mode == "screen":
                self._sync_plot_limit_fields_from_axes()
                self._ensure_crosshair_artists()
                self._set_crosshair_visible(False)
                try:
                    self.canvas.get_tk_widget().configure(cursor="tcross")
                except Exception:
                    pass
            self._graph_has_valid_view = True
            if graph_mode == "screen" and not should_restore_view and not getattr(self, "_suspend_history_reset", False):
                self._reset_toolbar_history_to_current()
        except Exception as exc:
            self.ax.clear()
            self._graph_has_valid_view = False
            self.ax.text(0.5, 0.5, f"No se pudo graficar simultáneamente:\n{exc}", ha="center", va="center", transform=self.ax.transAxes)
        if draw_idle:
            self.canvas.draw_idle()

    def _draw_graph(
        self,
        unified_result: Any,
        *,
        graph_mode: str = "screen",
        draw_idle: bool = True,
        preserve_view: bool = True,
    ) -> None:
        curve = self.current_curve
        if curve is None:
            self.ax.clear()
            self._graph_has_valid_view = False
            if draw_idle:
                self.canvas.draw_idle()
            return
        if graph_mode == "screen" and self._has_simultaneous_graphs():
            self._draw_simultaneous_graph(unified_result, graph_mode=graph_mode, draw_idle=draw_idle, preserve_view=preserve_view)
            return
        old_xlim = self.ax.get_xlim()
        old_ylim = self.ax.get_ylim()
        should_restore_view = bool(
            preserve_view
            and self._graph_has_valid_view
            and graph_mode == "screen"
            and old_xlim != (0.0, 1.0)
            and old_ylim != (0.0, 1.0)
        )
        try:
            graph_config = self._graph_config(graph_mode)
            graph_config["_precomputed_df"] = self._curve_plot_dataframe(curve)
            draw_unified_tensile_curve(
                self.ax,
                curve,
                unified_result,
                active_method=self._active_method_for_graph(),
                graph_config=graph_config,
            )
            if should_restore_view:
                self.ax.set_xlim(old_xlim)
                self.ax.set_ylim(old_ylim)
            self._apply_axis_spacing(dynamic_to_view=bool(should_restore_view and graph_mode == "screen"))
            if graph_mode == "screen":
                self._sync_plot_limit_fields_from_axes()
                self._ensure_crosshair_artists()
                self._set_crosshair_visible(False)
                try:
                    self.canvas.get_tk_widget().configure(cursor="tcross")
                except Exception:
                    pass
            self._graph_has_valid_view = True
            if graph_mode == "screen" and not should_restore_view and not getattr(self, "_suspend_history_reset", False):
                self._reset_toolbar_history_to_current()
        except Exception as exc:
            self.ax.clear()
            self._graph_has_valid_view = False
            self.ax.text(0.5, 0.5, f"No se pudo graficar:\n{exc}", ha="center", va="center", transform=self.ax.transAxes)
        if draw_idle:
            self.canvas.draw_idle()

    def _on_mouse_move(self, event: Any) -> None:
        try:
            if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
                self.cursor_var.set("Punto actual: —")
                self._set_crosshair_visible(False)
                return

            # La cruz de precisión debe seguir el mouse de forma continua.
            # Antes se ajustaba al punto de datos más cercano; al hacer zoom fuerte
            # eso producía saltos grandes y dificultaba leer valores pequeños.
            x_cursor = float(event.xdata)
            y_cursor = float(event.ydata)
            self.cursor_var.set("Punto actual: " + self._format_graph_xy(x_cursor, y_cursor))
            self._set_crosshair_visible(True, x=x_cursor, y=y_cursor)

            # El arrastre manual sigue usando el punto real más cercano de la curva
            # para no inventar datos ni alterar el cálculo sobre el CSV original.
            if self._is_dragging_manual_point:
                self._set_manual_point_from_event(self._drag_mode_active, event, redraw=True)
        except Exception:
            self.cursor_var.set("Punto actual: —")
            self._set_crosshair_visible(False)

    def _toolbar_nav_stack_len(self) -> int:
        try:
            return len(getattr(self.toolbar, "_nav_stack", []))
        except Exception:
            return 0

    def _ensure_toolbar_history_base(self) -> None:
        try:
            if self._toolbar_nav_stack_len() <= 0:
                self.toolbar.push_current()
        except Exception:
            pass

    def _push_toolbar_view(self) -> None:
        try:
            self.toolbar.push_current()
        except Exception:
            pass

    def _reset_toolbar_history_to_current(self) -> None:
        try:
            nav_stack = getattr(self.toolbar, "_nav_stack", None)
            if nav_stack is not None and hasattr(nav_stack, "clear"):
                nav_stack.clear()
            self.toolbar.push_current()
            if hasattr(self.toolbar, "set_history_buttons"):
                self.toolbar.set_history_buttons()
        except Exception:
            pass

    def _after_toolbar_view_navigation(self) -> None:
        """Sincroniza grilla/campos tras usar Atrás/Adelante, pan o zoom de la barra."""
        try:
            self._apply_axis_spacing(dynamic_to_view=True)
            self._sync_plot_limit_fields_from_axes()
            self._graph_has_valid_view = True
            self.canvas.draw_idle()
        except Exception:
            pass

    def _on_toolbar_view_release(self, event: Any) -> None:
        try:
            if getattr(event, "inaxes", None) is not self.ax:
                return
            if self._is_dragging_manual_point:
                return
            if self._toolbar_is_active():
                self.after_idle(self._after_toolbar_view_navigation)
        except Exception:
            pass

    def _toolbar_is_active(self) -> bool:
        try:
            mode = getattr(self.toolbar, "mode", "")
            return bool(str(mode).strip())
        except Exception:
            return False

    def _effective_method_for_manual_drag(self) -> str:
        active = self._current_active_method_value()
        if active == METHOD_AUTO and self.current_result is not None:
            selected = getattr(self._effective_result(self.current_result), "selected_result", None)
            return str(getattr(selected, "method", active) or active)
        return active

    def _manual_drag_candidates(self) -> list[tuple[str, Optional[float], Optional[float]]]:
        if self.current_result is None or self.current_curve is None:
            return []
        result = self._effective_result(self.current_result)
        method = self._effective_method_for_manual_drag()
        candidates: list[tuple[str, Optional[float], Optional[float]]] = []
        df = None
        try:
            df = self._curve_plot_dataframe()
        except Exception:
            df = None

        def add_max(source_result: Any) -> None:
            try:
                diagnostics = getattr(result, "diagnostics", {}) or {}
                mx = _safe_float(diagnostics.get("max_elongation_mm"))
                my = _safe_float(getattr(source_result, "max_stress_mpa", None))
                if (mx is None or my is None) and df is not None:
                    stresses = df["stress_MPa"].astype(float).to_numpy()
                    if len(stresses):
                        idx = int(stresses.argmax())
                        mx, my = self._row_xy(df, idx)
                candidates.append(("max", mx, my))
            except Exception:
                pass

        plastic_points = []
        try:
            plastic_points = (getattr(result, "diagnostics", {}) or {}).get("plastic_points") or []
        except Exception:
            plastic_points = []
        if plastic_points:
            for p in plastic_points:
                mode = str(p.get("mode") or "")
                if _plastic_key_for_mode(mode) is not None:
                    candidates.append((mode, _safe_float(p.get("x_mm")), _safe_float(p.get("stress_mpa"))))
        elif method == METHOD_UPPER_YIELD:
            uy = getattr(result, "upper_yield_result", None)
            diag = getattr(uy, "diagnostics", {}) or {}
            candidates.append(("yield", _safe_float(diag.get("point_x_mm")), _safe_float(getattr(uy, "value_mpa", None))))
            add_max(uy)
        elif method == METHOD_RP_OFFSET:
            rp = getattr(result, "rp_offset_result", None)
            diag = getattr(rp, "diagnostics", {}) or {}
            indices = diag.get("elastic_modulus_line_indices") or {}
            if isinstance(indices, dict) and df is not None:
                ax_mm, ay = self._row_xy(df, int(indices.get("a"))) if indices.get("a") is not None else (None, None)
                bx_mm, by = self._row_xy(df, int(indices.get("b"))) if indices.get("b") is not None else (None, None)
                candidates.append(("rp_a", ax_mm, ay))
                candidates.append(("rp_b", bx_mm, by))
            add_max(rp)
        return [(mode, x, y) for mode, x, y in candidates if x is not None and y is not None]

    def _detect_manual_drag_target(self, event: Any) -> Optional[str]:
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return None
        try:
            cursor = np.asarray([float(event.x), float(event.y)], dtype=float)
            best_mode: Optional[str] = None
            best_distance = float("inf")
            for mode, px, py in self._manual_drag_candidates():
                marker_px = self.ax.transData.transform([[float(px), float(py)]])[0]
                distance = float(np.linalg.norm(marker_px - cursor))
                if distance < best_distance:
                    best_distance = distance
                    best_mode = mode
            # Tolerancia en pixeles, no en unidades de eje. Es más fácil tomar
            # el marcador con zoom fuerte y evita que la sensibilidad cambie al
            # modificar la escala.
            return best_mode if best_distance <= 30.0 else None
        except Exception:
            return None

    def _on_drag_control_changed(self) -> None:
        if str(self.drag_mode_var.get() or "auto") == "auto":
            try:
                self._manual_points_by_specimen[self._curve_comment_key()] = {}
                if self.current_curve is not None:
                    self.recalculate()
                elif self.current_result is not None:
                    effective = self._effective_result(self.current_result)
                    self._update_result_panel(effective)
                    self._draw_graph(effective, preserve_view=True)
                self.status_var.set("Modo automático restaurado.")
            except Exception:
                if self.current_result is not None:
                    self.recalculate()
        else:
            self.status_var.set("Modo manual: seleccione un marcador editable de la gráfica para arrastrarlo.")

    def _on_graph_button_press(self, event: Any) -> None:
        if getattr(event, "button", None) != 1 or event.inaxes != self.ax or self._toolbar_is_active():
            return
        if str(self.drag_mode_var.get() or "auto") != "manual":
            return
        mode = self._detect_manual_drag_target(event)
        if mode is None:
            self.status_var.set("Seleccione directamente un marcador editable para arrastrarlo.")
            return
        self._is_dragging_manual_point = True
        self._drag_mode_active = mode
        self._set_manual_point_from_event(mode, event, redraw=True)

    def _on_graph_button_release(self, event: Any) -> None:
        if not self._is_dragging_manual_point:
            return
        mode = self._drag_mode_active
        self._is_dragging_manual_point = False
        self._drag_mode_active = "none"
        if event is not None and event.inaxes == self.ax and event.xdata is not None:
            self._set_manual_point_from_event(mode, event, redraw=True)
        self.status_var.set("Punto manual actualizado.")

    def _scroll_zoom_factor(self) -> float:
        return float(getattr(self, "_zoom_base_default", 1.20) or 1.20)

    def _on_scroll_zoom(self, event: Any) -> None:
        """Zoom con rueda como en los módulos originales.

        Mantiene el punto bajo el cursor como centro relativo y no depende del
        modo zoom de la barra Matplotlib.
        """
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return
        try:
            base = self._scroll_zoom_factor()
            self._ensure_toolbar_history_base()
            scale = 1.0 / base if getattr(event, "button", None) == "up" else base
            x_left, x_right = self.ax.get_xlim()
            y_bottom, y_top = self.ax.get_ylim()
            x_range = (x_right - x_left) * scale
            y_range = (y_top - y_bottom) * scale
            rel_x = (x_right - event.xdata) / (x_right - x_left) if x_right != x_left else 0.5
            rel_y = (y_top - event.ydata) / (y_top - y_bottom) if y_top != y_bottom else 0.5
            new_x_left = event.xdata - x_range * (1 - rel_x)
            new_x_right = event.xdata + x_range * rel_x
            new_y_bottom = event.ydata - y_range * (1 - rel_y)
            new_y_top = event.ydata + y_range * rel_y
            self.ax.set_xlim(new_x_left, new_x_right)
            self.ax.set_ylim(new_y_bottom, new_y_top)
            self._apply_axis_spacing(dynamic_to_view=True)
            self._sync_plot_limit_fields_from_axes()
            self._graph_has_valid_view = True
            self._push_toolbar_view()
            self.canvas.draw_idle()
        except Exception as exc:
            self.status_var.set(f"No se pudo aplicar zoom scroll: {exc}")

    def _sync_plot_limit_fields_from_axes(self) -> None:
        try:
            self._plot_limits_update_in_progress = True
            x0, x1 = self.ax.get_xlim()
            y0, y1 = self.ax.get_ylim()
            self.x_min_var.set("0")
            self.y_min_var.set("0")
            self.x_max_var.set(f"{float(x1):.6g}")
            self.y_max_var.set(f"{float(y1):.6g}")
        except Exception:
            pass
        finally:
            self._plot_limits_update_in_progress = False

    def _schedule_plot_configuration(self) -> None:
        if getattr(self, "_plot_limits_update_in_progress", False):
            return
        self.x_min_var.set("0")
        self.y_min_var.set("0")
        if self.current_result is None:
            return
        try:
            if self._plot_update_after_id is not None:
                self.after_cancel(self._plot_update_after_id)
        except Exception:
            pass
        self._plot_update_after_id = self.after(180, self._run_scheduled_plot_configuration)

    def _run_scheduled_plot_configuration(self) -> None:
        self._plot_update_after_id = None
        self._apply_plot_configuration()

    def auto_adjust_graph(self) -> None:
        try:
            self._ensure_toolbar_history_base()
            self.plot_mode_var.set("manual")
            self.x_min_var.set("0")
            self.y_min_var.set("0")
            auto_x_max, auto_y_max = self._best_auto_limits()
            xspace = self._axis_spacing_value("x", initialize=False)
            yspace = self._axis_spacing_value("y", initialize=False)
            if xspace is None or xspace <= 0:
                xspace = self._nice_axis_step(auto_x_max, target_intervals=8)
                self._xspace = xspace
            if yspace is None or yspace <= 0:
                yspace = self._nice_axis_step(auto_y_max, target_intervals=8)
                self._yspace = yspace
            self.x_max_var.set(f"{float(auto_x_max):.6g}")
            self.y_max_var.set(f"{float(auto_y_max):.6g}")
            if self.current_result is not None:
                self._suspend_history_reset = True
                try:
                    self._draw_graph(self._effective_result(self.current_result), graph_mode="screen", draw_idle=True, preserve_view=False)
                finally:
                    self._suspend_history_reset = False
            else:
                self.ax.relim()
                self.ax.autoscale_view()
                self.ax.set_xlim(left=0, right=auto_x_max)
                self.ax.set_ylim(bottom=0, top=auto_y_max)
                self._apply_axis_spacing()
                self._sync_plot_limit_fields_from_axes()
                self.canvas.draw_idle()
            self._graph_has_valid_view = True
            self._push_toolbar_view()
        except Exception as exc:
            show_error("Error al autoajustar gráfica", exc)

    def _apply_plot_configuration(self) -> None:
        self.x_min_var.set("0")
        self.y_min_var.set("0")
        if self.current_result is not None:
            self._draw_graph(self._effective_result(self.current_result), graph_mode="screen", draw_idle=True, preserve_view=False)
        self._graph_has_valid_view = True

    def _configure_toolbar_home(self) -> None:
        try:
            buttons = getattr(self.toolbar, "_buttons", {}) or {}

            def _home_action(*_args: Any) -> None:
                self.auto_adjust_graph()

            def _back_action(*_args: Any) -> None:
                try:
                    self.toolbar._nav_stack.back()
                    if hasattr(self.toolbar, "set_history_buttons"):
                        self.toolbar.set_history_buttons()
                    self.toolbar._update_view()
                except Exception:
                    try:
                        type(self.toolbar).back(self.toolbar)
                    except Exception:
                        pass
                self._after_toolbar_view_navigation()

            def _forward_action(*_args: Any) -> None:
                try:
                    self.toolbar._nav_stack.forward()
                    if hasattr(self.toolbar, "set_history_buttons"):
                        self.toolbar.set_history_buttons()
                    self.toolbar._update_view()
                except Exception:
                    try:
                        type(self.toolbar).forward(self.toolbar)
                    except Exception:
                        pass
                self._after_toolbar_view_navigation()

            home_button = buttons.get("Home") or buttons.get("Inicio")
            if home_button is not None:
                home_button.configure(command=_home_action)
            back_button = buttons.get("Back") or buttons.get("Atrás") or buttons.get("Atras")
            if back_button is not None:
                back_button.configure(command=_back_action)
            forward_button = buttons.get("Forward") or buttons.get("Adelante")
            if forward_button is not None:
                forward_button.configure(command=_forward_action)

            subplots_button = buttons.get("Subplots") or buttons.get("Configure subplots") or buttons.get("Configurar subgráficos")
            if subplots_button is not None:
                subplots_button.configure(command=self.open_subplot_configuration_tool)
        except Exception:
            pass
        try:
            self.toolbar.home = self.auto_adjust_graph
        except Exception:
            pass
        try:
            self.toolbar.configure_subplots = self.open_subplot_configuration_tool
        except Exception:
            pass

    def _subplot_params_dict(self) -> dict[str, float]:
        auto_x_max, auto_y_max = self._best_auto_limits()
        x_max = _safe_float(self.x_max_var.get())
        y_max = _safe_float(self.y_max_var.get())
        xspace = self._axis_spacing_value("x", initialize=True) or self._nice_axis_step(auto_x_max, target_intervals=8)
        yspace = self._axis_spacing_value("y", initialize=True) or self._nice_axis_step(auto_y_max, target_intervals=8)
        return {
            "x_max": float(x_max if x_max is not None and x_max > 0 else auto_x_max),
            "y_max": float(y_max if y_max is not None and y_max > 0 else auto_y_max),
            "xspace": float(xspace),
            "yspace": float(yspace),
        }

    def _apply_subplot_params(self, *_args: Any) -> None:
        if getattr(self, "_subplot_dialog_updating", False):
            return
        try:
            raw: dict[str, Optional[float]] = {}
            for name, var in self._subplot_param_vars.items():
                try:
                    raw[name] = float(str(var.get()).strip().replace(",", "."))
                except Exception:
                    raw[name] = None

            # Migración defensiva por si alguna configuración antigua todavía
            # entrega wspace/hspace. Ya no se usan como separación de subplots.
            if "xspace" not in raw and "wspace" in raw:
                raw["xspace"] = raw.get("wspace")
            if "yspace" not in raw and "hspace" in raw:
                raw["yspace"] = raw.get("hspace")

            params = self._subplot_params_dict()
            params.update({name: value for name, value in raw.items() if value is not None})
            params["x_max"] = max(float(params.get("x_max") or 0.0), 1e-9)
            params["y_max"] = max(float(params.get("y_max") or 0.0), 1e-9)
            params["xspace"] = max(float(params.get("xspace") or self._axis_spacing_value("x") or 1.0), 1e-9)
            params["yspace"] = max(float(params.get("yspace") or self._axis_spacing_value("y") or 1.0), 1e-9)
            # X max/Y max son límites visibles exactos; X space/Y space solo
            # controlan la separación de la grilla. No se redondean los límites
            # a la grilla para evitar que la curva quede demasiado baja.

            self._xspace = params["xspace"]
            self._yspace = params["yspace"]
            self._plot_limits_update_in_progress = True
            try:
                self.x_min_var.set("0")
                self.y_min_var.set("0")
                self.x_max_var.set(f"{params['x_max']:.6g}")
                self.y_max_var.set(f"{params['y_max']:.6g}")
            finally:
                self._plot_limits_update_in_progress = False

            self._subplot_dialog_updating = True
            for name, value in params.items():
                if name in self._subplot_param_vars:
                    self._subplot_param_vars[name].set(float(value))
            self._subplot_dialog_updating = False

            if self.current_result is not None:
                self._draw_graph(self._effective_result(self.current_result), graph_mode="screen", draw_idle=True, preserve_view=False)
            else:
                self.ax.set_xlim(0.0, params["x_max"])
                self.ax.set_ylim(0.0, params["y_max"])
                self._apply_axis_spacing()
                self.canvas.draw_idle()
            self._graph_has_valid_view = True
        except Exception as exc:
            try:
                self.status_var.set(f"No se pudo aplicar configuración de gráfica: {exc}")
            except Exception:
                pass
        finally:
            self._subplot_dialog_updating = False

    def _reset_subplot_params(self) -> None:
        try:
            auto_x_max, auto_y_max = self._best_auto_limits()
            xspace = self._nice_axis_step(auto_x_max, target_intervals=8)
            yspace = self._nice_axis_step(auto_y_max, target_intervals=8)
        except Exception:
            auto_x_max, auto_y_max, xspace, yspace = 10.0, 100.0, 1.0, 10.0
        defaults = {"x_max": auto_x_max, "y_max": auto_y_max, "xspace": xspace, "yspace": yspace}
        self._subplot_dialog_updating = True
        try:
            for name, value in defaults.items():
                if name in self._subplot_param_vars:
                    self._subplot_param_vars[name].set(value)
        finally:
            self._subplot_dialog_updating = False
        self._apply_subplot_params()

    def open_subplot_configuration_tool(self) -> None:
        dialog = getattr(self, "_subplot_dialog", None)
        if dialog is not None:
            try:
                if dialog.winfo_exists():
                    dialog.deiconify()
                    dialog.lift()
                    dialog.focus_force()
                    return
            except Exception:
                pass
        dialog = tk.Toplevel(self.winfo_toplevel())
        dialog.title("Configuración de gráfica")
        dialog.transient(self.winfo_toplevel())
        dialog.resizable(False, False)
        dialog.columnconfigure(1, weight=1)
        self._subplot_dialog = dialog
        self._subplot_param_vars = {}
        self._subplot_dialog_updating = False
        ttk.Label(dialog, text="Ajuste manual de escala", font=("Segoe UI", 12)).grid(row=0, column=0, columnspan=3, sticky="w", padx=12, pady=(12, 10))
        params = self._subplot_params_dict()
        try:
            auto_x_max, auto_y_max = self._best_auto_limits()
        except Exception:
            auto_x_max, auto_y_max = params.get("x_max", 10.0), params.get("y_max", 100.0)
        specs = [
            ("x_max", "X max", 1e-6, max(float(params.get("x_max", 10.0)) * 2.0, float(auto_x_max) * 1.25, 1.0)),
            ("y_max", "Y max", 1e-6, max(float(params.get("y_max", 100.0)) * 2.0, float(auto_y_max) * 1.25, 1.0)),
            ("xspace", "X space", 1e-6, max(float(params.get("xspace", 1.0)) * 10.0, float(params.get("x_max", 10.0)), 1.0)),
            ("yspace", "Y space", 1e-6, max(float(params.get("yspace", 10.0)) * 10.0, float(params.get("y_max", 100.0)), 1.0)),
        ]
        for row_index, (name, label, start, end) in enumerate(specs, start=1):
            var = tk.DoubleVar(value=float(params.get(name, start)))
            self._subplot_param_vars[name] = var
            ttk.Label(dialog, text=label).grid(row=row_index, column=0, sticky="w", padx=(12, 8), pady=4)
            ttk.Scale(dialog, from_=start, to=end, variable=var, command=lambda _value, _name=name: self._apply_subplot_params()).grid(row=row_index, column=1, sticky="ew", padx=(0, 8), pady=4)
            entry = ttk.Entry(dialog, width=10, textvariable=var)
            entry.grid(row=row_index, column=2, sticky="e", padx=(0, 12), pady=4)
            entry.bind("<Return>", lambda _event, _name=name: self._apply_subplot_params())
            entry.bind("<FocusOut>", lambda _event, _name=name: self._apply_subplot_params())
        actions = ttk.Frame(dialog)
        actions.grid(row=len(specs) + 1, column=0, columnspan=3, sticky="ew", padx=12, pady=(8, 12))
        actions.columnconfigure((0, 1), weight=1)
        ttk.Button(actions, text="Aplicar", command=self._apply_subplot_params).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(actions, text="Reset", command=self._reset_subplot_params).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)

    def toggle_zoom(self) -> None:
        try:
            self.toolbar.zoom()
        except Exception as exc:
            show_error("Error al activar zoom", exc)
