from __future__ import annotations

"""Adaptador del módulo Tracción plásticos hacia el exportador Word común.

Mantiene la función pública ``export_unified_report`` para no romper la interfaz
actual del módulo nuevo, pero delega el armado del documento a
``shared.tensile_unified.word_report``.
"""

from pathlib import Path
from typing import Any, Optional

from shared.tensile_unified import METHOD_AUTO, TensileGeometry, TensileReportContext
from shared.tensile_unified.word_report import build_results_table, export_tensile_report


def _coerce_geometry(geometry: Any) -> TensileGeometry:
    if isinstance(geometry, TensileGeometry):
        return geometry.copy()
    try:
        return TensileGeometry.from_legacy_geometry(geometry)
    except Exception:
        return TensileGeometry()


def export_unified_report(
    output_path: str | Path,
    *,
    specimen_id: str,
    geometry: Any,
    result: Any,
    detection: Optional[dict[str, Any]] = None,
    comment: str = "",
    graph_path: str | Path | None = None,
    source_path: str | Path | None = None,
    template_path: str | Path | None = None,
) -> Path:
    """Genera un Word editable para la probeta activa del módulo Tracción plásticos.

    ``comment`` llega desde el cuadro editable de la interfaz. Si llega vacío,
    el exportador común genera el comentario automático correspondiente según
    geometría + método.
    """
    method = getattr(result, "method", METHOD_AUTO)
    context = TensileReportContext(
        specimen_id=specimen_id,
        geometry=_coerce_geometry(geometry),
        active_method=method,
        method_result=result,
        graph_path=graph_path,
        comments=comment,
    )
    return export_tensile_report(
        output_path,
        context,
        detection=detection,
        source_path=source_path,
        template_path=template_path,
    )


__all__ = ["build_results_table", "export_unified_report", "export_tensile_report"]
