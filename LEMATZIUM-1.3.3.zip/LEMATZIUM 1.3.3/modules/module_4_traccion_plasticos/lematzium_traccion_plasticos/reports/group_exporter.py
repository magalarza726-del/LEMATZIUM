from __future__ import annotations

"""Exportación Word por grupos para el módulo de tracción plásticos.

Esta capa replica el flujo operativo del Módulo 1 —plantilla MC, OT PDF,
grupos, observaciones y un DOCX por grupo— sin modificar los módulos 1 y 2.
El cálculo se mantiene en ``shared.tensile_unified`` y la gráfica se genera con
el graficador común del módulo Tracción plásticos.
"""

import io
import math
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt

from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import METHOD_AUTO, TensileAnalysisConfig, analyze_curve, get_default_comment
from shared.tensile_unified.analysis_config import METHOD_RP_OFFSET, METHOD_UPPER_YIELD
from shared.runtime_theme import load_runtime_theme
from lematzium_traccion_plasticos.plastic_plotting import draw_plastic_tensile_curve as draw_unified_tensile_curve
from shared.word_report_utils import add_inline_picture as _add_inline_picture
from lematzium_modulo1.reports.exporter import (  # type: ignore
    ARIAL,
    REPORT_TABLE_WIDTH_CM,
    _add_signature_block,
    _build_client_block,
    _build_observations_block,
    _build_sample_block,
    _build_title_block,
    _cleanup_editable_report,
    _make_table,
    _meta_first,
    _safe,
    _set_cell_text,
    _set_header_content,
    _set_table_border_nil,
)

from .ot_pdf_reader import OTContext
from .templates import ACCREDITATION_ACCREDITED, ACCREDITATION_NON_ACCREDITED, get_report_template_path


# Todas las tablas técnicas del reporte unificado deben ocupar el mismo ancho
# institucional. Si cada tabla tiene un ancho total distinto, Word las centra de
# forma independiente y visualmente quedan desfasadas, como ocurrió con
# geometría vs resultados.
UNIFIED_REPORT_TABLE_WIDTH_CM = float(REPORT_TABLE_WIDTH_CM)


def _complete_widths(widths: list[float]) -> list[float]:
    """Ajusta el último ancho para que la tabla sume el ancho institucional."""
    if not widths:
        return widths
    fixed = [float(w) for w in widths]
    delta = UNIFIED_REPORT_TABLE_WIDTH_CM - sum(fixed)
    fixed[-1] = max(0.5, fixed[-1] + delta)
    return fixed


@dataclass
class ReportExportGroup:
    report_number: str
    order_number: str
    specimen_ids: List[str]
    observations: str = ""
    title: str = "ENSAYO DE TENSIÓN"


@dataclass
class ReportExportPayload:
    accreditation_mode: str
    issue_date: str = ""
    client_name: str = ""
    client_phone: str = ""
    client_address: str = ""
    client_email: str = ""
    client_contact: str = ""
    default_comment: str = ""
    source_path: str = ""
    ot_pdf_path: str = ""
    ot_context: Optional[OTContext] = None
    groups: List[ReportExportGroup] = field(default_factory=list)
    graph_config: Dict[str, Any] = field(default_factory=dict)


ResultProvider = Callable[[Any], Any]
CommentProvider = Callable[[Any, Any], str]

class _IndexAwareDataset:
    """Delegado mínimo para permitir códigos repetidos en la UI.

    Los grupos internos pueden guardar referencias ``__idx__:N``; el reporte
    sigue mostrando el código visible de la curva y no cambia el flujo Word.
    """

    def __init__(self, dataset: Any) -> None:
        self._dataset = dataset

    def __getattr__(self, name: str) -> Any:
        return getattr(self._dataset, name)

    def get_curve(self, specimen_ref: str) -> Any:
        text = str(specimen_ref or "")
        if text.startswith("__idx__:"):
            index = int(text.split(":", 1)[1])
            return self._dataset.curves[index]
        return self._dataset.get_curve(specimen_ref)


def _f(value: Any, ndigits: int = 2, *, unavailable: str = "No disponible") -> str:
    try:
        if value is None:
            return unavailable
        number = float(value)
        if not math.isfinite(number):
            return unavailable
        return f"{number:.{ndigits}f}"
    except Exception:
        return unavailable


def _create_document_from_template(template_path: str | Path) -> Document:
    document = Document(str(template_path))
    # Las plantillas históricas pueden tener protección de edición. El helper
    # compartido del Módulo 1 ya la remueve al limpiar el documento final; aquí
    # no se modifica la plantilla original, solo el documento en memoria.
    return document


def _default_result_provider(config: TensileAnalysisConfig) -> ResultProvider:
    def provider(curve: Any) -> Any:
        return analyze_curve(curve, getattr(curve, "geometry", None), config)
    return provider


def _default_comment_provider(payload: ReportExportPayload, config: TensileAnalysisConfig) -> CommentProvider:
    def provider(curve: Any, analysis_result: Any) -> str:
        selected = getattr(analysis_result, "selected_result", None)
        method = getattr(selected, "method", METHOD_AUTO)
        geometry = getattr(curve, "geometry", None)
        shape = getattr(geometry, "shape", None)
        context = {
            "offset_percent": f"{float(config.offset_percent):g}",
            "upper_yield_drop_mpa": f"{float(config.upper_yield_drop_mpa):g}",
            "procedure_code": _meta_first(getattr(curve, "meta", {}), "Procedure", "Procedimiento", default=""),
            "standard_label": "",
            "machine_label": "MUE 600 kN",
        }
        scalar = getattr(selected, "diagnostics", {}).get("plastic_scalar", {}) if selected is not None else {}
        ptype = scalar.get("applied_type") or getattr(analysis_result, "diagnostics", {}).get("plastic_type", "")
        comment = plastic_comment(ptype, scalar)
        return comment or payload.default_comment
    return provider


def _render_unified_curve_png(
    curve: Any,
    analysis_result: Any,
    *,
    active_method: str,
    graph_config: Optional[Dict[str, Any]] = None,
    width_inches: float = 7.0,
    height_inches: float = 4.3,
    dpi: int = 220,
) -> bytes:
    figure = plt.figure(figsize=(width_inches, height_inches), dpi=dpi, facecolor="none")
    ax = figure.add_subplot(111)
    figure.patch.set_alpha(0.0)
    specimen_id = str(getattr(curve, "specimen_id", "") or "Probeta")
    try:
        theme = load_runtime_theme()
    except Exception:
        theme = {}
    base_graph_config = {
        "mode": "report",
        "legend_mode": "report_right",
        "legend_single_label": specimen_id,
        "report_clean": True,
        "axis_mode": "auto",
        "anchor_origin": True,
        "curve_linewidth": 1.05,
        "show_r2p_lines": True,
        "colors": {
            "curve": str(theme.get("curve") or theme.get("accent") or "#2563eb"),
            "reference_line": str(theme.get("offset") or theme.get("accent_soft") or "#64748b"),
        },
    }
    if graph_config:
        extra = dict(graph_config)
        base_graph_config.update({k: v for k, v in extra.items() if k != "colors"})
        if isinstance(extra.get("colors"), dict):
            base_graph_config["colors"] = {**base_graph_config.get("colors", {}), **extra.get("colors", {})}
    draw_unified_tensile_curve(
        ax,
        curve,
        analysis_result,
        active_method=active_method,
        graph_config=base_graph_config,
    )
    output = io.BytesIO()
    figure.tight_layout(pad=0.9)
    figure.savefig(output, format="png", dpi=dpi, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(figure)
    return output.getvalue()


def _method_title_suffix(analysis_result: Any) -> str:
    selected = getattr(analysis_result, "selected_result", None)
    diagnostics = getattr(selected, "diagnostics", {}) or {}
    scalar = diagnostics.get("plastic_scalar", {}) or {}
    ptype = scalar.get("applied_type") or diagnostics.get("plastic_type")
    return f"Tipo {ptype}" if ptype else "ISO 527"


def _geometry_value(geometry: Any, *names: str) -> Any:
    """Lee atributos de geometría soportando modelos legacy y unificados."""
    if geometry is None:
        return None
    for name in names:
        try:
            value = getattr(geometry, name, None)
        except Exception:
            continue
        if callable(value):
            try:
                value = value()
            except Exception:
                continue
        if value is not None:
            return value
    return None


def _geometry_area(geometry: Any) -> Any:
    area = _geometry_value(geometry, "area_mm2_manual", "area_mm2", "effective_area_mm2")
    if area is not None:
        return area
    return None


def _geometry_shape(geometry: Any) -> str:
    shape = _geometry_value(geometry, "shape", "geometry_type")
    return normalize_shape(shape, default=SHAPE_RECTANGULAR)


def _geometry_shape_report_label(geometry: Any) -> str:
    shape = _geometry_shape(geometry)
    if shape == SHAPE_CIRCULAR:
        return "Circular"
    if shape == SHAPE_IRREGULAR:
        return "Irregular"
    # En los reportes históricos del Módulo 1, la geometría rectangular se
    # presenta al analista/cliente como forma plana.
    return "Plana"


def _fmt_dimension(value: Any, ndigits: int = 2) -> str:
    try:
        if value is None:
            return ""
        number = float(value)
        if not math.isfinite(number):
            return ""
        return f"{number:.{ndigits}f}"
    except Exception:
        return ""


def _build_unified_geometry_table(document: Document, geometry: Any, specimen_id: str) -> None:
    """Tabla de geometría tipo Módulo 1, sin columna 'Probeta'.

    La primera columna identifica la fila de unidades y la muestra, como en los
    reportes históricos. La forma se informa fuera de la tabla para evitar
    columnas desplazadas y mantener el formato compacto.
    """
    shape = _geometry_shape(geometry)
    forma = document.add_paragraph()
    forma.paragraph_format.space_before = Pt(2)
    forma.paragraph_format.space_after = Pt(0)
    run = forma.add_run(f"Forma: {_geometry_shape_report_label(geometry)}")
    run.font.name = ARIAL
    run.font.size = Pt(8)

    if shape == SHAPE_CIRCULAR:
        headers = ["", "Diámetro", "Longitud calibrada"]
        units = ["Unidades", "mm", "mm"]
        values = [
            _safe(specimen_id),
            _fmt_dimension(_geometry_value(geometry, "diameter_mm"), 2),
            _fmt_dimension(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = _complete_widths([3.2, 6.8, 6.8])
    elif shape == SHAPE_IRREGULAR:
        headers = ["", "Área", "Longitud calibrada"]
        units = ["Unidades", "mm²", "mm"]
        values = [
            _safe(specimen_id),
            _fmt_dimension(_geometry_area(geometry), 2),
            _fmt_dimension(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = _complete_widths([3.2, 6.8, 6.8])
    else:
        headers = ["", "Espesor", "Ancho", "Longitud calibrada"]
        units = ["Unidades", "mm", "mm", "mm"]
        values = [
            _safe(specimen_id),
            _fmt_dimension(_geometry_value(geometry, "side1_mm", "thickness_mm"), 3),
            _fmt_dimension(_geometry_value(geometry, "side2_mm", "width_mm"), 2),
            _fmt_dimension(_geometry_value(geometry, "gauge_length_mm"), 2),
        ]
        widths = _complete_widths([3.0, 4.6, 4.6, 4.6])

    table = _make_table(document, 3, len(headers), widths)
    for col, text in enumerate(headers):
        _set_cell_text(table.cell(0, col), text, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    for col, text in enumerate(units):
        _set_cell_text(table.cell(1, col), text, bold=True if col == 0 else False, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    for col, text in enumerate(values):
        _set_cell_text(table.cell(2, col), text, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)


def _rp_label_from_result(result: Any) -> str:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    label = diagnostics.get("rp_label")
    if label:
        return str(label)
    offset_percent = diagnostics.get("offset_percent", 0.2)
    try:
        return TensileAnalysisConfig(offset_percent=float(offset_percent)).rp_label
    except Exception:
        return "σx"


def _build_unified_results_table(document: Document, specimen_id: str, result: Any) -> None:
    """Tabla de resultados para puntos característicos ISO 527."""
    diagnostics = getattr(result, "diagnostics", {}) or {}
    scalar = diagnostics.get("plastic_scalar", {}) or {}
    ptype = str(scalar.get("applied_type") or diagnostics.get("plastic_type") or "").upper()

    if ptype == "A":
        headers = ["Nombre", "Módulo", "Esfuerzo Máximo", "Esfuerzo de Rotura", "Deformación de Rotura"]
        parameter = ["Parámetro", "ME", "σM", "σB", "εB"]
        units = ["Unidades", "GPa", "MPa", "MPa", "%"]
        values = [_safe(specimen_id), _f(scalar.get("modulus_gpa"), 2, unavailable=""), _f(scalar.get("max_stress_mpa"), 2, unavailable=""), _f(scalar.get("break_stress_mpa"), 2, unavailable=""), _f(scalar.get("break_strain_pct"), 2, unavailable="")]
        widths = _complete_widths([2.8, 3.1, 3.6, 3.6, 3.8])
    elif ptype == "D":
        x = scalar.get("type_d_x_percent", 100)
        headers = ["Nombre", "σ1", "σ2", f"σx ({float(x):g} %)", "σm/σb"]
        parameter = ["Parámetro", "100 %", "200 %", f"{float(x):g} %", "Máx./Rotura"]
        units = ["Unidades", "MPa", "MPa", "MPa", "MPa"]
        values = [_safe(specimen_id), _f(scalar.get("sigma1_stress_mpa"), 2, unavailable=""), _f(scalar.get("sigma2_stress_mpa"), 2, unavailable=""), _f(scalar.get("sigmax_stress_mpa"), 2, unavailable=""), _f(scalar.get("sigma_m_or_b_stress_mpa"), 2, unavailable="")]
        widths = _complete_widths([2.8, 3.2, 3.2, 3.6, 3.8])
    elif ptype == "C":
        headers = ["Nombre", "Esfuerzo de Fluencia", "Esfuerzo Máximo", "Esfuerzo de Rotura", "Deformación de Rotura"]
        parameter = ["Parámetro", "σY", "σM", "σB", "εB"]
        units = ["Unidades", "MPa", "MPa", "MPa", "%"]
        values = [_safe(specimen_id), _f(scalar.get("yield_stress_mpa"), 2, unavailable=""), _f(scalar.get("max_stress_mpa"), 2, unavailable=""), _f(scalar.get("break_stress_mpa"), 2, unavailable=""), _f(scalar.get("break_strain_pct"), 2, unavailable="")]
        widths = _complete_widths([2.8, 3.8, 3.2, 3.2, 3.8])
    else:
        headers = ["Nombre", "Esfuerzo de Fluencia", "Esfuerzo Máximo"]
        parameter = ["Parámetro", "σY", "σM"]
        units = ["Unidades", "MPa", "MPa"]
        values = [_safe(specimen_id), _f(scalar.get("yield_stress_mpa") or getattr(result, "value_mpa", None), 2, unavailable=""), _f(scalar.get("max_stress_mpa") or getattr(result, "max_stress_mpa", None), 2, unavailable="")]
        widths = _complete_widths([4.0, 6.0, 6.8])

    table = _make_table(document, 4, len(headers), widths)
    rows = (headers, parameter, units, values)
    for row_index, row_values in enumerate(rows):
        for col, cell_text in enumerate(row_values):
            _set_cell_text(table.cell(row_index, col), cell_text, bold=(row_index == 0), align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)


def _build_unified_tension_section(
    document: Document,
    dataset: Any,
    group: ReportExportGroup,
    curve: Any,
    analysis_result: Any,
    comment_text: str,
    *,
    active_method: str,
    graph_config: Optional[Dict[str, Any]] = None,
) -> None:
    document.add_page_break()

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(10)
    title_run = title.add_run(group.title or "ENSAYO DE TRACCIÓN EN PLÁSTICOS")
    title_run.bold = True
    title_run.font.name = ARIAL
    title_run.font.size = Pt(13)

    meta = getattr(dataset, "meta", {}) or {}
    meta_table = _make_table(document, 4, 4, _complete_widths([3.2, 4.2, 3.6, 5.2]))
    _set_table_border_nil(meta_table)
    left_pairs = [
        ("Procedimiento", _meta_first(meta, "Procedimiento", "Procedure", default="PEE/LEMAT/03")),
        ("Temperatura Máx/Mín", _meta_first(meta, "Temperatura Máx/Mín", "Temperatura Max/Min", "Temperature Max/Min")),
        ("Equipo utilizado", _meta_first(meta, "Equipo Utilizado", "Used Device", default="MUE 600KN")),
        ("Velocidad de ensayo", _meta_first(meta, "Velocidad de Ensayo", "Velocidad de ensayo", "Test Speed")),
    ]
    right_pairs = [
        ("Norma de Referencia", _meta_first(meta, "Norma de Referencia", "Norma de referencia", "Reference Standard", default="ISO 527-1")),
        ("Humedad Máx/Mín", _meta_first(meta, "Humedad Máx/Mín", "Humidity Max/Min")),
        ("Material", _meta_first(meta, "Material", default="Plástico")),
        ("Control de Velocidad", _meta_first(meta, "Control de Velocidad", "Speed Control", default="Según método ISO 527")),
    ]
    for row_index, (label, value) in enumerate(left_pairs):
        _set_cell_text(meta_table.cell(row_index, 0), f"{label}:", bold=True, font_size=8)
        _set_cell_text(meta_table.cell(row_index, 1), _safe(value), font_size=8)
    for row_index, (label, value) in enumerate(right_pairs):
        _set_cell_text(meta_table.cell(row_index, 2), f"{label}:", bold=True, font_size=8)
        _set_cell_text(meta_table.cell(row_index, 3), _safe(value), font_size=8)

    specimen_id = str(getattr(curve, "specimen_id", ""))
    _build_unified_geometry_table(document, getattr(curve, "geometry", None), specimen_id)

    # Tabla de resultados dinámica. Mantiene tablas reales editables, con nombre
    # técnico según el método activo: Fluencia superior o Rp{offset}.
    _build_unified_results_table(document, specimen_id, getattr(analysis_result, "selected_result", None))

    image_bytes = _render_unified_curve_png(curve, analysis_result, active_method=active_method, graph_config=graph_config)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        temp_path = Path(tmp.name)
    picture_paragraph = document.add_paragraph()
    picture_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _add_inline_picture(picture_paragraph, temp_path, width_cm=16.6)
    temp_path.unlink(missing_ok=True)

    comment_title = document.add_paragraph()
    comment_run = comment_title.add_run("Comentarios")
    comment_run.bold = True
    comment_run.font.name = ARIAL
    comment_run.font.size = Pt(9)
    lines = str(comment_text or "").splitlines() or [""]
    for line in lines:
        paragraph = document.add_paragraph(line)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.space_before = Pt(0)
        for run in paragraph.runs:
            run.font.name = ARIAL
            run.font.size = Pt(8)


def export_group_to_docx(
    dataset: Any,
    payload: ReportExportPayload,
    group: ReportExportGroup,
    output_path: str | Path,
    *,
    analysis_config: Optional[TensileAnalysisConfig] = None,
    result_provider: Optional[ResultProvider] = None,
    comment_provider: Optional[CommentProvider] = None,
) -> Path:
    config = analysis_config or TensileAnalysisConfig()
    result_provider = result_provider or _default_result_provider(config)
    comment_provider = comment_provider or _default_comment_provider(payload, config)

    template_path = get_report_template_path(payload.accreditation_mode)
    document = _create_document_from_template(template_path)
    dataset_view = _IndexAwareDataset(dataset)
    total_pages = 1 + len(group.specimen_ids)
    _set_header_content(document, group.report_number, group.order_number, payload.issue_date, total_pages)
    _build_title_block(document, group.report_number, group.order_number, payload.issue_date)
    _build_client_block(document, payload)
    _build_sample_block(document, dataset_view, payload, group)
    _build_observations_block(document, group.observations)

    for specimen_id in group.specimen_ids:
        curve = dataset_view.get_curve(specimen_id)
        analysis_result = result_provider(curve)
        comment_text = comment_provider(curve, analysis_result)
        _build_unified_tension_section(
            document,
            dataset,
            group,
            curve,
            analysis_result,
            comment_text,
            active_method=config.active_method or METHOD_AUTO,
            graph_config=getattr(payload, "graph_config", {}) or {},
        )

    _add_signature_block(document)
    _cleanup_editable_report(document, max_table_width_cm=REPORT_TABLE_WIDTH_CM)

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    document.save(output)
    return output


def export_report_groups_to_docx(
    dataset: Any,
    payload: ReportExportPayload,
    output_dir: str | Path,
    *,
    analysis_config: Optional[TensileAnalysisConfig] = None,
    result_provider: Optional[ResultProvider] = None,
    comment_provider: Optional[CommentProvider] = None,
) -> List[Path]:
    output_directory = Path(output_dir)
    output_directory.mkdir(parents=True, exist_ok=True)
    exported_files: List[Path] = []
    for group in payload.groups:
        client_name = payload.client_name or (payload.ot_context.client_name if payload.ot_context else "")
        filename = f"INFORME N°{group.report_number} {client_name} {group.order_number}.docx"
        filename = re.sub(r'[\\/:*?"<>|]', "_", filename).strip()
        exported_files.append(
            export_group_to_docx(
                dataset,
                payload,
                group,
                output_directory / filename,
                analysis_config=analysis_config,
                result_provider=result_provider,
                comment_provider=comment_provider,
            )
        )
    return exported_files


__all__ = [
    "ACCREDITATION_ACCREDITED",
    "ACCREDITATION_NON_ACCREDITED",
    "ReportExportGroup",
    "ReportExportPayload",
    "export_group_to_docx",
    "export_report_groups_to_docx",
]
