from __future__ import annotations

import traceback
import tkinter as tk
from tkinter import messagebox

# Permite ejecutar este archivo directamente desde VS Code, además del launcher.
# Estructura esperada:
# modules/module_4_traccion_plasticos/lematzium_traccion_plasticos/app/main.py
from pathlib import Path
import sys

_THIS_FILE = Path(__file__).resolve()
_MODULE_ROOT = _THIS_FILE.parents[2]
_MODULES_DIR = _THIS_FILE.parents[3]
for _path in (
    _MODULE_ROOT,
    _MODULES_DIR,
    _MODULES_DIR / "module_1_drop1mpa",
    _MODULES_DIR / "module_2_offset02",
):
    _text = str(_path)
    if _path.exists() and _text not in sys.path:
        sys.path.insert(0, _text)


APP_TITLE = "LEMATZIUM - Módulo 2 - Tracción plásticos 1.0.0"


def _show_startup_error(title: str, exc: BaseException) -> None:
    details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    message = (
        "No se pudo iniciar el módulo Tracción plásticos ISO 527.\n\n"
        "El programa capturó el error para evitar un cierre silencioso.\n\n"
        f"Detalle técnico:\n{details[-1800:]}"
    )
    try:
        messagebox.showerror(title, message)
    except Exception:
        print(message)


def _install_tk_exception_hook(root: tk.Tk) -> None:
    def _report_callback_exception(exc_type, exc_value, exc_tb) -> None:  # type: ignore[no-untyped-def]
        details = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        try:
            messagebox.showerror(
                "Error en LEMATZIUM",
                "Se produjo un error en la interfaz, pero el módulo permanece abierto.\n\n"
                f"Detalle técnico:\n{details[-1800:]}",
            )
        except Exception:
            print(details)

    root.report_callback_exception = _report_callback_exception  # type: ignore[assignment]


def main() -> int:
    root = tk.Tk()
    root.withdraw()
    root.title(APP_TITLE)
    root.geometry("1760x1020")
    root.minsize(1280, 760)
    root.resizable(True, True)
    _install_tk_exception_hook(root)

    try:
        # Importación diferida: la ventana se construye después
        # de tener un root Tk y un manejador global de excepciones.
        from lematzium_traccion_plasticos.ui.main_window import UnifiedTensileWindow

        UnifiedTensileWindow(root).pack(fill="both", expand=True)

        def _show_root_normal() -> None:
            try:
                root.state("normal")
                root.deiconify()
                root.lift()
                root.focus_force()
            except Exception:
                root.deiconify()

        root.after_idle(_show_root_normal)
        root.mainloop()
        return 0
    except Exception as exc:
        _show_startup_error("Error de arranque", exc)
        try:
            root.destroy()
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
