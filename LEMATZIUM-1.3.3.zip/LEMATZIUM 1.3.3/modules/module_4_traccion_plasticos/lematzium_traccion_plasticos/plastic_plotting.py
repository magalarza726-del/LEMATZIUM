from __future__ import annotations

from typing import Any, Optional
import math

import numpy as np
import matplotlib.patheffects as pe
from matplotlib.ticker import AutoMinorLocator, FuncFormatter, MultipleLocator


def _safe_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "si", "sí", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return default


def _get_curve_df(curve: Any, graph_config: dict[str, Any]):
    pre = graph_config.get("_precomputed_df")
    if pre is not None:
        return pre.copy()
    from shared.tensile_unified.plotting import _get_curve_df as _legacy_get_curve_df
    df = _legacy_get_curve_df(curve)
    try:
        raw_df = getattr(curve, "raw_df", None)
        if raw_df is not None and "stress_MPa" in raw_df and len(raw_df) == len(df):
            raw_max = float(np.nanmax(np.asarray(raw_df["stress_MPa"], dtype=float)))
            df_max = float(np.nanmax(np.asarray(df["stress_MPa"], dtype=float)))
            if np.isfinite(raw_max) and np.isfinite(df_max) and raw_max > 0 and df_max / raw_max > 100.0:
                df = df.copy()
                df["stress_MPa"] = np.asarray(raw_df["stress_MPa"], dtype=float)
    except Exception:
        pass
    return df


def _nice_step(max_value: float, target_steps: int = 8) -> float:
    value = max(abs(float(max_value)), 1e-9)
    raw = value / max(int(target_steps), 1)
    exponent = math.floor(math.log10(raw)) if raw > 0 else 0
    fraction = raw / (10 ** exponent)
    if fraction <= 1:
        nice = 1
    elif fraction <= 2:
        nice = 2
    elif fraction <= 2.5:
        nice = 2.5
    elif fraction <= 5:
        nice = 5
    else:
        nice = 10
    return nice * (10 ** exponent)


def _fmt_axis(value: float, _pos: Any = None) -> str:
    try:
        number = float(value)
    except Exception:
        return ""
    text = f"{number:.4f}" if abs(number) < 1 else f"{number:.2f}"
    text = text.rstrip("0").rstrip(".")
    return text if text not in {"", "-0"} else "0"


def _configure_axes(ax: Any, graph_config: dict[str, Any], x: np.ndarray, y: np.ndarray) -> None:
    x_min_cfg = _safe_float(graph_config.get("x_min"))
    x_max_cfg = _safe_float(graph_config.get("x_max"))
    y_min_cfg = _safe_float(graph_config.get("y_min"))
    y_max_cfg = _safe_float(graph_config.get("y_max"))
    x_data_max = max(float(np.nanmax(x)) if len(x) else 1.0, 1e-9)
    y_data_max = max(float(np.nanmax(y)) if len(y) else 1.0, 1e-9)
    x_min = 0.0 if x_min_cfg is None else float(x_min_cfg)
    y_min = 0.0 if y_min_cfg is None else float(y_min_cfg)
    x_max = float(x_max_cfg) if x_max_cfg is not None and x_max_cfg > x_min else x_data_max * 1.05
    y_max = float(y_max_cfg) if y_max_cfg is not None and y_max_cfg > y_min else y_data_max * 1.10
    if x_max <= x_min:
        x_max = x_min + 1.0
    if y_max <= y_min:
        y_max = y_min + 1.0
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    grid_x = _safe_float(graph_config.get("grid_x")) or _nice_step(x_max - x_min)
    grid_y = _safe_float(graph_config.get("grid_y")) or _nice_step(y_max - y_min)
    if grid_x and grid_x > 0:
        ax.xaxis.set_major_locator(MultipleLocator(float(grid_x)))
    if grid_y and grid_y > 0:
        ax.yaxis.set_major_locator(MultipleLocator(float(grid_y)))
    try:
        ax.xaxis.set_minor_locator(AutoMinorLocator(5))
        ax.yaxis.set_minor_locator(AutoMinorLocator(5))
    except Exception:
        pass
    ax.xaxis.set_major_formatter(FuncFormatter(_fmt_axis))
    ax.yaxis.set_major_formatter(FuncFormatter(_fmt_axis))


def _normalize_graph_y_mode(value: Any) -> str:
    text = str(value or "").strip().lower()
    if "carga" in text or "load" in text or text in {"force", "fuerza"}:
        return "load"
    return "stress"


def _normalize_stress_unit(value: Any) -> str:
    text = str(value or "MPa").strip().lower().replace(" ", "")
    if text in {"pa", "pascal", "pascales"}:
        return "Pa"
    if text in {"kpa", "kilopascal", "kilopascales", "kilopascals"}:
        return "kPa"
    return "MPa"


def _normalize_load_unit(value: Any) -> str:
    text = str(value or "kN").strip().lower().replace(" ", "")
    if text in {"n", "newton", "newtons"}:
        return "N"
    return "kN"


def _stress_factor_from_mpa(unit: str) -> float:
    return {"MPa": 1.0, "kPa": 1000.0, "Pa": 1_000_000.0}.get(unit, 1.0)


def _load_factor_from_newton(unit: str) -> float:
    return {"N": 1.0, "kN": 0.001}.get(unit, 0.001)


def _geometry_area_mm2(curve: Any) -> Optional[float]:
    geometry = getattr(curve, "geometry", None)
    if geometry is None:
        return None
    for name in ("area_mm2", "effective_area_mm2"):
        try:
            value = getattr(geometry, name, None)
            if callable(value):
                value = value()
            number = _safe_float(value)
            if number is not None and number > 0:
                return float(number)
        except Exception:
            pass
    try:
        value = getattr(geometry, "area_mm2_manual", None)
        number = _safe_float(value)
        if number is not None and number > 0:
            return float(number)
    except Exception:
        pass
    try:
        s1 = _safe_float(getattr(geometry, "side1_mm", None) or getattr(geometry, "thickness_mm", None))
        s2 = _safe_float(getattr(geometry, "side2_mm", None) or getattr(geometry, "width_mm", None))
        if s1 is not None and s2 is not None and s1 > 0 and s2 > 0:
            return float(s1 * s2)
    except Exception:
        pass
    try:
        d = _safe_float(getattr(geometry, "diameter_mm", None))
        if d is not None and d > 0:
            return float(math.pi * d * d / 4.0)
    except Exception:
        pass
    return None


def _attr_force_unit(curve: Any, df: Any) -> Optional[str]:
    for obj in (df, getattr(curve, "raw_df", None), getattr(curve, "df", None), getattr(curve, "data", None), getattr(curve, "dataframe", None)):
        try:
            attrs = getattr(obj, "attrs", None)
            if isinstance(attrs, dict):
                value = str(attrs.get("iso527_force_unit") or "").strip()
                if value in {"N", "kN"}:
                    return value
        except Exception:
            pass
    return None


def _infer_load_input_unit(curve: Any, df: Any) -> str:
    attr_unit = _attr_force_unit(curve, df)
    if attr_unit in {"N", "kN"}:
        return attr_unit
    try:
        values = np.asarray(df["load_kN"], dtype=float)
        max_abs_load = float(np.nanmax(np.abs(values))) if len(values) else 0.0
    except Exception:
        max_abs_load = 0.0
    try:
        source = " ".join(str(getattr(curve, attr, "") or "") for attr in ("specimen_id", "source_path", "path", "filename")).lower()
    except Exception:
        source = ""
    if "caucho" in source or "rubber" in source or "tipo d" in source or "type d" in source or max_abs_load > 20.0:
        return "N"
    return "kN"


def _load_newton_array(curve: Any, df: Any) -> np.ndarray:
    if "load_N" in getattr(df, "columns", []):
        return np.asarray(df["load_N"], dtype=float)
    if "load_kN" in getattr(df, "columns", []):
        values = np.asarray(df["load_kN"], dtype=float)
        input_unit = _infer_load_input_unit(curve, df)
        return values if input_unit == "N" else values * 1000.0
    if "stress_MPa" in getattr(df, "columns", []):
        area = _geometry_area_mm2(curve)
        if area is not None and area > 0:
            return np.asarray(df["stress_MPa"], dtype=float) * float(area)
    raise ValueError("La curva no contiene carga graficable ni área válida para reconstruirla.")


def _stress_mpa_array(curve: Any, df: Any) -> np.ndarray:
    if "stress_MPa" in getattr(df, "columns", []):
        return np.asarray(df["stress_MPa"], dtype=float)
    area = _geometry_area_mm2(curve)
    if area is None or area <= 0:
        raise ValueError("La curva no contiene esfuerzo y no hay área válida para calcularlo.")
    return _load_newton_array(curve, df) / float(area)


def _graph_y_selection(graph_config: dict[str, Any]) -> tuple[str, str]:
    mode = _normalize_graph_y_mode(graph_config.get("y_mode") or graph_config.get("graph_type") or graph_config.get("plot_type"))
    if mode == "load":
        return "load", _normalize_load_unit(graph_config.get("load_unit") or graph_config.get("y_unit"))
    return "stress", _normalize_stress_unit(graph_config.get("stress_unit") or graph_config.get("y_unit"))


def _graph_y_label(mode: str, unit: str) -> str:
    return f"Carga ({unit})" if mode == "load" else f"Esfuerzo ({unit})"


def get_plastic_plot_series(curve: Any, graph_config: dict[str, Any] | None = None) -> tuple[Any, np.ndarray, np.ndarray, str, str, str]:
    """Devuelve DataFrame, X, Y y metadatos de la gráfica seleccionada."""
    config = dict(graph_config or {})
    df = _get_curve_df(curve, config)
    x = np.asarray(df["elongation_mm"], dtype=float)
    mode, unit = _graph_y_selection(config)
    if mode == "load":
        y = _load_newton_array(curve, df) * _load_factor_from_newton(unit)
    else:
        y = _stress_mpa_array(curve, df) * _stress_factor_from_mpa(unit)
    label = _graph_y_label(mode, unit)
    return df, x, np.asarray(y, dtype=float), label, mode, unit


def _extract_points(analysis_result: Any) -> list[dict[str, Any]]:
    diag = getattr(analysis_result, "diagnostics", {}) or {}
    points = diag.get("plastic_points") or []
    if not points:
        selected = getattr(analysis_result, "selected_result", None)
        points = (getattr(selected, "diagnostics", {}) or {}).get("plastic_points") or []
    return list(points or [])


POINT_COLORS = {
    "yield": "#111827",
    "max": "#dc2626",
    "break": "#9333ea",
    "sigma1": "#16a34a",
    "sigma2": "#f97316",
    "sigmax": "#0891b2",
    "mod_e1": "#64748b",
    "mod_e2": "#64748b",
}

POINT_OFFSETS = {
    "yield": (6, 7),
    "max": (6, -16),
    "break": (6, 7),
    "sigma1": (8, 10),
    "sigma2": (8, 22),
    "sigmax": (8, 9),
    "mod_e1": (8, -13),
    "mod_e2": (8, 9),
}


def _legend_gap_axes_fraction(ax: Any, gap_cm: float = 0.10) -> float:
    try:
        fig = getattr(ax, "figure", None)
        if fig is None:
            return 0.004
        fig_width_in = float(fig.get_figwidth())
        bbox = ax.get_position()
        axes_width_in = max(float(bbox.width) * fig_width_in, 1e-9)
        return max((float(gap_cm) / 2.54) / axes_width_in, 0.0)
    except Exception:
        return 0.004


def _point_by_mode(points: list[dict[str, Any]], *modes: str) -> dict[str, Any] | None:
    wanted = {str(mode) for mode in modes}
    for point in points:
        if str(point.get("mode") or "") in wanted:
            x = _safe_float(point.get("x_mm"))
            y = _safe_float(point.get("stress_mpa"))
            if x is not None and y is not None:
                return point
    return None


def _point_display_xy(point: dict[str, Any], df: Any, curve: Any, graph_config: dict[str, Any]) -> tuple[Optional[float], Optional[float]]:
    x = _safe_float(point.get("x_mm"))
    if x is None:
        return None, None
    mode, unit = _graph_y_selection(graph_config)
    if mode == "stress":
        y_mpa = _safe_float(point.get("stress_mpa"))
        if y_mpa is None:
            try:
                idx = int(point.get("index"))
                y_mpa = _safe_float(df.iloc[idx].get("stress_MPa"))
            except Exception:
                y_mpa = None
        return x, None if y_mpa is None else float(y_mpa) * _stress_factor_from_mpa(unit)

    try:
        loads = _load_newton_array(curve, df) * _load_factor_from_newton(unit)
        idx_raw = point.get("index")
        if idx_raw is not None:
            idx = int(idx_raw)
            if 0 <= idx < len(loads):
                y_load = _safe_float(loads[idx])
                if y_load is not None:
                    return x, float(y_load)
        xs = np.asarray(df["elongation_mm"], dtype=float)
        finite = np.isfinite(xs) & np.isfinite(loads)
        if np.count_nonzero(finite) >= 2:
            xs_f = xs[finite]
            loads_f = np.asarray(loads, dtype=float)[finite]
            order = np.argsort(xs_f)
            y_load = float(np.interp(float(x), xs_f[order], loads_f[order]))
            return x, y_load
    except Exception:
        pass
    # Respaldo: reconstruir carga desde esfuerzo y área, manteniendo coherencia visual.
    stress = _safe_float(point.get("stress_mpa"))
    area = _geometry_area_mm2(curve)
    if stress is not None and area is not None and area > 0:
        return x, float(stress) * float(area) * _load_factor_from_newton(unit)
    return x, None


def _draw_reference_segment(ax: Any, p1: dict[str, Any] | None, p2: dict[str, Any] | None, *, df: Any, curve: Any, graph_config: dict[str, Any], color: str, linestyle: str = "--") -> None:
    if p1 is None or p2 is None:
        return
    x1, y1 = _point_display_xy(p1, df, curve, graph_config)
    x2, y2 = _point_display_xy(p2, df, curve, graph_config)
    if None in (x1, y1, x2, y2):
        return
    ax.plot([x1, x2], [y1, y2], color=color, linewidth=1.05, linestyle=linestyle, alpha=0.72, zorder=4, label="_nolegend_")


def _draw_reference_projection(ax: Any, point: dict[str, Any] | None, *, df: Any, curve: Any, graph_config: dict[str, Any], color: str) -> None:
    if point is None:
        return
    x, y = _point_display_xy(point, df, curve, graph_config)
    if x is None or y is None:
        return
    try:
        x0, _x1 = ax.get_xlim()
        y0, _y1 = ax.get_ylim()
    except Exception:
        x0, y0 = 0.0, 0.0
    ax.plot([x, x], [y0, y], color=color, linewidth=0.95, linestyle=":", alpha=0.62, zorder=2, label="_nolegend_")
    ax.plot([x0, x], [y, y], color=color, linewidth=0.95, linestyle=":", alpha=0.62, zorder=2, label="_nolegend_")


def _draw_plastic_reference_lines(ax: Any, points: list[dict[str, Any]], graph_config: dict[str, Any], *, df: Any, curve: Any) -> None:
    if not _as_bool(graph_config.get("show_r2p_lines"), default=True):
        return
    colors = dict(graph_config.get("colors") or {})
    line_color = str(colors.get("reference_line") or colors.get("offset_line") or colors.get("curve") or "#64748b")
    # Recta de módulo / R2P: para Tipo A/B/C usa ε1-ε2; para Tipo D usa σ1-σ2.
    _draw_reference_segment(
        ax,
        _point_by_mode(points, "mod_e1", "sigma1"),
        _point_by_mode(points, "mod_e2", "sigma2"),
        df=df,
        curve=curve,
        graph_config=graph_config,
        color=line_color,
        linestyle="--",
    )
    # Proyección σx de Tipo D. Si no existe, no se dibuja nada.
    _draw_reference_projection(ax, _point_by_mode(points, "sigmax"), df=df, curve=curve, graph_config=graph_config, color=line_color)


def _draw_plastic_points(ax: Any, points: list[dict[str, Any]], *, df: Any, curve: Any, graph_config: dict[str, Any], annotate: bool = True) -> None:
    for point in points:
        x, y = _point_display_xy(point, df, curve, graph_config)
        if x is None or y is None:
            continue
        mode = str(point.get("mode") or "")
        label = str(point.get("label") or mode or "P")
        color = POINT_COLORS.get(mode, "#111827")
        ax.scatter(
            [x],
            [y],
            s=96,
            marker="o",
            color=color,
            edgecolors="#111827",
            linewidths=0.75,
            antialiased=True,
            zorder=8,
            label="_nolegend_",
        )
        if annotate:
            ax.annotate(
                label,
                (x, y),
                textcoords="offset points",
                xytext=POINT_OFFSETS.get(mode, (6, 7)),
                fontsize=10,
                fontweight="bold",
                color="#111827",
                zorder=9,
                annotation_clip=False,
                path_effects=[pe.withStroke(linewidth=2.4, foreground="white")],
            )


def draw_plastic_tensile_curve(ax: Any, curve: Any, analysis_result: Any, *, active_method: str = "auto", graph_config: dict[str, Any] | None = None) -> None:
    """Dibuja curvas ISO 527 sin superponer la lógica metálica Rp/YP del módulo unificado."""
    config: dict[str, Any] = dict(graph_config or {})
    clear_axes = _as_bool(config.get("clear_axes"), default=True)
    configure_axes = _as_bool(config.get("configure_axes"), default=True)
    draw_labels = _as_bool(config.get("draw_labels"), default=clear_axes)
    apply_legend = _as_bool(config.get("apply_legend"), default=True)
    if clear_axes:
        ax.clear()
    df, x, y, y_label, _y_mode, _y_unit = get_plastic_plot_series(curve, config)
    mask = np.isfinite(x) & np.isfinite(y)
    x, y = x[mask], y[mask]
    if len(x) == 0:
        raise ValueError("No hay datos numéricos finitos para graficar.")

    colors = dict(config.get("colors") or {})
    curve_color = str(colors.get("curve") or "#2563eb")
    label = str(config.get("curve_label") or getattr(curve, "specimen_id", "Curva") or "Curva")
    ax.set_facecolor(config.get("facecolor", "#fbfcfd"))
    ax.plot(x, y, linewidth=float(config.get("curve_linewidth", 1.35)), color=curve_color, label=label, zorder=3)

    if draw_labels:
        ax.set_xlabel("Alargamiento (mm)")
        ax.set_ylabel(str(config.get("y_axis_label") or y_label))
        ax.set_title("")
    ax.grid(True, which="major", color="#8fa1b5", linestyle="--", linewidth=0.85, alpha=0.96)
    ax.grid(True, which="minor", color="#c8d3df", linestyle=":", linewidth=0.60, alpha=0.86)
    if configure_axes:
        _configure_axes(ax, config, x, y)

    points = _extract_points(analysis_result)
    _draw_plastic_reference_lines(ax, points, config, df=df, curve=curve)
    annotate = _as_bool(config.get("draw_point_annotations"), default=draw_labels)
    _draw_plastic_points(ax, points, df=df, curve=curve, graph_config=config, annotate=annotate)

    if apply_legend:
        handles, labels = ax.get_legend_handles_labels()
        pairs = [(h, l) for h, l in zip(handles, labels) if l and not str(l).startswith("_")]
        if pairs:
            handles, labels = zip(*pairs)
            mode = str(config.get("legend_mode", config.get("mode", "screen"))).lower()
            fig = getattr(ax, "figure", None)
            if mode in {"outside", "screen", "report_right"} and fig is not None:
                fig.subplots_adjust(left=0.10, right=0.86, bottom=0.13, top=0.90)
                gap = _legend_gap_axes_fraction(ax, 0.10)
                ax.legend(
                    handles,
                    labels,
                    loc="upper left",
                    bbox_to_anchor=(1.0 + gap, 1.0),
                    borderaxespad=0.0,
                    handletextpad=0.35,
                    fontsize=8,
                    frameon=True,
                    framealpha=0.92,
                )
            else:
                ax.legend(handles, labels, loc="best", fontsize=8, frameon=True, framealpha=0.92)


__all__ = ["draw_plastic_tensile_curve", "get_plastic_plot_series"]
