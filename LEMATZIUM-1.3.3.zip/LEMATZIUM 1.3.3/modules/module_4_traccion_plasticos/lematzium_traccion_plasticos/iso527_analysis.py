from __future__ import annotations

"""Motor técnico ISO 527 para el Módulo 2 - Tracción plásticos 1.0.0.

La lógica se basa en las curvas típicas ISO 527 A/B/C/D:
- Tipo A: sin punto de fluencia; se reporta σM/σB y εB, más módulo.
- Tipo B: con punto de fluencia y posterior endurecimiento; se reporta σY y σM.
- Tipo C: con fluencia y rotura/fin de ensayo a menor esfuerzo; se reporta σY, σM y σB.
- Tipo D: curva de alta deformación sin fluencia definida; se reporta σ1, σ2, σx y σm/σb.
"""

import math
import re
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd

from shared.tensile_unified import METHOD_AUTO
from shared.tensile_unified.models import TensileMethodResult, TensileUnifiedResult
from lematzium_traccion_plasticos.point_labels import format_default_label

PLASTIC_AUTO = METHOD_AUTO
PLASTIC_TYPE_A = "plastic_type_a"
PLASTIC_TYPE_B = "plastic_type_b"
PLASTIC_TYPE_C = "plastic_type_c"
PLASTIC_TYPE_D = "plastic_type_d"

TYPE_BY_METHOD = {
    PLASTIC_TYPE_A: "A",
    PLASTIC_TYPE_B: "B",
    PLASTIC_TYPE_C: "C",
    PLASTIC_TYPE_D: "D",
}
METHOD_BY_TYPE = {v: k for k, v in TYPE_BY_METHOD.items()}
TYPE_LABEL = {
    "A": "Tipo A - sin fluencia: σM/σB, εB y módulo",
    "B": "Tipo B - fluencia y posterior máximo",
    "C": "Tipo C - fluencia y rotura/fin a menor esfuerzo",
    "D": "Tipo D - alta deformación: σ1, σ2, σx y σm/σb",
}


def _safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    if value is None:
        return default
    if isinstance(value, str):
        value = value.strip().replace(" ", "").replace(",", ".")
        if value in {"", "-.-", "--", "-"}:
            return default
    try:
        number = float(value)
    except Exception:
        return default
    return number if math.isfinite(number) else default




def _config_float(config: Any, *names: str, default: float) -> float:
    for name in names:
        try:
            value = _safe_float(getattr(config, name, None), None)
            if value is not None and value > 0:
                return float(value)
        except Exception:
            pass
    return float(default)


def _modulus_e1_pct(config: Any) -> float:
    return _config_float(config, "plastic_modulus_e1_pct", "modulus_e1_pct", default=0.05)


def _modulus_e2_pct(config: Any) -> float:
    e1 = _modulus_e1_pct(config)
    e2 = _config_float(config, "plastic_modulus_e2_pct", "modulus_e2_pct", default=0.25)
    if e2 <= e1:
        e2 = e1 + 0.20
    return float(e2)


def _break_drop_percent(config: Any) -> float:
    # ISO 527 define la deformación de rotura cuando el esfuerzo se reduce a
    # un valor <= 10 % de la resistencia; se expone como parámetro editable.
    return _config_float(config, "plastic_break_drop_percent", "break_drop_percent", default=10.0)


def _yield_drop_percent(config: Any) -> float:
    # Parámetro algorítmico auxiliar para reconocer el descenso posterior al
    # primer máximo local. No sustituye el criterio técnico del analista.
    return _config_float(config, "plastic_yield_drop_percent", "yield_drop_percent", "upper_yield_drop_mpa", default=1.0)

def _geometry_area(geometry: Any) -> Optional[float]:
    for name in ("area_mm2", "effective_area_mm2"):
        try:
            value = getattr(geometry, name)
            if callable(value):
                value = value()
            number = _safe_float(value)
            if number and number > 0:
                return float(number)
        except Exception:
            pass
    try:
        value = getattr(geometry, "area_mm2_manual", None)
        number = _safe_float(value)
        if number and number > 0:
            return float(number)
    except Exception:
        pass
    try:
        s1 = _safe_float(getattr(geometry, "side1_mm", None) or getattr(geometry, "thickness_mm", None))
        s2 = _safe_float(getattr(geometry, "side2_mm", None) or getattr(geometry, "width_mm", None))
        if s1 and s2 and s1 > 0 and s2 > 0:
            return float(s1 * s2)
    except Exception:
        pass
    try:
        d = _safe_float(getattr(geometry, "diameter_mm", None))
        if d and d > 0:
            return math.pi * d * d / 4.0
    except Exception:
        pass
    return None


def _gauge_length(geometry: Any) -> float:
    value = _safe_float(getattr(geometry, "gauge_length_mm", None), 50.0)
    return max(float(value or 50.0), 1e-9)


def _source_text(curve: Any) -> str:
    chunks: list[str] = []
    objects = [curve, getattr(curve, "dataset", None), getattr(curve, "raw_df", None), getattr(curve, "df", None)]
    for obj in objects:
        if obj is None:
            continue
        for attr in ("source_path", "path", "filename", "name"):
            try:
                value = getattr(obj, attr, None)
                if value:
                    chunks.append(str(value))
            except Exception:
                pass
        try:
            attrs = getattr(obj, "attrs", None)
            if isinstance(attrs, dict):
                chunks.extend(f"{k} {v}" for k, v in attrs.items())
        except Exception:
            pass
    try:
        chunks.append(str(getattr(curve, "specimen_id", "")))
    except Exception:
        pass
    for obj in (curve, getattr(curve, "dataset", None)):
        try:
            meta = getattr(obj, "meta", None) or {}
            if isinstance(meta, dict):
                chunks.extend(f"{k} {v}" for k, v in meta.items())
        except Exception:
            pass
    return " ".join(chunks).lower()


def _source_path(curve: Any) -> Optional[Path]:
    for obj in (curve, getattr(curve, "dataset", None), getattr(curve, "raw_df", None), getattr(curve, "df", None)):
        if obj is None:
            continue
        for attr in ("source_path", "path", "filename"):
            try:
                value = getattr(obj, attr, None)
                if value:
                    path = Path(str(value))
                    if path.exists() and path.is_file():
                        return path
            except Exception:
                pass
        try:
            attrs = getattr(obj, "attrs", None)
            if isinstance(attrs, dict):
                value = attrs.get("source_path") or attrs.get("path")
                if value:
                    path = Path(str(value))
                    if path.exists() and path.is_file():
                        return path
        except Exception:
            pass
    return None


def _csv_force_unit(curve: Any) -> Optional[str]:
    """Lee la unidad real de la columna Carga del CSV original si está disponible."""
    path = _source_path(curve)
    if path is None:
        return None
    try:
        lines = path.read_text(encoding="latin1", errors="ignore").splitlines()
    except Exception:
        return None
    for i, line in enumerate(lines[:-1]):
        norm = line.strip().lower().replace("\ufeff", "")
        if '"tiempo"' in norm and '"carga"' in norm:
            unit_line = lines[i + 1].strip().lower().replace('"', '').replace(" ", "")
            parts = [p.strip() for p in unit_line.split(",")]
            if len(parts) >= 2:
                if parts[1] == "n":
                    return "N"
                if parts[1] == "kn":
                    return "kN"
    return None


def _prepare_df(curve: Any, geometry: Any) -> tuple[pd.DataFrame, dict[str, Any]]:
    raw = getattr(curve, "raw_df", None)
    if raw is None:
        raw = getattr(curve, "df", None)
    if raw is None:
        raise ValueError("La curva no contiene datos tabulares.")
    df = raw.copy()

    if "elongation_mm" not in df.columns:
        for c in df.columns:
            text = str(c).lower()
            if "elong" in text or "alarg" in text or "despl" in text or text in {"x", "stroke"}:
                df["elongation_mm"] = df[c]
                break
    if "load_kN" not in df.columns:
        for c in df.columns:
            text = str(c).lower()
            if "load" in text or "fuerza" in text or "carga" in text or text in {"force", "y"}:
                df["load_kN"] = df[c]
                break
    for column in ("elongation_mm", "load_kN"):
        if column not in df.columns:
            raise ValueError(f"No se encontró la columna requerida {column}.")
        df[column] = pd.to_numeric(df[column], errors="coerce")
    df = df.dropna(subset=["elongation_mm", "load_kN"]).reset_index(drop=True)
    if df.empty:
        raise ValueError("La curva no contiene datos numéricos válidos.")

    area = _geometry_area(geometry)
    if not area or area <= 0:
        raise ValueError("No se pudo calcular el área de la sección para obtener esfuerzo.")

    load = df["load_kN"].astype(float).to_numpy()
    unit_from_csv = _csv_force_unit(curve)
    source = _source_text(curve)
    max_abs_load = float(np.nanmax(np.abs(load))) if len(load) else 0.0
    # Prioridad: unidad declarada por el CSV. Respaldo: metadatos/material y magnitud.
    if unit_from_csv in {"N", "kN"}:
        force_unit = unit_from_csv
    elif "caucho" in source or "rubber" in source or "tipo d" in source or "type d" in source or max_abs_load > 20.0:
        force_unit = "N"
    else:
        force_unit = "kN"
    factor_to_newton = 1.0 if force_unit == "N" else 1000.0
    stress = load * factor_to_newton / float(area)
    df["stress_MPa"] = stress

    # Sincronizar la corrección con el DataFrame de la curva para que gráfica,
    # arrastre y reportes usen la misma escala.
    for target in (raw, getattr(curve, "raw_df", None), getattr(curve, "df", None), getattr(curve, "data", None), getattr(curve, "dataframe", None)):
        try:
            if target is not None and len(target) == len(stress):
                target["stress_MPa"] = stress
                target.attrs["iso527_force_unit"] = force_unit
        except Exception:
            pass
    return df, {"area_mm2": float(area), "load_unit_interpreted": force_unit}


def _max_index(stress: np.ndarray) -> int:
    if len(stress) == 0:
        return 0
    arr = np.asarray(stress, dtype=float)
    max_value = float(np.nanmax(arr))
    tol = max(1e-9, abs(max_value) * 1e-6)
    hits = np.flatnonzero(np.isfinite(arr) & (np.abs(arr - max_value) <= tol))
    return int(hits[-1]) if hits.size else int(np.nanargmax(arr))


def _point(df: pd.DataFrame, index: int, *, label: str, mode: str, source: str = "auto") -> dict[str, Any]:
    index = max(0, min(int(index), len(df) - 1))
    return {
        "label": label,
        "mode": mode,
        "index": index,
        "x_mm": float(df.loc[index, "elongation_mm"]),
        "stress_mpa": float(df.loc[index, "stress_MPa"]),
        "strain_pct": float(df.loc[index, "strain_pct"]),
        "source": source,
    }


def _index_at_strain(strain: np.ndarray, target_pct: float) -> int:
    if len(strain) == 0:
        return 0
    finite = np.isfinite(strain)
    if not finite.any():
        return 0
    return int(np.nanargmin(np.abs(strain - float(target_pct))))


def _point_at_strain(df: pd.DataFrame, target_pct: float, *, label: str, mode: str, gauge_mm: float, clip_nonnegative: bool = False) -> dict[str, Any]:
    """Punto por interpolación lineal a una deformación objetivo."""
    x_target = float(gauge_mm) * float(target_pct) / 100.0
    x = df["elongation_mm"].astype(float).to_numpy()
    y = df["stress_MPa"].astype(float).to_numpy()
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if len(x) == 0:
        idx = 0
        stress = 0.0
        x_out = x_target
    else:
        order = np.argsort(x)
        x_sorted = x[order]
        y_sorted = y[order]
        # Eliminar duplicados de x conservando el primer valor útil para np.interp.
        unique_x, unique_idx = np.unique(x_sorted, return_index=True)
        unique_y = y_sorted[unique_idx]
        if len(unique_x) == 1:
            x_out = float(unique_x[0])
            stress = float(unique_y[0])
        else:
            x_out = float(np.clip(x_target, float(unique_x[0]), float(unique_x[-1])))
            stress = float(np.interp(x_out, unique_x, unique_y))
        idx = int(np.nanargmin(np.abs(df["elongation_mm"].astype(float).to_numpy() - x_out)))
    if clip_nonnegative and stress < 0:
        stress = 0.0
    return {
        "label": label,
        "mode": mode,
        "index": idx,
        "x_mm": float(x_out),
        "stress_mpa": float(stress),
        "strain_pct": float(target_pct),
        "source": "auto_interpolated",
    }


def _first_local_yield(stress: np.ndarray, strain: np.ndarray, *, drop_percent: float = 1.0) -> Optional[int]:
    """Primer máximo local compatible con punto de fluencia ISO 527."""
    if len(stress) < 8:
        return None
    stress = np.asarray(stress, dtype=float)
    strain = np.asarray(strain, dtype=float)
    max_i = _max_index(stress)
    # La fluencia debe aparecer antes de la resistencia máxima final o en la zona de primer pico.
    end = max(4, min(max_i if max_i > 8 else len(stress) - 2, len(stress) - 2))
    if end <= 4:
        return None
    rng = max(float(np.nanmax(stress) - np.nanmin(stress)), 1e-9)
    drop_threshold = max(0.12, max(float(drop_percent), 0.001) / 100.0 * rng)
    segment = stress[: end + 2]
    candidates = np.where((segment[1:-1] >= segment[:-2]) & (segment[1:-1] >= segment[2:]))[0] + 1
    candidates = candidates[candidates >= 3]
    if candidates.size:
        for i in candidates[:2000]:
            look = stress[i + 1 : min(len(stress), i + 31)]
            if look.size and float(stress[i] - np.nanmin(look)) >= drop_threshold:
                return int(i)
    return None


def _break_index(df: pd.DataFrame, max_i: int, *, drop_percent: float = 10.0) -> int:
    """Último punto válido de rotura/fin antes de descarga brusca, si existe."""
    stress = df["stress_MPa"].astype(float).to_numpy()
    if len(stress) == 0:
        return 0
    max_i = max(0, min(int(max_i), len(stress) - 1))
    max_stress = max(float(stress[max_i]), 1e-12)
    threshold = max(0.0, float(drop_percent) / 100.0) * max_stress
    # Si hay descarga a ≤ X % después del máximo, la rotura se registra en el punto anterior.
    tail = np.arange(max_i + 1, len(stress), dtype=int)
    if tail.size:
        hits = tail[np.isfinite(stress[tail]) & (stress[tail] <= threshold)]
        if hits.size:
            return max(max_i, int(hits[0]) - 1)
    finite = np.flatnonzero(np.isfinite(stress))
    return int(finite[-1]) if finite.size else max_i


def _modulus_between(df: pd.DataFrame, e1: float = 0.05, e2: float = 0.25) -> dict[str, Any]:
    strain = df["strain_pct"].astype(float).to_numpy()
    stress = df["stress_MPa"].astype(float).to_numpy()
    i1 = _index_at_strain(strain, e1)
    i2 = _index_at_strain(strain, e2)
    if i2 <= i1:
        i2 = min(len(df) - 1, i1 + 1)
    x = strain[i1 : i2 + 1] / 100.0
    y = stress[i1 : i2 + 1]
    slope = None
    r2 = None
    if len(x) >= 2 and np.nanmax(x) > np.nanmin(x):
        coeff = np.polyfit(x, y, 1)
        slope = float(coeff[0])
        pred = np.polyval(coeff, x)
        ss_res = float(np.nansum((y - pred) ** 2))
        ss_tot = float(np.nansum((y - np.nanmean(y)) ** 2))
        r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else None
    if slope is None or not math.isfinite(slope):
        s1, s2 = stress[i1], stress[i2]
        e1f, e2f = strain[i1] / 100.0, strain[i2] / 100.0
        slope = float((s2 - s1) / max(e2f - e1f, 1e-12))
    return {"modulus_mpa": slope, "modulus_gpa": slope / 1000.0, "modulus_r2": r2, "modulus_indices": {"a": i1, "b": i2}}


def _classify(curve: Any, df: pd.DataFrame, *, yield_drop_percent: float = 1.0) -> dict[str, Any]:
    text = _source_text(curve)
    scores = {"A": 0, "B": 0, "C": 0, "D": 0}
    # Los nombres de archivo/metadatos son una ayuda, no una imposición absoluta.
    if re.search(r"tipo\s*a|type\s*a|\b4a\b", text): scores["A"] += 25
    if re.search(r"tipo\s*b|type\s*b|\b4b\b", text): scores["B"] += 25
    if re.search(r"tipo\s*c|type\s*c|\b4c\b|6259|tuber|pe-?100", text): scores["C"] += 25
    if re.search(r"tipo\s*d|type\s*d|\b4d\b|elast|caucho|rubber", text): scores["D"] += 100

    strain = df["strain_pct"].to_numpy(float)
    stress = df["stress_MPa"].to_numpy(float)
    max_strain = float(np.nanmax(strain)) if len(strain) else 0.0
    max_stress = float(np.nanmax(stress)) if len(stress) else 0.0
    max_i = _max_index(stress)
    yield_i = _first_local_yield(stress, strain, drop_percent=yield_drop_percent)

    if yield_i is not None:
        yield_stress = float(stress[yield_i])
        # Tipo B: fluencia inicial seguida de endurecimiento claro hasta una σM mayor.
        if max_i > yield_i + 5 and max_stress >= yield_stress * 1.05 and max_strain > 40:
            scores["B"] += 55
        # Tipo C: fluencia con plateau/descenso; σM coincide o casi coincide con σY.
        elif max_strain > 40:
            scores["C"] += 55
        else:
            scores["B"] += 20
            scores["C"] += 15
    else:
        if max_strain <= 50:
            scores["A"] += 60
        elif ("caucho" in text or "rubber" in text or "tipo d" in text or "type d" in text or max_stress < 25) and max_strain > 100:
            scores["D"] += 45
        elif max_strain > 250:
            scores["D"] += 25
        else:
            scores["A"] += 20

    if max_strain <= 25 and yield_i is None:
        scores["A"] += 20
    if max_strain > 300 and ("caucho" in text or max_stress < 25):
        scores["D"] += 20

    detected = max(scores, key=lambda k: scores[k])
    confidence = "Alta" if scores[detected] >= 60 else ("Media" if scores[detected] >= 30 else "Baja")
    reason = (
        f"Clasificación por forma de curva y metadatos: deformación máx. {max_strain:.1f} %, "
        f"esfuerzo máx. {max_stress:.2f} MPa."
    )
    return {"detected_type": detected, "confidence": confidence, "reason": reason, "scores": scores, "yield_index_candidate": yield_i}


def _method_result(method: str, value: Optional[float], max_value: Optional[float], scalar: dict[str, Any], points: list[dict[str, Any]]) -> TensileMethodResult:
    primary_index = None
    primary_x = None
    primary_mode = scalar.get("primary_mode")
    for p in points:
        if p.get("mode") == primary_mode:
            primary_index = p.get("index")
            primary_x = p.get("x_mm")
            break
    return TensileMethodResult(
        method=method,
        is_available=value is not None,
        value_mpa=value,
        max_stress_mpa=max_value,
        elastic_modulus_gpa=scalar.get("modulus_gpa"),
        elongation_after_break_pct=scalar.get("break_strain_pct") or scalar.get("sigma_m_or_b_strain_pct"),
        diagnostics={
            "plastic_mode": True,
            "plastic_type": scalar.get("applied_type"),
            "plastic_scalar": scalar,
            "plastic_points": points,
            "plastic_primary_label": scalar.get("primary_label"),
            "plastic_primary_mode": scalar.get("primary_mode"),
            "point_index": primary_index,
            "point_x_mm": primary_x,
            "point_source": "auto",
            "rp_label": f"σx {scalar.get('type_d_x_percent', '')}%".strip(),
        },
    )


def _type_d_x_percent(config: Any) -> float:
    raw = _safe_float(getattr(config, "offset_percent", None), None)
    # El valor heredado 0,2 % pertenece al Rp0,2 metálico; en Tipo D no debe
    # usarse como σx por defecto. Si no hay valor explícito útil, usar X = 100 %.
    if raw is None or raw <= 1.0:
        return 100.0
    return float(raw)


def analyze_plastic_curve(curve: Any, geometry: Any, config: Any) -> TensileUnifiedResult:
    df, base_diag = _prepare_df(curve, geometry)
    gauge = _gauge_length(geometry)
    df["strain_pct"] = df["elongation_mm"].astype(float) / gauge * 100.0
    stress = df["stress_MPa"].astype(float).to_numpy()
    strain = df["strain_pct"].astype(float).to_numpy()
    max_i = _max_index(stress)
    e1_pct = _modulus_e1_pct(config)
    e2_pct = _modulus_e2_pct(config)
    break_drop_pct = _break_drop_percent(config)
    yield_drop_pct = _yield_drop_percent(config)
    class_info = _classify(curve, df, yield_drop_percent=yield_drop_pct)
    active = str(getattr(config, "active_method", PLASTIC_AUTO) or PLASTIC_AUTO)
    applied = TYPE_BY_METHOD.get(active) or class_info["detected_type"]
    method = METHOD_BY_TYPE.get(applied, PLASTIC_TYPE_A)
    points: list[dict[str, Any]] = []
    scalar: dict[str, Any] = {
        "applied_type": applied,
        "modulus_e1_pct": float(e1_pct),
        "modulus_e2_pct": float(e2_pct),
        "break_drop_percent": float(break_drop_pct),
        "yield_drop_percent": float(yield_drop_pct),
        **base_diag,
    }
    mod = _modulus_between(df, e1_pct, e2_pct)

    if applied == "A":
        # Curva A: según la figura típica, σM y σB coinciden en el punto máximo;
        # εB se toma en el punto de rotura/fin previo a descarga si existe.
        break_i = _break_index(df, max_i, drop_percent=break_drop_pct)
        points = [_point(df, max_i, label="σM/σB", mode="max")]
        for label, mode, idx in ((format_default_label("mod_e1", e1_pct=e1_pct), "mod_e1", mod["modulus_indices"]["a"]), (format_default_label("mod_e2", e2_pct=e2_pct), "mod_e2", mod["modulus_indices"]["b"])):
            points.append(_point(df, idx, label=label, mode=mode))
        scalar.update({
            "primary_label": "Esfuerzo máximo/rotura σM/σB", "primary_mode": "max", "primary_stress_mpa": float(stress[max_i]),
            "max_stress_mpa": float(stress[max_i]), "strain_at_max_pct": float(strain[max_i]), "max_strain_pct": float(strain[max_i]),
            "break_stress_mpa": float(stress[max_i]), "break_strain_pct": float(strain[break_i]),
            **mod,
        })
    elif applied == "D":
        x_percent = _type_d_x_percent(config)
        p1 = _point_at_strain(df, e1_pct, label=format_default_label("sigma1", e1_pct=e1_pct), mode="sigma1", gauge_mm=gauge, clip_nonnegative=True)
        p2 = _point_at_strain(df, e2_pct, label=format_default_label("sigma2", e2_pct=e2_pct), mode="sigma2", gauge_mm=gauge, clip_nonnegative=True)
        px = _point_at_strain(df, x_percent, label=f"σx ({x_percent:g}%)", mode="sigmax", gauge_mm=gauge, clip_nonnegative=True)
        pmax = _point(df, max_i, label="σm/σb", mode="max")
        points = [p1, p2, px, pmax]
        # Módulo secante entre σ1 y σ2 para trazabilidad de la zona inicial.
        denom = max((float(p2["strain_pct"]) - float(p1["strain_pct"])) / 100.0, 1e-12)
        modulus_mpa = (float(p2["stress_mpa"]) - float(p1["stress_mpa"])) / denom
        scalar.update({
            "primary_label": "Esfuerzo máximo/rotura σm/σb", "primary_mode": "max", "primary_stress_mpa": float(stress[max_i]),
            "max_stress_mpa": float(stress[max_i]), "max_strain_pct": float(strain[max_i]),
            "sigma_m_or_b_stress_mpa": float(stress[max_i]), "sigma_m_or_b_strain_pct": float(strain[max_i]),
            "sigma1_stress_mpa": float(p1["stress_mpa"]), "sigma1_strain_pct": float(p1["strain_pct"]),
            "sigma2_stress_mpa": float(p2["stress_mpa"]), "sigma2_strain_pct": float(p2["strain_pct"]),
            "sigmax_stress_mpa": float(px["stress_mpa"]), "sigmax_strain_pct": float(px["strain_pct"]), "type_d_x_percent": float(x_percent),
            "modulus_mpa": float(modulus_mpa), "modulus_gpa": float(modulus_mpa) / 1000.0,
        })
    else:
        yi = class_info.get("yield_index_candidate")
        if yi is None:
            # Si el usuario fuerza Tipo B/C pero no hay fluencia detectable, usar el máximo.
            yi = max_i
        yi = int(yi)
        break_i = _break_index(df, max_i, drop_percent=break_drop_pct)
        points = [_point(df, yi, label="σY", mode="yield"), _point(df, max_i, label="σM", mode="max")]
        scalar.update({
            "primary_label": "Esfuerzo de fluencia σY", "primary_mode": "yield", "primary_stress_mpa": float(stress[yi]),
            "yield_stress_mpa": float(stress[yi]), "yield_strain_pct": float(strain[yi]),
            "max_stress_mpa": float(stress[max_i]), "max_strain_pct": float(strain[max_i]),
            **mod,
        })
        if applied == "C":
            points.append(_point(df, break_i, label="σB", mode="break"))
            scalar.update({"break_stress_mpa": float(stress[break_i]), "break_strain_pct": float(strain[break_i])})

    scalar["plastic_table_rows"] = points
    selected = _method_result(method, scalar.get("primary_stress_mpa"), scalar.get("max_stress_mpa"), scalar, points)
    upper = _method_result(PLASTIC_TYPE_B, scalar.get("yield_stress_mpa") or scalar.get("primary_stress_mpa"), scalar.get("max_stress_mpa"), scalar, points)
    rp = _method_result(PLASTIC_TYPE_A, scalar.get("max_stress_mpa") or scalar.get("primary_stress_mpa"), scalar.get("max_stress_mpa"), scalar, points)
    detection = {
        **class_info,
        "suggested_method": METHOD_BY_TYPE.get(class_info.get("detected_type"), PLASTIC_TYPE_A),
        "applied_type": applied,
        "applied_method": method,
        "display_method": TYPE_LABEL.get(applied, applied),
        "reason": class_info.get("reason"),
    }
    diag = {
        "plastic_mode": True,
        "plastic_type": applied,
        "plastic_scalar": scalar,
        "plastic_points": points,
        "max_index": int(max_i),
        "max_elongation_mm": float(df.loc[max_i, "elongation_mm"]),
        **base_diag,
    }
    return TensileUnifiedResult(upper, rp, selected, method_detection=detection, diagnostics=diag)


def plastic_comment(applied_type: str, scalar: dict[str, Any] | None = None) -> str:
    scalar = scalar or {}
    applied_type = str(applied_type or "").upper()
    if applied_type == "A":
        return "Curva clasificada como Tipo A. Se reporta σM/σB, εB y el módulo en el intervalo inicial ISO 527."
    if applied_type == "B":
        return "Curva clasificada como Tipo B. Se identifica σY como primer máximo local y σM como resistencia máxima posterior."
    if applied_type == "C":
        return "Curva clasificada como Tipo C. Se reportan σY, σM y σB para comportamiento con fluencia y rotura/fin a menor esfuerzo."
    if applied_type == "D":
        x = scalar.get("type_d_x_percent", 100)
        e1 = scalar.get("modulus_e1_pct", 0.05)
        e2 = scalar.get("modulus_e2_pct", 0.25)
        return f"Curva clasificada como Tipo D. Se reportan σ1 a {float(e1):g} %, σ2 a {float(e2):g} %, σx a {float(x):g} % y σm/σb."
    return "Análisis de tracción de plásticos con clasificación A/B/C/D y puntos característicos ISO 527."


def get_plastic_default_comment(shape: Any = None, method: Any = None, context: dict[str, Any] | None = None) -> str:
    type_guess = TYPE_BY_METHOD.get(str(method or ""), "")
    return plastic_comment(type_guess, context or {})


__all__ = [
    "PLASTIC_AUTO", "PLASTIC_TYPE_A", "PLASTIC_TYPE_B", "PLASTIC_TYPE_C", "PLASTIC_TYPE_D",
    "TYPE_BY_METHOD", "METHOD_BY_TYPE", "TYPE_LABEL", "analyze_plastic_curve", "plastic_comment", "get_plastic_default_comment",
]
