from __future__ import annotations

"""Etiquetas editables para puntos característicos ISO 527.

Se separa la etiqueta corta de gráfica de la descripción técnica que se muestra
al auditor/usuario en la tabla de edición. El archivo JSON de usuario permite
persistir la decisión mediante "Guardar como predeterminado" sin tocar el
motor de cálculo.
"""

from pathlib import Path
from typing import Any
import json
import os

DEFAULT_POINT_LABELS: dict[str, str] = {
    "yield": "σY Fluencia",
    "max": "σM Máximo",
    "break": "σB Rotura",
    "sigma1": "σ1 a ε1",
    "sigma2": "σ2 a ε2",
    "sigmax": "σx a εx",
    "mod_e1": "ε1 módulo",
    "mod_e2": "ε2 módulo",
}

POINT_LABEL_DESCRIPTIONS: dict[str, str] = {
    "yield": "Primer máximo local donde aparece fluencia, cuando la curva lo presenta.",
    "max": "Mayor esfuerzo de la curva o resistencia máxima registrada.",
    "break": "Esfuerzo asociado a rotura o final de ensayo previo a la descarga definida.",
    "sigma1": "Esfuerzo interpolado en la deformación ε1 usada para el módulo.",
    "sigma2": "Esfuerzo interpolado en la deformación ε2 usada para el módulo.",
    "sigmax": "Esfuerzo interpolado en la deformación especificada εx, editable para Tipo D.",
    "mod_e1": "Punto inicial del intervalo de cálculo del módulo de elasticidad en tracción.",
    "mod_e2": "Punto final del intervalo de cálculo del módulo de elasticidad en tracción.",
}

POINT_ORDER: tuple[str, ...] = ("yield", "max", "break", "sigma1", "sigma2", "sigmax", "mod_e1", "mod_e2")


def _settings_dir() -> Path:
    raw = os.environ.get("LEMATZIUM_SETTINGS_DIR") or os.environ.get("APPDATA")
    if raw:
        return Path(raw) / "LEMATZIUM"
    return Path.home() / ".lematzium"


def point_labels_path() -> Path:
    return _settings_dir() / "traccion_plasticos_point_labels.json"


def load_point_labels() -> dict[str, str]:
    labels = dict(DEFAULT_POINT_LABELS)
    path = point_labels_path()
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for key, value in data.items():
                    if key in labels and str(value).strip():
                        labels[key] = str(value).strip()
    except Exception:
        pass
    return labels


def save_point_labels(labels: dict[str, Any]) -> Path:
    clean = dict(DEFAULT_POINT_LABELS)
    for key, value in (labels or {}).items():
        if key in clean and str(value).strip():
            clean[key] = str(value).strip()
    path = point_labels_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def reset_point_labels() -> Path:
    path = point_labels_path()
    try:
        if path.exists():
            path.unlink()
    except Exception:
        pass
    return path


def format_default_label(mode: str, *, e1_pct: float | None = None, e2_pct: float | None = None, ex_pct: float | None = None) -> str:
    """Etiqueta técnica predeterminada con los porcentajes actuales."""
    try:
        if mode in {"sigma1", "mod_e1"} and e1_pct is not None:
            return f"{'σ1' if mode == 'sigma1' else 'ε1'} ({float(e1_pct):g} %)"
        if mode in {"sigma2", "mod_e2"} and e2_pct is not None:
            return f"{'σ2' if mode == 'sigma2' else 'ε2'} ({float(e2_pct):g} %)"
        if mode == "sigmax" and ex_pct is not None:
            return f"σx ({float(ex_pct):g} %)"
    except Exception:
        pass
    return DEFAULT_POINT_LABELS.get(mode, mode)
