# Módulo 2 - Tracción plásticos 1.0.0

Módulo ISO 527 para análisis de curvas de tracción en plásticos dentro de LEMATZIUM.

Funciones principales:

- clasificación automática o manual de curvas Tipo A/B/C/D;
- cálculo de esfuerzo, deformación, módulo y puntos característicos;
- parámetros ISO 527 editables desde la interfaz;
- nombres de puntos editables y guardables como predeterminados;
- exportación institucional y gráfica.

Ejecutar desde el launcher principal o directamente con:

```bash
python launch_traccion_plasticos.py
```
