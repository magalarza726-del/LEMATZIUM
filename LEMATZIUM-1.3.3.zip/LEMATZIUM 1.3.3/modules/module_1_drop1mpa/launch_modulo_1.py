from __future__ import annotations

from pathlib import Path
import sys

MODULES_DIR = Path(__file__).resolve().parent.parent
if str(MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(MODULES_DIR))

from shared.bootstrap import run_module_main  # noqa: E402


def main():
    return run_module_main(__file__, "lematzium_modulo1.app.main")


if __name__ == "__main__":
    raise SystemExit(main())
