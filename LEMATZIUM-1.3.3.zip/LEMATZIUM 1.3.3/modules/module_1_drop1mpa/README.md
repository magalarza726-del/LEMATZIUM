# LEMATZIUM - Módulo 1 v1.2.0

Módulo independiente para:
- cálculo automático del punto de fluencia por **caída de 1 MPa**
- cálculo automático del **punto máximo**
- **zoom con scroll**
- **arrastre manual independiente** de fluencia y máximo
- preservación del **nivel actual de zoom** al seleccionar o arrastrar puntos manuales
- **formato dinámico con decimales** en ejes al acercar la gráfica
- recuperación de los campos de **Datos del ensayo**, **N° de orden** y **Comentario**
- memoria independiente por curva/probeta
- autoajuste de la vista en tiempo real y exportación siempre desde `0,0`
- exportación automática de informes DOCX con plantillas MC acreditada y no acreditada
- agrupación flexible de probetas por informe desde un planeador de exportación

## Estructura
- `lematzium_modulo1/app`: arranque de aplicación
- `lematzium_modulo1/assays/tensile_drop_1mpa`: contratos, lector, cálculo y controlador
- `lematzium_modulo1/ui`: interfaz y diálogo de exportación
- `lematzium_modulo1/reports`: exportador DOCX automático y lógica de plantillas
- `lematzium_modulo1/templates`: plantillas MC institucionales

## Ejecución local
```bash
pip install -r requirements.txt
python launch_modulo_1.py
```

## Nota
La depuración actual eliminó los scripts de acceso directo e iconos independientes del módulo. El flujo oficial es abrir este módulo desde el launcher de LEMATZIUM.
