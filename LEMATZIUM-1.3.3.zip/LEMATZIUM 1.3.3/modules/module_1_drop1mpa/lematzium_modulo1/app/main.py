from __future__ import annotations


def main() -> int:
    from lematzium_modulo1.assays.tensile_drop_1mpa.controller import TensileDrop1MPaController
    from lematzium_modulo1.ui.main_window import TensileDrop1MPaWindow

    controller = TensileDrop1MPaController()
    window = TensileDrop1MPaWindow(controller=controller)
    window.run()
    return 0
