from __future__ import annotations

from pathlib import Path
import sys
from typing import Any, Dict

MODULES_DIR = Path(__file__).resolve().parents[3]
if str(MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(MODULES_DIR))

from shared.preferences import APP_DIR_NAME, EXPORT_OUTPUT_DIR_KEY, PreferenceStore  # noqa: E402

PREFS_FILENAME = "modulo1_user_prefs.json"
_STORE = PreferenceStore(PREFS_FILENAME)


def get_user_prefs_path() -> Path:
    return _STORE.path


def load_user_prefs() -> Dict[str, Any]:
    return _STORE.load()


def save_user_prefs(prefs: Dict[str, Any]) -> None:
    _STORE.save(prefs)


def load_last_export_output_dir() -> str:
    return _STORE.get_text(EXPORT_OUTPUT_DIR_KEY)


def save_last_export_output_dir(output_dir: str) -> None:
    _STORE.set_text(EXPORT_OUTPUT_DIR_KEY, output_dir)


__all__ = [
    "APP_DIR_NAME",
    "EXPORT_OUTPUT_DIR_KEY",
    "PREFS_FILENAME",
    "get_user_prefs_path",
    "load_last_export_output_dir",
    "load_user_prefs",
    "save_last_export_output_dir",
    "save_user_prefs",
]
