"""Wrappers de compatibilidad para normalizar estructura del módulo 1."""
