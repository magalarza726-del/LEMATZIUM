"""Punto de extensión reservado para utilidades comunes del módulo 1."""
