from lematzium_modulo1.ui.theme import *  # noqa: F401,F403
