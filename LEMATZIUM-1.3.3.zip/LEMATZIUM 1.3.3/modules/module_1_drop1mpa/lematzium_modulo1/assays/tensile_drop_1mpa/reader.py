from __future__ import annotations

import csv
import io
import math
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .contracts import CurveState, Geometry, ParsedDataset, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
try:
    from shared.tensile_geometry import SHAPE_CIRCULAR, shape_from_headers
except ModuleNotFoundError:
    SHAPE_CIRCULAR = "Circular"
    def shape_from_headers(headers, export_shape=None):
        return normalize_shape(export_shape)


SUPPORTED_TEXT_EXTENSIONS = {".csv", ".txt", ".tsv", ".dat", ".prn"}
SUPPORTED_EXCEL_EXTENSIONS = {".xlsx", ".xlsm", ".xltx", ".xltm", ".xls", ".xlsb"}
SUPPORTED_INPUT_EXTENSIONS = SUPPORTED_TEXT_EXTENSIONS | SUPPORTED_EXCEL_EXTENSIONS


class FileReadError(RuntimeError):
    pass


class ParseError(RuntimeError):
    pass


def as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    return str(value).replace("\ufeff", "").strip()


def as_float(value: Any, default: float = np.nan) -> float:
    if value is None:
        return default
    if isinstance(value, (int, float, np.integer, np.floating)):
        try:
            return float(value)
        except Exception:
            return default
    s = as_text(value)
    if not s:
        return default
    s = s.replace(" ", "")
    s = s.replace(",", ".")
    s = _UNIT_SUFFIX_RE.sub("", s).strip()
    try:
        return float(s)
    except Exception:
        return default


def is_blank_row(row: Sequence[Any]) -> bool:
    return all(as_text(x) == "" for x in row)


def normalize_row(row: Sequence[Any]) -> List[str]:
    return [as_text(x) for x in row]


def make_unique_name(base: str, seen: Dict[str, int]) -> str:
    base = as_text(base) or "Specimen"
    count = seen.get(base, 0) + 1
    seen[base] = count
    return base if count == 1 else f"{base}_R{count}"


TEXT_ENCODINGS = ("utf-8-sig", "utf-8", "cp1252", "latin-1")
TEXT_DELIMITERS = (",", ";", "\t", "|")

_NUMERIC_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")
_BLOCK_ID_RE = re.compile(r"^\d+\s*-\s*\d+$")
_SPECIMEN_ID_RE = re.compile(r"^\d{2}-\d{4}$")
_UNIT_SUFFIX_RE = re.compile(r"(?i)(mm|mpa|kn|seg|s|%)$")


def decode_text_bytes(content: bytes) -> tuple[str, str]:
    """Decodifica exportaciones de máquina con codificaciones conocidas.

    Los CSV de Trapezium/LEMATZIUM pueden venir en cp1252 o latin-1; otros
    archivos pueden venir en utf-8-sig. Se conserva el texto completo para que
    csv.reader procese correctamente comentarios multilínea entre comillas.
    """
    last_error: Exception | None = None
    for encoding in TEXT_ENCODINGS:
        try:
            return content.decode(encoding), encoding
        except UnicodeDecodeError as exc:
            last_error = exc
    if last_error is not None:
        return content.decode("latin-1", errors="replace"), "latin-1-replace"
    return "", "latin-1"


def _rows_with_delimiter(text: str, delimiter: str) -> list[list[str]]:
    try:
        return list(csv.reader(io.StringIO(text), delimiter=delimiter))
    except csv.Error:
        return []


def _sample_text_for_delimiter(text: str, max_chars: int = 96_000, max_lines: int = 240) -> str:
    """Toma una muestra suficiente para detectar separador sin leer el archivo cuatro veces."""
    if not text:
        return ""
    # Muestra por líneas para evitar cortar innecesariamente archivos pequeños.
    lines = text.splitlines(True)
    if not lines:
        return text[:max_chars]
    sample = "".join(lines[:max_lines])
    if len(sample) < min(len(text), max_chars // 2):
        sample = text[:max_chars]
    return sample[:max_chars]


def detect_delimiter_from_text(text: str) -> str:
    """Detecta el separador en una muestra representativa.

    La versión anterior aplicaba ``csv.reader`` a todo el archivo una vez por
    cada delimitador candidato. En CSV grandes eso multiplicaba el tiempo de
    apertura. Esta versión solo usa una muestra para decidir el separador y el
    archivo completo se procesa una sola vez después, preservando todas las
    filas y celdas originales.
    """
    sample = _sample_text_for_delimiter(text)
    best_delimiter = ","
    best_score: tuple[int, int, int, int] = (-1, -1, -1, -1)
    for delimiter in TEXT_DELIMITERS:
        rows = _rows_with_delimiter(sample, delimiter)
        if not rows:
            continue
        widths = [len(row) for row in rows if any(as_text(cell) for cell in row)]
        if not widths:
            continue
        multi_column_rows = sum(1 for width in widths if width > 1)
        total_columns = sum(widths)
        max_columns = max(widths, default=0)
        # Premia estructuras estables: si muchas filas tienen el mismo ancho,
        # suele ser el delimitador correcto para exportaciones de Trapezium.
        modal_width = max((widths.count(width) for width in set(widths)), default=0)
        score = (multi_column_rows, modal_width, total_columns, max_columns)
        if score > best_score:
            best_score = score
            best_delimiter = delimiter
    return best_delimiter


def read_delimited_rows(path: str | Path) -> list[list[str]]:
    """Lee un CSV/TXT completo como filas, sin convertirlo primero a DataFrame.

    Esto conserva absolutamente toda la información textual, incluyendo celdas
    vacías, comentarios multilínea y valores con coma decimal; solo evita la
    conversión temprana a pandas cuando el archivo es una exportación de máquina.
    """
    raw = Path(path).read_bytes()
    text, _encoding = decode_text_bytes(raw)
    delimiter = detect_delimiter_from_text(text)
    rows = _rows_with_delimiter(text, delimiter)
    if not rows:
        raise FileReadError("No se encontraron filas legibles en el archivo de texto.")
    max_width = max((len(row) for row in rows), default=0)
    if max_width <= 0:
        raise FileReadError("No se encontraron columnas legibles en el archivo de texto.")
    return [row + [""] * (max_width - len(row)) for row in rows]


def read_delimited_text(path: str | Path) -> pd.DataFrame:
    return pd.DataFrame(read_delimited_rows(path), dtype=str)

def read_any_table(path: str | Path, sheet_name: Optional[str] = None) -> pd.DataFrame:
    path = Path(path)
    ext = path.suffix.lower()

    if ext not in SUPPORTED_INPUT_EXTENSIONS:
        raise FileReadError(f"Extensión no soportada: {ext}")

    if ext in SUPPORTED_TEXT_EXTENSIONS:
        return read_delimited_text(path)

    engine_candidates: List[Tuple[str, Dict[str, Any]]] = []
    if ext == ".xlsb":
        engine_candidates = [("pyxlsb", {})]
    elif ext == ".xls":
        engine_candidates = [("xlrd", {})]
    else:
        engine_candidates = [("openpyxl", {"read_only": True, "data_only": True})]

    last_error = None
    for engine, kwargs in engine_candidates:
        try:
            excel_file = pd.ExcelFile(path, engine=engine, engine_kwargs=kwargs if kwargs else None)
            sheet = sheet_name or excel_file.sheet_names[0]
            return pd.read_excel(excel_file, sheet_name=sheet, header=None, dtype=str, keep_default_na=False)
        except Exception as exc:
            last_error = exc
    raise FileReadError(f"No se pudo leer el archivo Excel: {last_error}")


def dataframe_to_rows(df: pd.DataFrame) -> List[List[str]]:
    """Convierte DataFrame a matriz de texto evitando iterrows(), que es lento."""
    if df is None or df.empty:
        return []
    values = df.fillna("").to_numpy(dtype=object, copy=False)
    return [[as_text(cell) for cell in row] for row in values]


def first_nonempty_index(rows: List[List[str]], predicate, start: int = 0) -> Optional[int]:
    for i in range(start, len(rows)):
        if predicate(rows[i]):
            return i
    return None


def _looks_like_specimen_name(text: str) -> bool:
    value = as_text(text).strip()
    if not value:
        return False
    lower = value.lower().rstrip(":")
    forbidden = {"titulo", "forma", "nombre", "parametro", "unidades", "unidad de longitud", "tiempo", "seg"}
    if lower in forbidden:
        return False
    block_match = re.match(r"^(\d+)\s*-\s*(\d+)$", value)
    if block_match:
        left, right = block_match.groups()
        if len(left) <= 2 and len(right) <= 2:
            return False
    return True


def _header_index(headers: List[str], *needles: str) -> Optional[int]:
    normalized = [h.lower().replace(":", "").strip() for h in headers]
    for idx, cell in enumerate(normalized):
        if any(needle in cell for needle in needles):
            return idx
    return None


def _export_shape_before_geometry(rows: List[List[str]], geometry_header_idx: int) -> Optional[str]:
    start = max(0, geometry_header_idx - 8)
    for idx in range(start, geometry_header_idx):
        row = rows[idx]
        first = as_text(row[0]).lower().replace(":", "") if row else ""
        if first == "forma":
            if idx + 1 < geometry_header_idx and rows[idx + 1]:
                return as_text(rows[idx + 1][0])
        if idx > 0:
            prev = rows[idx - 1]
            prev_first = as_text(prev[0]).lower().replace(":", "") if prev else ""
            if prev_first == "forma":
                return as_text(row[0])
    return None


def _geometry_from_row(row: List[str], headers: List[str], export_shape: Optional[str]) -> Geometry:
    thickness_idx = _header_index(headers, "espesor", "thickness", "lado 1")
    width_idx = _header_index(headers, "anchura", "ancho", "width", "lado 2")
    diameter_idx = _header_index(headers, "diámetro", "diametro", "diameter")
    area_idx = _header_index(headers, "área", "area")
    gauge_idx = _header_index(headers, "longitud", "calibrada", "gauge")

    gauge = as_float(row[gauge_idx]) if gauge_idx is not None and len(row) > gauge_idx else np.nan
    shape = shape_from_headers(headers, export_shape)

    if diameter_idx is not None:
        diameter = as_float(row[diameter_idx]) if len(row) > diameter_idx else np.nan
        return Geometry(
            shape=SHAPE_CIRCULAR,
            diameter_mm=diameter if np.isfinite(diameter) else None,
            gauge_length_mm=gauge if np.isfinite(gauge) else None,
        )

    if thickness_idx is not None and width_idx is not None:
        side1 = as_float(row[thickness_idx]) if len(row) > thickness_idx else np.nan
        side2 = as_float(row[width_idx]) if len(row) > width_idx else np.nan
        return Geometry(
            shape=SHAPE_RECTANGULAR,
            side1_mm=side1 if np.isfinite(side1) else None,
            side2_mm=side2 if np.isfinite(side2) else None,
            gauge_length_mm=gauge if np.isfinite(gauge) else None,
        )

    if area_idx is not None:
        area = as_float(row[area_idx]) if len(row) > area_idx else np.nan
        return Geometry(
            shape=SHAPE_IRREGULAR if normalize_shape(shape) != SHAPE_CIRCULAR else SHAPE_IRREGULAR,
            area_mm2_manual=area if np.isfinite(area) else None,
            gauge_length_mm=gauge if np.isfinite(gauge) else None,
        )

    return Geometry(shape=normalize_shape(export_shape), gauge_length_mm=gauge if np.isfinite(gauge) else None)


def parse_machine_export(rows: List[List[str]], source_path: str) -> ParsedDataset:
    meta: Dict[str, Any] = {}

    header_idx = first_nonempty_index(rows, lambda r: len(r) >= 2 and r[0].lower() == "titulo")
    if header_idx is None or header_idx + 1 >= len(rows):
        raise ParseError("No se encontró la cabecera general de la exportación de máquina.")

    for key, value in zip(rows[header_idx], rows[header_idx + 1]):
        key_text = as_text(key)
        if key_text:
            meta[key_text] = as_text(value)

    geometry_header_idx = first_nonempty_index(
        rows,
        lambda r: len(r) >= 3 and as_text(r[0]).lower().startswith("nombre") and (
            any("espesor" in as_text(c).lower() for c in r)
            or any("anchura" in as_text(c).lower() for c in r)
            or any("diámetro" in as_text(c).lower() or "diametro" in as_text(c).lower() for c in r)
            or any("área" in as_text(c).lower() or "area" in as_text(c).lower() for c in r)
        ),
        start=header_idx + 1,
    )
    if geometry_header_idx is None:
        raise ParseError("No se encontró la tabla de geometría.")

    geometry_rows: Dict[str, Geometry] = {}
    geometry_sequence: List[str] = []
    seen_geometry: Dict[str, int] = {}
    geometry_headers = rows[geometry_header_idx]
    export_shape = _export_shape_before_geometry(rows, geometry_header_idx)
    i = geometry_header_idx + 1
    if i < len(rows) and rows[i] and as_text(rows[i][0]).lower().startswith("unidad"):
        i += 1
    while i < len(rows):
        row = rows[i]
        specimen_raw = as_text(row[0]) if len(row) > 0 else ""
        if not _looks_like_specimen_name(specimen_raw):
            break
        specimen = make_unique_name(specimen_raw.strip(), seen_geometry)
        geometry = _geometry_from_row(row, geometry_headers, export_shape)
        geometry_rows[specimen] = geometry
        geometry_sequence.append(specimen)
        i += 1

    result_header_idx = first_nonempty_index(
        rows,
        lambda r: len(r) >= 4 and r[0].lower() == "nombre" and "fluencia" in r[1].lower() and "máximo" in r[2].lower(),
        start=i,
    )
    result_map: Dict[str, Dict[str, Optional[float]]] = {}
    if result_header_idx is not None:
        j = result_header_idx + 3
        seen_results: Dict[str, int] = {}
        while j < len(rows):
            row = rows[j]
            specimen_raw = as_text(row[0]) if len(row) > 0 else ""
            if not specimen_raw:
                break
            if not _SPECIMEN_ID_RE.match(specimen_raw.strip()):
                break
            specimen = make_unique_name(specimen_raw, seen_results)
            result_map[specimen] = {
                "yield_mpa": _nan_to_none(as_float(row[1]) if len(row) > 1 else np.nan),
                "max_mpa": _nan_to_none(as_float(row[2]) if len(row) > 2 else np.nan),
                "elong_pct": _nan_to_none(as_float(row[3]) if len(row) > 3 else np.nan),
            }
            j += 1

    block_starts: List[Tuple[int, str]] = []
    for idx, row in enumerate(rows):
        tag = as_text(row[0]) if row else ""
        if not _BLOCK_ID_RE.match(tag):
            continue
        next_row = rows[idx + 1] if idx + 1 < len(rows) else []
        if len(next_row) >= 3 and next_row[0].lower() == "tiempo" and "carga" in next_row[1].lower() and "alarg" in next_row[2].lower():
            block_starts.append((idx, re.sub(r"\s+", "", tag)))

    if not block_starts:
        raise ParseError("No se encontraron bloques de datos.")

    curves: List[CurveState] = []
    specimen_order = geometry_sequence if geometry_sequence else list(geometry_rows.keys())

    for ordinal, (start_idx, block_id) in enumerate(block_starts):
        specimen_id = specimen_order[ordinal] if ordinal < len(specimen_order) else f"Specimen_{ordinal + 1:02d}"
        geometry = geometry_rows.get(specimen_id, Geometry())
        results = result_map.get(specimen_id, {})

        time_values: list[float] = []
        load_values: list[float] = []
        elong_values: list[float] = []
        k = start_idx + 3
        while k < len(rows):
            current = rows[k]
            first = as_text(current[0]) if current else ""
            if _BLOCK_ID_RE.match(first):
                break
            if not current or is_blank_row(current):
                k += 1
                continue
            if not _NUMERIC_RE.match(first.replace(",", ".")):
                k += 1
                continue
            time_s = as_float(current[0])
            load_kn = as_float(current[1]) if len(current) > 1 else np.nan
            elong_mm = as_float(current[2]) if len(current) > 2 else np.nan
            # Mismo criterio que antes: se conservan los puntos completos y se
            # descartan únicamente filas sin los tres campos numéricos mínimos.
            if np.isfinite(time_s) and np.isfinite(load_kn) and np.isfinite(elong_mm):
                time_values.append(float(time_s))
                load_values.append(float(load_kn))
                elong_values.append(float(elong_mm))
            k += 1

        df_curve = pd.DataFrame(
            {
                "time_s": np.asarray(time_values, dtype=float),
                "load_kN": np.asarray(load_values, dtype=float),
                "elongation_mm": np.asarray(elong_values, dtype=float),
            }
        )

        curves.append(
            CurveState(
                specimen_id=specimen_id,
                block_id=block_id,
                geometry=geometry,
                raw_df=df_curve,
                reported_yield_mpa=results.get("yield_mpa"),
                reported_max_mpa=results.get("max_mpa"),
                reported_elong_after_fracture_pct=results.get("elong_pct"),
            )
        )

    return ParsedDataset(
        source_path=str(source_path),
        source_kind="machine_export",
        meta=meta,
        curves=curves,
    )


def parse_generic_numeric_table(df: pd.DataFrame, source_path: str) -> ParsedDataset:
    lowered = [as_text(x).lower() for x in df.iloc[0].tolist()]

    def find_col(possible_names: Iterable[str]) -> Optional[int]:
        for idx, col_name in enumerate(lowered):
            if any(name in col_name for name in possible_names):
                return idx
        return None

    time_idx = find_col(["time", "tiempo", "seg"])
    load_idx = find_col(["load", "carga", "kn"])
    elong_idx = find_col(["elong", "alarg", "disp", "mm"])
    stress_idx = find_col(["stress", "esfuerzo", "mpa"])

    if elong_idx is None:
        raise ParseError("No se encontró columna de alargamiento o desplazamiento.")
    if load_idx is None and stress_idx is None:
        raise ParseError("No se encontró ni carga ni esfuerzo.")

    table = df.iloc[1:].copy().reset_index(drop=True)
    out = pd.DataFrame()
    out["time_s"] = table.iloc[:, time_idx].map(as_float) if time_idx is not None else np.arange(len(table), dtype=float)
    out["elongation_mm"] = table.iloc[:, elong_idx].map(as_float)
    if load_idx is not None:
        out["load_kN"] = table.iloc[:, load_idx].map(as_float)
    if stress_idx is not None:
        out["stress_MPa"] = table.iloc[:, stress_idx].map(as_float)

    out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=["elongation_mm"]).reset_index(drop=True)
    curve = CurveState(
        specimen_id=Path(source_path).stem,
        block_id="1-1",
        geometry=Geometry(shape=SHAPE_RECTANGULAR),
        raw_df=out,
    )
    return ParsedDataset(
        source_path=str(source_path),
        source_kind="generic_table",
        meta={},
        curves=[curve],
    )


def load_dataset(path: str | Path, sheet_name: Optional[str] = None) -> ParsedDataset:
    path = Path(path)
    ext = path.suffix.lower()
    if ext in SUPPORTED_TEXT_EXTENSIONS:
        rows = read_delimited_rows(path)
        try:
            return parse_machine_export(rows, str(path))
        except Exception:
            # Fallback genérico: solo aquí se construye el DataFrame completo.
            return parse_generic_numeric_table(pd.DataFrame(rows, dtype=str), str(path))

    table = read_any_table(path, sheet_name=sheet_name)
    rows = dataframe_to_rows(table)
    try:
        return parse_machine_export(rows, str(path))
    except Exception:
        return parse_generic_numeric_table(table, str(path))


def _nan_to_none(value: Any) -> Optional[float]:
    try:
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return None
        if pd.isna(value):
            return None
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return None
