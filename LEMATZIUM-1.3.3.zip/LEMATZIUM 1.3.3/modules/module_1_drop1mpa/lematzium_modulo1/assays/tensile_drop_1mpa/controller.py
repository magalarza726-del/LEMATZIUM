from __future__ import annotations

from typing import Any, Dict, List, Optional

from .contracts import CurveState, DetectionSettings, ParsedDataset, PlotSnapshot, normalize_shape
from .detection import clear_manual_point, run_auto_detection, set_manual_point
from .reader import load_dataset

try:
    from shared.tensile_unified.compat import apply_unified_analysis_for_module1
except Exception:  # pragma: no cover - compatibilidad si shared no esta disponible
    apply_unified_analysis_for_module1 = None


class TensileDrop1MPaController:
    def __init__(self) -> None:
        self.dataset: Optional[ParsedDataset] = None
        self.current_curve_id: Optional[str] = None
        self.settings = DetectionSettings()

    def set_upper_yield_drop_mpa(self, value: float) -> None:
        """Actualiza el criterio configurable de fluencia superior.

        Mantiene compatibilidad interna sincronizando el alias histórico
        min_required_drop_mpa.
        """
        drop = max(0.0, float(value))
        self.settings.upper_yield_drop_mpa = drop
        self.settings.min_required_drop_mpa = drop

    def _apply_unified_analysis(self, curve: CurveState) -> None:
        """Registra analisis del motor comun sin alterar puntos historicos."""
        if apply_unified_analysis_for_module1 is None:
            return
        try:
            apply_unified_analysis_for_module1(curve, self.settings)
        except Exception as exc:
            curve.diagnostics["unified_bridge_error"] = f"{type(exc).__name__}: {exc}"

    def load_file(self, file_path: str) -> ParsedDataset:
        dataset = load_dataset(file_path)
        for curve in dataset.curves:
            run_auto_detection(curve, settings=self.settings)
        self._apply_unified_analysis(curve)
        self.dataset = dataset
        self.current_curve_id = dataset.curves[0].specimen_id if dataset.curves else None
        return dataset

    def reload_current(self) -> ParsedDataset:
        if not self.dataset:
            raise RuntimeError("No hay dataset cargado.")
        return self.load_file(self.dataset.source_path)

    def get_specimen_ids(self) -> List[str]:
        return self.dataset.specimen_ids() if self.dataset else []

    def select_curve(self, specimen_id: str) -> CurveState:
        if not self.dataset:
            raise RuntimeError("No hay dataset cargado.")
        curve = self.dataset.get_curve(specimen_id)
        self.current_curve_id = specimen_id
        return curve

    def get_current_curve(self) -> CurveState:
        if not self.dataset or not self.current_curve_id:
            raise RuntimeError("No hay curva seleccionada.")
        return self.dataset.get_curve(self.current_curve_id)

    def recalculate_all(self) -> None:
        """Recalcula todas las curvas sin recargar el archivo fuente."""
        if not self.dataset:
            raise RuntimeError("No hay dataset cargado.")
        current_id = self.current_curve_id
        for curve in self.dataset.curves:
            run_auto_detection(curve, settings=self.settings)
            self._apply_unified_analysis(curve)
        self.current_curve_id = current_id

    def update_geometry(
        self,
        specimen_id: str,
        shape: str,
        side1_mm: Optional[float],
        side2_mm: Optional[float],
        diameter_mm: Optional[float],
        gauge_length_mm: Optional[float],
        area_mm2_manual: Optional[float] = None,
    ) -> CurveState:
        curve = self.select_curve(specimen_id)
        curve.geometry.shape = normalize_shape(shape)
        curve.geometry.side1_mm = side1_mm
        curve.geometry.side2_mm = side2_mm
        curve.geometry.diameter_mm = diameter_mm
        curve.geometry.gauge_length_mm = gauge_length_mm
        curve.geometry.area_mm2_manual = area_mm2_manual
        if hasattr(curve.geometry, "validate"):
            curve.diagnostics["geometry_validation_errors"] = curve.geometry.validate(require_gauge=True)
        run_auto_detection(curve, settings=self.settings)
        self._apply_unified_analysis(curve)
        return curve

    def update_geometry_all(
        self,
        shape: str,
        side1_mm: Optional[float],
        side2_mm: Optional[float],
        diameter_mm: Optional[float],
        gauge_length_mm: Optional[float],
        area_mm2_manual: Optional[float] = None,
    ) -> None:
        if not self.dataset:
            raise RuntimeError("No hay dataset cargado.")
        current_id = self.current_curve_id
        for curve in self.dataset.curves:
            curve.geometry.shape = normalize_shape(shape)
            curve.geometry.side1_mm = side1_mm
            curve.geometry.side2_mm = side2_mm
            curve.geometry.diameter_mm = diameter_mm
            curve.geometry.gauge_length_mm = gauge_length_mm
            curve.geometry.area_mm2_manual = area_mm2_manual
            if hasattr(curve.geometry, "validate"):
                curve.diagnostics["geometry_validation_errors"] = curve.geometry.validate(require_gauge=True)
            run_auto_detection(curve, settings=self.settings)
            self._apply_unified_analysis(curve)
        if current_id:
            self.current_curve_id = current_id

    def update_metadata(self, updates: Dict[str, Any]) -> None:
        if not self.dataset:
            raise RuntimeError("No hay dataset cargado.")
        self.dataset.meta.update(updates)

    def apply_manual_point(self, specimen_id: str, point_kind: str, x_mm: float, y_mpa: Optional[float]) -> CurveState:
        curve = self.select_curve(specimen_id)
        set_manual_point(curve, point_kind=point_kind, x_mm=x_mm, y_mpa=y_mpa)
        return curve

    def clear_manual_point(self, specimen_id: str, point_kind: str) -> CurveState:
        curve = self.select_curve(specimen_id)
        clear_manual_point(curve, point_kind=point_kind)
        return curve

    def set_visibility(self, specimen_id: str, show_yield: bool, show_max: bool) -> CurveState:
        curve = self.select_curve(specimen_id)
        curve.is_yield_visible = bool(show_yield)
        curve.is_max_visible = bool(show_max)
        return curve

    def get_plot_snapshot(self, specimen_id: Optional[str] = None) -> PlotSnapshot:
        curve = self.select_curve(specimen_id or self.current_curve_id or "")
        return PlotSnapshot(
            specimen_id=curve.specimen_id,
            curve_df=curve.df,
            chosen_yield=curve.chosen_yield,
            chosen_max=curve.chosen_max,
            area_mm2=curve.geometry.area_mm2,
            gauge_length_mm=curve.geometry.gauge_length_mm,
            reported_elong_pct=curve.reported_elong_after_fracture_pct,
        )

    def get_summary_rows(self) -> List[Dict[str, Any]]:
        if not self.dataset:
            return []
        rows: List[Dict[str, Any]] = []
        for curve in self.dataset.curves:
            rows.append(
                {
                    "specimen_id": curve.specimen_id,
                    "block_id": curve.block_id,
                    "yield_mpa": curve.chosen_yield.y,
                    "max_mpa": curve.chosen_max.y,
                    "area_mm2": curve.geometry.area_mm2,
                    "gauge_length_mm": curve.geometry.gauge_length_mm,
                    "yield_source": curve.chosen_yield.source,
                    "max_source": curve.chosen_max.source,
                }
            )
        return rows
