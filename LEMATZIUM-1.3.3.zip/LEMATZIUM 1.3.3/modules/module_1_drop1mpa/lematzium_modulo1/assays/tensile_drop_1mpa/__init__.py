"""Subpaquete del ensayo de tracción con fluencia superior configurable."""

__all__ = [
    "contracts",
    "controller",
    "detection",
    "reader",
]
