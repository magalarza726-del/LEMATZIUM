from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

try:
    from shared.tensile_geometry import (
        SHAPE_CIRCULAR,
        SHAPE_IRREGULAR,
        SHAPE_OPTIONS,
        SHAPE_RECTANGULAR,
        TensileGeometry as Geometry,
        normalize_shape,
    )
except ModuleNotFoundError:  # ejecución directa del módulo sin launcher
    import sys
    from pathlib import Path

    _modules_dir = Path(__file__).resolve().parents[4]
    if str(_modules_dir) not in sys.path:
        sys.path.insert(0, str(_modules_dir))
    from shared.tensile_geometry import (
        SHAPE_CIRCULAR,
        SHAPE_IRREGULAR,
        SHAPE_OPTIONS,
        SHAPE_RECTANGULAR,
        TensileGeometry as Geometry,
        normalize_shape,
    )


APP_TITLE = "LEMATZIUM - Módulo 1 v1.2.0 - Fluencia superior"


@dataclass
class DetectionSettings:
    smoothing_window: int = 7
    # Parámetro nuevo: criterio operativo para detectar la fluencia superior.
    # El valor predeterminado conserva el comportamiento histórico del módulo 1.
    upper_yield_drop_mpa: float = 1.0
    # Alias de compatibilidad con versiones anteriores. Si alguien construye
    # DetectionSettings(min_required_drop_mpa=...), se respeta ese valor.
    min_required_drop_mpa: Optional[float] = None
    min_candidate_fraction_of_global_max: float = 0.65
    min_candidate_rise_mpa: float = 8.0
    min_x_fraction_before_search: float = 0.02
    max_x_fraction_for_search: float = 0.70
    pre_window_points: int = 120
    future_window_points: int = 800
    snap_window_points: int = 18
    first_peak_min_consecutive_drop_points: int = 3
    fallback_smoothing_window: int = 9
    fallback_early_fraction_of_x_at_max: float = 0.40
    fallback_fraction_of_total_x: float = 0.22
    fallback_min_required_drop_fraction_of_max: float = 0.0025
    fallback_min_yield_fraction_of_global_max: float = 0.55
    fallback_min_work_hardening_gain_mpa: float = 8.0
    fallback_confirm_window_points: int = 15
    fallback_plateau_window_points: int = 12
    fallback_min_post_nonpositive_ratio: float = 0.35
    fallback_min_plateau_ratio: float = 0.35

    def __post_init__(self) -> None:
        if self.min_required_drop_mpa is not None:
            self.upper_yield_drop_mpa = float(self.min_required_drop_mpa)
        self.upper_yield_drop_mpa = max(0.0, float(self.upper_yield_drop_mpa))
        self.min_required_drop_mpa = self.upper_yield_drop_mpa

    @property
    def drop_label(self) -> str:
        return f"{self.upper_yield_drop_mpa:g} MPa"


@dataclass
class SelectedPoint:
    index: Optional[int] = None
    x: Optional[float] = None
    y: Optional[float] = None
    source: str = "auto"
    note: str = ""


@dataclass
class CurveState:
    specimen_id: str
    block_id: str
    geometry: Geometry
    raw_df: pd.DataFrame
    reported_yield_mpa: Optional[float] = None
    reported_max_mpa: Optional[float] = None
    reported_elong_after_fracture_pct: Optional[float] = None
    auto_yield: SelectedPoint = field(default_factory=SelectedPoint)
    auto_max: SelectedPoint = field(default_factory=SelectedPoint)
    manual_yield: SelectedPoint = field(default_factory=SelectedPoint)
    manual_max: SelectedPoint = field(default_factory=SelectedPoint)
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    is_yield_visible: bool = True
    is_max_visible: bool = True

    @property
    def df(self) -> pd.DataFrame:
        df = self.raw_df.copy()
        area = self.geometry.area_mm2
        if area and "load_kN" in df.columns:
            df["stress_MPa"] = (df["load_kN"].astype(float) * 1000.0) / float(area)
        elif "stress_MPa" in df.columns:
            df["stress_MPa"] = pd.to_numeric(df["stress_MPa"], errors="coerce")
        return df

    @property
    def chosen_yield(self) -> SelectedPoint:
        return self.manual_yield if self.manual_yield.index is not None else self.auto_yield

    @property
    def chosen_max(self) -> SelectedPoint:
        return self.manual_max if self.manual_max.index is not None else self.auto_max


@dataclass
class ParsedDataset:
    source_path: str
    source_kind: str
    meta: Dict[str, Any]
    curves: List[CurveState] = field(default_factory=list)

    def specimen_ids(self) -> List[str]:
        return [curve.specimen_id for curve in self.curves]

    def get_curve(self, specimen_id: str) -> CurveState:
        for curve in self.curves:
            if curve.specimen_id == specimen_id:
                return curve
        raise KeyError(f"No existe la probeta '{specimen_id}'.")


@dataclass
class PlotSnapshot:
    specimen_id: str
    curve_df: pd.DataFrame
    chosen_yield: SelectedPoint
    chosen_max: SelectedPoint
    area_mm2: Optional[float]
    gauge_length_mm: Optional[float]
    reported_elong_pct: Optional[float]
