from __future__ import annotations

from dataclasses import asdict
from typing import Optional

import numpy as np
import pandas as pd

from .contracts import CurveState, DetectionSettings, SelectedPoint


def _drop_label(settings: DetectionSettings) -> str:
    return getattr(settings, "drop_label", f"{float(settings.min_required_drop_mpa):g} MPa")


def _sync_drop_setting(settings: DetectionSettings, upper_yield_drop_mpa: Optional[float] = None) -> DetectionSettings:
    if upper_yield_drop_mpa is not None:
        settings.upper_yield_drop_mpa = max(0.0, float(upper_yield_drop_mpa))
        settings.min_required_drop_mpa = settings.upper_yield_drop_mpa
    elif getattr(settings, "min_required_drop_mpa", None) is None:
        settings.min_required_drop_mpa = getattr(settings, "upper_yield_drop_mpa", 1.0)
    return settings


def rolling_mean(y: np.ndarray, window: int) -> np.ndarray:
    if window <= 1:
        return np.asarray(y, dtype=float)
    return pd.Series(np.asarray(y, dtype=float)).rolling(window, center=True, min_periods=1).mean().to_numpy()


def rolling_median(y: np.ndarray, window: int) -> np.ndarray:
    if window <= 1:
        return np.asarray(y, dtype=float)
    return pd.Series(np.asarray(y, dtype=float)).rolling(window, center=True, min_periods=1).median().to_numpy()


def safe_gradient(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    if len(y) < 2 or len(x) < 2:
        return np.zeros_like(y)
    dx = np.diff(x)
    dx[dx == 0] = np.nan
    dy = np.diff(y)
    g = np.empty_like(y, dtype=float)
    g[:] = 0.0
    core = np.divide(dy, dx, out=np.zeros_like(dy, dtype=float), where=np.isfinite(dx))
    if len(core) == 1:
        g[:] = core[0]
    else:
        g[1:-1] = (core[:-1] + core[1:]) / 2.0
        g[0] = core[0]
        g[-1] = core[-1]
    return np.nan_to_num(g, nan=0.0, posinf=0.0, neginf=0.0)


def local_maxima_indices(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    if len(y) < 3:
        return np.array([], dtype=int)
    left = y[1:-1] >= y[:-2]
    right = y[1:-1] > y[2:]
    return (np.where(left & right)[0] + 1).astype(int)


def detect_global_maximum(curve: CurveState) -> SelectedPoint:
    df = curve.df
    if df.empty or "stress_MPa" not in df.columns:
        return SelectedPoint(note="Sin esfuerzo calculado para detectar máximo.")
    stress = pd.to_numeric(df["stress_MPa"], errors="coerce")
    idx = int(stress.idxmax())
    row = df.iloc[idx]
    return SelectedPoint(index=idx, x=float(row["elongation_mm"]), y=float(row["stress_MPa"]), source="auto", note="Máximo global")


def _snap_candidate_to_raw_peak(y_raw: np.ndarray, candidate_idx: int, window: int) -> int:
    left = max(0, candidate_idx - max(1, window))
    right = min(len(y_raw), candidate_idx + max(1, window) + 1)
    local_idx = int(np.argmax(y_raw[left:right]))
    return left + local_idx


def _detect_first_peak_with_drop(curve: CurveState, settings: DetectionSettings) -> SelectedPoint:
    """
    Detecta el primer máximo real seguido por una caída sostenida configurable
    antes de que aparezca un máximo superior. Esta lógica es más fiel a la
    definición operativa buscada que simplemente revisar máximos locales
    aislados, porque trabaja con el "running peak" de la curva suavizada.
    """
    df = curve.df
    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)

    if len(x) < 8:
        return SelectedPoint(note="Muy pocos puntos para detectar fluencia.")

    y_med = rolling_median(y, settings.smoothing_window)
    y_smooth = rolling_mean(y_med, settings.smoothing_window)

    x_min = float(np.nanmin(x))
    x_max = float(np.nanmax(x))
    x_span = max(x_max - x_min, 1e-9)
    global_max = float(np.nanmax(y_smooth))

    min_x_allowed = x_min + settings.min_x_fraction_before_search * x_span
    max_x_allowed = x_min + settings.max_x_fraction_for_search * x_span
    min_y_allowed = settings.min_candidate_fraction_of_global_max * global_max

    start_idx = int(np.searchsorted(x, min_x_allowed, side="left"))
    start_idx = max(0, min(start_idx, len(x) - 1))
    baseline = float(np.nanmin(y_smooth[: start_idx + 1])) if start_idx >= 0 else float(y_smooth[0])

    peak_idx = start_idx
    peak_val = float(y_smooth[start_idx])
    consecutive_drop_points = 0

    for idx in range(start_idx + 1, len(y_smooth)):
        if float(x[idx]) > max_x_allowed:
            break

        current_y = float(y_smooth[idx])

        if current_y >= peak_val:
            peak_val = current_y
            peak_idx = idx
            consecutive_drop_points = 0
            continue

        rise_from_baseline = peak_val - baseline
        if peak_val < min_y_allowed or rise_from_baseline < settings.min_candidate_rise_mpa:
            continue

        if (peak_val - current_y) >= settings.min_required_drop_mpa:
            consecutive_drop_points += 1
        else:
            consecutive_drop_points = 0

        if consecutive_drop_points >= max(1, settings.first_peak_min_consecutive_drop_points):
            raw_idx = _snap_candidate_to_raw_peak(y, peak_idx, settings.snap_window_points)
            return SelectedPoint(
                index=raw_idx,
                x=float(x[raw_idx]),
                y=float(y[raw_idx]),
                source="auto",
                note=f"Fluencia superior automática por primer máximo con caída sostenida ≥ {_drop_label(settings)}",
            )

    return SelectedPoint(note=f"No se encontró un primer máximo válido con caída sostenida ≥ {_drop_label(settings)}.")


def _detect_upper_yield_fallback(curve: CurveState, settings: DetectionSettings) -> SelectedPoint:
    df = curve.df
    if df.empty or "stress_MPa" not in df.columns:
        return SelectedPoint(note="Sin esfuerzo calculado para detectar fluencia.")

    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)
    if len(x) < 8:
        return SelectedPoint(note="Muy pocos puntos para detectar fluencia.")

    y_med = rolling_median(y, settings.fallback_smoothing_window)
    y_smooth = rolling_mean(y_med, settings.fallback_smoothing_window)
    grad = safe_gradient(y_smooth, x)
    gmax_idx = int(np.argmax(y_smooth))
    gmax_y = float(y_smooth[gmax_idx])
    x_at_max = float(x[gmax_idx]) if gmax_idx < len(x) else float(x[-1])

    early_limit_x = max(
        x_at_max * settings.fallback_early_fraction_of_x_at_max,
        float(np.nanmax(x)) * settings.fallback_fraction_of_total_x,
    )
    early_mask = x <= early_limit_x
    candidate_idx = local_maxima_indices(y_smooth)
    candidate_idx = candidate_idx[early_mask[candidate_idx]] if len(candidate_idx) else candidate_idx

    min_y_threshold = max(
        settings.min_required_drop_mpa * 5.0,
        settings.fallback_min_yield_fraction_of_global_max * gmax_y,
    )

    best_idx: Optional[int] = None
    best_score = -1e18

    for idx in candidate_idx:
        current_y = float(y_smooth[idx])
        if current_y < min_y_threshold:
            continue

        left = max(0, idx - settings.fallback_confirm_window_points)
        right = min(len(y_smooth), idx + settings.fallback_confirm_window_points + settings.fallback_plateau_window_points)

        pre_grad = float(np.nanmedian(grad[left:idx])) if idx > left else 0.0
        if pre_grad <= 0:
            continue

        future_window = y_smooth[idx + 1:right]
        if len(future_window) < 3:
            continue

        local_min_after = float(np.nanmin(future_window))
        sustained_drop = current_y - local_min_after
        required_drop = max(settings.min_required_drop_mpa, settings.fallback_min_required_drop_fraction_of_max * gmax_y)
        if sustained_drop < required_drop:
            continue

        future_far = y_smooth[min(len(y_smooth) - 1, idx + settings.fallback_confirm_window_points):]
        if len(future_far) == 0:
            continue
        hardening_gain = float(np.nanmax(future_far) - current_y)
        if hardening_gain < settings.fallback_min_work_hardening_gain_mpa:
            continue

        post_grad = grad[idx + 1:right]
        nonpositive_ratio = float(np.mean(post_grad <= 0.0)) if len(post_grad) else 0.0
        plateau_ratio = float(np.mean(np.abs(future_window - current_y) <= max(required_drop * 1.2, 1.5)))
        if nonpositive_ratio < settings.fallback_min_post_nonpositive_ratio and plateau_ratio < settings.fallback_min_plateau_ratio:
            continue

        score = (
            800.0 / (idx + 5)
            + sustained_drop * 12.0
            + hardening_gain * 2.0
            + pre_grad * 0.1
            + plateau_ratio * 20.0
            + nonpositive_ratio * 20.0
        )
        if score > best_score:
            best_score = score
            best_idx = int(idx)

    if best_idx is not None:
        raw_idx = _snap_candidate_to_raw_peak(y, best_idx, settings.snap_window_points)
        return SelectedPoint(
            index=raw_idx,
            x=float(x[raw_idx]),
            y=float(y[raw_idx]),
            source="auto",
            note="Fluencia automática por fallback mecánico",
        )

    return SelectedPoint(note="No se pudo detectar automáticamente una fluencia superior confiable.")


def detect_upper_yield_by_drop(
    curve: CurveState,
    upper_yield_drop_mpa: Optional[float] = None,
    settings: Optional[DetectionSettings] = None,
) -> SelectedPoint:
    """Detecta esfuerzo de fluencia superior usando una caída configurable.

    El valor predeterminado es 1.0 MPa para preservar el comportamiento
    histórico del módulo 1.
    """
    settings = _sync_drop_setting(settings or DetectionSettings(), upper_yield_drop_mpa)
    df = curve.df
    if df.empty or "stress_MPa" not in df.columns:
        return SelectedPoint(note="Sin esfuerzo calculado para detectar fluencia superior.")
    first_peak_result = _detect_first_peak_with_drop(curve, settings)
    if first_peak_result.index is not None:
        return first_peak_result
    fallback_result = _detect_upper_yield_fallback(curve, settings)
    if fallback_result.index is not None:
        fallback_result.note = f"{fallback_result.note} (se usó fallback porque no se encontró primer máximo válido)"
    return fallback_result


def detect_upper_yield_by_drop_1mpa(curve: CurveState, settings: Optional[DetectionSettings] = None) -> SelectedPoint:
    """Alias de compatibilidad: mantiene la API histórica del módulo 1."""
    return detect_upper_yield_by_drop(curve, upper_yield_drop_mpa=None, settings=settings)


def nearest_index(curve: CurveState, x_mm: float, y_mpa: Optional[float] = None) -> int:
    df = curve.df
    if df.empty:
        raise ValueError("La curva no tiene datos.")
    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)
    x_span = max(float(np.nanmax(x) - np.nanmin(x)), 1e-9)
    y_span = max(float(np.nanmax(y) - np.nanmin(y)), 1e-9)
    dx = (x - float(x_mm)) / x_span
    if y_mpa is None or not np.isfinite(y_mpa):
        dist2 = dx * dx
    else:
        dy = (y - float(y_mpa)) / y_span
        dist2 = dx * dx + dy * dy
    return int(np.argmin(dist2))


def set_manual_point(curve: CurveState, point_kind: str, x_mm: float, y_mpa: Optional[float] = None) -> SelectedPoint:
    idx = nearest_index(curve, x_mm=x_mm, y_mpa=y_mpa)
    row = curve.df.iloc[idx]
    point = SelectedPoint(
        index=idx,
        x=float(row["elongation_mm"]),
        y=float(row["stress_MPa"]),
        source="manual",
        note=f"Selección manual por arrastre: {point_kind}",
    )
    normalized = point_kind.lower()
    if normalized in {"yield", "yp", "fluencia"}:
        curve.manual_yield = point
    elif normalized in {"max", "maximum", "máximo"}:
        curve.manual_max = point
    else:
        raise ValueError("point_kind debe ser 'yield' o 'max'.")
    return point


def clear_manual_point(curve: CurveState, point_kind: str) -> None:
    normalized = point_kind.lower()
    if normalized in {"yield", "yp", "fluencia"}:
        curve.manual_yield = SelectedPoint()
    elif normalized in {"max", "maximum", "máximo"}:
        curve.manual_max = SelectedPoint()
    else:
        raise ValueError("point_kind debe ser 'yield' o 'max'.")


def run_auto_detection(curve: CurveState, settings: Optional[DetectionSettings] = None) -> CurveState:
    settings = _sync_drop_setting(settings or DetectionSettings())
    curve.auto_max = detect_global_maximum(curve)
    curve.auto_yield = detect_upper_yield_by_drop(curve, settings=settings)
    curve.diagnostics["auto_detection_settings"] = asdict(settings)
    curve.diagnostics["upper_yield_drop_mpa"] = settings.upper_yield_drop_mpa
    curve.diagnostics["upper_yield_stress_mpa"] = curve.auto_yield.y
    curve.diagnostics["detection_message"] = curve.auto_yield.note or (
        "Fluencia superior detectada." if curve.auto_yield.y is not None else "No disponible"
    )
    return curve
