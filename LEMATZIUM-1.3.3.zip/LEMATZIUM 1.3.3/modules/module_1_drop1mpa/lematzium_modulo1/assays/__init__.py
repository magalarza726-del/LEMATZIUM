"""Ensayos disponibles del módulo 1."""

__all__ = ["tensile_drop_1mpa"]
