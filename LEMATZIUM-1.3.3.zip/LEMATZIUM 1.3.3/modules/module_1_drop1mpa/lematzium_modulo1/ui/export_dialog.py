from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from lematzium_modulo1.assays.tensile_drop_1mpa.contracts import ParsedDataset
from shared.tk_window_restore import install_window_restore_guard, release_modal_state, show_window_normally
from lematzium_modulo1.reports.exporter import (
    ACCREDITATION_ACCREDITED,
    ACCREDITATION_NON_ACCREDITED,
    ReportExportGroup,
    ReportExportPayload,
    export_report_groups_to_docx,
)
from lematzium_modulo1.reports.ot_pdf_reader import parse_ot_pdf
from lematzium_modulo1.reports.templates import get_report_template_choices, register_custom_report_template
from .theme import BG
from lematzium_modulo1.app.user_prefs import load_last_export_output_dir, save_last_export_output_dir

ACCREDITATION_LABELS = {
    ACCREDITATION_ACCREDITED: "Acreditado (MC2202-08)",
    ACCREDITATION_NON_ACCREDITED: "No acreditado (MC2201-06)",
}


class ReportExportDialog(tk.Toplevel):
    def __init__(self, master, dataset: ParsedDataset, default_order_number: str, default_comment: str):
        super().__init__(master)
        self.title("Exportación automática de informes")
        self.configure(bg=BG)
        self.geometry("1220x780")
        self.minsize(1080, 700)
        self.transient(master)
        install_window_restore_guard(self)
        self.protocol("WM_DELETE_WINDOW", self._close_dialog)

        self.dataset = dataset
        self.default_comment = default_comment
        self.group_rows: List[Dict[str, str]] = []
        self.selected_vars: Dict[str, tk.BooleanVar] = {}

        self.accreditation_var = tk.StringVar(value=ACCREDITATION_ACCREDITED)
        self.report_number_var = tk.StringVar(value="")
        self.order_number_var = tk.StringVar(value=default_order_number)
        self.issue_date_var = tk.StringVar(value="")
        self.client_name_var = tk.StringVar(value="")
        self.phone_var = tk.StringVar(value="")
        self.address_var = tk.StringVar(value="")
        self.email_var = tk.StringVar(value="")
        self.contact_var = tk.StringVar(value="")
        persisted_output_dir = load_last_export_output_dir().strip()
        default_output_dir = persisted_output_dir or str(Path(dataset.source_path).parent)
        self.output_dir_var = tk.StringVar(value=default_output_dir)
        self.ot_pdf_path_var = tk.StringVar(value="")

        self._build_ui()
        self._load_specimens()

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=8)
        outer.pack(fill="both", expand=True)

        top_actions = ttk.Frame(outer)
        top_actions.pack(fill="x", pady=(0, 8))
        ttk.Button(top_actions, text="Agregar plantilla", command=self.add_template).pack(side="left", padx=(0, 8))
        ttk.Button(top_actions, text="Exportar ahora", command=self.export_now).pack(side="left")
        ttk.Button(top_actions, text="Cerrar", command=self._close_dialog).pack(side="right")

        self.dialog_canvas = tk.Canvas(outer, bg=BG, highlightthickness=0, bd=0)
        dialog_vscroll = ttk.Scrollbar(outer, orient="vertical", command=self.dialog_canvas.yview)
        self.dialog_canvas.configure(yscrollcommand=dialog_vscroll.set)
        self.dialog_canvas.pack(side="left", fill="both", expand=True)
        dialog_vscroll.pack(side="right", fill="y")

        container = ttk.Frame(self.dialog_canvas, padding=12)
        self.dialog_window = self.dialog_canvas.create_window((0, 0), window=container, anchor="nw")
        container.bind("<Configure>", lambda _e: self.dialog_canvas.configure(scrollregion=self.dialog_canvas.bbox("all")))
        self.dialog_canvas.bind("<Configure>", lambda e: self.dialog_canvas.itemconfigure(self.dialog_window, width=e.width))
        self.bind_all("<MouseWheel>", self._on_mousewheel, add="+")

        accreditation_box = ttk.LabelFrame(container, text="1. Tipo de ensayo", padding=10)
        accreditation_box.pack(fill="x")
        ttk.Label(
            accreditation_box,
            text="Seleccione la plantilla MC antes de exportar. El sistema usará la plantilla institucional correspondiente.",
            wraplength=1050,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))
        self.template_choices_frame = ttk.Frame(accreditation_box)
        self.template_choices_frame.pack(fill="x")
        self._refresh_template_choices()
        ttk.Button(accreditation_box, text="Agregar plantilla", command=self.add_template).pack(anchor="w", pady=(8, 0))

        top = ttk.LabelFrame(container, text="2. Selección de probetas", padding=10)
        top.pack(fill="x", pady=(10, 0))
        self.specimen_canvas = tk.Canvas(top, height=100, bg="#ffffff", highlightthickness=0)
        self.specimen_scroll = ttk.Scrollbar(top, orient="vertical", command=self.specimen_canvas.yview)
        self.specimen_inner = ttk.Frame(self.specimen_canvas)
        self.specimen_inner.bind("<Configure>", lambda e: self.specimen_canvas.configure(scrollregion=self.specimen_canvas.bbox("all")))
        self.specimen_canvas.create_window((0, 0), window=self.specimen_inner, anchor="nw")
        self.specimen_canvas.configure(yscrollcommand=self.specimen_scroll.set)
        self.specimen_canvas.pack(side="left", fill="both", expand=True)
        self.specimen_scroll.pack(side="right", fill="y")

        controls = ttk.LabelFrame(container, text="3. Crear grupo de informe", padding=10)
        controls.pack(fill="x", pady=(10, 0))
        ttk.Label(controls, text="N° informe:").grid(row=0, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.report_number_var, width=20).grid(row=0, column=1, sticky="w", padx=(6, 16))
        ttk.Label(controls, text="N° orden:").grid(row=0, column=2, sticky="w")
        ttk.Entry(controls, textvariable=self.order_number_var, width=20).grid(row=0, column=3, sticky="w", padx=(6, 16))
        ttk.Label(controls, text="Observaciones del informe:").grid(row=1, column=0, sticky="nw", pady=(8, 0))
        self.obs_text = tk.Text(controls, width=72, height=4, wrap="word")
        self.obs_text.grid(row=1, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=(8, 0))
        ttk.Button(controls, text="Agregar grupo", command=self.add_group).grid(row=0, column=4, rowspan=2, padx=(12, 0), sticky="ns")
        controls.columnconfigure(3, weight=1)

        middle = ttk.Panedwindow(container, orient="horizontal")
        middle.pack(fill="both", expand=True, pady=(10, 0))
        left = ttk.Frame(middle)
        right = ttk.Frame(middle)
        middle.add(left, weight=3)
        middle.add(right, weight=2)

        table_box = ttk.LabelFrame(left, text="4. Grupos listos", padding=10)
        table_box.pack(fill="both", expand=True)
        columns = ("report", "order", "specimens", "obs")
        self.tree = ttk.Treeview(table_box, columns=columns, show="headings", height=12)
        self.tree.heading("report", text="N° informe")
        self.tree.heading("order", text="N° orden")
        self.tree.heading("specimens", text="Probetas")
        self.tree.heading("obs", text="Observaciones")
        self.tree.column("report", width=120, anchor="center")
        self.tree.column("order", width=120, anchor="center")
        self.tree.column("specimens", width=260)
        self.tree.column("obs", width=360)
        self.tree.pack(fill="both", expand=True)
        buttons_bar = ttk.Frame(table_box)
        buttons_bar.pack(fill="x", pady=(8, 0))
        ttk.Button(buttons_bar, text="Eliminar grupo seleccionado", command=self.remove_selected_group).pack(side="left")
        ttk.Button(buttons_bar, text="Guardar plan JSON", command=self.save_plan_json).pack(side="right")

        header_box = ttk.LabelFrame(right, text="5. Datos del encabezado y salida", padding=10)
        header_box.pack(fill="both", expand=True)
        self._row(header_box, 0, "Fecha de emisión", self.issue_date_var, "Cliente", self.client_name_var)
        self._row(header_box, 1, "Teléfono", self.phone_var, "Contacto", self.contact_var)
        self._row(header_box, 2, "Correo", self.email_var, "", tk.StringVar())
        ttk.Label(header_box, text="Dirección").grid(row=3, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(header_box, textvariable=self.address_var, width=52).grid(row=3, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=(8, 0))

        ttk.Label(header_box, text="OT PDF").grid(row=4, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(header_box, textvariable=self.ot_pdf_path_var, width=52).grid(row=4, column=1, columnspan=2, sticky="ew", padx=(6, 6), pady=(8, 0))
        ttk.Button(header_box, text="Cargar OT PDF…", command=self.pick_ot_pdf).grid(row=4, column=3, sticky="e", pady=(8, 0))

        ttk.Separator(header_box, orient="horizontal").grid(row=5, column=0, columnspan=4, sticky="ew", pady=12)
        ttk.Label(header_box, text="Carpeta de salida").grid(row=6, column=0, sticky="w")
        ttk.Entry(header_box, textvariable=self.output_dir_var, width=52).grid(row=6, column=1, columnspan=2, sticky="ew", padx=(6, 6))
        ttk.Button(header_box, text="Buscar…", command=self.pick_output_dir).grid(row=6, column=3, sticky="e")
        ttk.Button(header_box, text="Exportar ahora", command=self.export_now).grid(row=7, column=0, columnspan=4, sticky="ew", pady=(14, 0))
        header_box.columnconfigure(2, weight=1)

        bottom_actions = ttk.Frame(container)
        bottom_actions.pack(fill="x", pady=(10, 0))
        ttk.Button(bottom_actions, text="Exportar ahora", command=self.export_now).pack(side="left")
        ttk.Button(bottom_actions, text="Cerrar", command=self._close_dialog).pack(side="right")

    def _on_mousewheel(self, event) -> None:
        try:
            if not self.winfo_exists():
                return
            widget = self.focus_displayof()
            if widget is None:
                widget = self
            if widget.winfo_toplevel() is not self:
                return
            self.dialog_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            return

    def _close_dialog(self) -> None:
        try:
            release_modal_state(self)
        except Exception:
            pass
        try:
            self.unbind_all("<MouseWheel>")
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass
        try:
            show_window_normally(self.master)
        except Exception:
            pass

    def _after_successful_export(self) -> None:
        try:
            release_modal_state(self)
        except Exception:
            pass
        try:
            show_window_normally(self.master)
        except Exception:
            pass
        try:
            self.after(120, self._close_dialog)
        except Exception:
            self._close_dialog()

    def _row(self, parent, row: int, left_label: str, left_var: tk.StringVar, right_label: str, right_var: tk.StringVar) -> None:
        ttk.Label(parent, text=left_label).grid(row=row, column=0, sticky="w")
        ttk.Entry(parent, textvariable=left_var, width=24).grid(row=row, column=1, sticky="w", padx=(6, 12), pady=2)
        if right_label:
            ttk.Label(parent, text=right_label).grid(row=row, column=2, sticky="w")
            ttk.Entry(parent, textvariable=right_var, width=24).grid(row=row, column=3, sticky="ew", padx=(6, 0), pady=2)

    def _load_specimens(self) -> None:
        for child in self.specimen_inner.winfo_children():
            child.destroy()
        self.selected_vars.clear()
        for index, specimen_id in enumerate(self.dataset.specimen_ids()):
            variable = tk.BooleanVar(value=False)
            self.selected_vars[specimen_id] = variable
            ttk.Checkbutton(self.specimen_inner, text=specimen_id, variable=variable).grid(row=index // 4, column=index % 4, sticky="w", padx=8, pady=4)

    def add_group(self) -> None:
        report_number = self.report_number_var.get().strip()
        order_number = self.order_number_var.get().strip()
        observations = self.obs_text.get("1.0", "end").strip()
        selected = [specimen_id for specimen_id, variable in self.selected_vars.items() if variable.get()]
        if not report_number:
            messagebox.showwarning("Dato requerido", "Ingresa el número de informe.", parent=self)
            return
        if not selected:
            messagebox.showwarning("Dato requerido", "Selecciona al menos una probeta.", parent=self)
            return
        row = {"report": report_number, "order": order_number, "specimens": ", ".join(selected), "obs": observations}
        self.group_rows.append(row)
        self.tree.insert("", "end", values=(row["report"], row["order"], row["specimens"], row["obs"]))
        self.report_number_var.set("")
        self.obs_text.delete("1.0", "end")
        for variable in self.selected_vars.values():
            variable.set(False)

    def remove_selected_group(self) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        for item in selection:
            index = self.tree.index(item)
            self.tree.delete(item)
            if 0 <= index < len(self.group_rows):
                self.group_rows.pop(index)

    def _build_payload(self) -> ReportExportPayload:
        payload = ReportExportPayload(
            accreditation_mode=self.accreditation_var.get(),
            issue_date=self.issue_date_var.get().strip(),
            client_name=self.client_name_var.get().strip(),
            client_phone=self.phone_var.get().strip(),
            client_address=self.address_var.get().strip(),
            client_email=self.email_var.get().strip(),
            client_contact=self.contact_var.get().strip(),
            default_comment=self.default_comment,
            source_path=self.dataset.source_path,
            ot_pdf_path=self.ot_pdf_path_var.get().strip(),
        )
        if payload.ot_pdf_path:
            payload.ot_context = parse_ot_pdf(payload.ot_pdf_path)
        for row in self.group_rows:
            payload.groups.append(
                ReportExportGroup(
                    report_number=row["report"],
                    order_number=row["order"],
                    specimen_ids=[value.strip() for value in row["specimens"].split(",") if value.strip()],
                    observations=row["obs"],
                )
            )
        return payload

    def save_plan_json(self) -> None:
        if not self.group_rows:
            messagebox.showwarning("Sin grupos", "No hay grupos para guardar.", parent=self)
            return
        payload = self._build_payload()
        file_path = filedialog.asksaveasfilename(title="Guardar plan de exportación", defaultextension=".json", filetypes=[("JSON", "*.json")], initialfile="plan_exportacion_tension.json")
        if not file_path:
            return
        data = {
            "accreditation_mode": payload.accreditation_mode,
            "issue_date": payload.issue_date,
            "client_name": payload.client_name,
            "client_phone": payload.client_phone,
            "client_address": payload.client_address,
            "client_email": payload.client_email,
            "client_contact": payload.client_contact,
            "default_comment": payload.default_comment,
            "source_path": payload.source_path,
            "ot_pdf_path": payload.ot_pdf_path,
            "groups": [asdict(group) for group in payload.groups],
        }
        Path(file_path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        messagebox.showinfo("Plan guardado", "Se guardó el plan JSON.", parent=self)

    def pick_ot_pdf(self) -> None:
        path = filedialog.askopenfilename(title="Seleccionar OT PDF", filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        self.ot_pdf_path_var.set(path)
        try:
            context = parse_ot_pdf(path)
        except Exception as exc:
            messagebox.showerror("OT PDF", f"No se pudo leer el PDF OT:\n\n{exc}", parent=self)
            return
        if context.ot_number:
            self.order_number_var.set(context.ot_number)
        self.client_name_var.set(context.client_name)
        self.phone_var.set(context.phone)
        self.address_var.set(context.address)
        self.email_var.set(context.email)
        self.contact_var.set(context.contact)
        if context.observations and not self.obs_text.get("1.0", "end").strip():
            self.obs_text.insert("1.0", context.observations)

    def pick_output_dir(self) -> None:
        path = filedialog.askdirectory(title="Seleccionar carpeta de salida")
        if path:
            self.output_dir_var.set(path)
            save_last_export_output_dir(path)

    def export_now(self) -> None:
        if not self.group_rows:
            messagebox.showwarning("Sin grupos", "Agrega al menos un grupo antes de exportar.", parent=self)
            return
        output_dir = self.output_dir_var.get().strip()
        if not output_dir:
            messagebox.showwarning("Salida requerida", "Selecciona una carpeta de salida.", parent=self)
            return
        try:
            payload = self._build_payload()
            exported_files = export_report_groups_to_docx(self.dataset, payload, output_dir)
            save_last_export_output_dir(output_dir)
        except Exception as exc:
            messagebox.showerror("Error de exportación", f"No se pudo exportar:\n\n{exc}", parent=self)
            return
        template_label = ACCREDITATION_LABELS.get(payload.accreditation_mode, payload.accreditation_mode)
        messagebox.showinfo(
            "Exportación completada",
            f"Se generaron {len(exported_files)} archivo(s) DOCX.\n\nPlantilla usada:\n{template_label}\n\nCarpeta:\n{output_dir}",
            parent=self,
        )
        self._after_successful_export()
