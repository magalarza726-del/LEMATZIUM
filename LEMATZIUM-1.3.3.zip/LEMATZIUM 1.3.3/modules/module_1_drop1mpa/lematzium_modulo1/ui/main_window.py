from __future__ import annotations

import math
import os
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Optional

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from matplotlib.ticker import AutoLocator, AutoMinorLocator, FuncFormatter, MultipleLocator

from lematzium_modulo1.assays.tensile_drop_1mpa.controller import TensileDrop1MPaController
from lematzium_modulo1.assays.tensile_drop_1mpa.contracts import (
    APP_TITLE,
    CurveState,
    SelectedPoint,
    SHAPE_CIRCULAR,
    SHAPE_IRREGULAR,
    SHAPE_OPTIONS,
    SHAPE_RECTANGULAR,
)
from .theme import ACCENT, ACCENT_SOFT, BG, CURVE_COLOR, FONT, GRID, MAX_COLOR, PANEL, SMALL_FONT, TITLE_FONT, YIELD_COLOR
from shared.tk_window_restore import install_window_restore_guard, set_windows_app_user_model_id
from shared.tk_ui_standard import (
    TEXT_ACTIONS_SECTION,
    TEXT_APPLY_VIEW,
    TEXT_AUTO_ADJUST,
    TEXT_EXPORT_PNG,
    TEXT_EXPORT_WORD,
    TEXT_GEOMETRY_SECTION,
    TEXT_IMPORT_CSV,
    TEXT_INTERACTIVE_GRAPH,
    TEXT_NO_FILE,
    TEXT_READY,
    TEXT_RECALCULATE,
    TEXT_RELOAD,
    TEXT_RESULTS_SECTION,
    TEXT_SPECIMEN,
    SUPPORTED_FILETYPES,
    configure_standard_style,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
    warning_summary,
)


DEFAULT_COMMENT = (
    "El área corresponde al área nominal de la muestra.\n"
    "El esfuerzo de fluencia registrado corresponde al esfuerzo de fluencia superior de acuerdo a la norma ISO 6892-1:2016.\n"
    "La probeta ensayada fue de tipo no proporcional y no maquinada.\n"
    "La muestra y la información de la misma fue proporcionada por el cliente.\n"
    "El alargamiento registrado corresponde al desplazamiento de los cabezales de la MUE 600 kN.\n"
    "La incertidumbre de la medición fue calculada con un factor de cobertura k=2 y con un nivel de confianza de aproximadamente 95%.\n"
    "Incertidumbre de la medición en: Esfuerzo Máximo = 16 MPa. Esfuerzo de Fluencia = 15 MPa. Porcentaje de Elongación luego de la rotura = 4.5 %.\n\n"
    "PEE0303-01"
)


class CollapsibleSection(ttk.Frame):
    def __init__(self, master, title: str, expanded: bool = True, on_toggle=None):
        super().__init__(master)
        self.title = title
        self.on_toggle = on_toggle
        self.is_expanded = tk.BooleanVar(value=expanded)
        self.header_button = ttk.Button(self, text=self._button_text(), command=self.toggle)
        self.header_button.pack(fill="x")
        self.body = ttk.Frame(self)
        if expanded:
            self.body.pack(fill="x", pady=(6, 0))

    def _button_text(self) -> str:
        return f"{'▼' if self.is_expanded.get() else '▶'} {self.title}"

    def toggle(self) -> None:
        self.is_expanded.set(not self.is_expanded.get())
        self.header_button.configure(text=self._button_text())
        if self.is_expanded.get():
            self.body.pack(fill="x", pady=(6, 0))
        else:
            self.body.pack_forget()
        self.update_idletasks()
        if self.on_toggle:
            self.on_toggle()


class TensileDrop1MPaWindow:
    def __init__(self, controller: TensileDrop1MPaController) -> None:
        self.controller = controller
        set_windows_app_user_model_id("LEMATZIUM.Modulo1.Drop1MPa")
        self.root = tk.Tk()
        install_window_restore_guard(self.root, app_id="LEMATZIUM.Modulo1.Drop1MPa")
        self.root.title(APP_TITLE)
        self.root.geometry("1760x1020")
        self.root.minsize(1180, 760)
        self.root.resizable(True, True)
        self.root.configure(bg=BG)
        try:
            level = max(35, min(100, int(os.getenv("LEMATZIUM_BRIGHTNESS", "85"))))
            self.root.attributes("-alpha", 0.55 + (level / 100.0) * 0.45)
        except Exception:
            pass

        self.style = ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass
        self._build_root_scaffold()
        self._configure_style()

        self.current_file: Optional[str] = None
        self._geometry_after_id: Optional[str] = None
        self._active_drag_target: Optional[str] = None
        self._suspend_var_trace = False
        self._is_updating_formatters = False

        self.status_var = tk.StringVar(value=TEXT_READY)
        self.cursor_var = tk.StringVar(value="Punto actual: —")
        self.drag_mode_var = tk.StringVar(value="none")
        self.specimen_var = tk.StringVar(value="")
        self.show_yield_var = tk.BooleanVar(value=True)
        self.show_max_var = tk.BooleanVar(value=True)
        self.zoom_factor_var = tk.DoubleVar(value=1.20)
        self.upper_yield_drop_var = tk.StringVar(value=f"{self.controller.settings.upper_yield_drop_mpa:g}")

        self.lock_meta_var = tk.BooleanVar(value=False)
        self.lock_geometry_var = tk.BooleanVar(value=False)
        self.apply_geometry_all_var = tk.BooleanVar(value=False)

        self.procedure_var = tk.StringVar(value="")
        self.standard_var = tk.StringVar(value="")
        self.machine_var = tk.StringVar(value="")
        self.material_var = tk.StringVar(value="")
        self.speed_var = tk.StringVar(value="")
        self.humidity_var = tk.StringVar(value="")
        self.temp_var = tk.StringVar(value="")
        self.control_var = tk.StringVar(value="")
        self.order_var = tk.StringVar(value="")

        self.shape_var = tk.StringVar(value=SHAPE_RECTANGULAR)
        self.side1_var = tk.StringVar(value="")
        self.side2_var = tk.StringVar(value="")
        self.diameter_var = tk.StringVar(value="")
        self.gauge_var = tk.StringVar(value="")
        self.area_var = tk.StringVar(value="")
        self.yield_auto_var = tk.StringVar(value="")
        self.yield_manual_var = tk.StringVar(value="")
        self.max_auto_var = tk.StringVar(value="")
        self.max_manual_var = tk.StringVar(value="")
        self.elong_var = tk.StringVar(value="")

        self.plot_mode_var = tk.StringVar(value="auto")
        self.anchor_origin_var = tk.BooleanVar(value=False)
        self.x_min_var = tk.StringVar(value="")
        self.x_max_var = tk.StringVar(value="")
        self.y_min_var = tk.StringVar(value="")
        self.y_max_var = tk.StringVar(value="")
        self.grid_x_spacing_var = tk.StringVar(value="")
        self.grid_y_spacing_var = tk.StringVar(value="")

        self.fig = Figure(figsize=(9.6, 6.5), dpi=100, facecolor=PANEL)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor("#ffffff")
        self.ax.grid(True, color=GRID, linestyle="--", linewidth=0.6)

        self.plot_canvas = None
        self.canvas_widget = None
        self.toolbar = None
        self.specimen_combo = None
        self.summary_tree = None
        self.comment_text = None
        self.order_entry = None

        self.side1_entry = None
        self.side2_entry = None
        self.diameter_entry = None
        self.gauge_entry = None
        self.area_entry = None
        self.area_label_var = tk.StringVar(value="Área calculada (mm²)")
        self.apply_geometry_all_check = None
        self.shape_combo = None
        self.meta_entries: list[ttk.Entry] = []
        self.plot_limit_entries: list[ttk.Entry] = []
        self.right_canvas = None
        self.right_scrollbar = None
        self.right_inner = None
        self.right_window_id = None

        self._build_ui()
        self._bind_events()
        self._apply_meta_lock_state()
        self._apply_geometry_lock_state()
        self._apply_shape_visibility()
        self._update_plot_config_state()
        self._reset_axes_labels()

    def _build_root_scaffold(self) -> None:
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.root_canvas = tk.Canvas(self.root, bg=BG, highlightthickness=0, bd=0)
        self.root_vscroll = ttk.Scrollbar(self.root, orient="vertical", command=self.root_canvas.yview)
        self.root_hscroll = ttk.Scrollbar(self.root, orient="horizontal", command=self.root_canvas.xview)
        self.root_canvas.configure(yscrollcommand=self.root_vscroll.set, xscrollcommand=self.root_hscroll.set)
        self.root_canvas.grid(row=0, column=0, sticky="nsew")
        self.root_vscroll.grid(row=0, column=1, sticky="ns")
        self.root_hscroll.grid(row=1, column=0, sticky="ew")
        self.root_host = ttk.Frame(self.root_canvas)
        self.root_canvas_window = self.root_canvas.create_window((0, 0), window=self.root_host, anchor="nw")
        self.root_host.bind("<Configure>", lambda _e: self.root_canvas.configure(scrollregion=self.root_canvas.bbox("all")))
        self.root_canvas.bind("<Configure>", self._on_root_canvas_configure)
        self.root.bind_all("<Shift-MouseWheel>", self._on_root_shift_mousewheel, add="+")

    def _on_root_canvas_configure(self, event=None) -> None:
        if event is not None:
            self.root_canvas.itemconfigure(self.root_canvas_window, height=max(event.height, self.root_host.winfo_reqheight()))

    def _on_root_shift_mousewheel(self, event) -> None:
        self.root_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")

    def _configure_style(self) -> None:
        self.root.configure(bg=BG)
        configure_standard_style(self.style, bg=BG, accent=ACCENT, accent_soft=ACCENT_SOFT)

    def _build_ui(self) -> None:
        root_container = ttk.Frame(self.root_host, padding=10)
        root_container.pack(fill="both", expand=True)

        header = ttk.Frame(root_container)
        header.pack(fill="x")
        ttk.Label(header, text="LEMATZIUM - Módulo 1", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Fluencia superior configurable, punto máximo y reporte Word editable",
            style="SubHeader.TLabel",
        ).pack(anchor="w", pady=(0, 8))

        body = ttk.Panedwindow(root_container, orient="horizontal")
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body)
        right = ttk.Frame(body)
        body.add(left, weight=4)
        body.add(right, weight=2)

        self._build_left_panel(left)
        self._build_right_panel(right)

        status = ttk.Label(root_container, textvariable=self.status_var, relief="groove", anchor="w", padding=6)
        status.pack(fill="x", pady=(8, 0))

    def _build_left_panel(self, parent: ttk.Frame) -> None:
        filebar = ttk.Frame(parent)
        filebar.pack(fill="x", pady=(0, 8))
        ttk.Button(filebar, text=TEXT_IMPORT_CSV, style="Accent.TButton", command=self.open_file).pack(side="left")
        ttk.Button(filebar, text=TEXT_RELOAD, command=self.reload_file).pack(side="left", padx=(6, 0))
        ttk.Button(filebar, text=TEXT_RECALCULATE, command=self.recalculate_all).pack(side="left", padx=(6, 0))
        self.file_label = ttk.Label(filebar, text=TEXT_NO_FILE)
        self.file_label.pack(side="left", padx=(12, 0))

        top = ttk.Frame(parent)
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text=TEXT_SPECIMEN).grid(row=0, column=0, sticky="w")
        self.specimen_combo = ttk.Combobox(top, textvariable=self.specimen_var, state="readonly", width=18)
        self.specimen_combo.grid(row=0, column=1, sticky="w", padx=(6, 14))
        ttk.Label(top, textvariable=self.cursor_var, font=("Segoe UI", 10, "bold")).grid(row=0, column=2, sticky="w")

        plot_frame = ttk.LabelFrame(parent, text=TEXT_INTERACTIVE_GRAPH, padding=8)
        plot_frame.pack(fill="both", expand=True)

        toolbar_frame = ttk.Frame(plot_frame)
        toolbar_frame.pack(fill="x")

        self.plot_canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.plot_canvas.draw_idle()
        self.canvas_widget = self.plot_canvas.get_tk_widget()
        self.canvas_widget.configure(bg=PANEL, highlightthickness=0)
        self.canvas_widget.pack(fill="both", expand=True)

        self.toolbar = NavigationToolbar2Tk(self.plot_canvas, toolbar_frame, pack_toolbar=False)
        self.toolbar.update()
        self.toolbar.pack(side="left")

    def _build_right_panel(self, parent: ttk.Frame) -> None:
        self.right_canvas = tk.Canvas(parent, bg="#ffffff", highlightthickness=0)
        self.right_scrollbar = ttk.Scrollbar(parent, orient="vertical", command=self.right_canvas.yview)
        self.right_canvas.configure(yscrollcommand=self.right_scrollbar.set)
        self.right_scrollbar.pack(side="right", fill="y")
        self.right_canvas.pack(side="left", fill="both", expand=True)

        self.right_inner = ttk.Frame(self.right_canvas)
        self.right_window_id = self.right_canvas.create_window((0, 0), window=self.right_inner, anchor="nw")
        self.right_inner.bind("<Configure>", self._on_right_inner_configure)
        self.right_canvas.bind("<Configure>", self._on_right_canvas_configure)
        self.right_inner.bind("<Enter>", self._bind_right_mousewheel)
        self.right_inner.bind("<Leave>", self._unbind_right_mousewheel)

        make_section = lambda title, expanded=True: self._make_section(title, expanded)

        section_scroll = make_section("A. Factor de scroll", expanded=False)
        ttk.Label(section_scroll.body, text="Factor zoom scroll:").pack(anchor="w")
        ttk.Entry(section_scroll.body, textvariable=self.zoom_factor_var, width=12).pack(anchor="w", pady=(4, 0))

        section_points = make_section("B. Punto de fluencia y máximo", expanded=False)
        ttk.Label(section_points.body, text="Modo manual:").pack(anchor="w")
        ttk.Radiobutton(section_points.body, text="Sin arrastre", value="none", variable=self.drag_mode_var).pack(anchor="w")
        ttk.Radiobutton(section_points.body, text="Fluencia superior", value="yield", variable=self.drag_mode_var).pack(anchor="w")
        ttk.Radiobutton(section_points.body, text="Máximo", value="max", variable=self.drag_mode_var).pack(anchor="w")
        drop_row = ttk.Frame(section_points.body)
        drop_row.pack(fill="x", pady=(8, 0))
        ttk.Label(drop_row, text="Caída requerida para fluencia superior (MPa)").pack(anchor="w")
        ttk.Entry(drop_row, textvariable=self.upper_yield_drop_var, width=12).pack(anchor="w", pady=(4, 0))
        ttk.Button(section_points.body, text="Aplicar criterio de fluencia", command=self._apply_upper_yield_drop_setting).pack(fill="x", pady=(6, 0))
        ttk.Checkbutton(section_points.body, text="Mostrar fluencia superior", variable=self.show_yield_var, command=self._on_visibility_changed).pack(anchor="w", pady=(6, 0))
        ttk.Checkbutton(section_points.body, text="Mostrar máximo", variable=self.show_max_var, command=self._on_visibility_changed).pack(anchor="w")
        ttk.Button(section_points.body, text="Limpiar fluencia superior manual", command=lambda: self.clear_manual_point("yield")).pack(fill="x", pady=(8, 0))
        ttk.Button(section_points.body, text="Limpiar máximo manual", command=lambda: self.clear_manual_point("max")).pack(fill="x", pady=(6, 0))

        section_plot = make_section("C. Configuración de la gráfica", expanded=False)
        ttk.Radiobutton(section_plot.body, text="Autoajustar", value="auto", variable=self.plot_mode_var, command=self._update_plot_config_state).pack(anchor="w")
        ttk.Radiobutton(section_plot.body, text="Manual", value="manual", variable=self.plot_mode_var, command=self._update_plot_config_state).pack(anchor="w")
        ttk.Checkbutton(section_plot.body, text="Anclar inicio en 0,0", variable=self.anchor_origin_var, command=self._update_plot_config_state).pack(anchor="w", pady=(4, 0))
        self._packed_entry(section_plot.body, "X mín.", self.x_min_var)
        entry_xmin = self._last_packed_entry
        self._packed_entry(section_plot.body, "X máx.", self.x_max_var)
        entry_xmax = self._last_packed_entry
        self._packed_entry(section_plot.body, "Y mín.", self.y_min_var)
        entry_ymin = self._last_packed_entry
        self._packed_entry(section_plot.body, "Y máx.", self.y_max_var)
        entry_ymax = self._last_packed_entry
        ttk.Button(section_plot.body, text=TEXT_APPLY_VIEW, command=self._apply_plot_configuration).pack(fill="x", pady=(8, 0))
        ttk.Button(section_plot.body, text=TEXT_AUTO_ADJUST, command=self._auto_adjust_plot).pack(fill="x", pady=(6, 0))
        ttk.Label(section_plot.body, text="El intervalo de la cuadrícula ahora se ajusta automáticamente con el zoom.", wraplength=280, justify="left").pack(anchor="w", pady=(6, 0))
        self.plot_limit_entries = [entry_xmin, entry_xmax, entry_ymin, entry_ymax]

        section_meta = make_section("D. Datos del ensayo", expanded=False)
        ttk.Checkbutton(section_meta.body, text="Desbloquear datos del ensayo", variable=self.lock_meta_var, command=self._apply_meta_lock_state).pack(anchor="w", pady=(0, 8))
        self._meta_row_vertical(section_meta.body, "Procedimiento", self.procedure_var)
        self._meta_row_vertical(section_meta.body, "Norma de referencia", self.standard_var)
        self._meta_row_vertical(section_meta.body, "Temperatura Máx/Mín", self.temp_var)
        self._meta_row_vertical(section_meta.body, "Humedad Máx/Mín", self.humidity_var)
        self._meta_row_vertical(section_meta.body, "Equipo utilizado", self.machine_var)
        self._meta_row_vertical(section_meta.body, "Material", self.material_var)
        self._meta_row_vertical(section_meta.body, "Velocidad de ensayo", self.speed_var)
        self._meta_row_vertical(section_meta.body, "Control de velocidad", self.control_var)

        section_geom = make_section(TEXT_GEOMETRY_SECTION, expanded=False)
        ttk.Checkbutton(section_geom.body, text="Desbloquear forma y geometría", variable=self.lock_geometry_var, command=self._apply_geometry_lock_state).pack(anchor="w", pady=(0, 8))
        ttk.Label(section_geom.body, text="Forma").pack(anchor="w")
        self.shape_combo = ttk.Combobox(section_geom.body, textvariable=self.shape_var, values=SHAPE_OPTIONS, state="readonly", width=18)
        self.shape_combo.pack(anchor="w", pady=(4, 0))
        self.side1_row = self._make_labeled_entry(section_geom.body, "Espesor (mm)", self.side1_var)
        self.side1_entry = self.side1_row['entry']
        self.side2_row = self._make_labeled_entry(section_geom.body, "Anchura (mm)", self.side2_var)
        self.side2_entry = self.side2_row['entry']
        self.diameter_row = self._make_labeled_entry(section_geom.body, "Diámetro (mm)", self.diameter_var)
        self.diameter_entry = self.diameter_row['entry']
        area_row = ttk.Frame(section_geom.body)
        area_row.pack(fill="x", pady=(6, 0))
        self.area_label = ttk.Label(area_row, textvariable=self.area_label_var)
        self.area_label.pack(anchor="w")
        self.area_entry = ttk.Entry(area_row, textvariable=self.area_var, width=18)
        self.area_entry.pack(anchor="w", pady=(4, 0))
        gauge_row = self._make_labeled_entry(section_geom.body, "Longitud calibrada (mm)", self.gauge_var)
        self.gauge_entry = gauge_row['entry']
        self.apply_geometry_all_check = ttk.Checkbutton(
            section_geom.body,
            text="Aplicar esta geometría a todas las probetas",
            variable=self.apply_geometry_all_var,
        )
        self.apply_geometry_all_check.pack(anchor="w", pady=(8, 0))

        section_results = make_section(TEXT_RESULTS_SECTION, expanded=False)
        self._readonly_result_row(section_results.body, "Fluencia superior auto (MPa)", self.yield_auto_var)
        self._readonly_result_row(section_results.body, "Fluencia superior manual (MPa)", self.yield_manual_var)
        self._readonly_result_row(section_results.body, "Máximo auto (MPa)", self.max_auto_var)
        self._readonly_result_row(section_results.body, "Máximo manual (MPa)", self.max_manual_var)
        self._readonly_result_row(section_results.body, "Elongación luego de rotura (%)", self.elong_var)
        self._editable_row(section_results.body, "N° orden", self.order_var)
        self.order_entry = self._last_entry

        section_comment = make_section("G. Comentario", expanded=False)
        self.comment_text = tk.Text(section_comment.body, height=7, wrap="word", font=("Segoe UI", 9))
        self.comment_text.pack(fill="both", expand=True)
        self.comment_text.insert("1.0", DEFAULT_COMMENT)

        section_summary = make_section("H. Resumen por probeta", expanded=False)
        columns = ("specimen", "yield", "max", "yield_source", "max_source")
        summary_grid = ttk.Frame(section_summary.body)
        summary_grid.pack(fill="both", expand=True)
        self.summary_tree = ttk.Treeview(summary_grid, columns=columns, show="headings", height=8)
        self.summary_tree.heading("specimen", text="Probeta")
        self.summary_tree.heading("yield", text="Fluencia superior")
        self.summary_tree.heading("max", text="Máximo")
        self.summary_tree.heading("yield_source", text="Origen YP")
        self.summary_tree.heading("max_source", text="Origen Max")
        self.summary_tree.column("specimen", width=110, anchor="center")
        self.summary_tree.column("yield", width=90, anchor="center")
        self.summary_tree.column("max", width=90, anchor="center")
        self.summary_tree.column("yield_source", width=110, anchor="center")
        self.summary_tree.column("max_source", width=110, anchor="center")
        self.summary_tree.grid(row=0, column=0, sticky="nsew")
        summary_scroll_y = ttk.Scrollbar(summary_grid, orient="vertical", command=self.summary_tree.yview)
        summary_scroll_y.grid(row=0, column=1, sticky="ns")
        summary_scroll_x = ttk.Scrollbar(summary_grid, orient="horizontal", command=self.summary_tree.xview)
        summary_scroll_x.grid(row=1, column=0, sticky="ew")
        self.summary_tree.configure(yscrollcommand=summary_scroll_y.set, xscrollcommand=summary_scroll_x.set)
        summary_grid.rowconfigure(0, weight=1)
        summary_grid.columnconfigure(0, weight=1)

        section_actions = make_section(TEXT_ACTIONS_SECTION, expanded=False)
        ttk.Button(section_actions.body, text=TEXT_EXPORT_PNG, command=self._export_graph_png).pack(fill="x")
        ttk.Button(section_actions.body, text=TEXT_EXPORT_WORD, command=self.open_export_dialog).pack(fill="x", pady=(6, 0))

        self.root.after_idle(self._refresh_right_scrollregion)

    def _make_section(self, title: str, expanded: bool = True) -> CollapsibleSection:
        section = CollapsibleSection(self.right_inner, title, expanded=expanded, on_toggle=self._refresh_right_scrollregion)
        section.pack(fill="x", pady=(0, 8))
        return section

    def _packed_entry(self, parent, label: str, variable: tk.StringVar) -> None:
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=(6, 0))
        ttk.Label(frame, text=label).pack(anchor="w")
        entry = ttk.Entry(frame, textvariable=variable, width=18)
        entry.pack(anchor="w", pady=(4, 0))
        self._last_packed_entry = entry

    def _make_labeled_entry(self, parent, label: str, variable: tk.StringVar) -> dict:
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=(6, 0))
        ttk.Label(frame, text=label).pack(anchor="w")
        entry = ttk.Entry(frame, textvariable=variable, width=18)
        entry.pack(anchor="w", pady=(4, 0))
        return {"frame": frame, "entry": entry}

    def _meta_row_vertical(self, parent, label: str, variable: tk.StringVar) -> None:
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=(4, 0))
        ttk.Label(frame, text=f"{label}:").pack(anchor="w")
        entry = ttk.Entry(frame, textvariable=variable, width=28)
        entry.pack(fill="x", pady=(4, 0))
        self.meta_entries.append(entry)

    def _readonly_result_row(self, parent, label: str, variable: tk.StringVar) -> None:
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=(4, 0))
        ttk.Label(frame, text=label).pack(anchor="w")
        ttk.Entry(frame, textvariable=variable, width=20, state="readonly").pack(anchor="w", pady=(4, 0))

    def _editable_row(self, parent, label: str, variable: tk.StringVar) -> None:
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=(4, 0))
        ttk.Label(frame, text=label).pack(anchor="w")
        entry = ttk.Entry(frame, textvariable=variable, width=20)
        entry.pack(anchor="w", pady=(4, 0))
        self._last_entry = entry

    def _bind_events(self) -> None:
        self.specimen_combo.bind("<<ComboboxSelected>>", self._on_specimen_changed)
        self.summary_tree.bind("<<TreeviewSelect>>", self._on_summary_selected)
        self.shape_combo.bind("<<ComboboxSelected>>", self._on_shape_changed)

        self.plot_canvas.mpl_connect("motion_notify_event", self._on_mouse_move)
        self.plot_canvas.mpl_connect("button_press_event", self._on_mouse_press)
        self.plot_canvas.mpl_connect("button_release_event", self._on_mouse_release)
        self.plot_canvas.mpl_connect("scroll_event", self._on_scroll_zoom)
        self.plot_canvas.mpl_connect("draw_event", self._on_plot_draw)
        self.ax.callbacks.connect("xlim_changed", self._on_axes_limits_changed)
        self.ax.callbacks.connect("ylim_changed", self._on_axes_limits_changed)

        for var in (self.side1_var, self.side2_var, self.diameter_var, self.gauge_var, self.area_var, self.shape_var):
            var.trace_add("write", self._on_geometry_var_changed)

        for entry in self.meta_entries:
            entry.bind("<FocusOut>", self._on_metadata_focus_out)
        self.order_entry.bind("<FocusOut>", self._on_metadata_focus_out)
        self.comment_text.bind("<FocusOut>", self._on_metadata_focus_out)

    def _refresh_right_scrollregion(self) -> None:
        self.root.after_idle(self._on_right_inner_configure)
        self.root.after_idle(lambda: self.right_canvas.yview_moveto(self.right_canvas.yview()[0]))

    def _on_right_inner_configure(self, _event=None) -> None:
        if self.right_canvas is None:
            return
        self.right_canvas.configure(scrollregion=self.right_canvas.bbox("all"))

    def _on_right_canvas_configure(self, event=None) -> None:
        if self.right_canvas is None or self.right_window_id is None or event is None:
            return
        self.right_canvas.itemconfigure(self.right_window_id, width=event.width)
        self._on_right_inner_configure()

    def _bind_right_mousewheel(self, _event=None) -> None:
        self.right_canvas.bind_all("<MouseWheel>", self._on_right_mousewheel)

    def _unbind_right_mousewheel(self, _event=None) -> None:
        self.right_canvas.unbind_all("<MouseWheel>")

    def _on_right_mousewheel(self, event) -> None:
        if self.right_canvas is not None:
            self.right_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def open_file(self) -> None:
        file_path = filedialog.askopenfilename(
            title="Importar CSV de ensayo",
            filetypes=SUPPORTED_FILETYPES,
        )
        if file_path:
            self.load_file(file_path)

    def reload_file(self) -> None:
        if not self.current_file:
            show_info("Sin archivo", "No hay archivo cargado para recargar.")
            return
        self.load_file(self.current_file)

    def _sync_upper_yield_drop_from_ui(self) -> None:
        raw = self.upper_yield_drop_var.get().strip().replace(",", ".")
        try:
            value = float(raw)
        except Exception as exc:
            raise ValueError("La caída requerida para fluencia superior debe ser numérica.") from exc
        if value < 0:
            raise ValueError("La caída requerida para fluencia superior no puede ser negativa.")
        self.controller.set_upper_yield_drop_mpa(value)
        self.upper_yield_drop_var.set(f"{self.controller.settings.upper_yield_drop_mpa:g}")

    def _apply_upper_yield_drop_setting(self) -> None:
        try:
            self._sync_upper_yield_drop_from_ui()
            if self.controller.dataset:
                self.controller.recalculate_all()
                active = self.specimen_var.get().strip()
                if active:
                    self.controller.select_curve(active)
                self._refresh_current_curve(reset_zoom=False)
                self._refresh_summary_tree()
            self.status_var.set(
                f"Criterio de fluencia superior actualizado: caída ≥ {self.controller.settings.upper_yield_drop_mpa:g} MPa."
            )
        except Exception as exc:
            show_error("Criterio de fluencia", exc)

    def recalculate_all(self) -> None:
        if not self.controller.dataset:
            show_warning("Sin datos", "Primero importa un CSV para recalcular.")
            return
        active = self.specimen_var.get().strip()
        try:
            self._sync_upper_yield_drop_from_ui()
            self.controller.recalculate_all()
            if active:
                self.controller.select_curve(active)
            self._refresh_current_curve(reset_zoom=False)
            self._refresh_summary_tree()
            self.status_var.set("Curvas recalculadas con la configuración actual.")
        except Exception as exc:
            show_error("Recalcular", exc)

    def load_file(self, file_path: str) -> None:
        try:
            self._sync_upper_yield_drop_from_ui()
            dataset = self.controller.load_file(file_path)
        except Exception as exc:
            show_import_error(exc)
            return

        self.current_file = file_path
        self.file_label.config(text=Path(file_path).name)
        specimen_ids = dataset.specimen_ids()
        self.specimen_combo["values"] = specimen_ids
        if self.apply_geometry_all_check is not None:
            try:
                self.apply_geometry_all_check.configure(state=("normal" if len(specimen_ids) > 1 else "disabled"))
            except Exception:
                pass
            if len(specimen_ids) <= 1:
                self.apply_geometry_all_var.set(False)
        if specimen_ids:
            self.specimen_var.set(specimen_ids[0])
            self.controller.select_curve(specimen_ids[0])

        self._load_meta_from_dataset()
        self._auto_adjust_plot(silent=True)
        self._refresh_current_curve(reset_zoom=True)
        self._refresh_summary_tree()
        set_loaded_status(self.status_var, file_path, extra=warning_summary(dataset))

    def _load_meta_from_dataset(self) -> None:
        dataset = self.controller.dataset
        meta = dataset.meta if dataset else {}
        self._suspend_var_trace = True
        try:
            self.procedure_var.set(meta.get("Procedure", meta.get("Procedimiento", "")))
            self.standard_var.set(meta.get("Reference Standard", meta.get("Norma de Referencia", "")))
            self.machine_var.set(meta.get("Used Device", meta.get("Equipo Utilizado", "")))
            self.material_var.set(meta.get("Material", ""))
            self.speed_var.set(meta.get("Test Speed", meta.get("Velocidad de Ensayo", "")))
            self.humidity_var.set(meta.get("Humidity Max/Min", meta.get("Humedad Máx/Min", "")))
            self.temp_var.set(meta.get("Temperature Max/Min", meta.get("Temperatura Máx/Mín", meta.get("Temperatura Max/Min", ""))))
            self.control_var.set(meta.get("Speed Control", meta.get("Control de Velocidad", "")))
            self.order_var.set(meta.get("Order No", meta.get("Número de Orden", meta.get("N° orden", ""))))
            self.comment_text.delete("1.0", "end")
            self.comment_text.insert("1.0", meta.get("Comment", DEFAULT_COMMENT) or DEFAULT_COMMENT)
        finally:
            self._suspend_var_trace = False

    def _save_metadata_from_ui(self) -> None:
        if self._suspend_var_trace or not self.controller.dataset:
            return
        updates = {
            "Procedure": self.procedure_var.get().strip(),
            "Reference Standard": self.standard_var.get().strip(),
            "Used Device": self.machine_var.get().strip(),
            "Material": self.material_var.get().strip(),
            "Test Speed": self.speed_var.get().strip(),
            "Humidity Max/Min": self.humidity_var.get().strip(),
            "Temperature Max/Min": self.temp_var.get().strip(),
            "Speed Control": self.control_var.get().strip(),
            "Order No": self.order_var.get().strip(),
            "Comment": self.comment_text.get("1.0", "end").strip() or DEFAULT_COMMENT,
        }
        self.controller.update_metadata(updates)

    def _on_metadata_focus_out(self, _event=None) -> None:
        self._save_metadata_from_ui()

    def _on_specimen_changed(self, _event=None) -> None:
        specimen_id = self.specimen_var.get().strip()
        if specimen_id:
            self.controller.select_curve(specimen_id)
            self._refresh_current_curve(reset_zoom=True)

    def _on_summary_selected(self, _event=None) -> None:
        selection = self.summary_tree.selection()
        if not selection:
            return
        values = self.summary_tree.item(selection[0], "values")
        if not values:
            return
        specimen_id = values[0]
        self.specimen_var.set(specimen_id)
        self.controller.select_curve(specimen_id)
        self._refresh_current_curve(reset_zoom=True)

    def _on_shape_changed(self, _event=None) -> None:
        self._apply_shape_visibility()
        self._on_geometry_var_changed()

    def _apply_shape_visibility(self) -> None:
        shape = self.shape_var.get()
        is_circular = shape == SHAPE_CIRCULAR
        is_irregular = shape == SHAPE_IRREGULAR
        self.area_label_var.set("Área (mm²)" if is_irregular else "Área calculada (mm²)")
        if is_circular:
            self.side1_row['frame'].pack_forget()
            self.side2_row['frame'].pack_forget()
            self.diameter_row['frame'].pack(fill="x", pady=(6, 0), before=self.gauge_entry.master)
        elif is_irregular:
            self.side1_row['frame'].pack_forget()
            self.side2_row['frame'].pack_forget()
            self.diameter_row['frame'].pack_forget()
        else:
            self.diameter_row['frame'].pack_forget()
            self.side1_row['frame'].pack(fill="x", pady=(6, 0), before=self.gauge_entry.master)
            self.side2_row['frame'].pack(fill="x", pady=(6, 0), before=self.gauge_entry.master)
        self._apply_geometry_lock_state()

    def _refresh_current_curve(self, reset_zoom: bool = False) -> None:
        try:
            curve = self.controller.get_current_curve()
        except Exception:
            return

        self._suspend_var_trace = True
        try:
            self.shape_var.set(curve.geometry.shape or SHAPE_RECTANGULAR)
            self.side1_var.set(self._fmt(curve.geometry.side1_mm, 4))
            self.side2_var.set(self._fmt(curve.geometry.side2_mm, 4))
            self.diameter_var.set(self._fmt(curve.geometry.diameter_mm, 4))
            self.area_var.set(self._fmt(curve.geometry.area_mm2_manual if curve.geometry.shape == SHAPE_IRREGULAR else curve.geometry.area_mm2, 4))
            self.gauge_var.set(self._fmt(curve.geometry.gauge_length_mm, 4))
        finally:
            self._suspend_var_trace = False

        self._apply_shape_visibility()
        self.show_yield_var.set(curve.is_yield_visible)
        self.show_max_var.set(curve.is_max_visible)
        self.yield_auto_var.set(self._fmt_or_na(curve.auto_yield.y, 4))
        self.yield_manual_var.set(self._fmt_or_na(curve.manual_yield.y, 4))
        self.max_auto_var.set(self._fmt(curve.auto_max.y, 4))
        self.max_manual_var.set(self._fmt(curve.manual_max.y, 4))
        self.elong_var.set(self._fmt(curve.reported_elong_after_fracture_pct, 4))

        self._draw_curve(curve, reset_zoom=reset_zoom)
        self.status_var.set(f"Probeta activa: {curve.specimen_id}")

    def _draw_curve(self, curve: CurveState, reset_zoom: bool = False) -> None:
        limits_to_preserve = None if reset_zoom else (self.ax.get_xlim(), self.ax.get_ylim())

        self.ax.clear()
        self.ax.set_facecolor("#ffffff")
        self.ax.set_xlabel("Alargamiento (mm)")
        self.ax.set_ylabel("Esfuerzo (MPa)")

        df = curve.df
        if df.empty or "stress_MPa" not in df.columns:
            self.ax.text(0.5, 0.5, "Sin datos suficientes para graficar", ha="center", va="center", transform=self.ax.transAxes)
            self._apply_grid_and_formatting()
            self.plot_canvas.draw_idle()
            return

        x = df["elongation_mm"].to_numpy(dtype=float)
        y = df["stress_MPa"].to_numpy(dtype=float)
        self.ax.plot(x, y, color=CURVE_COLOR, linewidth=1.2, label=curve.specimen_id)

        if curve.is_yield_visible:
            self._draw_point(curve.chosen_yield, "YP", YIELD_COLOR)
        if curve.is_max_visible:
            self._draw_point(curve.chosen_max, "Max", MAX_COLOR)

        self.fig.subplots_adjust(right=0.84)
        self.ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), borderaxespad=0.0)
        self.ax.set_title(f"Curva esfuerzo-alargamiento: {curve.specimen_id}", fontsize=16, color="#314d6c", pad=18)

        if reset_zoom:
            self._apply_plot_configuration(curve_override=curve)
        elif limits_to_preserve is not None:
            self.ax.set_xlim(*limits_to_preserve[0])
            self.ax.set_ylim(*limits_to_preserve[1])
            self._apply_grid_and_formatting()
            self.plot_canvas.draw_idle()
        else:
            self._apply_grid_and_formatting()
            self.plot_canvas.draw_idle()

    def _draw_point(self, point: SelectedPoint, label: str, color: str) -> None:
        if point.index is None or point.x is None or point.y is None:
            return
        self.ax.scatter([point.x], [point.y], s=38, c=color, edgecolors="white", linewidths=0.8, zorder=6)
        self.ax.annotate(label, (point.x, point.y), textcoords="offset points", xytext=(4, -8), fontsize=10, color=color)

    def _apply_meta_lock_state(self) -> None:
        editable_state = "normal" if self.lock_meta_var.get() else "readonly"
        for entry in self.meta_entries:
            if editable_state == "normal":
                entry.state(["!readonly"])
            else:
                entry.state(["readonly"])

    def _apply_geometry_lock_state(self) -> None:
        editable_state = "normal" if self.lock_geometry_var.get() else "readonly"
        shape = self.shape_var.get()
        is_circular = shape == SHAPE_CIRCULAR
        is_irregular = shape == SHAPE_IRREGULAR

        def _set(entry, editable: bool) -> None:
            if entry is None:
                return
            if editable:
                entry.state(["!readonly"])
            else:
                entry.state(["readonly"])

        _set(self.side1_entry, editable_state == "normal" and not is_circular and not is_irregular)
        _set(self.side2_entry, editable_state == "normal" and not is_circular and not is_irregular)
        _set(self.diameter_entry, editable_state == "normal" and is_circular)
        _set(self.area_entry, editable_state == "normal" and is_irregular)
        _set(self.gauge_entry, editable_state == "normal")

        if editable_state == "normal":
            self.shape_combo.state(["!readonly"])
        else:
            self.shape_combo.state(["readonly"])

    def _update_plot_config_state(self) -> None:
        is_manual = self.plot_mode_var.get() == "manual"
        anchor = self.anchor_origin_var.get()
        for entry in self.plot_limit_entries:
            if is_manual:
                entry.state(["!readonly"])
            else:
                entry.state(["readonly"])
        if is_manual and anchor:
            self.plot_limit_entries[0].state(["readonly"])
            self.plot_limit_entries[2].state(["readonly"])
        self._apply_plot_style_only()

    def _on_visibility_changed(self) -> None:
        specimen_id = self.specimen_var.get().strip()
        if specimen_id:
            self.controller.set_visibility(specimen_id, self.show_yield_var.get(), self.show_max_var.get())
            self._refresh_current_curve(reset_zoom=False)

    def clear_manual_point(self, point_kind: str) -> None:
        specimen_id = self.specimen_var.get().strip()
        if not specimen_id:
            return
        try:
            self.controller.clear_manual_point(specimen_id, point_kind)
        except Exception as exc:
            show_error("Limpiar punto", exc)
            return
        self._refresh_current_curve(reset_zoom=False)
        self._refresh_summary_tree()

    def _on_geometry_var_changed(self, *args) -> None:
        if self._suspend_var_trace or not self.lock_geometry_var.get():
            return
        if self._geometry_after_id is not None:
            self.root.after_cancel(self._geometry_after_id)
        self._geometry_after_id = self.root.after(150, self._apply_geometry_change)

    def _apply_geometry_change(self) -> None:
        self._geometry_after_id = None
        specimen_id = self.specimen_var.get().strip()
        if not specimen_id:
            return
        shape = self.shape_var.get() or SHAPE_RECTANGULAR
        area_manual = self._parse_float_or_none(self.area_var.get()) if shape == SHAPE_IRREGULAR else None
        kwargs = dict(
            shape=shape,
            side1_mm=self._parse_float_or_none(self.side1_var.get()),
            side2_mm=self._parse_float_or_none(self.side2_var.get()),
            diameter_mm=self._parse_float_or_none(self.diameter_var.get()),
            gauge_length_mm=self._parse_float_or_none(self.gauge_var.get()),
            area_mm2_manual=area_manual,
        )
        try:
            if self.apply_geometry_all_var.get() and self.controller.dataset and len(self.controller.dataset.curves) > 1:
                self.controller.update_geometry_all(**kwargs)
                self.controller.select_curve(specimen_id)
                message = "Geometría aplicada a todas las probetas y curvas recalculadas."
            else:
                self.controller.update_geometry(specimen_id, **kwargs)
                message = "Geometría actualizada y curva recalculada."
        except Exception as exc:
            self.status_var.set(f"No se pudo actualizar geometría: {exc}")
            return
        self._refresh_current_curve(reset_zoom=False)
        self._refresh_summary_tree()
        self.status_var.set(message)

    def _recommended_limits(self, curve: CurveState) -> tuple[float, float, float, float]:
        x_min, x_max, y_min, y_max, _x_step, _y_step = self._auto_layout_with_full_squares(curve)
        return x_min, x_max, y_min, y_max

    def _set_plot_limit_vars(self, x_min: float, x_max: float, y_min: float, y_max: float) -> None:
        self.x_min_var.set(self._fmt(x_min, 4))
        self.x_max_var.set(self._fmt(x_max, 4))
        self.y_min_var.set(self._fmt(y_min, 4))
        self.y_max_var.set(self._fmt(y_max, 4))

    def _auto_adjust_plot(self, silent: bool = False) -> None:
        try:
            curve = self.controller.get_current_curve()
        except Exception:
            return
        self.plot_mode_var.set("auto")
        self._update_plot_config_state()
        x_min, x_max, y_min, y_max = self._recommended_limits(curve)
        self._set_plot_limit_vars(x_min, x_max, y_min, y_max)
        self.ax.set_xlim(x_min, x_max)
        self.ax.set_ylim(y_min, y_max)
        self._apply_grid_and_formatting()
        self.plot_canvas.draw_idle()
        if not silent:
            self.status_var.set("Vista autoajustada según la curva actual.")

    def _apply_plot_configuration(self, curve_override: Optional[CurveState] = None) -> None:
        try:
            curve = curve_override or self.controller.get_current_curve()
        except Exception:
            return
        recommended = self._recommended_limits(curve)
        if self.plot_mode_var.get() == "auto":
            x_min, x_max, y_min, y_max = recommended
            self._set_plot_limit_vars(x_min, x_max, y_min, y_max)
        else:
            if self.anchor_origin_var.get():
                x_min, y_min = 0.0, 0.0
            else:
                x_min = self._parse_float_or_none(self.x_min_var.get())
                y_min = self._parse_float_or_none(self.y_min_var.get())
            x_max = self._parse_float_or_none(self.x_max_var.get())
            y_max = self._parse_float_or_none(self.y_max_var.get())
            if x_min is None:
                x_min = recommended[0]
            if y_min is None:
                y_min = recommended[2]
            if x_max is None or x_max <= x_min:
                x_max = recommended[1]
            if y_max is None or y_max <= y_min:
                y_max = recommended[3]
            self._set_plot_limit_vars(x_min, x_max, y_min, y_max)
        self.ax.set_xlim(x_min, x_max)
        self.ax.set_ylim(y_min, y_max)
        self._apply_grid_and_formatting()
        self.plot_canvas.draw_idle()
        if curve_override is None:
            self.status_var.set("Configuración de gráfica aplicada.")

    def _apply_plot_style_only(self) -> None:
        self._apply_grid_and_formatting()
        self.plot_canvas.draw_idle()

    def _recommended_spacing(self, span: float) -> str:
        span = max(float(span), 1e-9)
        target_steps = 6.0
        raw = span / target_steps
        magnitude = 10 ** math.floor(math.log10(raw))
        normalized = raw / magnitude
        if normalized <= 1:
            nice = 1
        elif normalized <= 2:
            nice = 2
        elif normalized <= 5:
            nice = 5
        else:
            nice = 10
        return self._fmt(nice * magnitude, 4)

    def _apply_grid_and_formatting(self) -> None:
        # El intervalo de cuadros debe variar con el zoom, por lo que aquí no se
        # usan locators fijos por parte del usuario. AutoLocator recalcula los
        # pasos principales según los límites visibles actuales.
        self.ax.xaxis.set_major_locator(AutoLocator())
        self.ax.yaxis.set_major_locator(AutoLocator())
        try:
            self.ax.xaxis.set_minor_locator(AutoMinorLocator(2))
            self.ax.yaxis.set_minor_locator(AutoMinorLocator(2))
        except Exception:
            pass
        self.ax.grid(True, which="major", color=GRID, linestyle="--", linewidth=0.6)
        self.ax.grid(True, which="minor", color=GRID, linestyle=":", linewidth=0.35, alpha=0.7)
        self.ax.set_aspect("auto")
        self._apply_dynamic_formatters()

    def _on_mouse_move(self, event) -> None:
        specimen_id = self.specimen_var.get().strip()
        if not specimen_id or event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            self.cursor_var.set("Punto actual: —")
            return
        curve = self.controller.get_current_curve()
        idx = self._nearest_idx_to_cursor(curve, event.xdata, event.ydata)
        row = curve.df.iloc[idx]
        self.cursor_var.set(f"Punto actual: X={row['elongation_mm']:.6f} mm | Y={row['stress_MPa']:.6f} MPa | idx={idx}")
        if self._active_drag_target in {"yield", "max"}:
            self._apply_drag_point(self._active_drag_target, event.xdata, event.ydata)

    def _on_mouse_press(self, event) -> None:
        if event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            return
        drag_mode = self.drag_mode_var.get()
        if drag_mode not in {"yield", "max"}:
            return
        curve = self.controller.get_current_curve()
        target_point = curve.chosen_yield if drag_mode == "yield" else curve.chosen_max
        if not self._is_press_near_point(event, target_point):
            self._active_drag_target = None
            return
        self._active_drag_target = drag_mode
        self._apply_drag_point(self._active_drag_target, event.xdata, event.ydata)

    def _on_mouse_release(self, _event) -> None:
        if self._active_drag_target is not None:
            self._active_drag_target = None
            self._refresh_summary_tree()

    def _is_press_near_point(self, event, point: SelectedPoint, tolerance_px: float = 14.0) -> bool:
        if point.index is None or point.x is None or point.y is None:
            return False
        try:
            point_px = self.ax.transData.transform((point.x, point.y))
            dx = point_px[0] - event.x
            dy = point_px[1] - event.y
            return math.hypot(dx, dy) <= tolerance_px
        except Exception:
            return False

    def _apply_drag_point(self, point_kind: str, xdata: float, ydata: float) -> None:
        specimen_id = self.specimen_var.get().strip()
        if not specimen_id:
            return
        curve = self.controller.get_current_curve()
        next_idx = self._nearest_idx_to_cursor(curve, xdata, ydata)
        current_point = curve.chosen_yield if point_kind == "yield" else curve.chosen_max
        if current_point.index == next_idx and current_point.source == "manual":
            return
        try:
            self.controller.apply_manual_point(specimen_id, point_kind, x_mm=xdata, y_mpa=ydata)
        except Exception as exc:
            self.status_var.set(f"No se pudo arrastrar el punto: {exc}")
            return
        self._refresh_current_curve(reset_zoom=False)

    def _on_scroll_zoom(self, event) -> None:
        if event.inaxes != self.ax:
            return
        try:
            scale = float(self.zoom_factor_var.get())
        except Exception:
            scale = 1.20
        if scale <= 1.0:
            scale = 1.20
        cur_xlim = self.ax.get_xlim()
        cur_ylim = self.ax.get_ylim()
        xdata = event.xdata if event.xdata is not None else (cur_xlim[0] + cur_xlim[1]) / 2.0
        ydata = event.ydata if event.ydata is not None else (cur_ylim[0] + cur_ylim[1]) / 2.0
        factor = 1.0 / scale if event.button == "up" else scale if event.button == "down" else None
        if factor is None:
            return
        new_width = (cur_xlim[1] - cur_xlim[0]) * factor
        new_height = (cur_ylim[1] - cur_ylim[0]) * factor
        relx = (cur_xlim[1] - xdata) / max(cur_xlim[1] - cur_xlim[0], 1e-12)
        rely = (cur_ylim[1] - ydata) / max(cur_ylim[1] - cur_ylim[0], 1e-12)
        self.ax.set_xlim([xdata - new_width * (1 - relx), xdata + new_width * relx])
        self.ax.set_ylim([ydata - new_height * (1 - rely), ydata + new_height * rely])
        self._apply_grid_and_formatting()
        self.plot_canvas.draw_idle()

    def _on_axes_limits_changed(self, _axes=None) -> None:
        self._apply_dynamic_formatters(redraw=False)

    def _on_plot_draw(self, _event=None) -> None:
        self._apply_dynamic_formatters(redraw=False)

    def _apply_dynamic_formatters(self, redraw: bool = False) -> None:
        if self._is_updating_formatters:
            return
        self._is_updating_formatters = True
        try:
            x_step = self._estimate_axis_step("x")
            y_step = self._estimate_axis_step("y")
            x_decimals = self._decimals_for_step(x_step)
            y_decimals = self._decimals_for_step(y_step)
            self.ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _pos=None, dec=x_decimals: f"{value:.{dec}f}"))
            self.ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _pos=None, dec=y_decimals: f"{value:.{dec}f}"))
            if redraw and self.plot_canvas is not None:
                self.plot_canvas.draw_idle()
        finally:
            self._is_updating_formatters = False

    def _estimate_axis_step(self, axis_name: str) -> float:
        ticks = self.ax.get_xticks() if axis_name == "x" else self.ax.get_yticks()
        valid_diffs = [abs(ticks[i + 1] - ticks[i]) for i in range(len(ticks) - 1) if abs(ticks[i + 1] - ticks[i]) > 1e-12]
        if valid_diffs:
            return min(valid_diffs)
        view_min, view_max = self.ax.get_xlim() if axis_name == "x" else self.ax.get_ylim()
        span = abs(view_max - view_min)
        return max(span / 6.0, 1e-12)

    @staticmethod
    def _decimals_for_step(step: float) -> int:
        if step >= 100:
            return 0
        if step >= 10:
            return 1
        if step >= 1:
            return 2
        if step >= 0.1:
            return 3
        if step >= 0.01:
            return 4
        if step >= 0.001:
            return 5
        return 6

    def _refresh_summary_tree(self) -> None:
        for item in self.summary_tree.get_children():
            self.summary_tree.delete(item)
        for row in self.controller.get_summary_rows():
            self.summary_tree.insert(
                "",
                "end",
                values=(
                    row["specimen_id"],
                    self._fmt(row["yield_mpa"], 4),
                    self._fmt(row["max_mpa"], 4),
                    row["yield_source"],
                    row["max_source"],
                ),
            )

    def _nearest_idx_to_cursor(self, curve: CurveState, x: float, y: float) -> int:
        df = curve.df
        x_values = df["elongation_mm"].to_numpy(dtype=float)
        y_values = df["stress_MPa"].to_numpy(dtype=float)
        x_span = max(float(x_values.max() - x_values.min()), 1e-9)
        y_span = max(float(y_values.max() - y_values.min()), 1e-9)
        dx = (x_values - x) / x_span
        dy = (y_values - y) / y_span
        return int((dx * dx + dy * dy).argmin())

    def _nice_step(self, span: float, target_steps: float = 8.0, max_step: Optional[float] = None) -> float:
        span = max(float(span), 1e-9)
        raw = span / max(float(target_steps), 1.0)
        magnitude = 10 ** math.floor(math.log10(raw))
        normalized = raw / magnitude
        if normalized <= 1:
            nice = 1.0
        elif normalized <= 2:
            nice = 2.0
        elif normalized <= 2.5:
            nice = 2.5
        elif normalized <= 5:
            nice = 5.0
        else:
            nice = 10.0
        step = nice * magnitude
        if max_step is not None:
            step = min(step, float(max_step))
        return max(step, 1e-9)

    @staticmethod
    def _ceil_to_step(value: float, step: float) -> float:
        step = max(float(step), 1e-12)
        return math.ceil((float(value) - 1e-12) / step) * step

    @staticmethod
    def _floor_to_step(value: float, step: float) -> float:
        step = max(float(step), 1e-12)
        return math.floor((float(value) + 1e-12) / step) * step

    def _auto_layout_with_full_squares(self, curve: CurveState) -> tuple[float, float, float, float, float, float]:
        df = curve.df
        x = df["elongation_mm"].to_numpy(dtype=float)
        y = df["stress_MPa"].to_numpy(dtype=float)
        x_min_data = float(x.min())
        x_max_data = float(x.max())
        y_min_data = float(y.min())
        y_max_data = float(y.max())

        x_span = max(x_max_data - x_min_data, 1e-9)
        y_span = max(y_max_data - y_min_data, 1e-9)

        # Se busca que la vista automática y la exportación compartan la misma
        # lógica: cuadros completos, algo de aire y sin arrancar en negativo
        # cuando la curva realmente nace cerca del origen.
        x_step = self._nice_step(x_span * 1.15, target_steps=8.0)
        y_step = self._nice_step(y_span * 1.18, target_steps=10.0, max_step=25.0)

        x_air = 0.60 * x_step
        y_air = 0.60 * y_step

        # Requisito de la versión 1.2.0: en autoajuste la vista debe
        # arrancar siempre desde 0,0, tanto en tiempo real como en exportación.
        # El anclaje manual puede seguir existiendo, pero el modo automático ya
        # no debe retroceder a mínimos negativos como -10.
        x_min = 0.0
        y_min = 0.0

        x_max = self._ceil_to_step(x_max_data + x_air, x_step)
        y_max = self._ceil_to_step(y_max_data + y_air, y_step)

        if x_max <= x_min:
            x_max = x_min + x_step
        if y_max <= y_min:
            y_max = y_min + y_step

        return x_min, x_max, y_min, y_max, x_step, y_step

    def _export_auto_layout(self, curve: CurveState) -> tuple[float, float, float, float, float, float]:
        return self._auto_layout_with_full_squares(curve)

    def _export_graph_png(self) -> None:
        specimen_id = self.specimen_var.get().strip()
        if not specimen_id:
            show_warning("Sin probeta", "Primero selecciona una probeta.")
            return
        try:
            self._save_metadata_from_ui()
            curve = self.controller.get_current_curve()
        except Exception as exc:
            show_error("Exportar gráfica", exc)
            return

        output_path = filedialog.asksaveasfilename(
            title="Exportar gráfica PNG",
            defaultextension=".png",
            initialfile=f"grafica_{specimen_id}.png",
            filetypes=[("PNG", "*.png")],
        )
        if not output_path:
            return

        if self.plot_mode_var.get() == "auto":
            x_min, x_max, y_min, y_max, x_step, y_step = self._export_auto_layout(curve)
        else:
            x_min, x_max = self.ax.get_xlim()
            y_min, y_max = self.ax.get_ylim()
            x_step = self._estimate_axis_step("x")
            y_step = self._estimate_axis_step("y")
            x_min = self._floor_to_step(x_min, x_step)
            x_max = self._ceil_to_step(x_max, x_step)
            y_min = self._floor_to_step(y_min, y_step)
            y_max = self._ceil_to_step(y_max, y_step)

        export_fig = Figure(figsize=(8.4, 5.8), dpi=220, facecolor="none")
        export_ax = export_fig.add_subplot(111)
        export_ax.set_facecolor("none")

        df = curve.df
        x = df["elongation_mm"].to_numpy(dtype=float)
        y = df["stress_MPa"].to_numpy(dtype=float)
        export_ax.plot(x, y, color=CURVE_COLOR, linewidth=1.2, label=curve.specimen_id)

        if self.show_yield_var.get():
            point = curve.chosen_yield
            if point.index is not None and point.x is not None and point.y is not None:
                export_ax.scatter([point.x], [point.y], s=32, c=YIELD_COLOR, zorder=5)
                export_ax.annotate("YP", (point.x, point.y), textcoords="offset points", xytext=(4, -8), fontsize=9, color=YIELD_COLOR)
        if self.show_max_var.get():
            point = curve.chosen_max
            if point.index is not None and point.x is not None and point.y is not None:
                export_ax.scatter([point.x], [point.y], s=32, c=MAX_COLOR, zorder=5)
                export_ax.annotate("Max", (point.x, point.y), textcoords="offset points", xytext=(4, -8), fontsize=9, color=MAX_COLOR)

        export_ax.set_xlim(x_min, x_max)
        export_ax.set_ylim(y_min, y_max)
        export_ax.set_xlabel("Alargamiento (mm)")
        export_ax.set_ylabel("Esfuerzo (MPa)")
        export_ax.set_title(f"Curva esfuerzo-alargamiento: {curve.specimen_id}")
        export_ax.xaxis.set_major_locator(MultipleLocator(x_step))
        export_ax.yaxis.set_major_locator(MultipleLocator(y_step))
        export_ax.xaxis.set_minor_locator(AutoMinorLocator(2))
        export_ax.yaxis.set_minor_locator(AutoMinorLocator(2))
        export_ax.grid(True, which="major", color=GRID, linestyle="--", linewidth=0.7)
        export_ax.grid(True, which="minor", color=GRID, linestyle=":", linewidth=0.4, alpha=0.7)
        x_decimals = self._decimals_for_step(x_step)
        y_decimals = self._decimals_for_step(y_step)
        export_ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _pos=None, dec=x_decimals: f"{value:.{dec}f}"))
        export_ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _pos=None, dec=y_decimals: f"{value:.{dec}f}"))
        export_ax.legend(loc="upper left", bbox_to_anchor=(1.01, 1.0), borderaxespad=0.0)
        export_fig.tight_layout(rect=(0.0, 0.0, 0.88, 1.0))
        export_fig.savefig(output_path, dpi=220, transparent=True)
        show_info(
            "Gráfica exportada",
            "La gráfica se exportó correctamente.\n\n"
            f"Archivo:\n{output_path}\n\n"
            f"Autoajuste exportado con cuadros completos y paso Y={self._fmt(y_step, 4)}.",
        )

    def _reset_axes_labels(self) -> None:
        self.ax.set_xlabel("Alargamiento (mm)")
        self.ax.set_ylabel("Esfuerzo (MPa)")
        self._apply_grid_and_formatting()
        self.plot_canvas.draw_idle()

    @staticmethod
    def _parse_float_or_none(text: str) -> Optional[float]:
        s = (text or "").strip().replace(",", ".")
        if not s:
            return None
        try:
            return float(s)
        except Exception:
            return None

    @staticmethod
    def _fmt_or_na(value: Optional[float], ndigits: int = 2) -> str:
        if value is None:
            return "No disponible"
        try:
            return f"{float(value):.{ndigits}f}"
        except Exception:
            return "No disponible"

    @staticmethod
    def _fmt(value: Optional[float], ndigits: int = 2) -> str:
        if value is None:
            return ""
        try:
            return f"{float(value):.{ndigits}f}"
        except Exception:
            return ""


    def open_export_dialog(self) -> None:
        dataset = self.controller.dataset
        if dataset is None:
            show_warning("Sin datos", "Primero importa un CSV antes de preparar el informe.")
            return
        from .export_dialog import ReportExportDialog

        default_comment = self.comment_text.get("1.0", "end").strip() if self.comment_text is not None else DEFAULT_COMMENT
        ReportExportDialog(
            self.root,
            dataset=dataset,
            default_order_number=self.order_var.get().strip(),
            default_comment=default_comment,
        )

    def run(self) -> None:
        self.root.mainloop()
