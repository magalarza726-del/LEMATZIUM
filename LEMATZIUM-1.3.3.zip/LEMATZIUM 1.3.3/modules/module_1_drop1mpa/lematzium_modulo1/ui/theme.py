from __future__ import annotations

"""Theme constants for module 1.

Module 1 was changed back to a mostly native Tkinter look for faster startup,
but the UI code still expects ACCENT_SOFT and a few palette values. This file
keeps the window white while borrowing only the secondary accent from the
runtime theme selected in the launcher.
"""

try:
    from .runtime_theme import load_runtime_theme
    _palette = load_runtime_theme()
except Exception:
    _palette = {}

BG = "#f0f0f0"
PANEL = "#ffffff"
ACCENT = _palette.get("accent", "#0b69a3")
ACCENT_SOFT = _palette.get("accent_soft", "#66d9ff")
GRID = "#d8d8d8"
CURVE_COLOR = "#1f77b4"
YIELD_COLOR = "#444444"
MAX_COLOR = "#c23b22"
TEXT = "#111111"
TEXT_SOFT = "#4b5563"
FIELD_BG = ACCENT_SOFT
FIELD_TEXT = "#0f172a"
TOOLBAR_BG = "#ffffff"
FONT = ("Segoe UI", 10)
TITLE_FONT = ("Segoe UI Semibold", 11)
SMALL_FONT = ("Segoe UI", 9)
