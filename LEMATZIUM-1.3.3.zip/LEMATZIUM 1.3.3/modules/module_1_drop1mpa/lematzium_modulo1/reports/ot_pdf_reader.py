from __future__ import annotations

from pathlib import Path
import sys

MODULES_DIR = Path(__file__).resolve().parents[3]
if str(MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(MODULES_DIR))

from shared.ot_pdf_reader import OTContext, OTSampleRow, parse_ot_pdf  # noqa: E402

__all__ = ["OTContext", "OTSampleRow", "parse_ot_pdf"]
