from __future__ import annotations

import io
import re
import math
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml import parse_xml
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

from lematzium_modulo1.assays.tensile_drop_1mpa.contracts import CurveState, ParsedDataset
from .ot_pdf_reader import OTContext
from .templates import (
    ACCREDITATION_ACCREDITED,
    ACCREDITATION_NON_ACCREDITED,
    get_report_template_path,
)
from shared.tensile_report_tables import build_geometry_table
from shared.word_report_utils import (
    add_inline_picture as _add_inline_picture,
    cleanup_editable_report as _cleanup_editable_report,
    prepare_editable_document as _prepare_editable_document,
    remove_document_protection as _shared_remove_document_protection,
)

ARIAL = "Arial"
HEADER_FONT = "Calibri"
SECTION_FILL = "C0C0C0"
REPORT_LAYOUT_PATCH_VERSION = "v7_fecha_ensayo_borde_final_plus_4pt_real_header_calibri_body"
# Equivalente aproximado a mover un borde de tabla 1 punto en Word.
WORD_POINT_CM = 2.54 / 72
SAMPLE_TABLE_WIDTHS_CM = [
    1.75,
    3.55,  # descripción: se cede ancho a recepción para evitar salto en fechas ISO (AAAA-MM-DD)
    2.25,  # fecha de recepción en una sola línea
    2.05,
    2.20,
    3.10 + WORD_POINT_CM,  # línea condición/fecha de ensayo: 1 punto a la derecha
    1.60 + 8 * WORD_POINT_CM,  # borde final derecho conservado
]
SAMPLE_TABLE_WIDTH_CM = sum(SAMPLE_TABLE_WIDTHS_CM)
REPORT_TABLE_WIDTH_CM = SAMPLE_TABLE_WIDTH_CM
EXPORT_CURVE_COLOR = "#8b0f87"
EXPORT_BG_COLOR = "#efefef"
EXPORT_GRID_COLOR = "#808080"


@dataclass
class ReportExportGroup:
    report_number: str
    order_number: str
    specimen_ids: List[str]
    observations: str = ""
    title: str = "ENSAYO DE TENSIÓN"


@dataclass
class ReportExportPayload:
    accreditation_mode: str
    issue_date: str = ""
    client_name: str = ""
    client_phone: str = ""
    client_address: str = ""
    client_email: str = ""
    client_contact: str = ""
    default_comment: str = ""
    source_path: str = ""
    ot_pdf_path: str = ""
    ot_context: Optional[OTContext] = None
    groups: List[ReportExportGroup] = field(default_factory=list)


# ---------- basic helpers ----------
def _safe(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).replace("\ufeff", "")
    # Word repara el DOCX si entra algún carácter de control no válido en XML.
    text = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F]", "", text)
    return text.strip()


_SPANISH_MONTHS = {
    "enero": 1,
    "febrero": 2,
    "marzo": 3,
    "abril": 4,
    "mayo": 5,
    "junio": 6,
    "julio": 7,
    "agosto": 8,
    "septiembre": 9,
    "setiembre": 9,
    "octubre": 10,
    "noviembre": 11,
    "diciembre": 12,
}


def _flatten_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _client_line(value: Any) -> str:
    """Normaliza campos del encabezado provenientes del PDF de OT a una sola línea."""
    return _flatten_spaces(_safe(value))


def _to_iso_date(value: Any) -> str:
    normalized = _flatten_spaces(_safe(value))
    if not normalized:
        return ""
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
        return normalized
    match = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})", normalized)
    if match:
        day, month, year = match.groups()
        if len(year) == 2:
            year = f"20{year}"
        return f"{int(year):04d}-{int(month):02d}-{int(day):02d}"
    match = re.search(r"(\d{1,2})\s+de\s+([A-Za-zÁÉÍÓÚáéíóúñÑ]+)\s+del?\s+(\d{4})", normalized, re.IGNORECASE)
    if match:
        day, month_text, year = match.groups()
        month = _SPANISH_MONTHS.get(month_text.lower())
        if month:
            return f"{int(year):04d}-{month:02d}-{int(day):02d}"
    return normalized


def _meta_first(meta: Any, *keys: str, default: str = "") -> Any:
    if not isinstance(meta, dict):
        return default
    for key in keys:
        value = meta.get(key)
        if value not in (None, ""):
            return value
    return default


def _normalize_sample_key(value: Any) -> str:
    """Normaliza códigos de muestra para cruzar CSV, OT PDF y referencias internas."""
    text = _flatten_spaces(_safe(value)).upper()
    text = re.sub(r"[^A-Z0-9]+", "", text)
    return text


def _extract_sample_codes(value: Any) -> List[str]:
    """Extrae códigos tipo 26-0001 desde textos compuestos o referencias internas."""
    text = _safe(value)
    return re.findall(r"\b\d{2}-\d{4}(?:-\d+)?\b", text)


def _find_ot_sample_row(payload: ReportExportPayload, specimen_id: Any):
    """Busca la fila de muestra de la OT aun cuando el código venga con texto adicional."""
    if not payload.ot_context or not getattr(payload.ot_context, "sample_rows", None):
        return None
    rows = payload.ot_context.sample_rows
    specimen_text = _safe(specimen_id)
    candidates = [specimen_text, *_extract_sample_codes(specimen_text)]
    for candidate in candidates:
        if candidate in rows:
            return rows[candidate]
    normalized_candidates = {_normalize_sample_key(candidate) for candidate in candidates if _safe(candidate)}
    for key, row in rows.items():
        key_norm = _normalize_sample_key(key)
        row_code_norm = _normalize_sample_key(getattr(row, "specimen_id", key))
        if key_norm in normalized_candidates or row_code_norm in normalized_candidates:
            return row
    for key, row in rows.items():
        combined = f"{key} {getattr(row, 'specimen_id', '')} {getattr(row, 'raw_text', '')}"
        combined_norm = _normalize_sample_key(combined)
        if any(candidate and candidate in combined_norm for candidate in normalized_candidates):
            return row
    return None


def _sanitize_filename(name: str) -> str:
    import re
    return re.sub(r"[^\w\-. ]+", "_", _safe(name)).strip().replace(" ", "_")


def _f2(value: Optional[float], ndigits: int = 2) -> str:
    try:
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return ""
        return f"{float(value):.{ndigits}f}"
    except Exception:
        return ""


def _f0(value: Optional[float]) -> str:
    try:
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return ""
        return f"{float(value):.0f}"
    except Exception:
        return ""


def _f0_or_na(value: Optional[float]) -> str:
    text = _f0(value)
    return text if text else "No disponible"


def _remove_leading_empty_paragraphs(document: Document) -> None:
    for paragraph in list(document.paragraphs):
        if paragraph.text.strip():
            break
        paragraph._element.getparent().remove(paragraph._element)


def _set_cell_text(cell, text: str, *, bold: bool = False, align: int = WD_ALIGN_PARAGRAPH.LEFT, font_size: int = 9) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = align
    run = paragraph.add_run(_safe(text))
    run.bold = bold
    run.font.name = ARIAL
    run.font.size = Pt(font_size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def _set_table_borders(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "000000")


def _set_table_outer_borders_only(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "000000")
    for edge in ("insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "nil")


def _cm_to_dxa(width_cm: float) -> int:
    """Convert centimeters to Word twips (dxa)."""
    return max(1, int(round(width_cm * 1440 / 2.54)))


def _set_table_fixed_widths(table, widths_cm: Sequence[float]) -> None:
    """Force Word to use the exact column grid instead of recalculating AutoFit.

    Setting only ``cell.width`` is not always enough: Word can rewrite the
    table grid when opening the document. This writes the table width, the
    fixed layout flag, the ``tblGrid`` columns, and each cell ``tcW`` value.
    """
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    tbl = table._tbl
    tbl_pr = tbl.tblPr

    # Center at XML level and remove any inherited indentation from the template.
    tbl_jc = tbl_pr.find(qn("w:jc"))
    if tbl_jc is None:
        tbl_jc = OxmlElement("w:jc")
        tbl_pr.append(tbl_jc)
    tbl_jc.set(qn("w:val"), "center")
    for tbl_ind in list(tbl_pr.findall(qn("w:tblInd"))):
        tbl_pr.remove(tbl_ind)

    tbl_layout = tbl_pr.find(qn("w:tblLayout"))
    if tbl_layout is None:
        tbl_layout = OxmlElement("w:tblLayout")
        tbl_pr.append(tbl_layout)
    tbl_layout.set(qn("w:type"), "fixed")

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), str(_cm_to_dxa(sum(widths_cm))))

    existing_grid = tbl.find(qn("w:tblGrid"))
    if existing_grid is not None:
        tbl.remove(existing_grid)
    tbl_grid = OxmlElement("w:tblGrid")
    for width in widths_cm:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(_cm_to_dxa(width)))
        tbl_grid.append(grid_col)
    tbl.insert(1, tbl_grid)

    for row in table.rows:
        for column_index, width in enumerate(widths_cm):
            cell = row.cells[column_index]
            cell.width = Cm(width)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:type"), "dxa")
            tc_w.set(qn("w:w"), str(_cm_to_dxa(width)))


def _make_table(document: Document, rows: int, cols: int, widths_cm: Sequence[float]):
    table = document.add_table(rows=rows, cols=cols)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    _set_table_fixed_widths(table, widths_cm)
    _set_table_borders(table)
    return table


def _add_simple_field(paragraph, field_code: str, placeholder: str = "1") -> None:
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), field_code)
    run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    _set_rpr_font_name(r_pr, HEADER_FONT)
    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), "22")  # 11 pt = 22 half-points
    r_pr.append(sz)
    sz_cs = OxmlElement("w:szCs")
    sz_cs.set(qn("w:val"), "22")
    r_pr.append(sz_cs)
    run.append(r_pr)
    text_el = OxmlElement("w:t")
    text_el.text = placeholder
    run.append(text_el)
    fld.append(run)
    paragraph._p.append(fld)


def _set_table_border_nil(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "nil")


def _remove_document_protection(document: Document) -> None:
    _shared_remove_document_protection(document)


def _style_paragraph_runs(paragraph, *, font_name: str = ARIAL, font_size: int = 10, bold_labels: Sequence[str] | None = None) -> None:
    bold_labels = tuple(bold_labels or [])
    for run in paragraph.runs:
        run.font.name = font_name
        run.font.size = Pt(font_size)
        if any(label in run.text for label in bold_labels):
            run.bold = True



def _set_rpr_font_name(r_pr, font_name: str = HEADER_FONT) -> None:
    """Set run fonts explicitly to Calibri and tag them as Word body-theme text."""
    r_fonts = r_pr.find(qn("w:rFonts"))
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.insert(0, r_fonts)
    for attr in ("ascii", "hAnsi", "eastAsia", "cs"):
        r_fonts.set(qn(f"w:{attr}"), font_name)
    # These theme attributes make Word show/use the body font family when applicable.
    r_fonts.set(qn("w:asciiTheme"), "minorHAnsi")
    r_fonts.set(qn("w:hAnsiTheme"), "minorHAnsi")
    r_fonts.set(qn("w:eastAsiaTheme"), "minorEastAsia")
    r_fonts.set(qn("w:cstheme"), "minorBidi")


def _force_header_font_calibri_body(header) -> None:
    """Force every run in the Word header to Calibri (Body) at 11 pt.

    This includes runs created inside PAGE/NUMPAGES fields and paragraph breaks,
    so Word does not fall back to the template's previous 10 pt value when the
    user places the cursor in the header.
    """
    for run_el in header._element.xpath(".//w:r"):
        r_pr = run_el.find(qn("w:rPr"))
        if r_pr is None:
            r_pr = OxmlElement("w:rPr")
            run_el.insert(0, r_pr)
        _set_rpr_font_name(r_pr, HEADER_FONT)
        for tag in ("w:sz", "w:szCs"):
            existing = r_pr.find(qn(tag))
            if existing is None:
                existing = OxmlElement(tag)
                r_pr.append(existing)
            existing.set(qn("w:val"), "22")  # 11 pt = 22 half-points

def _set_header_content(document: Document, report_number: str, order_number: str, issue_date: str, total_pages: int) -> None:
    issue_date = _to_iso_date(issue_date)
    for section in document.sections:
        section.different_first_page_header_footer = False
        header = section.header
        if not header.tables:
            _force_header_font_calibri_body(header)
            continue
        header_table = header.tables[0]
        while len(header_table.rows) > 1:
            header_table._tbl.remove(header_table.rows[-1]._tr)
        metadata_row = header_table.add_row()

        if len(metadata_row.cells) == 3:
            left_cell, middle_cell, right_cell = metadata_row.cells
            middle_cell.text = ""
        else:
            left_cell, right_cell = metadata_row.cells

        for paragraph in (left_cell.paragraphs[0], right_cell.paragraphs[0]):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
            paragraph.paragraph_format.space_before = Pt(4)
            paragraph.paragraph_format.space_after = Pt(0)

        left_p = left_cell.paragraphs[0]
        r = left_p.add_run("Hoja: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        _add_simple_field(left_p, "PAGE", "1")
        r = left_p.add_run(" de ")
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        _add_simple_field(left_p, "NUMPAGES", str(total_pages))
        left_p.add_run("\n")
        r = left_p.add_run("N° de informe: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        r = left_p.add_run(report_number)
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)

        right_p = right_cell.paragraphs[0]
        r = right_p.add_run("Fecha de emisión: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        r = right_p.add_run(issue_date)
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        right_p.add_run("\n")
        r = right_p.add_run("Número de Orden: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        r = right_p.add_run(order_number)
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)

        _set_table_border_nil(header_table)
        _force_header_font_calibri_body(header)


def _add_signature_block(document: Document) -> None:
    spacer = document.add_paragraph()
    spacer.paragraph_format.space_before = Pt(8)
    spacer.paragraph_format.space_after = Pt(4)

    table = document.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    row = table.rows[0]
    row.height = Cm(1.7)
    row.height_rule = WD_ROW_HEIGHT_RULE.EXACTLY
    row.cells[0].width = Cm(8.3)
    row.cells[1].width = Cm(8.3)
    _set_table_borders(table)
    _set_cell_text(table.cell(0, 0), "Departamento técnico", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=11)
    _set_cell_text(table.cell(0, 1), "", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=11)
# ---------- content builders ----------
def _build_title_block(document: Document, report_number: str, order_number: str, issue_date: str) -> None:
    # Kept for backward compatibility; header is now built via _set_header_content.
    return


def _build_client_block(document: Document, payload: ReportExportPayload) -> None:
    title_table = _make_table(document, 1, 1, [REPORT_TABLE_WIDTH_CM])
    _set_cell_text(title_table.cell(0, 0), 'DATOS GENERALES DEL CLIENTE', bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=10)
    _set_cell_shading(title_table.cell(0, 0), SECTION_FILL)
    for paragraph in title_table.cell(0, 0).paragraphs:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    table = _make_table(document, 5, 1, [REPORT_TABLE_WIDTH_CM])
    _set_table_outer_borders_only(table)
    labels = [
        "DATOS DEL CLIENTE:",
        "TELÉFONO:",
        "DIRECCIÓN:",
        "CORREO ELECTRÓNICO:",
        "CONTACTO:",
    ]
    client_name = payload.client_name or (payload.ot_context.client_name if payload.ot_context else "")
    client_phone = payload.client_phone or (payload.ot_context.phone if payload.ot_context else "")
    client_address = payload.client_address or (payload.ot_context.address if payload.ot_context else "")
    client_email = payload.client_email or (payload.ot_context.email if payload.ot_context else "")
    client_contact = payload.client_contact or (payload.ot_context.contact if payload.ot_context else "")
    values = [client_name, client_phone, client_address, client_email, client_contact]
    for row_index, (label, value) in enumerate(zip(labels, values)):
        cell = table.cell(row_index, 0)
        cell.text = ""
        paragraph = cell.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        run_label = paragraph.add_run(label)
        run_label.bold = True
        run_label.font.name = ARIAL
        run_label.font.size = Pt(9)
        run_value = paragraph.add_run(f" {_client_line(value)}")
        run_value.font.name = ARIAL
        run_value.font.size = Pt(9)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _sample_row_for_curve(dataset: ParsedDataset, curve: CurveState, payload: ReportExportPayload) -> List[str]:
    meta = dataset.meta or {}
    curve_meta = getattr(curve, "meta", {}) or {}
    ot_row = _find_ot_sample_row(payload, getattr(curve, "specimen_id", ""))
    try:
        raw_description = curve.raw_df.attrs.get("description", "")
    except Exception:
        raw_description = ""

    specimen_id = _safe(getattr(curve, "specimen_id", ""))
    description = (
        (ot_row.description if ot_row else "")
        or raw_description
        or curve_meta.get("Descripción de la muestra", "")
        or curve_meta.get("Descripcion de la muestra", "")
        or curve_meta.get("Sample Description", "")
        or curve_meta.get("Description", "")
        or meta.get(f"description_{specimen_id}", "")
        or _meta_first(meta, "Descripción de la muestra", "Descripcion de la muestra", "Sample Description", "Description")
    )
    received = (ot_row.received_date if ot_row else "") or _meta_first(
        curve_meta,
        "Fecha Recepción",
        "Fecha de Recepción",
        "Fecha de recepción de muestras",
        "Reception Date",
        "Received Date",
    ) or _meta_first(
        meta,
        "Fecha Recepción",
        "Fecha de Recepción",
        "Fecha de recepción de muestras",
        "Reception Date",
        "Received Date",
    )
    tested = _meta_first(curve_meta, "Fecha Ensayo", "Fecha de Ensayo", "Test Date") or _meta_first(meta, "Fecha Ensayo", "Fecha de Ensayo", "Test Date") or received
    return [
        specimen_id,
        _safe(description),
        _to_iso_date(received),
        "☒ Cliente  \n☐ Otros  \n☐ No aplica",
        "☐ Cliente  \n☒ LEMAT  \n☐ No aplica",
        "☒ Acorde a norma  \n☐ No acorde a norma  \n☐ No aplica",
        _to_iso_date(tested),
    ]


def _set_checkbox_block_cell(cell, options: Sequence[str], selected_label: str) -> None:
    cell.text = ""
    inner = cell.add_table(rows=len(options), cols=1)
    inner.alignment = WD_TABLE_ALIGNMENT.CENTER
    inner.autofit = False
    _set_table_borders(inner)
    for idx, label in enumerate(options):
        inner_cell = inner.cell(idx, 0)
        _set_cell_text(
            inner_cell,
            ("☒ " if label == selected_label else "☐ ") + label,
            align=WD_ALIGN_PARAGRAPH.LEFT,
            font_size=8,
        )
        inner_cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        for paragraph in inner_cell.paragraphs:
            paragraph.paragraph_format.space_before = Pt(0)
            paragraph.paragraph_format.space_after = Pt(0)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _set_norma_checkbox_cell(cell, selected_label: str = "Acorde a norma") -> None:
    _set_checkbox_block_cell(cell, ["Acorde a norma", "No acorde a norma", "No aplica"], selected_label)

def _set_checkbox_option_row(cell, label: str, selected: bool) -> None:
    _set_cell_text(
        cell,
        ("☒ " if selected else "☐ ") + label,
        align=WD_ALIGN_PARAGRAPH.LEFT,
        font_size=8,
    )
    for paragraph in cell.paragraphs:
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER



def _build_sample_block(document: Document, dataset: ParsedDataset, payload: ReportExportPayload, group: ReportExportGroup) -> None:
    title_table = _make_table(document, 1, 1, [SAMPLE_TABLE_WIDTH_CM])
    _set_cell_text(title_table.cell(0, 0), 'DATOS DE LA MUESTRA', bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=10)
    _set_cell_shading(title_table.cell(0, 0), SECTION_FILL)
    for paragraph in title_table.cell(0, 0).paragraphs:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    specimen_count = len(group.specimen_ids)
    table = _make_table(document, 1 + specimen_count * 3, 7, SAMPLE_TABLE_WIDTHS_CM)
    headers = [
        "Código de Muestra LEMAT",
        "Descripción de la muestra proporcionada por el cliente",
        "Fecha de\nRecepción",
        "Muestreo\nrealizado por",
        "Preparación de\nmuestra\nrealizada por",
        "Condición de\nentrega de la\nmuestra previo al\nensayo",
        "Fecha de\nEnsayo",
    ]
    for col_index, header in enumerate(headers):
        _set_cell_text(table.cell(0, col_index), header, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)

    for specimen_index, specimen_id in enumerate(group.specimen_ids):
        curve = dataset.get_curve(specimen_id)
        row_values = _sample_row_for_curve(dataset, curve, payload)
        start_row = 1 + specimen_index * 3
        end_row = start_row + 2

        # Merge the non-checkbox columns vertically across the 3 subrows.
        for col_index in (0, 1, 2, 6):
            merged = table.cell(start_row, col_index).merge(table.cell(end_row, col_index))
            align = WD_ALIGN_PARAGRAPH.CENTER
            _set_cell_text(merged, row_values[col_index], align=align, font_size=8)
            merged.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

        # Checkbox columns as true uniform subcells, one row per option.
        _set_checkbox_option_row(table.cell(start_row + 0, 3), "Cliente", True)
        _set_checkbox_option_row(table.cell(start_row + 1, 3), "Otros", False)
        _set_checkbox_option_row(table.cell(start_row + 2, 3), "No aplica", False)

        _set_checkbox_option_row(table.cell(start_row + 0, 4), "Cliente", False)
        _set_checkbox_option_row(table.cell(start_row + 1, 4), "LEMAT", True)
        _set_checkbox_option_row(table.cell(start_row + 2, 4), "No aplica", False)

        _set_checkbox_option_row(table.cell(start_row + 0, 5), "Acorde a norma", True)
        _set_checkbox_option_row(table.cell(start_row + 1, 5), "No acorde a norma", False)
        _set_checkbox_option_row(table.cell(start_row + 2, 5), "No aplica", False)

    for row in table.rows[1:]:
        row.height = Cm(0.60)
        row.height_rule = WD_ROW_HEIGHT_RULE.EXACTLY

    # Reapply exact grid after vertical merges because Word/python-docx may rewrite tcW.
    _set_table_fixed_widths(table, SAMPLE_TABLE_WIDTHS_CM)


def _build_observations_block(document: Document, observations: str) -> None:
    # Separación equivalente a un Shift+Enter entre la tabla DATOS DE LA MUESTRA
    # y el rótulo Observaciones, manteniendo el flujo del reporte editable.
    cover_spacer = document.add_paragraph()
    cover_spacer.paragraph_format.space_before = Pt(0)
    cover_spacer.paragraph_format.space_after = Pt(0)
    cover_spacer.add_run().add_break(WD_BREAK.LINE)

    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(0)
    run = paragraph.add_run("Observaciones")
    run.bold = True
    run.font.name = ARIAL
    run.font.size = Pt(10)

    body = document.add_paragraph(_safe(observations))
    for run in body.runs:
        run.font.name = ARIAL
        run.font.size = Pt(9)


def _compute_export_plot_limits(x_values, y_values):
    x_max = max(float(max(x_values)) if len(x_values) else 0.0, 1.0)
    y_max = max(float(max(y_values)) if len(y_values) else 0.0, 1.0)
    x_lim = max(7.0, math.ceil(x_max / 7.0) * 7.0)
    y_lim = max(70.0, math.ceil((y_max + 20.0) / 70.0) * 70.0)
    return 0.0, x_lim, 0.0, y_lim


def render_curve_png(curve: CurveState, *, width_inches: float = 6.8, height_inches: float = 4.1, dpi: int = 220) -> bytes:
    df = curve.df.copy()
    x_values = df["elongation_mm"].astype(float).to_numpy()
    y_values = df["stress_MPa"].astype(float).to_numpy()

    figure = plt.figure(figsize=(width_inches, height_inches), dpi=dpi, facecolor="none")
    ax = figure.add_subplot(111)
    figure.patch.set_facecolor("none")
    figure.patch.set_alpha(0.0)
    ax.set_facecolor("none")

    ax.plot(x_values, y_values, color=EXPORT_CURVE_COLOR, linewidth=0.9)
    ax.set_xlabel("Alargamiento(mm)", fontsize=9)
    ax.set_ylabel("Esfuerzo(MPa)", fontsize=9)
    ax.tick_params(labelsize=8)
    xmin, xmax, ymin, ymax = _compute_export_plot_limits(x_values, y_values)
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)

    from matplotlib.ticker import MultipleLocator, AutoMinorLocator
    ax.xaxis.set_major_locator(MultipleLocator(7))
    ax.yaxis.set_major_locator(MultipleLocator(70))
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    ax.grid(which="major", color=EXPORT_GRID_COLOR, linestyle="-", linewidth=0.45)
    ax.grid(which="minor", color="#606060", linestyle=(0, (4, 6)), linewidth=0.45, alpha=0.95)

    for spine in ax.spines.values():
        spine.set_linewidth(0.6)
        spine.set_color("#5f5f5f")

    yield_point = curve.chosen_yield
    max_point = curve.chosen_max
    if yield_point.index is not None and yield_point.x is not None and yield_point.y is not None:
        ax.scatter([yield_point.x], [yield_point.y], s=18, color="black", zorder=5)
        ax.annotate("YP", (yield_point.x, yield_point.y), xytext=(5, -5), textcoords="offset points", fontsize=8)
    if max_point.index is not None and max_point.x is not None and max_point.y is not None:
        ax.scatter([max_point.x], [max_point.y], s=18, color="black", zorder=5)
        ax.annotate("Max", (max_point.x, max_point.y), xytext=(5, -5), textcoords="offset points", fontsize=8)

    ax.legend(
        [curve.specimen_id],
        loc="upper left",
        bbox_to_anchor=(1.01, 1.0),
        borderaxespad=0.0,
        fontsize=8,
        frameon=True,
        fancybox=False,
        edgecolor="#555",
    )
    output = io.BytesIO()
    figure.tight_layout(pad=0.9)
    figure.savefig(output, format="png", dpi=dpi, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(figure)
    return output.getvalue()


def _build_tension_section(document: Document, dataset: ParsedDataset, group: ReportExportGroup, curve: CurveState, comment_text: str) -> None:
    document.add_page_break()

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(10)
    title_text = str(group.title or "ENSAYO DE TENSIÓN").upper()
    title_run = title.add_run(title_text)
    title_run.bold = True
    title_run.font.name = "Calibri"
    title_run.font.size = Pt(11)

    meta_table = _make_table(document, 4, 4, [3.2, 4.2, 3.6, 5.2])
    _set_table_border_nil(meta_table)
    left_pairs = [
        ("Procedimiento", _meta_first(dataset.meta, "Procedimiento", "Procedure", default="PEE/LEMAT/03")),
        ("Temperatura Máx/Mín", _meta_first(dataset.meta, "Temperatura Máx/Mín", "Temperatura Max/Min", "Temperature Max/Min")),
        ("Equipo utilizado", _meta_first(dataset.meta, "Equipo Utilizado", "Used Device", default="MUE 600KN")),
        ("Velocidad de ensayo", _meta_first(dataset.meta, "Velocidad de Ensayo", "Velocidad de ensayo", "Test Speed")),
    ]
    right_pairs = [
        ("Norma de Referencia", _meta_first(dataset.meta, "Norma de Referencia", "Norma de referencia", "Reference Standard", default="ISO 6892-1:2016")),
        ("Humedad Máx/Mín", _meta_first(dataset.meta, "Humedad Máx/Mín", "Humidity Max/Min")),
        ("Material", _meta_first(dataset.meta, "Material", default="Acero")),
        ("Control de Velocidad", _meta_first(dataset.meta, "Control de Velocidad", "Speed Control", default="Mediante tasa de esfuerzo")),
    ]
    for row_index, (label, value) in enumerate(left_pairs):
        _set_cell_text(meta_table.cell(row_index, 0), f"{label}:", bold=True, font_size=8)
        _set_cell_text(meta_table.cell(row_index, 1), _safe(value), font_size=8)
    for row_index, (label, value) in enumerate(right_pairs):
        _set_cell_text(meta_table.cell(row_index, 2), f"{label}:", bold=True, font_size=8)
        _set_cell_text(meta_table.cell(row_index, 3), _safe(value), font_size=8)

    build_geometry_table(document, curve.geometry, curve.specimen_id, result_widths_cm=[2.8, 4.2, 3.4, 4.2])

    result_table = _make_table(document, 4, 4, [2.8, 4.2, 3.4, 4.2])
    headers = ["Nombre", "Esfuerzo de Fluencia\nSuperior", "Esfuerzo Máximo", "Elongación luego de\nRotura"]
    for col_index, header in enumerate(headers):
        _set_cell_text(result_table.cell(0, col_index), header, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(1, 0), "Parámetro", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(1, 1), "1 Puntos", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(2, 0), "Unidades", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(2, 1), "MPa", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(2, 2), "MPa", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(2, 3), "%", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(3, 0), curve.specimen_id, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(3, 1), _f0_or_na(curve.chosen_yield.y), align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(3, 2), _f0(curve.chosen_max.y), align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    _set_cell_text(result_table.cell(3, 3), _f2(curve.reported_elong_after_fracture_pct, 1), align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)

    image_bytes = render_curve_png(curve, width_inches=7.0, height_inches=4.3, dpi=220)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        temp_path = Path(tmp.name)
    picture_paragraph = document.add_paragraph()
    picture_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _add_inline_picture(picture_paragraph, temp_path, width_cm=16.6)
    temp_path.unlink(missing_ok=True)

    comment_title = document.add_paragraph()
    comment_run = comment_title.add_run("Comentarios")
    comment_run.bold = True
    comment_run.font.name = ARIAL
    comment_run.font.size = Pt(9)
    for line in _safe(comment_text).splitlines():
        paragraph = document.add_paragraph(line)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.space_before = Pt(0)
        for run in paragraph.runs:
            run.font.name = ARIAL
            run.font.size = Pt(8)


# ---------- public api ----------
def create_report_document_from_template(template_path: str | Path) -> Document:
    document = Document(str(template_path))
    _prepare_editable_document(document)
    return document


def export_group_to_docx(dataset: ParsedDataset, payload: ReportExportPayload, group: ReportExportGroup, output_path: str | Path) -> Path:
    template_path = get_report_template_path(payload.accreditation_mode)
    document = create_report_document_from_template(template_path)
    total_pages = 1 + len(group.specimen_ids)
    _set_header_content(document, group.report_number, group.order_number, payload.issue_date, total_pages)
    _build_title_block(document, group.report_number, group.order_number, payload.issue_date)
    _build_client_block(document, payload)
    _build_sample_block(document, dataset, payload, group)
    _build_observations_block(document, group.observations)
    comment_text = payload.default_comment
    for specimen_id in group.specimen_ids:
        curve = dataset.get_curve(specimen_id)
        _build_tension_section(document, dataset, group, curve, comment_text)
    _add_signature_block(document)
    _cleanup_editable_report(document, max_table_width_cm=REPORT_TABLE_WIDTH_CM)

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    document.save(output)
    return output


def export_report_groups_to_docx(dataset: ParsedDataset, payload: ReportExportPayload, output_dir: str | Path) -> List[Path]:
    output_directory = Path(output_dir)
    output_directory.mkdir(parents=True, exist_ok=True)
    exported_files: List[Path] = []
    for group in payload.groups:
        client_name = payload.client_name or (payload.ot_context.client_name if payload.ot_context else "")
        filename = f"INFORME N°{group.report_number} {client_name} {group.order_number}.docx"
        filename = re.sub(r'[\/:*?"<>|]', '_', filename).strip()
        exported_files.append(export_group_to_docx(dataset, payload, group, output_directory / filename))
    return exported_files


__all__ = [
    "ACCREDITATION_ACCREDITED",
    "ACCREDITATION_NON_ACCREDITED",
    "ReportExportGroup",
    "ReportExportPayload",
    "create_report_document_from_template",
    "export_group_to_docx",
    "export_report_groups_to_docx",
]
