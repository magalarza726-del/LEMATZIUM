from __future__ import annotations

from pathlib import Path
import sys

MODULES_DIR = Path(__file__).resolve().parents[3]
if str(MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(MODULES_DIR))

from shared.report_templates import (  # noqa: E402
    ACCREDITATION_ACCREDITED,
    ACCREDITATION_NON_ACCREDITED,
    get_report_template_path as _shared_get_report_template_path,
    register_custom_report_template,
    report_template_choices,
    report_template_mapping,
    templates_dir_from_reports_file,
)

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = templates_dir_from_reports_file(__file__)
REPORT_TEMPLATE_BY_ACCREDITATION = report_template_mapping(__file__)


def get_report_template_path(accreditation_mode: str) -> Path:
    return _shared_get_report_template_path(__file__, accreditation_mode)

def get_report_template_choices() -> list[tuple[str, str]]:
    return report_template_choices(__file__)


__all__ = [
    "ACCREDITATION_ACCREDITED",
    "ACCREDITATION_NON_ACCREDITED",
    "PACKAGE_ROOT",
    "REPORT_TEMPLATE_BY_ACCREDITATION",
    "TEMPLATES_DIR",
    "get_report_template_choices",
    "get_report_template_path",
    "register_custom_report_template",
]
