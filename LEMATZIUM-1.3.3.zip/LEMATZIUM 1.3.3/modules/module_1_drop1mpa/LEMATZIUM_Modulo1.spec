# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['launch_modulo_1.py'],
    pathex=['.'],
    binaries=[],
    datas=[('lematzium_modulo1', 'lematzium_modulo1')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LEMATZIUM_Modulo1',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['..\\..\\build_assets\\icons\\lematzium_default.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='LEMATZIUM_Modulo1',
)
