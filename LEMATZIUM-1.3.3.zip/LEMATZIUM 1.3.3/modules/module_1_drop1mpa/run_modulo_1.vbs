Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")
scriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)
cmd = Chr(34) & scriptDir & "\run_modulo_1.bat" & Chr(34)
WshShell.Run cmd, 0, False
