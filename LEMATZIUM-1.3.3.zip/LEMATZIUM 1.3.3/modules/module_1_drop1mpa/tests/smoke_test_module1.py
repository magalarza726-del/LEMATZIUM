from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from lematzium_modulo1.assays.tensile_drop_1mpa.controller import TensileDrop1MPaController


def main() -> int:
    sample = PROJECT_ROOT / "PRUEBA GRANDE DE GRAFICADORES.csv"
    if not sample.exists():
        print("No se encontró el CSV de ejemplo.")
        return 0

    controller = TensileDrop1MPaController()
    dataset = controller.load_file(str(sample))
    print("Curvas cargadas:", len(dataset.curves))
    for row in controller.get_summary_rows()[:5]:
        print(row)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
