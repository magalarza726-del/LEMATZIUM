from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_modulo1.reports.exporter import (
    ACCREDITATION_ACCREDITED,
    ReportExportGroup,
    ReportExportPayload,
    export_report_groups_to_docx,
)


def main() -> int:
    dataset = load_dataset(PROJECT_ROOT / 'PRUEBA GRANDE DE GRAFICADORES.csv')
    payload = ReportExportPayload(
        accreditation_mode=ACCREDITATION_ACCREDITED,
        issue_date='2026-04-20',
        client_name='CLIENTE DEMO',
        client_phone='0000000',
        client_address='GUAYAQUIL',
        client_email='demo@example.com',
        client_contact='Contacto Demo',
        default_comment='Comentario de prueba\nPEE0303-01',
        source_path=dataset.source_path,
        groups=[
            ReportExportGroup(
                report_number='26-999',
                order_number='OT-0001-26',
                specimen_ids=dataset.specimen_ids()[:2],
                observations='Observación de prueba.',
            )
        ],
    )
    out_dir = PROJECT_ROOT / '_smoke_reports'
    exported = export_report_groups_to_docx(dataset, payload, out_dir)
    print(f'Exportados: {len(exported)}')
    for item in exported:
        print(item)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
