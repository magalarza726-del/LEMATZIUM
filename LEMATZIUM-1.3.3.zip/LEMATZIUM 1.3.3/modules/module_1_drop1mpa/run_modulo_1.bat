@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 launch_modulo_1.py
    goto :eof
)

python launch_modulo_1.py
