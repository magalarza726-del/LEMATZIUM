from __future__ import annotations

"""Plantillas para tracción metales."""

from pathlib import Path
import sys

MODULES_DIR = Path(__file__).resolve().parents[3]
for path in (MODULES_DIR, MODULES_DIR / "module_1_drop1mpa"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from shared.report_templates import (  # noqa: E402
    ACCREDITATION_ACCREDITED,
    ACCREDITATION_NON_ACCREDITED,
    CUSTOM_TEMPLATE_PREFIX,
    register_custom_report_template,
    report_template_choices,
)
from lematzium_modulo1.reports.templates import get_report_template_path as _get_module1_template_path  # type: ignore  # noqa: E402

def get_report_template_path(accreditation_mode: str) -> Path:
    path = Path(_get_module1_template_path(accreditation_mode))
    if not path.exists():
        raise FileNotFoundError(f"No se encontró la plantilla de informe: {path}")
    return path

def get_report_template_choices() -> list[tuple[str, str]]:
    return report_template_choices(__file__)

__all__ = ["ACCREDITATION_ACCREDITED", "ACCREDITATION_NON_ACCREDITED", "CUSTOM_TEMPLATE_PREFIX", "get_report_template_choices", "get_report_template_path", "register_custom_report_template"]
