from __future__ import annotations

"""Exportación Word por grupos para el módulo de tracción unificada.

Esta capa replica el flujo operativo del Módulo 1 —plantilla MC, OT PDF,
grupos, observaciones y un DOCX por grupo— sin modificar los módulos 1 y 2.
El cálculo se mantiene en ``shared.tensile_unified`` y la gráfica se genera con
el graficador común del módulo unificado.
"""

import io
import math
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.shared import Cm, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import METHOD_AUTO, TensileAnalysisConfig, analyze_curve, get_default_comment, uncertainty_context_for_comment
from shared.tensile_unified.analysis_config import METHOD_RP_OFFSET, METHOD_UPPER_YIELD
from shared.tensile_unified.plotting import draw_unified_tensile_curve
from shared.word_report_utils import add_inline_picture as _add_inline_picture, normalize_calibri_body_font
from shared.tensile_report_tables import build_geometry_table
from lematzium_modulo1.reports.exporter import (  # type: ignore
    ARIAL,
    REPORT_TABLE_WIDTH_CM,
    _add_signature_block,
    _build_client_block,
    _build_observations_block,
    _build_sample_block,
    _build_title_block,
    _cleanup_editable_report,
    _make_table,
    _meta_first,
    _safe,
    _set_cell_text,
    _set_header_content,
    _set_table_border_nil,
)

from .ot_pdf_reader import OTContext
from .templates import ACCREDITATION_ACCREDITED, ACCREDITATION_NON_ACCREDITED, get_report_template_path


# Ancho institucional usado solo en tablas que sí deben ocupar todo el bloque
# del reporte. La tabla de geometría conserva un ancho compacto propio para
# replicar los ejemplos Word.
UNIFIED_REPORT_TABLE_WIDTH_CM = float(REPORT_TABLE_WIDTH_CM)
RESULT_WIDTHS_UPPER_YIELD_CM = [2.8, 4.2, 3.4, 4.2]
RESULT_WIDTHS_RP_OFFSET_CM = [2.4, 3.6, 3.2, 3.6, 3.0]


def _default_point_visibility() -> Dict[str, bool]:
    return {
        "show_point_yp": True,
        "show_point_rp": False,
        "show_point_a": False,
        "show_point_b": False,
        "show_point_max": True,
        "show_r2p_lines": True,
    }


def _complete_widths(widths: list[float]) -> list[float]:
    """Ajusta el último ancho para que la tabla sume el ancho institucional."""
    return _complete_widths_to_total(widths, UNIFIED_REPORT_TABLE_WIDTH_CM)


def _complete_widths_to_total(widths: list[float], total_width_cm: float) -> list[float]:
    """Ajusta el último ancho para que la tabla sume un total objetivo."""
    if not widths:
        return widths
    fixed = [float(w) for w in widths]
    delta = float(total_width_cm) - sum(fixed)
    fixed[-1] = max(0.5, fixed[-1] + delta)
    return fixed


def _metadata_widths_for_total(total_width_cm: float) -> list[float]:
    """Anchos de la tabla superior sin bordes.

    Las columnas de etiqueta se dejan lo bastante anchas para que
    "Temperatura Máx/Mín" y "Velocidad de ensayo" permanezcan en una sola
    línea. El ancho total coincide con la tabla de resultados para que ambas
    comiencen en el mismo borde izquierdo.
    """
    total = float(total_width_cm or UNIFIED_REPORT_TABLE_WIDTH_CM)
    label_left = 4.15
    label_right = 4.00
    remaining = max(2.0, total - label_left - label_right)
    value_left = max(2.75, remaining * 0.47)
    value_right = max(2.75, remaining - value_left)
    widths = [label_left, value_left, label_right, value_right]
    return _complete_widths_to_total(widths, total)


def _set_cell_no_wrap(cell) -> None:
    try:
        tc_pr = cell._tc.get_or_add_tcPr()
        if tc_pr.find(qn("w:noWrap")) is None:
            tc_pr.append(OxmlElement("w:noWrap"))
    except Exception:
        pass


def _curve_dataframe_for_report(curve: Any):
    for attr in ("df", "raw_df", "data", "dataframe"):
        try:
            value = getattr(curve, attr, None)
            if callable(value):
                value = value()
        except Exception:
            continue
        if value is not None:
            df = value.copy()
            if "stress_MPa" not in df.columns and "load_kN" in df.columns:
                area = _geometry_area(getattr(curve, "geometry", None))
                try:
                    area = float(area)
                    if area > 0:
                        df["stress_MPa"] = df["load_kN"].astype(float) * 1000.0 / area
                except Exception:
                    pass
            return df
    return None


def _stress_from_curve_index(curve: Any, index: Any) -> Optional[float]:
    try:
        idx = int(index)
    except Exception:
        return None
    df = _curve_dataframe_for_report(curve)
    if df is None or "stress_MPa" not in getattr(df, "columns", []):
        return None
    try:
        if idx < 0 or idx >= len(df):
            return None
        return float(df.iloc[idx]["stress_MPa"])
    except Exception:
        return None


@dataclass
class ReportExportGroup:
    report_number: str
    order_number: str
    specimen_ids: List[str]
    observations: str = ""
    title: str = "ENSAYO DE TENSIÓN"


@dataclass
class ReportExportPayload:
    accreditation_mode: str
    issue_date: str = ""
    client_name: str = ""
    client_phone: str = ""
    client_address: str = ""
    client_email: str = ""
    client_contact: str = ""
    default_comment: str = ""
    source_path: str = ""
    ot_pdf_path: str = ""
    ot_context: Optional[OTContext] = None
    groups: List[ReportExportGroup] = field(default_factory=list)
    point_visibility: Dict[str, bool] = field(default_factory=_default_point_visibility)
    graph_config: Dict[str, Any] = field(default_factory=dict)


ResultProvider = Callable[[Any], Any]
CommentProvider = Callable[[Any, Any], str]

class _IndexAwareDataset:
    """Delegado mínimo para permitir códigos repetidos en la UI.

    Los grupos internos pueden guardar referencias ``__idx__:N``; el reporte
    sigue mostrando el código visible de la curva y no cambia el flujo Word.
    """

    def __init__(self, dataset: Any) -> None:
        self._dataset = dataset

    def __getattr__(self, name: str) -> Any:
        return getattr(self._dataset, name)

    def get_curve(self, specimen_ref: str) -> Any:
        text = str(specimen_ref or "")
        if text.startswith("__idx__:"):
            index = int(text.split(":", 1)[1])
            return self._dataset.curves[index]
        return self._dataset.get_curve(specimen_ref)


def _natural_specimen_code_key(value: Any) -> tuple:
    """Clave de orden natural para códigos como 26-0497, 26-0500, etc."""
    text = str(value or "").strip()
    parts = re.split(r"(\d+)", text.lower())
    key: list[Any] = []
    for part in parts:
        if part.isdigit():
            key.append((0, int(part), len(part)))
        else:
            key.append((1, part))
    return tuple(key)


def _specimen_ref_index(specimen_ref: Any) -> int:
    text = str(specimen_ref or "")
    if text.startswith("__idx__:"):
        try:
            return int(text.split(":", 1)[1])
        except Exception:
            return 10**9
    return 10**9


def _ordered_specimen_refs(dataset_view: _IndexAwareDataset, specimen_refs: List[str]) -> List[str]:
    """Ordena referencias de probeta por el código visible.

    Esto mantiene alineados el bloque DATOS DE LA MUESTRA, las páginas de
    resultados y las gráficas del reporte con el orden natural mostrado al
    usuario en la tabla principal. Es especialmente importante cuando el grupo
    se forma desde una OT/PDF cuyo orden no coincide con la secuencia de códigos.
    """
    refs = list(specimen_refs or [])

    def key(ref: Any) -> tuple:
        try:
            curve = dataset_view.get_curve(str(ref))
            code = str(getattr(curve, "specimen_id", "") or ref)
        except Exception:
            code = str(ref or "")
        return (_natural_specimen_code_key(code), _specimen_ref_index(ref), str(ref or ""))

    return sorted(refs, key=key)


def _f(value: Any, ndigits: int = 2, *, unavailable: str = "No disponible") -> str:
    try:
        if value is None:
            return unavailable
        number = float(value)
        if not math.isfinite(number):
            return unavailable
        return f"{number:.{ndigits}f}"
    except Exception:
        return unavailable


def _modulus_mpa_from_gpa(value: Any, ndigits: int = 1, *, unavailable: str = "") -> str:
    try:
        if value is None:
            return unavailable
        number = float(value)
        if not math.isfinite(number):
            return unavailable
        return f"{number * 1000.0:.{ndigits}f}"
    except Exception:
        return unavailable


def _positive_float(value: Any) -> Optional[float]:
    """Convierte a float positivo, manejando propiedades/callables de geometría."""
    try:
        if callable(value):
            value = value()
        if value is None:
            return None
        number = float(value)
        if not math.isfinite(number) or number <= 0:
            return None
        return number
    except Exception:
        return None


def _curve_area_mm2_for_load(curve: Any) -> Optional[float]:
    """Área efectiva en mm² para convertir MPa ↔ N.

    1 MPa = 1 N/mm². Se replica la lógica del graficador para que la tabla
    del reporte use exactamente la misma base geométrica que la gráfica de
    Carga vs alargamiento.
    """
    geometry = getattr(curve, "geometry", None)
    if geometry is None:
        return None

    for attr in ("effective_area_mm2", "area_mm2", "area_mm2_manual"):
        try:
            area = _positive_float(getattr(geometry, attr, None))
        except Exception:
            area = None
        if area is not None:
            return area

    thickness = _positive_float(_geometry_value(geometry, "thickness_mm", "side1_mm", "espesor_mm"))
    width = _positive_float(_geometry_value(geometry, "width_mm", "side2_mm", "anchura_mm", "ancho_mm"))
    if thickness is not None and width is not None:
        return thickness * width

    diameter = _positive_float(_geometry_value(geometry, "diameter_mm", "diametro_mm"))
    if diameter is not None:
        return math.pi * diameter ** 2 / 4.0

    return None


def _report_y_axis_settings(curve: Any, graph_config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Configuración de unidades para tabla de resultados del reporte.

    El cálculo interno conserva MPa; esta función solo convierte los valores
    reportados para que coincidan con el eje Y seleccionado por el usuario.
    """
    config = dict(graph_config or {})
    y_axis = str(config.get("y_axis_type") or config.get("graph_y_axis") or "stress").strip().lower()
    if "load" in y_axis or "carga" in y_axis:
        unit = str(config.get("load_unit") or "kN").strip()
        unit = "N" if unit.lower() in {"n", "newton", "newtons"} else "kN"
        area = _curve_area_mm2_for_load(curve)
        factor = area if unit == "N" and area is not None else (area / 1000.0 if area is not None else None)
        return {
            "kind": "load",
            "unit": unit,
            "factor": factor,
            "yield_header": "Carga de Fluencia",
            "max_header": "Carga Máxima",
            "value_decimals": 0 if unit == "N" else 2,
            "ab_unit": unit,
        }

    unit = str(config.get("stress_unit") or "MPa").strip()
    stress_units = {"mpa": ("MPa", 1.0, 0), "kpa": ("kPa", 1000.0, 0), "pa": ("Pa", 1000000.0, 0)}
    normalized, factor, decimals = stress_units.get(unit.lower(), ("MPa", 1.0, 0))
    return {
        "kind": "stress",
        "unit": normalized,
        "factor": factor,
        "yield_header": "Esfuerzo de Fluencia",
        "max_header": "Esfuerzo Máximo",
        "value_decimals": decimals,
        "ab_unit": normalized,
    }


def _scaled_mpa_value(value: Any, settings: Dict[str, Any], ndigits: Optional[int] = None, *, unavailable: str = "") -> str:
    factor = settings.get("factor")
    if factor is None:
        return unavailable
    decimals = int(settings.get("value_decimals", 0) if ndigits is None else ndigits)
    try:
        if value is None:
            return unavailable
        number = float(value)
        if not math.isfinite(number):
            return unavailable
        return f"{number * float(factor):.{decimals}f}"
    except Exception:
        return unavailable


def _scaled_modulus_from_gpa(value: Any, settings: Dict[str, Any], ndigits: Optional[int] = None, *, unavailable: str = "") -> str:
    """Módulo elástico con la unidad de esfuerzo seleccionada.

    En gráfica de carga, el módulo se mantiene en MPa porque no es una carga.
    """
    if settings.get("kind") == "load":
        return _modulus_mpa_from_gpa(value, 1, unavailable=unavailable)
    try:
        factor = float(settings.get("factor") or 1.0)
        if ndigits is None:
            unit = str(settings.get("unit") or "MPa").lower()
            decimals = 1 if unit == "mpa" else 0
        else:
            decimals = int(ndigits)
        if value is None:
            return unavailable
        number = float(value)
        if not math.isfinite(number):
            return unavailable
        return f"{number * 1000.0 * factor:.{decimals}f}"
    except Exception:
        return unavailable


def _offset_parameter_label(result: Any) -> str:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    offset = diagnostics.get("offset_percent", 0.2)
    try:
        return f"{float(offset):g} %"
    except Exception:
        text = str(offset or "0.2").strip()
        return f"{text} %" if text else "0.2 %"


def _create_document_from_template(template_path: str | Path) -> Document:
    document = Document(str(template_path))
    # Las plantillas históricas pueden tener protección de edición. El helper
    # compartido del Módulo 1 ya la remueve al limpiar el documento final; aquí
    # no se modifica la plantilla original, solo el documento en memoria.
    return document


def _default_result_provider(config: TensileAnalysisConfig) -> ResultProvider:
    def provider(curve: Any) -> Any:
        return analyze_curve(curve, getattr(curve, "geometry", None), config)
    return provider


def _default_comment_provider(payload: ReportExportPayload, config: TensileAnalysisConfig) -> CommentProvider:
    def provider(curve: Any, analysis_result: Any) -> str:
        selected = getattr(analysis_result, "selected_result", None)
        method = getattr(selected, "method", METHOD_AUTO)
        geometry = getattr(curve, "geometry", None)
        shape = getattr(geometry, "shape", None)
        context = {
            "offset_percent": f"{float(config.offset_percent):g}",
            "upper_yield_drop_mpa": f"{float(config.upper_yield_drop_mpa):g}",
            "procedure_code": _meta_first(getattr(curve, "meta", {}), "Procedure", "Procedimiento", default=""),
            "standard_label": "",
            "machine_label": "MUE 600 kN",
        }
        context.update(uncertainty_context_for_comment(curve, analysis_result))
        comment = get_default_comment(shape, method, context)
        return comment or payload.default_comment
    return provider


def _valid_hex_color(value: Any) -> Optional[str]:
    text = str(value or "").strip()
    if re.fullmatch(r"#[0-9A-Fa-f]{6}", text):
        return text
    return None


def _report_curve_color(dataset: Any, curve: Any, graph_config: Optional[Dict[str, Any]]) -> Optional[str]:
    """Devuelve el color de la probeta según la tabla del graficador.

    Prioriza el id del objeto y luego el índice del lote; el código visible se
    usa solo como respaldo para no romper casos antiguos.
    """
    options = graph_config or {}
    try:
        by_object = options.get("curve_colors_by_object_id") or {}
        color = _valid_hex_color(by_object.get(str(id(curve))))
        if color:
            return color
    except Exception:
        pass
    try:
        curves = list(getattr(dataset, "curves", []) or [])
        for index, item in enumerate(curves):
            if item is curve:
                by_index = options.get("curve_colors_by_index") or {}
                color = _valid_hex_color(by_index.get(index)) or _valid_hex_color(by_index.get(str(index)))
                if color:
                    return color
                break
    except Exception:
        pass
    try:
        by_specimen = options.get("curve_colors_by_specimen") or {}
        code = str(getattr(curve, "specimen_id", "") or "")
        color = _valid_hex_color(by_specimen.get(code))
        if color:
            return color
    except Exception:
        pass
    return None


def _render_unified_curve_png(
    curve: Any,
    analysis_result: Any,
    *,
    active_method: str,
    point_visibility: Optional[Dict[str, bool]] = None,
    graph_config: Optional[Dict[str, Any]] = None,
    width_inches: float = 7.2,
    height_inches: float = 3.6,
    dpi: int = 300,
) -> bytes:
    figure = plt.figure(figsize=(width_inches, height_inches), dpi=dpi, facecolor="none")
    ax = figure.add_subplot(111)
    figure.patch.set_alpha(0.0)
    specimen_id = str(getattr(curve, "specimen_id", "") or "Probeta")
    visibility = _default_point_visibility()
    visibility.update(point_visibility or {})
    graph_options = dict(graph_config or {})
    draw_unified_tensile_curve(
        ax,
        curve,
        analysis_result,
        active_method=active_method,
        graph_config={
            "mode": "report",
            "legend_mode": "report_right",
            "legend_single_label": specimen_id,
            "report_clean": True,
            "axis_mode": "auto",
            "anchor_origin": True,
            "curve_linewidth": 1.10,
            "axis_headroom_fraction": 0.06,
            "report_tick_label_size": 7,
            **visibility,
            **graph_options,
        },
    )
    output = io.BytesIO()
    # Reserva margen derecho para que la leyenda no quede pegada ni se corte en Word.
    figure.subplots_adjust(left=0.080, right=0.855, bottom=0.180, top=0.955)
    figure.savefig(output, format="png", dpi=dpi, transparent=True, bbox_inches="tight", pad_inches=0.055)
    plt.close(figure)
    return output.getvalue()


def _method_title_suffix(analysis_result: Any) -> str:
    selected = getattr(analysis_result, "selected_result", None)
    method = getattr(selected, "method", "")
    if method == METHOD_RP_OFFSET:
        diagnostics = getattr(selected, "diagnostics", {}) or {}
        return str(diagnostics.get("rp_label") or "Rp0.2")
    if method == METHOD_UPPER_YIELD:
        return "Fluencia superior"
    return "Método en revisión"


def _geometry_value(geometry: Any, *names: str) -> Any:
    """Lee atributos de geometría soportando modelos legacy y unificados."""
    if geometry is None:
        return None
    for name in names:
        try:
            value = getattr(geometry, name, None)
        except Exception:
            continue
        if callable(value):
            try:
                value = value()
            except Exception:
                continue
        if value is not None:
            return value
    return None


def _geometry_area(geometry: Any) -> Any:
    area = _geometry_value(geometry, "area_mm2_manual", "area_mm2", "effective_area_mm2")
    if area is not None:
        return area
    return None


def _geometry_shape(geometry: Any) -> str:
    shape = _geometry_value(geometry, "shape", "geometry_type")
    return normalize_shape(shape, default=SHAPE_RECTANGULAR)


def _geometry_shape_report_label(geometry: Any) -> str:
    shape = _geometry_shape(geometry)
    if shape == SHAPE_CIRCULAR:
        return "Circular"
    if shape == SHAPE_IRREGULAR:
        return "Irregular"
    # En los reportes históricos del Módulo 1, la geometría rectangular se
    # presenta al analista/cliente como forma plana.
    return "Plana"


def _fmt_dimension(value: Any, ndigits: int = 2) -> str:
    try:
        if value is None:
            return ""
        number = float(value)
        if not math.isfinite(number):
            return ""
        return f"{number:.{ndigits}f}"
    except Exception:
        return ""


def _build_unified_geometry_table(document: Document, geometry: Any, specimen_id: str, result_widths_cm: list[float] | None = None) -> None:
    """Tabla de geometría alineada con la grilla de la tabla de resultados.

    Las columnas visibles no se estiran; si la tabla de resultados tiene
    columnas adicionales, se usan columnas espaciadoras invisibles para que los
    bordes queden en fase celda con celda.
    """
    build_geometry_table(document, geometry, specimen_id, result_widths_cm=result_widths_cm)

def _rp_label_from_result(result: Any) -> str:
    diagnostics = getattr(result, "diagnostics", {}) or {}
    label = diagnostics.get("rp_label")
    if label:
        return str(label)
    offset_percent = diagnostics.get("offset_percent", 0.2)
    try:
        return TensileAnalysisConfig(offset_percent=float(offset_percent)).rp_label
    except Exception:
        return "Rp0.2"


def _result_widths_for_method(method: str) -> list[float]:
    return RESULT_WIDTHS_RP_OFFSET_CM if method == METHOD_RP_OFFSET else RESULT_WIDTHS_UPPER_YIELD_CM


def _ab_points_label(result: Any, curve: Any = None, settings: Optional[Dict[str, Any]] = None) -> str:
    """Devuelve A/B en la misma unidad Y seleccionada para el reporte."""
    diagnostics = getattr(result, "diagnostics", {}) or {}
    indices = diagnostics.get("elastic_modulus_line_indices") or {}
    line_points = diagnostics.get("elastic_modulus_line_points") or {}
    unit_settings = settings or _report_y_axis_settings(curve, None)

    def _stress(key: str) -> Optional[float]:
        if isinstance(line_points, dict):
            point = line_points.get(key)
            if isinstance(point, dict):
                for name in ("y", "stress_MPa", "stress_mpa"):
                    try:
                        value = point.get(name)
                        if value is not None:
                            return float(value)
                    except Exception:
                        pass
        idx = indices.get(key) if isinstance(indices, dict) else None
        return _stress_from_curve_index(curve, idx) if curve is not None else None

    a = _stress("a")
    b = _stress("b")
    if a is None or b is None:
        return ""
    a_text = _scaled_mpa_value(a, unit_settings, unavailable="")
    b_text = _scaled_mpa_value(b, unit_settings, unavailable="")
    unit = str(unit_settings.get("ab_unit") or unit_settings.get("unit") or "MPa")
    if not a_text or not b_text:
        return ""
    return f"A: {a_text}, B: {b_text} {unit}"


def _build_unified_results_table(
    document: Document,
    specimen_id: str,
    result: Any,
    curve: Any = None,
    graph_config: Optional[Dict[str, Any]] = None,
) -> list[float]:
    """Tabla de resultados sincronizada con el tipo/unidad de gráfica.

    El cálculo interno permanece en MPa. Para el reporte, los valores de YP/Rp
    y MAX se expresan en la misma unidad del eje Y seleccionada por el usuario:
    MPa, kPa, Pa, kN o N. En modo carga se cambia también el encabezado a
    ``Carga de Fluencia`` / ``Carga Máxima``. El módulo elástico no se convierte
    a carga porque físicamente sigue siendo una magnitud de esfuerzo.
    """
    method = getattr(result, "method", "")
    y_settings = _report_y_axis_settings(curve, graph_config)
    y_unit = str(y_settings.get("unit") or "MPa")
    yield_header = str(y_settings.get("yield_header") or "Esfuerzo de Fluencia")
    max_header = str(y_settings.get("max_header") or "Esfuerzo Máximo")
    modulus_unit = y_unit if y_settings.get("kind") == "stress" else "MPa"

    if method == METHOD_RP_OFFSET:
        headers = [
            "Nombre",
            yield_header,
            max_header,
            "Elongación luego de\nRotura",
            "M . Elástico",
        ]
        parameter = ["Parámetro", _offset_parameter_label(result), "", "", _ab_points_label(result, curve, y_settings)]
        units = ["Unidades", y_unit, y_unit, "%", modulus_unit]
        values = [
            _safe(specimen_id),
            _scaled_mpa_value(getattr(result, "value_mpa", None), y_settings, unavailable=""),
            _scaled_mpa_value(getattr(result, "max_stress_mpa", None), y_settings, unavailable=""),
            _f(getattr(result, "elongation_after_break_pct", None), 1, unavailable=""),
            _scaled_modulus_from_gpa(getattr(result, "elastic_modulus_gpa", None), y_settings, unavailable=""),
        ]
        widths = RESULT_WIDTHS_RP_OFFSET_CM
    else:
        headers = [
            "Nombre",
            f"{yield_header}\nSuperior" if y_settings.get("kind") == "load" else "Esfuerzo de Fluencia\nSuperior",
            max_header,
            "Elongación luego de\nRotura",
        ]
        parameter = ["Parámetro", "1 Puntos", "", ""]
        units = ["Unidades", y_unit, y_unit, "%"]
        values = [
            _safe(specimen_id),
            _scaled_mpa_value(getattr(result, "value_mpa", None), y_settings, unavailable=""),
            _scaled_mpa_value(getattr(result, "max_stress_mpa", None), y_settings, unavailable=""),
            _f(getattr(result, "elongation_after_break_pct", None), 1, unavailable=""),
        ]
        widths = RESULT_WIDTHS_UPPER_YIELD_CM

    table = _make_table(document, 4, len(headers), widths)
    rows = (headers, parameter, units, values)
    for row_index, row_values in enumerate(rows):
        for col, cell_text in enumerate(row_values):
            _set_cell_text(
                table.cell(row_index, col),
                cell_text,
                bold=(row_index == 0),
                align=WD_ALIGN_PARAGRAPH.CENTER,
                font_size=8,
            )
    return widths


def _build_unified_tension_section(
    document: Document,
    dataset: Any,
    group: ReportExportGroup,
    curve: Any,
    analysis_result: Any,
    comment_text: str,
    *,
    active_method: str,
    point_visibility: Optional[Dict[str, bool]] = None,
    graph_config: Optional[Dict[str, Any]] = None,
) -> None:
    title = document.add_paragraph()
    # Inicia cada sección de probeta en página nueva sin generar páginas en blanco
    # cuando el bloque anterior alcanza el final de página.
    title.paragraph_format.page_break_before = True
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(10)
    title_text = str(group.title or "ENSAYO DE TENSIÓN").upper()
    title_run = title.add_run(title_text)
    title_run.bold = True
    title_run.font.name = "Calibri"
    title_run.font.size = Pt(11)

    specimen_id = str(getattr(curve, "specimen_id", ""))
    selected_result = getattr(analysis_result, "selected_result", None)
    result_widths = _result_widths_for_method(getattr(selected_result, "method", ""))

    meta = getattr(dataset, "meta", {}) or {}
    meta_table = _make_table(document, 4, 4, _metadata_widths_for_total(sum(result_widths)))
    _set_table_border_nil(meta_table)
    left_pairs = [
        ("Procedimiento", _meta_first(meta, "Procedimiento", "Procedure", default="PEE/LEMAT/03")),
        ("Temperatura Máx/Mín", _meta_first(meta, "Temperatura Máx/Mín", "Temperatura Max/Min", "Temperature Max/Min")),
        ("Equipo utilizado", _meta_first(meta, "Equipo Utilizado", "Used Device", default="MUE 600KN")),
        ("Velocidad de ensayo", _meta_first(meta, "Velocidad de Ensayo", "Velocidad de ensayo", "Test Speed")),
    ]
    right_pairs = [
        ("Norma de Referencia", _meta_first(meta, "Norma de Referencia", "Norma de referencia", "Reference Standard", default="ISO 6892-1:2016")),
        ("Humedad Máx/Mín", _meta_first(meta, "Humedad Máx/Mín", "Humidity Max/Min")),
        ("Material", _meta_first(meta, "Material", default="Acero")),
        ("Control de Velocidad", _meta_first(meta, "Control de Velocidad", "Speed Control", default="Mediante tasa de esfuerzo")),
    ]
    for row_index, (label, value) in enumerate(left_pairs):
        _set_cell_text(meta_table.cell(row_index, 0), f"{label}:", bold=True, font_size=8)
        _set_cell_no_wrap(meta_table.cell(row_index, 0))
        _set_cell_text(meta_table.cell(row_index, 1), _safe(value), font_size=8)
    for row_index, (label, value) in enumerate(right_pairs):
        _set_cell_text(meta_table.cell(row_index, 2), f"{label}:", bold=True, font_size=8)
        _set_cell_no_wrap(meta_table.cell(row_index, 2))
        _set_cell_text(meta_table.cell(row_index, 3), _safe(value), font_size=8)

    _build_unified_geometry_table(document, getattr(curve, "geometry", None), specimen_id, result_widths_cm=result_widths)

    # Tabla de resultados dinámica. Mantiene tablas reales editables, con nombre
    # técnico según el método activo: Fluencia superior o Rp{offset}.
    section_graph_config = dict(graph_config or {})
    _build_unified_results_table(document, specimen_id, selected_result, curve, section_graph_config)

    curve_color = _report_curve_color(dataset, curve, section_graph_config)
    if curve_color:
        colors = dict(section_graph_config.get("colors") or {})
        colors["curve"] = curve_color
        section_graph_config["colors"] = colors
    image_bytes = _render_unified_curve_png(curve, analysis_result, active_method=active_method, point_visibility=point_visibility, graph_config=section_graph_config)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        temp_path = Path(tmp.name)
    # Separación equivalente a un Shift+Enter entre la tabla de resultados y la gráfica.
    # Se usa un párrafo con salto manual para mantener el espaciado estable en Word.
    graph_spacer = document.add_paragraph()
    graph_spacer.paragraph_format.space_before = Pt(0)
    graph_spacer.paragraph_format.space_after = Pt(0)
    graph_spacer.add_run().add_break(WD_BREAK.LINE)

    picture_paragraph = document.add_paragraph()
    picture_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    picture_paragraph.paragraph_format.space_before = Pt(0)
    # El gráfico se inserta inline para que el espacio superior con la tabla quede fijo.
    # Luego se fijan ancho y alto de forma independiente, equivalente a desbloquear
    # la relación de aspecto en Word: 16 cm x 8 cm.
    picture = _add_inline_picture(picture_paragraph, temp_path, width_cm=16.0)
    picture.width = Cm(16.0)
    picture.height = Cm(8.0)
    temp_path.unlink(missing_ok=True)

    comment_title = document.add_paragraph()
    comment_run = comment_title.add_run("Comentarios")
    comment_run.bold = True
    comment_run.font.name = ARIAL
    comment_run.font.size = Pt(9)
    lines = str(comment_text or "").splitlines() or [""]
    for line in lines:
        paragraph = document.add_paragraph(line)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.space_before = Pt(0)
        for run in paragraph.runs:
            run.font.name = ARIAL
            run.font.size = Pt(8)


def export_group_to_docx(
    dataset: Any,
    payload: ReportExportPayload,
    group: ReportExportGroup,
    output_path: str | Path,
    *,
    analysis_config: Optional[TensileAnalysisConfig] = None,
    result_provider: Optional[ResultProvider] = None,
    comment_provider: Optional[CommentProvider] = None,
) -> Path:
    config = analysis_config or TensileAnalysisConfig()
    result_provider = result_provider or _default_result_provider(config)
    comment_provider = comment_provider or _default_comment_provider(payload, config)

    template_path = get_report_template_path(payload.accreditation_mode)
    document = _create_document_from_template(template_path)
    dataset_view = _IndexAwareDataset(dataset)
    ordered_specimen_ids = _ordered_specimen_refs(dataset_view, list(group.specimen_ids or []))
    report_group = ReportExportGroup(
        report_number=group.report_number,
        order_number=group.order_number,
        specimen_ids=ordered_specimen_ids,
        observations=group.observations,
        title=group.title,
    )
    total_pages = 1 + len(report_group.specimen_ids)
    _set_header_content(document, report_group.report_number, report_group.order_number, payload.issue_date, total_pages)
    _build_title_block(document, report_group.report_number, report_group.order_number, payload.issue_date)
    _build_client_block(document, payload)
    _build_sample_block(document, dataset_view, payload, report_group)
    _build_observations_block(document, report_group.observations)

    for specimen_id in report_group.specimen_ids:
        curve = dataset_view.get_curve(specimen_id)
        analysis_result = result_provider(curve)
        comment_text = comment_provider(curve, analysis_result)
        _build_unified_tension_section(
            document,
            dataset,
            report_group,
            curve,
            analysis_result,
            comment_text,
            active_method=config.active_method or METHOD_AUTO,
            point_visibility=getattr(payload, "point_visibility", None),
            graph_config=getattr(payload, "graph_config", None),
        )

    _add_signature_block(document)
    _cleanup_editable_report(document, max_table_width_cm=REPORT_TABLE_WIDTH_CM)
    normalize_calibri_body_font(document, bump_arial_points=True)

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    document.save(output)
    return output


def export_report_groups_to_docx(
    dataset: Any,
    payload: ReportExportPayload,
    output_dir: str | Path,
    *,
    analysis_config: Optional[TensileAnalysisConfig] = None,
    result_provider: Optional[ResultProvider] = None,
    comment_provider: Optional[CommentProvider] = None,
) -> List[Path]:
    output_directory = Path(output_dir)
    output_directory.mkdir(parents=True, exist_ok=True)
    exported_files: List[Path] = []
    for group in payload.groups:
        client_name = payload.client_name or (payload.ot_context.client_name if payload.ot_context else "")
        filename = f"INFORME N°{group.report_number} {client_name} {group.order_number}.docx"
        filename = re.sub(r'[\\/:*?"<>|]', "_", filename).strip()
        exported_files.append(
            export_group_to_docx(
                dataset,
                payload,
                group,
                output_directory / filename,
                analysis_config=analysis_config,
                result_provider=result_provider,
                comment_provider=comment_provider,
            )
        )
    return exported_files


__all__ = [
    "ACCREDITATION_ACCREDITED",
    "ACCREDITATION_NON_ACCREDITED",
    "ReportExportGroup",
    "ReportExportPayload",
    "export_group_to_docx",
    "export_report_groups_to_docx",
]
