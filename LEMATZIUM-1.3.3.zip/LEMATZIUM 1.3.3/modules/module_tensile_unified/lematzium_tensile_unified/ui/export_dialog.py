from __future__ import annotations

"""Diálogo de exportación automática del módulo de tracción unificada.

Es un adaptador funcional del flujo del Módulo 1: selección de plantilla,
carga de OT PDF, selección de probetas, grupos, observaciones, carpeta de
salida, plan JSON y exportación de uno o varios DOCX.
"""

import json
import re
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from shared.tensile_unified import TensileAnalysisConfig
from shared.tk_window_restore import release_modal_state, show_window_normally
from lematzium_tensile_unified.reports.group_exporter import (
    ACCREDITATION_ACCREDITED,
    ACCREDITATION_NON_ACCREDITED,
    ReportExportGroup,
    ReportExportPayload,
    export_report_groups_to_docx,
)
from lematzium_tensile_unified.reports.ot_pdf_reader import parse_ot_pdf
from lematzium_tensile_unified.reports.templates import get_report_template_choices, register_custom_report_template

ACCREDITATION_LABELS = {
    ACCREDITATION_ACCREDITED: "Acreditado (MC2202-08)",
    ACCREDITATION_NON_ACCREDITED: "No acreditado (MC2201-06)",
}

ResultProvider = Callable[[Any], Any]
CommentProvider = Callable[[Any, Any], str]


def _today_report_date() -> str:
    """Fecha local de la computadora para usarla como emisión por defecto."""
    try:
        return date.today().strftime("%Y-%m-%d")
    except Exception:
        return ""


def _default_point_visibility() -> Dict[str, bool]:
    return {
        "show_point_yp": True,
        "show_point_rp": False,
        "show_point_a": False,
        "show_point_b": False,
        "show_point_max": True,
        "show_r2p_lines": True,
    }


class ReportExportDialog(tk.Toplevel):
    def __init__(
        self,
        master: tk.Misc,
        *,
        dataset: Any,
        analysis_config: TensileAnalysisConfig,
        default_order_number: str = "",
        default_comment: str = "",
        result_provider: Optional[ResultProvider] = None,
        comment_provider: Optional[CommentProvider] = None,
        point_visibility: Optional[Dict[str, bool]] = None,
        graph_config: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(master)
        self.title("Exportación automática de informes")
        self.geometry("1220x780")
        self.minsize(1080, 700)
        # No usar grab modal persistente: después de exportar, un grab activo
        # podía impedir restaurar la ventana principal desde la barra de tareas.
        self.transient(master)
        # No instalar el guardia de restauración también en este Toplevel.
        # Cuando la ventana principal y la de exportación pulsaban topmost al
        # mismo tiempo, Windows podía alternarlas y producir superposición
        # intermitente al minimizar/restaurar la exportación.
        self.bind("<Map>", self._keep_export_dialog_focus, add="+")
        self.bind("<FocusIn>", self._keep_export_dialog_focus, add="+")
        self.bind("<Unmap>", self._release_on_minimize, add="+")
        self.protocol("WM_DELETE_WINDOW", self._close_dialog)

        self.dataset = dataset
        self.analysis_config = analysis_config
        self.default_comment = default_comment
        self.result_provider = result_provider
        self.comment_provider = comment_provider
        self.graph_config = dict(graph_config or {})
        self.group_rows: List[Dict[str, Any]] = []
        self.selected_vars: Dict[str, tk.BooleanVar] = {}
        self.selected_labels: Dict[str, str] = {}
        self.specimen_codes: Dict[str, str] = {}

        self.accreditation_var = tk.StringVar(value=ACCREDITATION_ACCREDITED)
        self.report_number_var = tk.StringVar(value="")
        self.order_number_var = tk.StringVar(value=default_order_number)
        self.issue_date_var = tk.StringVar(value=_today_report_date())
        self.client_name_var = tk.StringVar(value="")
        self.phone_var = tk.StringVar(value="")
        self.address_var = tk.StringVar(value="")
        self.email_var = tk.StringVar(value="")
        self.contact_var = tk.StringVar(value="")
        source_path = Path(str(getattr(dataset, "source_path", "") or "."))
        self.output_dir_var = tk.StringVar(value=str(source_path.parent if source_path.exists() else Path.cwd()))
        self.ot_pdf_path_var = tk.StringVar(value="")
        self.ot_context = None
        visibility = _default_point_visibility()
        visibility.update(point_visibility or {})
        self.show_point_yp_var = tk.BooleanVar(value=bool(visibility.get("show_point_yp", True)))
        self.show_point_rp_var = tk.BooleanVar(value=bool(visibility.get("show_point_rp", False)))
        self.show_point_a_var = tk.BooleanVar(value=bool(visibility.get("show_point_a", False)))
        self.show_point_b_var = tk.BooleanVar(value=bool(visibility.get("show_point_b", False)))
        self.show_point_max_var = tk.BooleanVar(value=bool(visibility.get("show_point_max", True)))
        self.show_r2p_lines_var = tk.BooleanVar(value=bool(visibility.get("show_r2p_lines", True)))

        self._build_ui()
        self._load_specimens()

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=8)
        outer.pack(fill="both", expand=True)

        top_actions = ttk.Frame(outer)
        top_actions.pack(fill="x", pady=(0, 8))
        ttk.Button(top_actions, text="Agregar plantilla", command=self.add_template).pack(side="left", padx=(0, 8))
        ttk.Button(top_actions, text="Exportar ahora", command=self.export_now).pack(side="left")
        ttk.Button(top_actions, text="Autoexportación", command=self.auto_export_from_ot).pack(side="left", padx=(8, 0))
        ttk.Button(top_actions, text="Cerrar", command=self._close_dialog).pack(side="right")

        self.dialog_canvas = tk.Canvas(outer, highlightthickness=0, bd=0)
        dialog_vscroll = ttk.Scrollbar(outer, orient="vertical", command=self.dialog_canvas.yview)
        self.dialog_canvas.configure(yscrollcommand=dialog_vscroll.set)
        self.dialog_canvas.pack(side="left", fill="both", expand=True)
        dialog_vscroll.pack(side="right", fill="y")

        container = ttk.Frame(self.dialog_canvas, padding=12)
        self.dialog_window = self.dialog_canvas.create_window((0, 0), window=container, anchor="nw")
        container.bind("<Configure>", lambda _e: self.dialog_canvas.configure(scrollregion=self.dialog_canvas.bbox("all")))
        self.dialog_canvas.bind("<Configure>", lambda e: self.dialog_canvas.itemconfigure(self.dialog_window, width=e.width))
        self.bind_all("<MouseWheel>", self._on_mousewheel, add="+")

        accreditation_box = ttk.LabelFrame(container, text="1. Tipo de informe", padding=10)
        accreditation_box.pack(fill="x")
        ttk.Label(
            accreditation_box,
            text="Seleccione la plantilla institucional antes de exportar.",
            wraplength=1050,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))
        self.template_choices_frame = ttk.Frame(accreditation_box)
        self.template_choices_frame.pack(fill="x")
        self._refresh_template_choices()
        ttk.Button(accreditation_box, text="Agregar plantilla", command=self.add_template).pack(anchor="w", pady=(8, 0))

        top = ttk.LabelFrame(container, text="2. Selección de probetas", padding=10)
        top.pack(fill="x", pady=(10, 0))
        self.specimen_canvas = tk.Canvas(top, height=110, bg="#ffffff", highlightthickness=0)
        self.specimen_scroll = ttk.Scrollbar(top, orient="vertical", command=self.specimen_canvas.yview)
        self.specimen_inner = ttk.Frame(self.specimen_canvas)
        self.specimen_inner.bind("<Configure>", lambda _e: self.specimen_canvas.configure(scrollregion=self.specimen_canvas.bbox("all")))
        self.specimen_canvas.create_window((0, 0), window=self.specimen_inner, anchor="nw")
        self.specimen_canvas.configure(yscrollcommand=self.specimen_scroll.set)
        self.specimen_canvas.pack(side="left", fill="both", expand=True)
        self.specimen_scroll.pack(side="right", fill="y")

        controls = ttk.LabelFrame(container, text="3. Crear grupo de informe", padding=10)
        controls.pack(fill="x", pady=(10, 0))
        ttk.Label(controls, text="N° informe:").grid(row=0, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.report_number_var, width=20).grid(row=0, column=1, sticky="w", padx=(6, 16))
        ttk.Label(controls, text="N° orden:").grid(row=0, column=2, sticky="w")
        ttk.Entry(controls, textvariable=self.order_number_var, width=20).grid(row=0, column=3, sticky="w", padx=(6, 16))
        ttk.Label(controls, text="Observaciones del informe:").grid(row=1, column=0, sticky="nw", pady=(8, 0))
        self.obs_text = tk.Text(controls, width=72, height=4, wrap="word")
        self.obs_text.grid(row=1, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=(8, 0))
        ttk.Button(controls, text="Agregar grupo", command=self.add_group).grid(row=0, column=4, rowspan=2, padx=(12, 0), sticky="ns")
        controls.columnconfigure(3, weight=1)

        middle = ttk.Panedwindow(container, orient="horizontal")
        middle.pack(fill="both", expand=True, pady=(10, 0))
        left = ttk.Frame(middle)
        right = ttk.Frame(middle)
        middle.add(left, weight=3)
        middle.add(right, weight=2)

        table_box = ttk.LabelFrame(left, text="4. Grupos listos", padding=10)
        table_box.pack(fill="both", expand=True)
        columns = ("report", "order", "specimens", "obs")
        self.tree = ttk.Treeview(table_box, columns=columns, show="headings", height=12)
        for col, text, width in (
            ("report", "N° informe", 120),
            ("order", "N° orden", 120),
            ("specimens", "Probetas", 260),
            ("obs", "Observaciones", 360),
        ):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=width, anchor="center" if col in {"report", "order"} else "w")
        self.tree.pack(fill="both", expand=True)
        buttons_bar = ttk.Frame(table_box)
        buttons_bar.pack(fill="x", pady=(8, 0))
        ttk.Button(buttons_bar, text="Eliminar grupo seleccionado", command=self.remove_selected_group).pack(side="left")
        ttk.Button(buttons_bar, text="Guardar plan JSON", command=self.save_plan_json).pack(side="right")

        header_box = ttk.LabelFrame(right, text="5. Datos del encabezado y salida", padding=10)
        header_box.pack(fill="both", expand=True)
        self._row(header_box, 0, "Fecha de emisión", self.issue_date_var, "Cliente", self.client_name_var)
        self._row(header_box, 1, "Teléfono", self.phone_var, "Contacto", self.contact_var)
        self._row(header_box, 2, "Correo", self.email_var, "", tk.StringVar())
        ttk.Label(header_box, text="Dirección").grid(row=3, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(header_box, textvariable=self.address_var, width=52).grid(row=3, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=(8, 0))

        ttk.Label(header_box, text="OT PDF").grid(row=4, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(header_box, textvariable=self.ot_pdf_path_var, width=52).grid(row=4, column=1, columnspan=2, sticky="ew", padx=(6, 6), pady=(8, 0))
        ttk.Button(header_box, text="Cargar OT PDF…", command=self.pick_ot_pdf).grid(row=4, column=3, sticky="e", pady=(8, 0))

        points_box = ttk.LabelFrame(header_box, text="Puntos visibles en gráfica del reporte", padding=6)
        points_box.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(10, 0))
        for col in range(5):
            points_box.columnconfigure(col, weight=1)
        ttk.Checkbutton(points_box, text="YP", variable=self.show_point_yp_var).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(points_box, text="R2P/Rp", variable=self.show_point_rp_var).grid(row=0, column=1, sticky="w")
        ttk.Checkbutton(points_box, text="A", variable=self.show_point_a_var).grid(row=0, column=2, sticky="w")
        ttk.Checkbutton(points_box, text="B", variable=self.show_point_b_var).grid(row=0, column=3, sticky="w")
        ttk.Checkbutton(points_box, text="MAX", variable=self.show_point_max_var).grid(row=0, column=4, sticky="w")
        ttk.Checkbutton(points_box, text="Rectas R2P/Rp", variable=self.show_r2p_lines_var).grid(row=0, column=5, sticky="w", padx=(10, 0))

        ttk.Separator(header_box, orient="horizontal").grid(row=6, column=0, columnspan=4, sticky="ew", pady=12)
        ttk.Label(header_box, text="Carpeta de salida").grid(row=7, column=0, sticky="w")
        ttk.Entry(header_box, textvariable=self.output_dir_var, width=52).grid(row=7, column=1, columnspan=2, sticky="ew", padx=(6, 6))
        ttk.Button(header_box, text="Buscar…", command=self.pick_output_dir).grid(row=7, column=3, sticky="e")
        export_buttons = ttk.Frame(header_box)
        export_buttons.grid(row=8, column=0, columnspan=4, sticky="ew", pady=(14, 0))
        export_buttons.columnconfigure(0, weight=1)
        export_buttons.columnconfigure(1, weight=1)
        ttk.Button(export_buttons, text="Exportar ahora", command=self.export_now).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(export_buttons, text="Autoexportación", command=self.auto_export_from_ot).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        header_box.columnconfigure(2, weight=1)

    def _row(self, parent: ttk.Frame, row: int, left_label: str, left_var: tk.StringVar, right_label: str, right_var: tk.StringVar) -> None:
        ttk.Label(parent, text=left_label).grid(row=row, column=0, sticky="w", pady=(0 if row == 0 else 8, 0))
        ttk.Entry(parent, textvariable=left_var, width=22).grid(row=row, column=1, sticky="ew", padx=(6, 12), pady=(0 if row == 0 else 8, 0))
        if right_label:
            ttk.Label(parent, text=right_label).grid(row=row, column=2, sticky="w", pady=(0 if row == 0 else 8, 0))
            ttk.Entry(parent, textvariable=right_var, width=22).grid(row=row, column=3, sticky="ew", padx=(6, 0), pady=(0 if row == 0 else 8, 0))


    def _refresh_template_choices(self) -> None:
        """Reconstruye las opciones de plantilla, incluyendo las agregadas."""
        frame = getattr(self, "template_choices_frame", None)
        if frame is None:
            return
        for child in frame.winfo_children():
            child.destroy()
        choices = get_report_template_choices()
        valid_values = {value for value, _label in choices}
        if self.accreditation_var.get() not in valid_values:
            self.accreditation_var.set(ACCREDITATION_ACCREDITED)
        for value, label in choices:
            ttk.Radiobutton(frame, text=label, variable=self.accreditation_var, value=value).pack(anchor="w", pady=1)

    def add_template(self) -> None:
        """Agrega una plantilla Word y la conserva como opción permanente."""
        path = filedialog.askopenfilename(
            title="Agregar plantilla de informe Word",
            filetypes=[("Plantilla Word", "*.docx"), ("Todos", "*.*")],
            parent=self,
        )
        if not path:
            return
        default_name = Path(path).stem
        label = simpledialog.askstring(
            "Nombre de plantilla",
            "Nombre visible para esta plantilla:",
            initialvalue=default_name,
            parent=self,
        )
        if label is None:
            return
        try:
            key, visible_label, _destination = register_custom_report_template(path, label.strip() or default_name)
        except Exception as exc:
            messagebox.showerror("No se pudo agregar la plantilla", f"Detalle: {exc}", parent=self)
            return
        self._refresh_template_choices()
        self.accreditation_var.set(key)
        messagebox.showinfo("Plantilla agregada", f"La plantilla '{visible_label}' quedó guardada como opción permanente.", parent=self)

    def _on_mousewheel(self, event: Any) -> None:
        try:
            if self.winfo_exists():
                self.dialog_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def _keep_export_dialog_focus(self, event: Any = None) -> None:
        if event is not None and getattr(event, "widget", None) is not self:
            return
        try:
            release_modal_state(self)
        except Exception:
            pass
        try:
            self.attributes("-topmost", False)
        except Exception:
            pass
        try:
            self.lift()
        except Exception:
            pass

    def _release_on_minimize(self, event: Any = None) -> None:
        if event is not None and getattr(event, "widget", None) is not self:
            return
        try:
            release_modal_state(self)
        except Exception:
            pass
        try:
            self.attributes("-topmost", False)
        except Exception:
            pass

    def _close_dialog(self) -> None:
        try:
            release_modal_state(self)
        except Exception:
            pass
        try:
            self.unbind_all("<MouseWheel>")
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass
        try:
            show_window_normally(self.master)
        except Exception:
            pass

    def _after_successful_export(self) -> None:
        # Cierra el diálogo de exportación y devuelve el foco al módulo. Esto
        # evita que un Toplevel transitorio quede oculto o con captura modal
        # después de abrir Word o de minimizar/restaurar la ventana principal.
        try:
            release_modal_state(self)
        except Exception:
            pass
        try:
            self.after(120, self._close_dialog)
        except Exception:
            self._close_dialog()

    @staticmethod
    def _natural_specimen_code_key(value: Any) -> tuple:
        text = str(value or "").strip()
        parts = re.split(r"(\d+)", text.lower())
        key: list[Any] = []
        for part in parts:
            if part.isdigit():
                key.append((0, int(part), len(part)))
            else:
                key.append((1, part))
        return tuple(key)

    def _sort_specimen_refs_by_code(self, refs: List[str]) -> List[str]:
        def key(ref: str) -> tuple:
            code = self.specimen_codes.get(ref, self.selected_labels.get(ref, ref))
            try:
                ref_index = int(str(ref).split(":", 1)[1]) if str(ref).startswith("__idx__:") else 10**9
            except Exception:
                ref_index = 10**9
            return (self._natural_specimen_code_key(code), ref_index, str(ref or ""))
        return sorted(list(refs or []), key=key)

    def _load_specimens(self) -> None:
        for child in self.specimen_inner.winfo_children():
            child.destroy()
        self.selected_vars.clear()
        self.selected_labels.clear()
        self.specimen_codes.clear()
        # Mostrar las probetas en matriz, no en lista vertical. Con 5 columnas
        # caben al menos 15 probetas dentro de la altura actual del recuadro.
        columns = 5
        for col in range(columns):
            try:
                self.specimen_inner.columnconfigure(col, weight=1)
            except Exception:
                pass
        curves_in_order = []
        for index, curve in enumerate(getattr(self.dataset, "curves", []) or []):
            specimen_id = str(getattr(curve, "specimen_id", "") or f"Probeta {index + 1}")
            curves_in_order.append((self._natural_specimen_code_key(specimen_id), index, curve, specimen_id))
        for display_index, (_key, index, curve, specimen_id) in enumerate(sorted(curves_in_order, key=lambda item: (item[0], item[1]))):
            ref = f"__idx__:{index}"
            var = tk.BooleanVar(value=False)
            self.selected_vars[ref] = var
            label = specimen_id
            if list(self.selected_labels.values()).count(specimen_id) > 0:
                label = f"{specimen_id} ({index + 1})"
            self.selected_labels[ref] = label
            self.specimen_codes[ref] = specimen_id
            check = ttk.Checkbutton(self.specimen_inner, text=label, variable=var)
            check.grid(row=display_index // columns, column=display_index % columns, sticky="w", padx=(4, 14), pady=1)

    def _selected_specimen_ids(self) -> List[str]:
        return self._sort_specimen_refs_by_code([ref for ref, var in self.selected_vars.items() if var.get()])

    def _selected_specimen_labels(self) -> List[str]:
        return [self.selected_labels.get(ref, ref) for ref in self._selected_specimen_ids()]

    def add_group(self) -> None:
        specimens = self._selected_specimen_ids()
        specimen_labels = self._selected_specimen_labels()
        if not specimens:
            messagebox.showwarning("Sin probetas", "Seleccione al menos una probeta para crear el grupo.", parent=self)
            return
        report_number = self.report_number_var.get().strip()
        order_number = self.order_number_var.get().strip()
        if not report_number:
            messagebox.showwarning("Sin número de informe", "Ingrese el número de informe.", parent=self)
            return
        observations = self.obs_text.get("1.0", tk.END).strip()
        row = {
            "report_number": report_number,
            "order_number": order_number,
            "specimen_ids": specimens,
            "observations": observations,
        }
        self.group_rows.append(row)
        self.tree.insert("", "end", values=(report_number, order_number, ", ".join(specimen_labels), observations))
        for var in self.selected_vars.values():
            var.set(False)
        self.obs_text.delete("1.0", tk.END)

    def remove_selected_group(self) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        for item in selection:
            index = self.tree.index(item)
            self.tree.delete(item)
            if 0 <= index < len(self.group_rows):
                self.group_rows.pop(index)

    def pick_output_dir(self) -> None:
        path = filedialog.askdirectory(title="Seleccionar carpeta de salida", initialdir=self.output_dir_var.get() or None, parent=self)
        if path:
            self.output_dir_var.set(path)

    def pick_ot_pdf(self) -> None:
        path = filedialog.askopenfilename(title="Seleccionar OT PDF", filetypes=[("PDF", "*.pdf"), ("Todos", "*.*")], parent=self)
        if not path:
            return
        try:
            context = parse_ot_pdf(path)
            self.ot_context = context
            self.ot_pdf_path_var.set(path)
            if context.ot_number and not self.order_number_var.get().strip():
                self.order_number_var.set(context.ot_number)
            if context.client_name:
                self.client_name_var.set(context.client_name)
            if context.phone:
                self.phone_var.set(context.phone)
            if context.address:
                self.address_var.set(context.address)
            if context.email:
                self.email_var.set(context.email)
            if context.contact:
                self.contact_var.set(context.contact)
            if context.observations and not self.obs_text.get("1.0", tk.END).strip():
                self.obs_text.insert("1.0", context.observations)
            messagebox.showinfo("OT cargada", "Se cargaron los datos disponibles de la OT PDF.", parent=self)
        except Exception as exc:
            messagebox.showerror("Error al leer OT", str(exc), parent=self)

    def save_plan_json(self) -> None:
        if not self.group_rows:
            messagebox.showwarning("Sin grupos", "Cree al menos un grupo antes de guardar el plan.", parent=self)
            return
        path = filedialog.asksaveasfilename(
            title="Guardar plan JSON",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialfile="plan_exportacion_traccion_unificada.json",
            parent=self,
        )
        if not path:
            return
        payload = self._build_payload()
        data = asdict(payload)
        Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        messagebox.showinfo("Plan guardado", f"Plan guardado correctamente:\n{path}", parent=self)

    @staticmethod
    def _join_report_refs(report_numbers: List[str]) -> str:
        numbers = [str(number).strip() for number in report_numbers if str(number).strip()]
        if not numbers:
            return "los demás informes asociados a la misma OT"
        if len(numbers) == 1:
            return f"el informe No. {numbers[0]}"
        return "los informes No. " + ", ".join(numbers[:-1]) + " y " + numbers[-1]

    @staticmethod
    def _format_ot_reference(order_number: str) -> str:
        text = str(order_number or "").strip()
        if not text:
            return "la OT"
        if text.upper().startswith("OT"):
            return text
        return f"OT-{text}"

    def _append_partial_group_observations(self, groups: List[ReportExportGroup]) -> None:
        all_refs = set(self.selected_labels.keys())
        if not all_refs:
            return
        for group in groups:
            selected = set(group.specimen_ids or [])
            if selected >= all_refs:
                continue
            other_reports = [g.report_number for g in groups if g is not group and str(g.report_number).strip()]
            ot_number = group.order_number or self.order_number_var.get().strip()
            if not ot_number and self.ot_context is not None:
                ot_number = getattr(self.ot_context, "ot_number", "") or ""
            order_ref = self._format_ot_reference(ot_number)
            other_text = self._join_report_refs(other_reports)
            auto_obs = f"Este informe No. {group.report_number} forma parte de la {order_ref}, junto con {other_text}."
            current = str(group.observations or "").strip()
            if auto_obs in current or "forma parte de la" in current and f"No. {group.report_number}" in current:
                continue
            group.observations = (current + "\n" + auto_obs).strip() if current else auto_obs

    @staticmethod
    def _increment_report_number(initial: str, count: int) -> List[str]:
        text = str(initial or "").strip()
        if not text:
            return []
        match = re.search(r"(\d+)$", text)
        if not match:
            return [text for _ in range(count)]
        start_text = match.group(1)
        prefix = text[: match.start(1)]
        start = int(start_text)
        width = len(start_text)
        return [f"{prefix}{start + i:0{width}d}" for i in range(max(0, count))]

    @staticmethod
    def _is_new_report_marker(row: Any) -> bool:
        info = str(getattr(row, "additional_info", "") or getattr(row, "raw_text", "") or "")
        return bool(re.search(r"informe\s+por\s+separado", info, re.IGNORECASE))

    def _detect_ot_report_groups(self) -> List[List[Any]]:
        if self.ot_context is None:
            return []
        rows = list(getattr(self.ot_context, "sample_rows", {}).values())
        if not rows:
            return []
        groups: List[List[Any]] = []
        current: List[Any] = []
        for row in rows:
            if self._is_new_report_marker(row) and current:
                groups.append(current)
                current = []
            current.append(row)
        if current:
            groups.append(current)
        return groups

    def _specimen_ref_for_ot_code(self, code: str, fallback_index: Optional[int] = None) -> Optional[str]:
        clean_code = str(code or "").strip().lower()
        for ref, specimen_code in self.specimen_codes.items():
            if str(specimen_code or "").strip().lower() == clean_code:
                return ref
        for ref, label in self.selected_labels.items():
            label_text = str(label or "").strip().lower()
            if label_text == clean_code or clean_code in label_text:
                return ref
        refs = list(self.selected_vars.keys())
        if fallback_index is not None and 0 <= int(fallback_index) < len(refs):
            return refs[int(fallback_index)]
        return None

    def _refresh_groups_tree(self) -> None:
        try:
            for item in self.tree.get_children():
                self.tree.delete(item)
        except Exception:
            return
        for row in self.group_rows:
            specimen_labels = [self.selected_labels.get(ref, ref) for ref in row.get("specimen_ids", [])]
            self.tree.insert("", "end", values=(
                row.get("report_number", ""),
                row.get("order_number", ""),
                ", ".join(specimen_labels),
                row.get("observations", ""),
            ))

    def auto_export_from_ot(self) -> None:
        if self.ot_context is None:
            path = filedialog.askopenfilename(
                title="Seleccionar OT PDF para autoexportación",
                filetypes=[("PDF", "*.pdf"), ("Todos", "*.*")],
                parent=self,
            )
            if not path:
                return
            try:
                context = parse_ot_pdf(path)
                self.ot_context = context
                self.ot_pdf_path_var.set(path)
                if context.ot_number:
                    self.order_number_var.set(context.ot_number)
                if context.client_name:
                    self.client_name_var.set(context.client_name)
                if context.phone:
                    self.phone_var.set(context.phone)
                if context.address:
                    self.address_var.set(context.address)
                if context.email:
                    self.email_var.set(context.email)
                if context.contact:
                    self.contact_var.set(context.contact)
            except Exception as exc:
                messagebox.showerror("Error al leer OT", str(exc), parent=self)
                return

        ot_groups = self._detect_ot_report_groups()
        if not ot_groups:
            messagebox.showwarning(
                "Sin grupos detectados",
                "No se detectaron filas con 'Informe por separado' en la OT cargada.",
                parent=self,
            )
            return

        initial = self.report_number_var.get().strip()
        if not initial:
            initial = simpledialog.askstring(
                "Número inicial de informe",
                "Ingrese el número inicial de informe, por ejemplo 26-268:",
                parent=self,
            ) or ""
        initial = initial.strip()
        if not initial:
            return

        report_numbers = self._increment_report_number(initial, len(ot_groups))
        if len(report_numbers) != len(ot_groups):
            messagebox.showwarning("Número inicial inválido", "No se pudo generar la secuencia de informes.", parent=self)
            return

        refs_in_order = list(self.selected_vars.keys())
        used_refs: set[str] = set()
        rows: List[Dict[str, Any]] = []
        absolute_index = 0
        for group_index, rows_from_ot in enumerate(ot_groups):
            group_refs: List[str] = []
            for row in rows_from_ot:
                ref = self._specimen_ref_for_ot_code(getattr(row, "specimen_id", ""), absolute_index)
                absolute_index += 1
                if ref and ref not in used_refs:
                    group_refs.append(ref)
                    used_refs.add(ref)
            if not group_refs:
                # Fallback defensivo: si los códigos de la OT no empatan con los
                # nombres cargados, reparte por orden según el tamaño detectado.
                start = sum(len(r.get("specimen_ids", [])) for r in rows)
                group_refs = refs_in_order[start : start + len(rows_from_ot)]
            group_refs = self._sort_specimen_refs_by_code(group_refs)
            rows.append({
                "report_number": report_numbers[group_index],
                "order_number": self.order_number_var.get().strip() or getattr(self.ot_context, "ot_number", ""),
                "specimen_ids": group_refs,
                "observations": "",
            })

        temp_groups = [
            ReportExportGroup(
                report_number=row["report_number"],
                order_number=row["order_number"],
                specimen_ids=list(row["specimen_ids"]),
                observations=row.get("observations", ""),
            )
            for row in rows
        ]
        self._append_partial_group_observations(temp_groups)
        for row, group in zip(rows, temp_groups):
            row["observations"] = group.observations

        self.group_rows = rows
        self._refresh_groups_tree()
        self.report_number_var.set(report_numbers[0])
        if not self.order_number_var.get().strip() and self.ot_context is not None:
            self.order_number_var.set(getattr(self.ot_context, "ot_number", "") or "")
        self.export_now()

    def _point_visibility_payload(self) -> Dict[str, bool]:
        return {
            "show_point_yp": bool(self.show_point_yp_var.get()),
            "show_point_rp": bool(self.show_point_rp_var.get()),
            "show_point_a": bool(self.show_point_a_var.get()),
            "show_point_b": bool(self.show_point_b_var.get()),
            "show_point_max": bool(self.show_point_max_var.get()),
            "show_r2p_lines": bool(self.show_r2p_lines_var.get()),
        }

    def _build_payload(self) -> ReportExportPayload:
        groups = [
            ReportExportGroup(
                report_number=row["report_number"],
                order_number=row["order_number"],
                specimen_ids=list(row["specimen_ids"]),
                observations=row.get("observations", ""),
            )
            for row in self.group_rows
        ]
        self._append_partial_group_observations(groups)
        return ReportExportPayload(
            accreditation_mode=self.accreditation_var.get(),
            issue_date=self.issue_date_var.get().strip(),
            client_name=self.client_name_var.get().strip(),
            client_phone=self.phone_var.get().strip(),
            client_address=self.address_var.get().strip(),
            client_email=self.email_var.get().strip(),
            client_contact=self.contact_var.get().strip(),
            default_comment=self.default_comment,
            source_path=str(getattr(self.dataset, "source_path", "") or ""),
            ot_pdf_path=self.ot_pdf_path_var.get().strip(),
            ot_context=self.ot_context,
            groups=groups,
            point_visibility=self._point_visibility_payload(),
            graph_config=self.graph_config,
        )

    def export_now(self) -> None:
        if not self.group_rows:
            # Flujo rápido: si no hay grupo, crea un grupo con las probetas seleccionadas.
            if self._selected_specimen_ids():
                self.add_group()
            else:
                messagebox.showwarning("Sin grupos", "Cree al menos un grupo de informe antes de exportar.", parent=self)
                return
        output_dir = self.output_dir_var.get().strip()
        if not output_dir:
            messagebox.showwarning("Sin carpeta", "Seleccione la carpeta de salida.", parent=self)
            return
        try:
            payload = self._build_payload()
            exported = export_report_groups_to_docx(
                self.dataset,
                payload,
                output_dir,
                analysis_config=self.analysis_config,
                result_provider=self.result_provider,
                comment_provider=self.comment_provider,
            )
            messagebox.showinfo("Exportación completa", "Se generaron:\n" + "\n".join(str(path) for path in exported), parent=self)
            try:
                self.master.status_var.set(f"Reportes exportados: {len(exported)}")
            except Exception:
                pass
            self._after_successful_export()
        except Exception as exc:
            messagebox.showerror("Error al exportar", str(exc), parent=self)


__all__ = ["ReportExportDialog"]
