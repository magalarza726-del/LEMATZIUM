from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import copy
import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from matplotlib.figure import Figure

from shared.tk_ui_standard import (
    TEXT_EXPORT_WORD,
    TEXT_RECALCULATE,
    SUPPORTED_FILETYPES,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
)
from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
    analyze_curve,
    get_default_comment,
)
from shared.tensile_unified.plotting import draw_unified_tensile_curve
from shared.tensile_unified.summary import build_unified_summary_rows
from shared.tensile_unified.manual_points import MODE_TO_POINT_KEY, nearest_curve_index

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_tensile_unified.reports.exporter import export_unified_report
from lematzium_tensile_unified.ui.export_dialog import ReportExportDialog
from lematzium_tensile_unified.ui.presentation import (
    GEOMETRY_LABEL_BY_VALUE,
    GEOMETRY_MAP,
    MANUAL_DRAG_LABELS,
    META_FIELDS,
    METHOD_LABEL_ALIASES,
    METHOD_LABEL_BY_VALUE,
    display_confidence as _display_confidence,
    display_method as _display_method,
    display_reason as _display_reason,
    fmt as _fmt,
    result_value_label as _result_value_label,
    safe_float as _safe_float,
)


class CsvFlowMixin:
    def _schedule_recalculate_from_parameters(self) -> None:
        """Recalcula al cambiar caída u offset sin disparar múltiples cálculos por tecla."""
        if getattr(self, "_method_ui_loading", False):
            return
        try:
            self._save_method_config_for_current()
        except Exception:
            pass
        if not self.current_curve:
            return
        try:
            if self._recalculate_after_id is not None:
                self.after_cancel(self._recalculate_after_id)
        except Exception:
            pass
        self._recalculate_after_id = self.after(350, self._run_scheduled_recalculate)

    def _run_scheduled_recalculate(self) -> None:
        self._recalculate_after_id = None
        self.recalculate()

    def import_csv(self) -> None:
        file_path = filedialog.askopenfilename(title="Seleccionar archivo de datos", filetypes=SUPPORTED_FILETYPES)
        if not file_path:
            return
        self._load_csv_path(file_path)

    def reload_csv(self) -> None:
        if not self.current_file_path:
            show_info("Sin archivo", "No hay archivo cargado para recargar.")
            return
        self._load_csv_path(self.current_file_path)

    def _load_csv_path(self, file_path: str) -> None:
        try:
            self.dataset = load_dataset(file_path)
            try:
                self._clear_fast_caches()
            except Exception:
                pass
            try:
                self._reset_graph_scale_for_new_csv()
            except Exception:
                pass
            self.current_file_path = file_path
            self._manual_points_by_specimen = {}
            self._original_geometry_by_specimen = {}
            self._summary_multigraph_indices = set()
            self._curve_colors_by_index = {}
            self._analysis_config_by_specimen = {}
            self._summary_original_specimen_ids = [str(getattr(curve, "specimen_id", f"Probeta {idx + 1}")) for idx, curve in enumerate(getattr(self.dataset, "curves", []) or [])]
            self.source_path_var.set(Path(file_path).name)
            self._load_meta_from_dataset()
            self._populate_specimens()
            if self.dataset.curves:
                self._set_active_curve_by_index(0)
            self._refresh_summary_table()
            set_loaded_status(self.status_var, file_path, extra=f"Probetas: {len(self.dataset.curves)}")
        except Exception as exc:
            self.current_result = None
            self.analysis_message_var.set("Curva insuficiente para análisis o archivo no compatible.")
            self._update_export_button_state()
            show_import_error(exc)
            self.status_var.set("No se pudo importar el archivo.")

    def _populate_specimens(self) -> None:
        values = []
        if self.dataset is not None:
            values = [str(getattr(curve, "specimen_id", f"Probeta {idx + 1}")) for idx, curve in enumerate(self.dataset.curves)]
        self._is_updating_specimen_combo = True
        try:
            self.specimen_combo.configure(values=values)
            self.specimen_var.set(values[0] if values else "")
        finally:
            self._is_updating_specimen_combo = False

    def _set_active_curve_by_index(self, index: int) -> None:
        if not self.dataset or not self.dataset.curves:
            return
        index = max(0, min(index, len(self.dataset.curves) - 1))
        curve = self.dataset.curves[index]
        self._is_updating_specimen_combo = True
        try:
            self.specimen_var.set(str(getattr(curve, "specimen_id", f"Probeta {index + 1}")))
        finally:
            self._is_updating_specimen_combo = False
        self._load_curve(curve)

    def _on_specimen_selected(self, _event: Any = None) -> None:
        if self._is_updating_specimen_combo or not self.dataset:
            return
        selected_index = -1
        try:
            selected_index = int(self.specimen_combo.current())
        except Exception:
            selected_index = -1
        if selected_index >= 0:
            self._set_active_curve_by_index(selected_index)
            return
        selected_id = self.specimen_var.get()
        for index, curve in enumerate(self.dataset.curves):
            if str(getattr(curve, "specimen_id", f"Probeta {index + 1}")) == selected_id:
                self._set_active_curve_by_index(index)
                return

    def _load_curve(self, curve: Any) -> None:
        try:
            if self.current_curve is not None:
                self._save_method_config_for_current()
        except Exception:
            pass
        new_key = self._curve_comment_key(curve)
        old_key = self._curve_comment_key(self.current_curve)
        if new_key != old_key:
            self._comment_dirty = False
            self._last_comment_curve_key = None
        self.current_curve = curve
        self._crosshair_last_state = None
        self._remember_original_geometry(curve)
        self._graph_has_valid_view = False
        try:
            self._plot_limits_update_in_progress = True
            self.x_min_var.set("0")
            self.y_min_var.set("0")
            self.x_max_var.set("")
            self.y_max_var.set("")
        finally:
            self._plot_limits_update_in_progress = False
        self._load_geometry_to_ui(getattr(curve, "geometry", None))
        try:
            self._load_method_config_for_curve(curve)
        except Exception:
            pass
        self.recalculate()

