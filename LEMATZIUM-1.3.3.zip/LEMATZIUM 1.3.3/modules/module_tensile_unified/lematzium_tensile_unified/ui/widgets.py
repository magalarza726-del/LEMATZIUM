from __future__ import annotations

"""Widgets reutilizables de la interfaz del modulo unificado."""

from typing import Any
import tkinter as tk
from tkinter import ttk


class CollapsibleSection(ttk.Frame):
    """Seccion colapsable tipo modulos originales.

    Mantiene el panel derecho compacto para que la grafica sea la zona
    protagonista, pero conserva todos los campos del flujo unificado.
    """

    def __init__(self, master: tk.Misc, title: str, *, expanded: bool = False, on_toggle: Any = None) -> None:
        super().__init__(master)
        self.title = title
        self.on_toggle = on_toggle
        self.is_expanded = tk.BooleanVar(value=expanded)
        self.header_button = ttk.Button(self, text=self._button_text(), command=self.toggle)
        self.header_button.grid(row=0, column=0, sticky="ew")
        self.body = ttk.Frame(self, padding=(6, 6, 6, 2))
        self.columnconfigure(0, weight=1)
        if expanded:
            self.body.grid(row=1, column=0, sticky="ew")

    def _button_text(self) -> str:
        return f"{'▼' if self.is_expanded.get() else '▶'} {self.title}"

    def toggle(self) -> None:
        self.is_expanded.set(not self.is_expanded.get())
        self.header_button.configure(text=self._button_text())
        if self.is_expanded.get():
            self.body.grid(row=1, column=0, sticky="ew")
        else:
            self.body.grid_remove()
        self.update_idletasks()
        if self.on_toggle:
            self.on_toggle()


__all__ = ["CollapsibleSection"]
