from __future__ import annotations

"""Textos, etiquetas y formateadores de presentacion para la UI unificada.

Este modulo no contiene logica de calculo ni widgets Tk. Centraliza constantes
visuales y conversiones de valores internos a etiquetas legibles, para mantener
``main_window.py`` enfocado en el flujo de interfaz.
"""

from typing import Any, Optional

from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, SHAPE_TUBULAR
from shared.tensile_unified import METHOD_AUTO, METHOD_RP_OFFSET, METHOD_UPPER_YIELD


METHOD_LABELS = {
    "Automático": METHOD_AUTO,
    "Fluencia superior": METHOD_UPPER_YIELD,
    "Rp offset": METHOD_RP_OFFSET,
}

METHOD_LABEL_ALIASES = {
    **METHOD_LABELS,
    "Automatico": METHOD_AUTO,
    "auto": METHOD_AUTO,
    METHOD_AUTO: METHOD_AUTO,
    METHOD_UPPER_YIELD: METHOD_UPPER_YIELD,
    METHOD_RP_OFFSET: METHOD_RP_OFFSET,
}

METHOD_LABEL_BY_VALUE = {
    METHOD_AUTO: "Automático",
    METHOD_UPPER_YIELD: "Fluencia superior",
    METHOD_RP_OFFSET: "Rp offset",
    "manual_review": "Revisión manual",
}

CONFIDENCE_LABEL_BY_VALUE = {
    "high": "Alta",
    "medium": "Media",
    "low": "Baja",
    "alta": "Alta",
    "media": "Media",
    "baja": "Baja",
}

GEOMETRY_LABELS = ["Rectangular", "Circular", "Tubería / anular", "Irregular / área nominal"]
GEOMETRY_ALIASES = {
    "Rectangular": SHAPE_RECTANGULAR,
    "Circular": SHAPE_CIRCULAR,
    "Tubería / anular": SHAPE_TUBULAR,
    "Tuberia / anular": SHAPE_TUBULAR,
    "Irregular / área nominal": SHAPE_IRREGULAR,
    "Irregular / area nominal": SHAPE_IRREGULAR,
}
GEOMETRY_MAP = GEOMETRY_ALIASES
GEOMETRY_LABEL_BY_VALUE = {
    SHAPE_RECTANGULAR: "Rectangular",
    SHAPE_CIRCULAR: "Circular",
    SHAPE_TUBULAR: "Tubería / anular",
    SHAPE_IRREGULAR: "Irregular / área nominal",
}

META_FIELDS = (
    ("procedure", "Procedimiento", ("Procedure", "Procedimiento")),
    ("standard", "Norma de referencia", ("Reference Standard", "Norma de Referencia", "Norma de referencia")),
    ("machine", "Equipo utilizado", ("Used Device", "Equipo Utilizado", "Equipo utilizado")),
    ("material", "Material", ("Material",)),
    ("speed", "Velocidad de ensayo", ("Test Speed", "Velocidad de Ensayo", "Velocidad de ensayo")),
    ("humidity", "Humedad Máx/Mín", ("Humidity Max/Min", "Humedad Máx/Min", "Humedad Máx/Mín")),
    ("temperature", "Temperatura Máx/Mín", ("Temperature Max/Min", "Temperatura Máx/Mín", "Temperatura Max/Min")),
    ("control", "Control de velocidad", ("Speed Control", "Control de Velocidad", "Control de velocidad")),
    ("order", "Número de orden", ("Order No", "Número de Orden", "N° orden", "Numero de orden")),
    ("sample_description", "Descripción de la muestra", ("Descripción de la muestra", "Descripcion de la muestra", "Sample Description", "Description")),
    ("received_date", "Fecha de recepción de muestras", ("Fecha de Recepción", "Fecha Recepción", "Fecha de recepción de muestras", "Reception Date", "Received Date")),
    ("test_date", "Fecha de ensayo", ("Fecha de Ensayo", "Fecha Ensayo", "Test Date")),
)

MANUAL_DRAG_LABELS = {
    "none": "Sin arrastre",
    "yield": "Fluencia superior",
    "max": "Máximo",
    "rp_a": "Punto A Rp",
    "rp_b": "Punto B Rp",
    "rp": "Punto Rp",
}


def safe_float(text: Any) -> Optional[float]:
    try:
        if text is None:
            return None
        value = str(text).strip().replace(",", ".")
        if not value:
            return None
        number = float(value)
        return number if number > 0 else None
    except Exception:
        return None


def fmt(value: Any, ndigits: int = 2) -> str:
    try:
        if value is None:
            return "No disponible"
        return f"{float(value):.{ndigits}f}"
    except Exception:
        return "No disponible"


def display_method(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    if not text or text == "-":
        return "-"
    return METHOD_LABEL_BY_VALUE.get(text, METHOD_LABEL_BY_VALUE.get(text.lower(), text))


def display_confidence(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    if not text or text == "-":
        return "-"
    return CONFIDENCE_LABEL_BY_VALUE.get(text.lower(), text)


def display_reason(value: Any) -> str:
    text = "" if value is None else str(value).strip()
    if not text or text == "-":
        return "-"
    replacements = {
        METHOD_UPPER_YIELD: "Fluencia superior",
        METHOD_RP_OFFSET: "Rp offset",
        METHOD_AUTO: "Automático",
        "manual_review": "Revisión manual",
        "high": "Alta",
        "medium": "Media",
        "low": "Baja",
    }
    for raw, visible in replacements.items():
        text = text.replace(str(raw), visible)
    return text


def result_value_label(method: Any, rp_label: str) -> str:
    if method == METHOD_RP_OFFSET:
        return f"Esfuerzo de fluencia {rp_label}:"
    if method == METHOD_UPPER_YIELD:
        return "Esfuerzo de fluencia superior:"
    return "Esfuerzo de fluencia:"


__all__ = [
    "CONFIDENCE_LABEL_BY_VALUE",
    "GEOMETRY_ALIASES",
    "GEOMETRY_LABELS",
    "GEOMETRY_LABEL_BY_VALUE",
    "GEOMETRY_MAP",
    "MANUAL_DRAG_LABELS",
    "META_FIELDS",
    "METHOD_LABEL_ALIASES",
    "METHOD_LABEL_BY_VALUE",
    "METHOD_LABELS",
    "display_confidence",
    "display_method",
    "display_reason",
    "fmt",
    "result_value_label",
    "safe_float",
]
