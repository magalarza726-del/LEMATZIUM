from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Optional
import copy
import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

from shared.tk_ui_standard import (
    TEXT_AUTO_ADJUST,
    TEXT_EXPORT_WORD,
    TEXT_GEOMETRY_SECTION,
    TEXT_IMPORT_CSV,
    TEXT_RECALCULATE,
    TEXT_RESULTS_SECTION,
    SUPPORTED_FILETYPES,
    configure_standard_style,
    set_loaded_status,
    show_error,
    show_import_error,
    show_info,
    show_warning,
)
from shared.tensile_geometry import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_RECTANGULAR, normalize_shape
from shared.tensile_unified import (
    METHOD_AUTO,
    METHOD_MANUAL_REVIEW,
    METHOD_RP_OFFSET,
    METHOD_UPPER_YIELD,
    TensileAnalysisConfig,
    analyze_curve,
    get_default_comment,
)
from shared.tensile_unified.plotting import draw_unified_tensile_curve
from shared.tensile_unified.summary import build_unified_summary_rows
from shared.tensile_unified.manual_points import MODE_TO_POINT_KEY, nearest_curve_index

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_tensile_unified.reports.exporter import export_unified_report
from lematzium_tensile_unified.ui.export_dialog import ReportExportDialog
from lematzium_tensile_unified.ui.presentation import (
    GEOMETRY_LABELS,
    GEOMETRY_LABEL_BY_VALUE,
    GEOMETRY_MAP,
    MANUAL_DRAG_LABELS,
    META_FIELDS,
    METHOD_LABEL_ALIASES,
    METHOD_LABEL_BY_VALUE,
    METHOD_LABELS,
    display_confidence as _display_confidence,
    display_method as _display_method,
    display_reason as _display_reason,
    fmt as _fmt,
    result_value_label as _result_value_label,
    safe_float as _safe_float,
)
from lematzium_tensile_unified.ui.widgets import CollapsibleSection
from lematzium_tensile_unified.ui.csv_flow import CsvFlowMixin
from lematzium_tensile_unified.ui.metadata_geometry_flow import MetadataGeometryFlowMixin
from lematzium_tensile_unified.ui.summary_comment_flow import SummaryCommentFlowMixin
from lematzium_tensile_unified.ui.graph_flow import GraphFlowMixin
from lematzium_tensile_unified.ui.export_flow import ExportFlowMixin


class UnifiedTensileWindow(
    CsvFlowMixin,
    MetadataGeometryFlowMixin,
    SummaryCommentFlowMixin,
    GraphFlowMixin,
    ExportFlowMixin,
    ttk.Frame,
):
    """Interfaz inicial del modulo unificado de traccion.

    Es deliberadamente autocontenida: usa el lector robusto del modulo 1 y el
    motor comun shared.tensile_unified, pero no modifica ni reemplaza los modulos
    1 y 2 existentes.
    """

    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master)
        self.master = master
        self.dataset = None
        self.current_curve = None
        self.current_result = None
        self.current_detection: dict[str, Any] = {}
        self.current_graph_path: Optional[Path] = None
        self._tempdir = TemporaryDirectory(prefix="lematzium_tensile_unified_")
        self._comment_dirty = False
        self._comment_update_in_progress = False
        self._last_comment_curve_key: Optional[str] = None
        self._recalculate_after_id: Optional[str] = None
        self._graph_has_valid_view = False
        self.current_file_path: Optional[str] = None
        self._curve_color = "#38BDF8"
        self._is_updating_specimen_combo = False
        self._zoom_base_default = 1.20
        self._manual_points_by_specimen: dict[str, dict[str, int]] = {}
        self._is_dragging_manual_point = False
        self._drag_mode_active = "none"
        self._plot_limits_update_in_progress = False
        self._plot_update_after_id: Optional[str] = None
        self._geometry_ui_loading = False
        self._geometry_update_after_id: Optional[str] = None
        self._original_geometry_by_specimen: dict[str, Any] = {}
        self._summary_original_specimen_ids: list[str] = []
        self._summary_multigraph_indices: set[int] = set()
        self._summary_edit_entry: Optional[ttk.Entry] = None
        self._curve_colors_by_index: dict[int, str] = {}
        self._summary_color_swatches: dict[str, tk.Widget] = {}


        self.status_var = tk.StringVar(value="Listo. Importe un CSV para comenzar.")
        self.source_path_var = tk.StringVar(value="Sin archivo cargado")
        self.specimen_var = tk.StringVar(value="")
        self.cursor_var = tk.StringVar(value="Punto actual: —")
        self.zoom_factor_var = tk.StringVar(value="1.20")
        self.plot_mode_var = tk.StringVar(value="auto")
        self.anchor_origin_var = tk.BooleanVar(value=True)
        self.x_min_var = tk.StringVar(value="0")
        self.x_max_var = tk.StringVar(value="")
        self.y_min_var = tk.StringVar(value="0")
        self.y_max_var = tk.StringVar(value="")
        self.drag_mode_var = tk.StringVar(value="auto")
        # Visibilidad de marcadores en gráfica y reporte.
        # Por defecto: YP y MÁX visibles; A, B y R2P/Rp ocultos.
        self.show_point_yp_var = tk.BooleanVar(value=True)
        self.show_point_rp_var = tk.BooleanVar(value=False)
        self.show_point_a_var = tk.BooleanVar(value=False)
        self.show_point_b_var = tk.BooleanVar(value=False)
        self.show_point_max_var = tk.BooleanVar(value=True)
        self.unlock_meta_var = tk.BooleanVar(value=False)
        self.unlock_geometry_var = tk.BooleanVar(value=False)
        self.geometry_var = tk.StringVar(value="Rectangular")
        self.method_var = tk.StringVar(value="Automático")
        # Visualización de la gráfica. Por defecto se conserva el modo histórico:
        # esfuerzo vs alargamiento en MPa. La carga se muestra en kN por defecto.
        self.graph_type_var = tk.StringVar(value="Esfuerzo vs alargamiento")
        self.stress_unit_var = tk.StringVar(value="MPa")
        self.load_unit_var = tk.StringVar(value="kN")
        self.show_r2p_lines_var = tk.BooleanVar(value=True)
        self.upper_yield_drop_var = tk.StringVar(value="1.0")
        self.offset_percent_var = tk.StringVar(value="0.2")
        self.apply_geometry_all_var = tk.BooleanVar(value=False)
        # Configuración de análisis: por defecto cada probeta puede conservar
        # sus propios parámetros. Al activar “Aplicar a todas”, la configuración
        # visible se replica al lote completo.
        self.apply_method_all_var = tk.BooleanVar(value=False)
        self._method_ui_loading = False
        self._analysis_config_by_specimen: dict[str, dict[str, str]] = {}

        self.meta_vars: dict[str, tk.StringVar] = {name: tk.StringVar(value="") for name, _label, _keys in META_FIELDS}
        self.meta_entries: list[ttk.Entry] = []
        self.geometry_widgets: list[tk.Widget] = []

        self.thickness_var = tk.StringVar()
        self.width_var = tk.StringVar()
        self.diameter_var = tk.StringVar()
        self.area_var = tk.StringVar()
        self.gauge_var = tk.StringVar()

        self.detection_method_var = tk.StringVar(value="-")
        self.detection_confidence_var = tk.StringVar(value="-")
        self.detection_reason_var = tk.StringVar(value="-")
        self.analysis_message_var = tk.StringVar(value="Importe un CSV para iniciar el análisis.")
        self.comment_notice_var = tk.StringVar(value="")
        self.result_value_label_var = tk.StringVar(value="Esfuerzo de fluencia superior:")
        self.result_max_label_var = tk.StringVar(value="Esfuerzo máximo:")
        self.result_elong_label_var = tk.StringVar(value="Elongación luego de rotura:")
        self.result_e_label_var = tk.StringVar(value="Módulo elástico:")
        self.rp_label_text_var = tk.StringVar(value="Etiqueta Rp:")
        self.result_value_var = tk.StringVar(value="No disponible")
        self.result_max_var = tk.StringVar(value="No disponible")
        self.result_elong_var = tk.StringVar(value="No disponible")
        self.result_e_var = tk.StringVar(value="No disponible")
        self.rp_label_var = tk.StringVar(value="Rp0.2")

        self._build_style()
        self._build_layout()
        self._bind_events()
        self._refresh_method_parameter_state()
        try:
            self._refresh_graph_unit_controls()
        except Exception:
            pass

    def destroy(self) -> None:
        try:
            self._tempdir.cleanup()
        except Exception:
            pass
        super().destroy()

    def _build_style(self) -> None:
        style = ttk.Style(self)
        configure_standard_style(style, bg="#f8fafc", accent="#1f4e79", accent_soft="#dbeafe")

    def _build_layout(self) -> None:
        """Distribución tipo Módulo 1: gráfica protagonista + panel derecho de control.

        La selección de tipo de gráfica se mantiene como control explícito, pero
        la zona principal queda ocupada por la curva y la barra Matplotlib.
        """
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        header = ttk.Frame(self, padding=(12, 10))
        header.grid(row=0, column=0, sticky="ew")
        ttk.Label(header, text="LEMATZIUM - Tracción unificada", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Importación CSV, detección de geometría, Fluencia superior y Rp offset en un solo flujo.",
            style="SubHeader.TLabel",
        ).pack(anchor="w")

        # Barra principal siempre visible. En versiones previas estos botones
        # quedaban fuera de la zona útil o dentro de secciones colapsadas en
        # pantallas pequeñas; aquí permanecen arriba como en los módulos 1 y 2.
        actionbar = ttk.Frame(header)
        actionbar.pack(anchor="w", fill="x", pady=(8, 0))
        actionbar.columnconfigure(3, weight=1)
        actionbar.columnconfigure(6, weight=1)
        self.import_csv_top_button = ttk.Button(
            actionbar,
            text="Importar CSV...",
            command=self.import_csv,
        )
        self.import_csv_top_button.grid(row=0, column=0, sticky="w")
        self.export_word_top_button = ttk.Button(
            actionbar,
            text="Exportar Word",
            command=self.export_word,
            state="disabled",
        )
        self.export_word_top_button.grid(row=0, column=1, sticky="w", padx=(8, 0))
        self.export_png_top_button = ttk.Button(
            actionbar,
            text="Exportar PNG",
            command=self.export_graph_png,
            state="disabled",
        )
        self.export_png_top_button.grid(row=0, column=2, sticky="w", padx=(8, 0))
        ttk.Label(actionbar, textvariable=self.source_path_var, anchor="w").grid(row=0, column=3, sticky="ew", padx=(12, 18))
        # La selección de probeta se gestiona desde la tabla de la sección A.
        # Se conserva un Combobox oculto solo por compatibilidad interna con flujos previos.
        self.specimen_combo = ttk.Combobox(actionbar, textvariable=self.specimen_var, state="readonly", width=18)

        body = ttk.Panedwindow(self, orient="horizontal")
        body.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 8))
        self.left_pane = ttk.Frame(body)
        self.right_pane = ttk.Frame(body)
        body.add(self.left_pane, weight=7)
        body.add(self.right_pane, weight=1)

        self._build_left_panel(self.left_pane)
        self._build_right_panel(self.right_pane)

        status = ttk.Label(self, textvariable=self.status_var, anchor="w", padding=(8, 4), relief="groove")
        status.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 8))

    def _build_left_panel(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(0, weight=1)

        graph_frame = ttk.LabelFrame(parent, text="Gráfica", padding=8)
        graph_frame.grid(row=0, column=0, sticky="nsew")
        graph_frame.rowconfigure(1, weight=1)
        graph_frame.columnconfigure(0, weight=1)

        toolbar_frame = ttk.Frame(graph_frame)
        toolbar_frame.grid(row=0, column=0, sticky="ew", pady=(0, 4))

        self.figure = Figure(figsize=(11.2, 7.2), dpi=100, facecolor="#f8fafc")
        self.ax = self.figure.add_subplot(111)
        self.ax.set_facecolor("#ffffff")
        self.ax.set_xlabel("Alargamiento (mm)")
        self.ax.set_ylabel("Esfuerzo (MPa)")
        self.ax.grid(True, which="major", color="#9aa7b4", linestyle="--", linewidth=0.75, alpha=0.78)
        self.ax.grid(True, which="minor", color="#d7dee7", linestyle=":", linewidth=0.50, alpha=0.72)
        self.canvas = FigureCanvasTkAgg(self.figure, master=graph_frame)
        self.plot_canvas = self.canvas
        self.canvas.get_tk_widget().configure(bg="#f8fafc", highlightthickness=0, cursor="tcross")
        self.canvas.get_tk_widget().grid(row=1, column=0, sticky="nsew")
        self.toolbar = NavigationToolbar2Tk(self.canvas, toolbar_frame, pack_toolbar=False)
        self.toolbar.update()
        self.toolbar.pack(side="left")
        self._configure_toolbar_home()

    def _build_right_panel(self, parent: ttk.Frame) -> None:
        """Panel derecho simplificado para el módulo automático."""
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(0, weight=1)
        self.right_canvas = tk.Canvas(parent, bg="#ffffff", highlightthickness=0, bd=0)
        self.right_scrollbar = ttk.Scrollbar(parent, orient="vertical", command=self.right_canvas.yview)
        self.right_canvas.configure(yscrollcommand=self.right_scrollbar.set)
        self.right_canvas.grid(row=0, column=0, sticky="nsew")
        self.right_scrollbar.grid(row=0, column=1, sticky="ns")
        self.right_inner = ttk.Frame(self.right_canvas, padding=(8, 0, 0, 0))
        self.right_window_id = self.right_canvas.create_window((0, 0), window=self.right_inner, anchor="nw")
        self.right_inner.bind("<Configure>", self._on_right_inner_configure)
        self.right_canvas.bind("<Configure>", self._on_right_canvas_configure)
        self.right_inner.bind("<Enter>", self._bind_right_mousewheel)
        self.right_inner.bind("<Leave>", self._unbind_right_mousewheel)
        self.right_inner.columnconfigure(0, weight=1)
        self._right_section_row = 0

        def make_section(title: str, *, expanded: bool = False) -> CollapsibleSection:
            section = CollapsibleSection(self.right_inner, title, expanded=expanded, on_toggle=self._refresh_right_scrollregion)
            section.grid(row=self._right_section_row, column=0, sticky="ew", pady=(0, 8))
            self._right_section_row += 1
            return section

        # C. Resumen del lote colocado arriba para seleccionar y resaltar la probeta activa.
        summary_section = make_section("A. Resumen del lote", expanded=True)
        summary_frame = summary_section.body
        summary_frame.columnconfigure(0, weight=1)
        summary_frame.rowconfigure(0, weight=1)
        summary_columns = ("show", "specimen", "color", "yp", "max")
        self.summary_tree = ttk.Treeview(summary_frame, columns=summary_columns, show="headings", height=6)
        headings = {"show": "☑", "specimen": "Código", "color": "Color", "yp": "YP (MPa)", "max": "MAX (MPa)"}
        widths = {"show": 34, "specimen": 104, "color": 52, "yp": 76, "max": 76}
        for col in summary_columns:
            self.summary_tree.heading(col, text=headings[col])
            self.summary_tree.column(col, width=widths[col], minwidth=28 if col in {"show", "color"} else 58, stretch=(col not in {"show", "color"}), anchor="center")
        try:
            self.summary_tree.tag_configure("current", background="#dbeafe")
        except Exception:
            pass
        yscroll = ttk.Scrollbar(summary_frame, orient="vertical")

        def _summary_yview(*args: Any) -> None:
            self.summary_tree.yview(*args)
            try:
                self.after_idle(self._refresh_summary_color_swatches)
            except Exception:
                pass

        def _summary_yscroll_set(*args: Any) -> None:
            yscroll.set(*args)
            try:
                self.after_idle(self._refresh_summary_color_swatches)
            except Exception:
                pass

        yscroll.configure(command=_summary_yview)
        self.summary_tree.configure(yscrollcommand=_summary_yscroll_set)
        self.summary_tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        summary_actions = ttk.Frame(summary_frame)
        summary_actions.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        summary_actions.columnconfigure(0, weight=1)
        ttk.Button(summary_actions, text="Reiniciar tabla", command=self.reset_summary_table).grid(row=0, column=0, sticky="ew")
        self.summary_tree.bind("<<TreeviewSelect>>", self._on_summary_selected)
        self.summary_tree.bind("<Button-1>", self._on_summary_tree_click, add="+")
        self.summary_tree.bind("<Double-1>", self._on_summary_tree_double_click, add="+")
        self.summary_tree.bind("<Configure>", lambda _event: self.after_idle(self._refresh_summary_color_swatches), add="+")

        # B. Método y parámetros. Los límites X/Y y la escala se ajustan desde el botón de configuración de subplots de la barra Matplotlib.
        method_section = make_section("B. Método y parámetros", expanded=True)
        method_frame = method_section.body
        method_frame.columnconfigure(1, weight=1)
        self.plot_limit_entries = []
        ttk.Label(method_frame, text="Método de análisis:").grid(row=0, column=0, sticky="w", pady=2)
        self.method_combo = ttk.Combobox(method_frame, textvariable=self.method_var, values=list(METHOD_LABELS.keys()), state="readonly")
        self.method_combo.grid(row=0, column=1, sticky="ew", pady=2)
        self.upper_yield_drop_label = ttk.Label(method_frame, text="Caída requerida para fluencia superior (MPa):")
        self.upper_yield_drop_label.grid(row=1, column=0, sticky="w", pady=2)
        self.upper_yield_drop_entry = ttk.Entry(method_frame, textvariable=self.upper_yield_drop_var, width=8)
        self.upper_yield_drop_entry.grid(row=1, column=1, sticky="ew", pady=2)
        self.offset_percent_label = ttk.Label(method_frame, text="Offset Rp (%):")
        self.offset_percent_label.grid(row=2, column=0, sticky="w", pady=2)
        self.offset_percent_entry = ttk.Entry(method_frame, textvariable=self.offset_percent_var, width=8)
        self.offset_percent_entry.grid(row=2, column=1, sticky="ew", pady=2)
        self.apply_method_all_check = ttk.Checkbutton(
            method_frame,
            text="Aplicar a todas",
            variable=self.apply_method_all_var,
            command=self._on_apply_method_all_changed,
        )
        self.apply_method_all_check.grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))

        ttk.Separator(method_frame).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 6))
        ttk.Label(method_frame, text="Visualización de gráfica:", font=("Segoe UI", 9, "bold")).grid(row=5, column=0, columnspan=2, sticky="w")
        ttk.Label(method_frame, text="Tipo de gráfica:").grid(row=6, column=0, sticky="w", pady=2)
        self.graph_type_combo = ttk.Combobox(
            method_frame,
            textvariable=self.graph_type_var,
            values=("Esfuerzo vs alargamiento", "Carga vs alargamiento"),
            state="readonly",
        )
        self.graph_type_combo.grid(row=6, column=1, sticky="ew", pady=2)
        ttk.Label(method_frame, text="Unidad esfuerzo:").grid(row=7, column=0, sticky="w", pady=2)
        self.stress_unit_combo = ttk.Combobox(method_frame, textvariable=self.stress_unit_var, values=("MPa", "kPa", "Pa"), state="readonly")
        self.stress_unit_combo.grid(row=7, column=1, sticky="ew", pady=2)
        ttk.Label(method_frame, text="Unidad carga:").grid(row=8, column=0, sticky="w", pady=2)
        self.load_unit_combo = ttk.Combobox(method_frame, textvariable=self.load_unit_var, values=("kN", "N"), state="readonly")
        self.load_unit_combo.grid(row=8, column=1, sticky="ew", pady=2)
        self.show_r2p_lines_check = ttk.Checkbutton(
            method_frame,
            text="Mostrar rectas R2P/Rp",
            variable=self.show_r2p_lines_var,
            command=self._apply_plot_configuration,
        )
        self.show_r2p_lines_check.grid(row=9, column=0, columnspan=2, sticky="w", pady=(6, 0))

        ttk.Separator(method_frame).grid(row=10, column=0, columnspan=2, sticky="ew", pady=(10, 6))
        ttk.Label(method_frame, text="Arrastre:", font=("Segoe UI", 9, "bold")).grid(row=11, column=0, columnspan=2, sticky="w")
        manual_frame = ttk.Frame(method_frame)
        manual_frame.grid(row=12, column=0, columnspan=2, sticky="ew")
        ttk.Radiobutton(manual_frame, text="Auto", value="auto", variable=self.drag_mode_var, command=self._on_drag_control_changed).pack(anchor="w")
        ttk.Radiobutton(manual_frame, text="Manual", value="manual", variable=self.drag_mode_var, command=self._on_drag_control_changed).pack(anchor="w")

        ttk.Separator(method_frame).grid(row=13, column=0, columnspan=2, sticky="ew", pady=(10, 6))
        ttk.Label(method_frame, text="Puntos visibles en gráfica/reporte:", font=("Segoe UI", 9, "bold")).grid(row=14, column=0, columnspan=2, sticky="w")
        points_frame = ttk.Frame(method_frame)
        points_frame.grid(row=15, column=0, columnspan=2, sticky="ew", pady=(2, 0))
        points_frame.columnconfigure(0, weight=1)
        points_frame.columnconfigure(1, weight=1)
        ttk.Checkbutton(points_frame, text="YP", variable=self.show_point_yp_var, command=self._apply_plot_configuration).grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(points_frame, text="R2P/Rp", variable=self.show_point_rp_var, command=self._apply_plot_configuration).grid(row=0, column=1, sticky="w")
        ttk.Checkbutton(points_frame, text="A", variable=self.show_point_a_var, command=self._apply_plot_configuration).grid(row=1, column=0, sticky="w")
        ttk.Checkbutton(points_frame, text="B", variable=self.show_point_b_var, command=self._apply_plot_configuration).grid(row=1, column=1, sticky="w")
        ttk.Checkbutton(points_frame, text="MAX", variable=self.show_point_max_var, command=self._apply_plot_configuration).grid(row=2, column=0, sticky="w")

        # C. Datos del ensayo.
        meta_section = make_section("C. Datos del ensayo", expanded=False)
        meta_frame = meta_section.body
        meta_frame.columnconfigure(0, weight=1)
        ttk.Checkbutton(
            meta_frame,
            text="Desbloquear datos del ensayo",
            variable=self.unlock_meta_var,
            command=self._apply_meta_lock_state,
        ).grid(row=0, column=0, sticky="w", pady=(0, 6))
        meta_buttons = ttk.Frame(meta_frame)
        meta_buttons.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        meta_buttons.columnconfigure((0, 1), weight=1)
        ttk.Button(meta_buttons, text="Restaurar desde CSV", command=self.restore_metadata_from_dataset).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        ttk.Button(meta_buttons, text="Aplicar a todas", command=self.apply_metadata_to_all_curves).grid(row=0, column=1, sticky="ew", padx=(3, 0))
        self.meta_entries.clear()
        row = 2
        for name, label, _keys in META_FIELDS:
            ttk.Label(meta_frame, text=label).grid(row=row, column=0, sticky="w", pady=(4, 0))
            entry = ttk.Entry(meta_frame, textvariable=self.meta_vars[name])
            entry.grid(row=row + 1, column=0, sticky="ew", pady=(2, 0))
            entry.bind("<FocusOut>", self._save_metadata_from_ui)
            self.meta_entries.append(entry)
            row += 2

        # D. Geometría.
        geom_section = make_section("D. Geometría", expanded=False)
        geom_frame = geom_section.body
        geom_frame.columnconfigure(1, weight=1)
        self.geometry_widgets.clear()
        unlock_geometry_check = ttk.Checkbutton(
            geom_frame,
            text="Desbloquear forma y geometría",
            variable=self.unlock_geometry_var,
            command=self._apply_geometry_lock_state,
        )
        unlock_geometry_check.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 6))
        ttk.Label(geom_frame, text="Forma:").grid(row=1, column=0, sticky="w", pady=2)
        self.geometry_combo = ttk.Combobox(geom_frame, textvariable=self.geometry_var, values=GEOMETRY_LABELS, state="readonly")
        self.geometry_combo.grid(row=1, column=1, sticky="ew", pady=2)
        self.geometry_widgets.append(self.geometry_combo)

        self.rectangular_rows = []
        self.circular_rows = []
        self.tubular_rows = []
        self.irregular_rows = []
        self._add_entry(geom_frame, 2, "Espesor (mm):", self.thickness_var, self.rectangular_rows)
        self._add_entry(geom_frame, 3, "Anchura (mm):", self.width_var, self.rectangular_rows)
        self._add_entry(geom_frame, 4, "Diámetro (mm):", self.diameter_var, self.circular_rows)
        self._add_entry(geom_frame, 2, "Diámetro interior (mm):", self.thickness_var, self.tubular_rows)
        self._add_entry(geom_frame, 3, "Diámetro exterior (mm):", self.width_var, self.tubular_rows)
        self._add_entry(geom_frame, 5, "Área nominal/manual (mm²):", self.area_var, self.irregular_rows)
        self._add_entry(geom_frame, 6, "Longitud calibrada (mm):", self.gauge_var, [])
        self.geometry_area_label_var = tk.StringVar(value="Área calculada: —")
        ttk.Label(geom_frame, textvariable=self.geometry_area_label_var).grid(row=7, column=0, columnspan=2, sticky="w", pady=(4, 2))
        self.reset_geometry_button = ttk.Button(geom_frame, text="Restablecer valores", command=self.reset_geometry_values)
        self.reset_geometry_button.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self._refresh_geometry_fields()

        # E. Comentario.
        comment_section = make_section("E. Comentario editable", expanded=False)
        comment_frame = comment_section.body
        comment_frame.columnconfigure(0, weight=1)
        self.comment_text = ScrolledText(comment_frame, height=8, wrap="word", font=("Segoe UI", 9))
        self.comment_text.grid(row=0, column=0, sticky="ew")
        comment_actions = ttk.Frame(comment_frame)
        comment_actions.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        comment_actions.columnconfigure(0, weight=1)
        ttk.Button(
            comment_actions,
            text="Actualizar comentario predeterminado",
            command=self.restore_default_comment,
        ).grid(row=0, column=0, sticky="ew")
        ttk.Label(comment_frame, textvariable=self.comment_notice_var, wraplength=330).grid(row=2, column=0, sticky="ew", pady=(4, 0))

        self._apply_meta_lock_state()
        self._apply_geometry_lock_state()
        self.after_idle(self._refresh_right_scrollregion)

    def _refresh_right_scrollregion(self) -> None:
        try:
            self.right_canvas.configure(scrollregion=self.right_canvas.bbox("all"))
        except Exception:
            pass

    def _on_right_inner_configure(self, _event: Any = None) -> None:
        self._refresh_right_scrollregion()

    def _on_right_canvas_configure(self, event: Any = None) -> None:
        try:
            if event is not None:
                self.right_canvas.itemconfigure(self.right_window_id, width=event.width)
            self._refresh_right_scrollregion()
        except Exception:
            pass

    def _bind_right_mousewheel(self, _event: Any = None) -> None:
        try:
            self.right_canvas.bind_all("<MouseWheel>", self._on_right_mousewheel)
        except Exception:
            pass

    def _unbind_right_mousewheel(self, _event: Any = None) -> None:
        try:
            self.right_canvas.unbind_all("<MouseWheel>")
        except Exception:
            pass

    def _on_right_mousewheel(self, event: Any) -> None:
        try:
            self.right_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def _add_entry(self, parent: ttk.Frame, row: int, label: str, var: tk.StringVar, row_store: list) -> None:
        label_widget = ttk.Label(parent, text=label)
        entry_widget = ttk.Entry(parent, textvariable=var)
        label_widget.grid(row=row, column=0, sticky="w", pady=2)
        entry_widget.grid(row=row, column=1, sticky="ew", pady=2)
        row_store.append((label_widget, entry_widget))
        try:
            self.geometry_widgets.append(entry_widget)
        except Exception:
            pass

    def _add_readonly_row(self, parent: ttk.Frame, row: int, label: str, var: tk.StringVar) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2)
        ttk.Label(parent, textvariable=var, wraplength=190).grid(row=row, column=1, sticky="ew", pady=2)

    def _add_readonly_var_row(self, parent: ttk.Frame, row: int, label_var: tk.StringVar, value_var: tk.StringVar) -> None:
        ttk.Label(parent, textvariable=label_var).grid(row=row, column=0, sticky="w", pady=2)
        ttk.Label(parent, textvariable=value_var, wraplength=190).grid(row=row, column=1, sticky="ew", pady=2)

    def _add_plot_limit_entry(self, parent: ttk.Frame, row: int, label: str, var: tk.StringVar) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2)
        entry = ttk.Entry(parent, textvariable=var, width=10)
        entry.grid(row=row, column=1, sticky="ew", pady=2)
        entry.bind("<Return>", lambda _event: self._apply_plot_configuration())
        self.plot_limit_entries.append(entry)

    def _bind_events(self) -> None:
        self.specimen_combo.bind("<<ComboboxSelected>>", self._on_specimen_selected)
        self.geometry_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_geometry_changed())
        self.method_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_method_changed())
        self.graph_type_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_graph_axis_changed())
        self.stress_unit_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_graph_axis_changed())
        self.load_unit_combo.bind("<<ComboboxSelected>>", lambda _event: self._on_graph_axis_changed())
        self.upper_yield_drop_var.trace_add("write", lambda *_args: self._schedule_recalculate_from_parameters())
        self.offset_percent_var.trace_add("write", lambda *_args: self._schedule_recalculate_from_parameters())
        self.x_max_var.trace_add("write", lambda *_args: self._schedule_plot_configuration())
        self.y_max_var.trace_add("write", lambda *_args: self._schedule_plot_configuration())
        for _var in (self.thickness_var, self.width_var, self.diameter_var, self.area_var, self.gauge_var):
            _var.trace_add("write", lambda *_args: self._schedule_geometry_update_from_ui())
        self.comment_text.bind("<<Modified>>", self._on_comment_modified)
        self.canvas.mpl_connect("scroll_event", self._on_scroll_zoom)
        self.canvas.mpl_connect("button_press_event", self._on_graph_button_press)
        self.canvas.mpl_connect("button_release_event", self._on_graph_button_release)
        self.canvas.mpl_connect("button_release_event", self._on_toolbar_view_release)
        self.canvas.mpl_connect("motion_notify_event", self._on_mouse_move)

