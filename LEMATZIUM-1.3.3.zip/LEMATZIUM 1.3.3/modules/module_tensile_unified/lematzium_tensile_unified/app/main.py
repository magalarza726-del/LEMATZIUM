from __future__ import annotations

import traceback
import tkinter as tk
from tkinter import messagebox

from shared.tk_window_restore import install_window_restore_guard, set_windows_app_user_model_id, show_window_normally


APP_TITLE = "LEMATZIUM - Tracción unificada v1.2.3"


def _show_startup_error(title: str, exc: BaseException) -> None:
    details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    message = (
        "No se pudo iniciar el módulo unificado.\n\n"
        "El programa capturó el error para evitar un cierre silencioso.\n\n"
        f"Detalle técnico:\n{details[-1800:]}"
    )
    try:
        messagebox.showerror(title, message)
    except Exception:
        print(message)


def _install_tk_exception_hook(root: tk.Tk) -> None:
    def _report_callback_exception(exc_type, exc_value, exc_tb) -> None:  # type: ignore[no-untyped-def]
        details = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        try:
            messagebox.showerror(
                "Error en LEMATZIUM",
                "Se produjo un error en la interfaz, pero el módulo permanece abierto.\n\n"
                f"Detalle técnico:\n{details[-1800:]}",
            )
        except Exception:
            print(details)

    root.report_callback_exception = _report_callback_exception  # type: ignore[assignment]


def main() -> int:
    set_windows_app_user_model_id("LEMATZIUM.Tension.Unificada")
    root = tk.Tk()
    # No se usa withdraw() en el arranque: en Windows puede dejar la ventana
    # sin restauracion confiable despues de minimizarla desde la barra de tareas.
    install_window_restore_guard(root, app_id="LEMATZIUM.Tension.Unificada")
    root.title(APP_TITLE)
    root.geometry("1760x1020")
    root.minsize(1280, 760)
    root.resizable(True, True)
    _install_tk_exception_hook(root)

    try:
        # Importación diferida tipo módulo 4B: la ventana se construye después
        # de tener un root Tk y un manejador global de excepciones.
        from lematzium_tensile_unified.ui.main_window import UnifiedTensileWindow

        UnifiedTensileWindow(root).pack(fill="both", expand=True)

        def _show_root_normal() -> None:
            show_window_normally(root)

        root.after_idle(_show_root_normal)
        root.mainloop()
        return 0
    except Exception as exc:
        _show_startup_error("Error de arranque", exc)
        try:
            root.destroy()
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
