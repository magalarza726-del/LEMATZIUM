from __future__ import annotations

"""QA del modulo unificado con CSV reales.

Uso desde la raiz del proyecto:
  PYTHONPATH="modules:modules/module_1_drop1mpa:modules/module_2_offset02:modules/module_tensile_unified" \
  xvfb-run -a python3 modules/module_tensile_unified/qa_validate_real_csv.py \
    --csv /ruta/OT-4675-26.csv --csv /ruta/OT-4676-26.csv --csv /ruta/OT-4690-26.csv --csv /ruta/OT-4691-26.csv

No modifica modulo 1, modulo 2, lector CSV ni reportes Word.
"""

from argparse import ArgumentParser
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
import json
import sys
import tkinter as tk

from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset
from lematzium_tensile_unified.ui import main_window as ui_main_window
from lematzium_tensile_unified.ui.main_window import UnifiedTensileWindow
from shared.tensile_unified import TensileAnalysisConfig, analyze_curve
from shared.tensile_unified.analysis_config import METHOD_AUTO, METHOD_RP_OFFSET, METHOD_UPPER_YIELD
from shared.tensile_unified.plotting import draw_unified_tensile_curve
from matplotlib.figure import Figure


@dataclass
class MethodRun:
    active_method: str
    drop_mpa: float
    offset_percent: float
    selected_method: str
    selected_available: bool
    selected_value_mpa: float | None
    suggested_method: str | None
    confidence: str | None
    candidate_index: int | None
    global_max_index: int | None
    drop_region_is_valid: bool | None
    drop_value_mpa: float | None
    rp_available: bool | None
    reason: str
    legend_labels: list[str] = field(default_factory=list)
    line_count: int = 0
    marker_count: int = 0
    grid_x: bool = False
    grid_y: bool = False


@dataclass
class CurveQA:
    specimen_id: str
    block_id: str
    geometry_shape: str
    thickness_mm: float | None
    width_mm: float | None
    diameter_mm: float | None
    area_mm2_manual: float | None
    gauge_length_mm: float | None
    points: int
    auto: MethodRun | None = None
    upper_drops: list[MethodRun] = field(default_factory=list)
    rp_offsets: list[MethodRun] = field(default_factory=list)
    ui_selection_preserved: bool = False
    ui_no_traceback: bool = False


@dataclass
class CsvQA:
    csv_name: str
    curves_loaded: int
    curves: list[CurveQA] = field(default_factory=list)


def _none_or_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except Exception:
        return None


def _legend_labels_for(curve: Any, result: Any, active_method: str) -> tuple[list[str], int, int, bool, bool]:
    fig = Figure(figsize=(7, 4.5), dpi=100)
    ax = fig.add_subplot(111)
    draw_unified_tensile_curve(ax, curve, result, active_method=active_method, graph_config={"mode": "screen"})
    labels = list(ax.get_legend_handles_labels()[1])
    line_count = len(ax.lines)
    marker_count = len(ax.collections)
    grid_x = any(gl.get_visible() for gl in ax.get_xgridlines())
    grid_y = any(gl.get_visible() for gl in ax.get_ygridlines())
    return labels, line_count, marker_count, grid_x, grid_y


def _run_method(curve: Any, active_method: str, drop_mpa: float, offset_percent: float) -> MethodRun:
    result = analyze_curve(
        curve,
        getattr(curve, "geometry", None),
        TensileAnalysisConfig(
            active_method=active_method,
            upper_yield_drop_mpa=drop_mpa,
            offset_percent=offset_percent,
        ),
    )
    labels, lines, markers, grid_x, grid_y = _legend_labels_for(curve, result, active_method)
    selected = result.selected_result
    detection = dict(result.method_detection or {})
    return MethodRun(
        active_method=active_method,
        drop_mpa=drop_mpa,
        offset_percent=offset_percent,
        selected_method=str(getattr(selected, "method", "")),
        selected_available=bool(getattr(selected, "is_available", False)),
        selected_value_mpa=_none_or_float(getattr(selected, "value_mpa", None)),
        suggested_method=detection.get("suggested_method"),
        confidence=detection.get("confidence"),
        candidate_index=detection.get("upper_yield_candidate_index"),
        global_max_index=detection.get("global_max_index"),
        drop_region_is_valid=detection.get("drop_region_is_valid"),
        drop_value_mpa=_none_or_float(detection.get("drop_value_mpa")),
        rp_available=detection.get("rp_available"),
        reason=str(detection.get("reason", "")),
        legend_labels=labels,
        line_count=lines,
        marker_count=markers,
        grid_x=grid_x,
        grid_y=grid_y,
    )


def _assert_graph_contract(run: MethodRun) -> None:
    labels = set(run.legend_labels)
    assert "Curva esfuerzo-alargamiento" in labels, f"Falta curva en leyenda: {run.legend_labels}"
    assert run.grid_x and run.grid_y, "La cuadricula no esta activa en ambos ejes."
    method_to_draw = run.selected_method if run.active_method == METHOD_AUTO else run.active_method
    if method_to_draw == METHOD_RP_OFFSET and run.selected_available:
        rp_label = f"Rp{run.offset_percent:g}"
        assert "Recta elástica A-B" in labels, f"Falta recta A-B: {run.legend_labels}"
        assert f"Recta offset {rp_label}" in labels, f"Falta recta offset {rp_label}: {run.legend_labels}"
        assert rp_label in labels, f"Falta punto {rp_label}: {run.legend_labels}"
        assert "Máximo" in labels, f"Falta punto maximo: {run.legend_labels}"
        assert run.line_count >= 3, f"Rp requiere curva + recta A-B + offset; line_count={run.line_count}"
        assert run.marker_count >= 4, f"Rp requiere puntos A, B, Rp y maximo; marker_count={run.marker_count}"
    if method_to_draw == METHOD_UPPER_YIELD:
        assert "Recta elástica A-B" not in labels, "No deben verse rectas Rp en modo Fluencia superior."
        assert not any(str(label).startswith("Recta offset") for label in labels), "No debe verse recta offset en modo Fluencia superior."
        assert "Máximo" in labels, f"Falta punto maximo: {run.legend_labels}"
        if run.selected_available:
            assert "Fluencia superior" in labels, f"Falta punto de fluencia superior: {run.legend_labels}"


def _assert_detector_contract(auto_run: MethodRun) -> None:
    # Si el detector no valido la region de caida, no debe sugerir Fluencia superior en automatico.
    if auto_run.drop_region_is_valid is False:
        assert auto_run.suggested_method != METHOD_UPPER_YIELD, (
            "El detector sugirio Fluencia superior aunque drop_region_is_valid=False."
        )
    if auto_run.candidate_index is not None and auto_run.global_max_index is not None:
        if auto_run.candidate_index >= auto_run.global_max_index:
            assert auto_run.suggested_method != METHOD_UPPER_YIELD, (
                "El detector confundio caida post-maximo/final con Fluencia superior."
            )


def _select_curve_in_ui(window: UnifiedTensileWindow, curve_index: int) -> Any:
    assert window.dataset is not None and window.dataset.curves, "La UI no tiene dataset cargado."
    curve_index = max(0, min(curve_index, len(window.dataset.curves) - 1))
    curve = window.dataset.curves[curve_index]
    specimen_id = str(getattr(curve, "specimen_id", f"Probeta {curve_index + 1}"))
    window.specimen_var.set(specimen_id)
    window._on_specimen_selected()
    assert window.current_curve is curve, "La probeta activa de la UI no coincide con la seleccion."
    return curve


def _ui_smoke_for_curve(root: tk.Tk, window: UnifiedTensileWindow, curve_index: int) -> bool:
    before_curve = _select_curve_in_ui(window, curve_index)
    before_selection = window.specimen_var.get()

    for method_label in ("Automático", "Fluencia superior", "Rp offset"):
        window.method_var.set(method_label)
        window._on_method_changed()
        assert window.current_curve is before_curve, "Cambio de metodo cambio la probeta activa."
        assert window.specimen_var.get() == before_selection, "Cambio de metodo cambio la seleccion de probeta."
    for drop in ("0.5", "1.0", "2.0"):
        window.method_var.set("Fluencia superior")
        window.upper_yield_drop_var.set(drop)
        window.recalculate()
        assert window.current_result is not None, "Recalculo devolvio resultado nulo."
        assert window.current_curve is before_curve, "Cambio de caida cambio la probeta activa."
        assert window.specimen_var.get() == before_selection, "Cambio de caida cambio la seleccion de probeta."
    for offset in ("0.2", "0.5"):
        window.method_var.set("Rp offset")
        window.offset_percent_var.set(offset)
        window.recalculate()
        assert window.current_result is not None, "Recalculo devolvio resultado nulo."
        assert window.current_curve is before_curve, "Cambio de offset cambio la probeta activa."
        assert window.specimen_var.get() == before_selection, "Cambio de offset cambio la seleccion de probeta."
    return True


def run_qa(csv_paths: list[Path]) -> list[CsvQA]:
    # Evita cuadros modales durante QA automatizada; los resultados se validan con asserts.
    ui_main_window.show_error = lambda *args, **kwargs: None
    ui_main_window.show_warning = lambda *args, **kwargs: None
    ui_main_window.show_info = lambda *args, **kwargs: None
    results: list[CsvQA] = []

    for csv_path in csv_paths:
        root = tk.Tk()
        root.withdraw()
        window = UnifiedTensileWindow(root)
        # El contrato grafico se valida aparte con Matplotlib/Agg.
        # Para el smoke de Tkinter se evita redibujar repetidamente el canvas.
        window._draw_graph = lambda *args, **kwargs: None
        try:
            # 1. Importar CSV desde la ventana real del modulo unificado.
            window._load_csv_path(str(csv_path))
            dataset = window.dataset
            assert dataset is not None, f"La UI no cargo dataset para {csv_path.name}"
            assert len(dataset.curves) > 0, f"No se cargaron probetas en {csv_path.name}"

            # Carga independiente para confirmar lector/analyzer sin depender del estado UI.
            dataset_check = load_dataset(csv_path)
            assert len(dataset_check.curves) == len(dataset.curves), "Diferencia entre carga UI y carga directa."

            csv_result = CsvQA(csv_name=csv_path.name, curves_loaded=len(dataset.curves))
            for index, curve in enumerate(dataset.curves):
                geometry = getattr(curve, "geometry", None)
                raw_df = getattr(curve, "raw_df", None)
                curve_qa = CurveQA(
                    specimen_id=str(getattr(curve, "specimen_id", "")),
                    block_id=str(getattr(curve, "block_id", "")),
                    geometry_shape=str(getattr(geometry, "shape", "")),
                    thickness_mm=_none_or_float(getattr(geometry, "side1_mm", None)),
                    width_mm=_none_or_float(getattr(geometry, "side2_mm", None)),
                    diameter_mm=_none_or_float(getattr(geometry, "diameter_mm", None)),
                    area_mm2_manual=_none_or_float(getattr(geometry, "area_mm2_manual", None)),
                    gauge_length_mm=_none_or_float(getattr(geometry, "gauge_length_mm", None)),
                    points=int(len(raw_df)) if raw_df is not None else 0,
                )

                # 4. Metodo Automatico.
                curve_qa.auto = _run_method(curve, METHOD_AUTO, 1.0, 0.2)
                _assert_detector_contract(curve_qa.auto)
                _assert_graph_contract(curve_qa.auto)

                # 5 y 7. Forzar Fluencia superior con caidas 0.5, 1.0 y 2.0 MPa.
                for drop in (0.5, 1.0, 2.0):
                    run = _run_method(curve, METHOD_UPPER_YIELD, drop, 0.2)
                    _assert_graph_contract(run)
                    curve_qa.upper_drops.append(run)

                # 6 y 8. Forzar Rp offset con offset 0.2 y 0.5 %.
                for offset in (0.2, 0.5):
                    run = _run_method(curve, METHOD_RP_OFFSET, 1.0, offset)
                    _assert_graph_contract(run)
                    curve_qa.rp_offsets.append(run)

                # UI smoke: conserva probeta al cambiar metodo/parametros.
                curve_qa.ui_selection_preserved = _ui_smoke_for_curve(root, window, index)
                curve_qa.ui_no_traceback = True
                csv_result.curves.append(curve_qa)
            results.append(csv_result)
        finally:
            try:
                window.destroy()
            except Exception:
                pass
            try:
                root.destroy()
            except Exception:
                pass
    return results


def main(argv: list[str]) -> int:
    parser = ArgumentParser()
    parser.add_argument("--csv", action="append", required=True, help="Ruta de CSV real a validar.")
    parser.add_argument("--json-out", default="qa_artifacts/qa_modulo_unificado_csv_reales.json")
    args = parser.parse_args(argv)

    csv_paths = [Path(item).resolve() for item in args.csv]
    for csv_path in csv_paths:
        if not csv_path.exists():
            raise FileNotFoundError(csv_path)
    results = run_qa(csv_paths)
    output = Path(args.json_out)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps([asdict(item) for item in results], ensure_ascii=False, indent=2), encoding="utf-8")
    total_curves = sum(item.curves_loaded for item in results)
    print(f"QA OK - CSV validados: {len(results)}; probetas: {total_curves}; salida: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
