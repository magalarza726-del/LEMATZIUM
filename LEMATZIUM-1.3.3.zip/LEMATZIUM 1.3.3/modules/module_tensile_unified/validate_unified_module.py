from __future__ import annotations

"""Validacion minima del modulo unificado de traccion.

Este script no modifica archivos. Debe ejecutarse desde la raiz del proyecto o
con este archivo como ruta. Valida importaciones y, si existen los CSV de prueba
en /mnt/data o en la raiz del proyecto, intenta cargar y analizar las curvas.
"""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
MODULES_DIR = ROOT / "modules"
for path in (
    MODULES_DIR,
    MODULES_DIR / "module_tensile_unified",
    MODULES_DIR / "module_1_drop1mpa",
    MODULES_DIR / "module_2_offset02",
):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from shared.tensile_unified import METHOD_AUTO, TensileAnalysisConfig, analyze_curve, get_default_comment  # noqa: E402
from lematzium_modulo1.assays.tensile_drop_1mpa.reader import load_dataset  # noqa: E402


def _candidate_csvs() -> list[Path]:
    names = ["OT-4675-26.csv", "OT-4676-26.csv", "OT-4690-26.csv", "OT-4691-26.csv"]
    roots = [ROOT, ROOT.parent, Path("/mnt/data")]
    found: list[Path] = []
    for name in names:
        for root in roots:
            path = root / name
            if path.exists():
                found.append(path)
                break
    return found


def main() -> int:
    config = TensileAnalysisConfig(active_method=METHOD_AUTO, upper_yield_drop_mpa=1.0, offset_percent=0.2)
    csvs = _candidate_csvs()
    if not csvs:
        print("OK - modulo unificado importa correctamente. No se encontraron CSV de prueba.")
        return 0
    for csv_path in csvs:
        dataset = load_dataset(csv_path)
        if not dataset.curves:
            raise AssertionError(f"No se cargaron curvas desde {csv_path}")
        result = analyze_curve(dataset.curves[0], dataset.curves[0].geometry, config)
        comment = get_default_comment(dataset.curves[0].geometry.shape, result.selected_result.method, {"offset_percent": "0.2"})
        print(csv_path.name, "curvas=", len(dataset.curves), "metodo=", result.selected_result.method, "comentario=", bool(comment))
    print("OK - modulo unificado validado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
