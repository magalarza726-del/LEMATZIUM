from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lematzium_ai_assistant.knowledge import LematZiumKnowledgeBase


def main() -> int:
    kb = LematZiumKnowledgeBase()
    hits = kb.search("Como se calcula paso a paso el punto de fluencia en el modulo de Metales?", max_results=10)
    paths = [hit.chunk.path for hit in hits]
    if not any("GUIA_TECNICA_CALCULO_FLUENCIA_METALES" in path for path in paths[:5]):
        raise SystemExit("No se priorizó la guía técnica de fluencia de metales.")
    if not any("tensile_drop_1mpa/detection.py" in path for path in paths[:10]):
        raise SystemExit("No se recuperó el código detector de fluencia de metales.")
    print("OK: recuperación profunda de fluencia metales")
    for hit in hits[:5]:
        print(f"- {hit.chunk.kind}: {hit.chunk.path}:{hit.chunk.start_line}-{hit.chunk.end_line}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
