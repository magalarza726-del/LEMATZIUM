from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from lematzium_ai_assistant.knowledge import LematZiumKnowledgeBase


def main() -> int:
    kb = LematZiumKnowledgeBase()
    hits = kb.search("autoexportación reporte Word metales", max_results=5)
    if not hits:
        raise SystemExit("No se recuperó evidencia para autoexportación.")
    print(f"OK: {kb.stats.display()} · {len(hits)} hallazgos")
    for hit in hits[:3]:
        print(f"- {hit.chunk.kind}: {hit.chunk.path}:{hit.chunk.start_line}-{hit.chunk.end_line}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
