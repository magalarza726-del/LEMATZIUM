from __future__ import annotations

from lematzium_ai_assistant.client import ChatTurn, build_prompt
from lematzium_ai_assistant.settings import AssistantSettings


def test_prompt_includes_assistant_name_and_history() -> None:
    settings = AssistantSettings(assistant_name="Asistente LEMAT", api_key="x")
    prompt = build_prompt([ChatTurn("user", "Hola")], "¿Qué puedes hacer?", settings, "[Fuente 1] Manual", [])
    assert "Asistente LEMAT" in prompt
    assert "Usuario: Hola" in prompt
    assert "¿Qué puedes hacer?" in prompt
