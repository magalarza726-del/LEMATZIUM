from __future__ import annotations

from pathlib import Path
import py_compile

ROOT = Path(__file__).resolve().parent
TARGETS = [
    ROOT / "launch_ai_assistant.py",
    ROOT / "lematzium_ai_assistant" / "settings.py",
    ROOT / "lematzium_ai_assistant" / "client.py",
    ROOT / "lematzium_ai_assistant" / "knowledge.py",
    ROOT / "lematzium_ai_assistant" / "conversations.py",
    ROOT / "lematzium_ai_assistant" / "audio_live.py",
    ROOT / "lematzium_ai_assistant" / "ui.py",
]


def main() -> int:
    for target in TARGETS:
        py_compile.compile(str(target), doraise=True)
        print(f"OK: {target.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
