# Módulo 3 - Asistente experto LEMATZIUM

Módulo conversacional integrado a LEMATZIUM 1.3.3 para interactuar con modelos de escritura de Gemini API / Gemma y con modelos Live API de audio, apoyado por una base de conocimiento interna del programa.

## Configuración desde el HUB

En **Configuración > Asistente virtual IA** se ajusta:

- Nombre visible del asistente.
- Modelo de escritura: `Gemini 3.1 Flash Lite` o `Gemma 4 31B`.
- Modo Gemma 4: `Thinking` o `No thinking`.
- Perfil de respuesta: `Auditoría estricta`, `Capacitación` o `Soporte técnico`.
- API key de Google AI.
- Modelo de audio: `Gemini 3.1 Flash Live` o `Gemini 2.5 Flash Native Audio Dialog`.

## Base de conocimiento experta

El asistente indexa localmente:

- Manual de uso de LEMATZIUM incorporado en `docs/knowledge/`.
- Documentación `.md` y `.txt` del proyecto.
- Código Python del launcher y de los módulos.
- Configuraciones JSON relevantes.

En cada pregunta textual se recuperan fragmentos relevantes antes de consultar el modelo. En audio, la sesión Live API dispone de la herramienta local `buscar_conocimiento_lematzium`, que el modelo debe invocar para preguntas sobre funcionamiento, auditoría, capacitación, código o reportes.

El botón **Actualizar conocimiento** vuelve a escanear los archivos del paquete sin reiniciar el módulo.

## Modos de respuesta

- **Auditoría estricta:** responde solo con evidencia interna recuperada y marca los vacíos documentales.
- **Capacitación:** explica de forma pedagógica, como instructor interno del programa.
- **Soporte técnico:** prioriza diagnóstico operativo y trazabilidad entre manual/código.

## Modelos mapeados

- `Gemini 3.1 Flash Lite` → `gemini-3.1-flash-lite`.
- `Gemma 4 31B` → `gemma-4-31b-it`.
- `Gemini 3.1 Flash Live` → `gemini-3.1-flash-live-preview`.
- `Gemini 2.5 Flash Native Audio Dialog` → `gemini-2.5-flash-native-audio-preview-12-2025`.

## Gemma 4 Thinking

Cuando se selecciona **Thinking**, las llamadas a Gemma 4 31B se realizan con `thinking_level="high"`. En **No thinking**, el módulo no envía esa configuración de pensamiento para Gemma 4.

## Funcionalidades

- Interfaz tipo chat moderno, con mensajes visualmente diferenciados entre usuario, asistente, audio y sistema.
- Panel lateral de conversaciones guardadas, con recuperación de sesiones previas.
- Memoria persistente por conversación en `config/assistant_conversations.json`.
- Chat textual multi-turno por sesión.
- Respuestas más guiadas: ruta de uso, pasos, verificaciones, advertencias y límites de evidencia según el modo activo.
- Recuperación local de evidencia del manual, documentación y código.
- Evidencia consultada mostrada después de cada respuesta textual.
- Botón **Nueva conversación**.
- Botón **Copiar última respuesta**.
- Botón **Actualizar conocimiento**.
- Cambio automático a modelo de escritura alternativo cuando el modelo activo queda sin cuota o temporalmente no disponible.
- Aviso visible al usuario cuando se produce el cambio automático.
- Botón **🎙 Iniciar audio** para abrir una sesión Live API.
- Audio con tool calling a la base de conocimiento interna.
- Transcripción visible del audio del usuario y de la respuesta del asistente.
- Reproducción de audio de respuesta.

## Dependencias

- `google-genai`
- `sounddevice`

El HUB puede proponer la instalación automática cuando falta la dependencia principal. Si el chat textual abre, pero el audio no inicia, instalar manualmente:

```bash
pip install sounddevice
```


## Mejoras de conversación y profundidad técnica
- El chat adopta una interfaz tipo mensajería: burbujas diferenciadas para usuario y asistente.
- Cada mensaje se puede copiar; los mensajes del usuario pueden editarse desde el propio historial.
- Enter envía el mensaje y Shift+Enter inserta salto de línea.
- Las consultas de cálculo o algoritmo activan recuperación ampliada de código y documentación técnica.
- El asistente dispone de una guía técnica interna específica para explicar, paso a paso, el cálculo de fluencia superior del Módulo 1 de Metales.
