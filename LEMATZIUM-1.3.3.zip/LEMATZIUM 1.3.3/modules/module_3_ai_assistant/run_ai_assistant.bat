@echo off
setlocal
cd /d "%~dp0"
python launch_ai_assistant.py
endlocal
