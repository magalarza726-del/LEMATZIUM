from __future__ import annotations

from lematzium_ai_assistant.ui import main


if __name__ == "__main__":
    raise SystemExit(main())
