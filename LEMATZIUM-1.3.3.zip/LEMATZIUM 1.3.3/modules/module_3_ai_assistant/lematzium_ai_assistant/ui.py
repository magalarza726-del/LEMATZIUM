from __future__ import annotations

import queue
import re
import threading
from dataclasses import replace
import os
import subprocess
import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk
from typing import Any

try:
    from shared.runtime_theme import load_runtime_theme
except Exception:  # pragma: no cover - ejecución directa fuera del HUB
    def load_runtime_theme(default: str = "Azul eléctrico") -> dict[str, str]:
        return {
            "name": default,
            "bg": "#041321",
            "panel": "#0b2138",
            "accent": "#4fb8ff",
            "accent_soft": "#66d9ff",
            "text": "#eaf8ff",
            "text_soft": "#bfe4ff",
            "field_bg": "#102c47",
            "field_text": "#eaf8ff",
        }

from .audio_live import AudioUiEvent, LiveAudioController
from .client import ChatReply, ChatTurn, GeminiApiError, GeminiChatBackend
from .conversations import ConversationRecord, ConversationStore
from .knowledge import LematZiumKnowledgeBase
from .settings import (
    AUDIO_VOICE_FILTER_LABELS,
    AUDIO_VOICE_FILTER_PRESETS,
    AUDIO_VOICE_NAMES,
    AUDIO_VOICE_STYLES,
    AssistantSettings,
    load_assistant_settings,
    save_assistant_preference,
)


class AssistantWindow:
    """Ventana del asistente IA con interfaz de conversación persistente.

    Diseño operativo:
    - Columna izquierda: conversaciones guardadas y acciones de sesión.
    - Columna central: chat tipo mensajería, con burbujas de usuario a la derecha y asistente a la izquierda.
    - Cada mensaje puede copiarse; los mensajes del usuario pueden editarse desde la misma conversación.
    - Compositor inferior: campo de texto y controles sin desbordes verticales.
    - Historial persistente: cada conversación se conserva en config/assistant_conversations.json.
    """

    SIDEBAR_WIDTH = 286

    def __init__(self, master: tk.Misc | None = None, *, embedded: bool = False) -> None:
        self.embedded = bool(embedded)
        self.settings: AssistantSettings = load_assistant_settings()
        self.theme = load_runtime_theme()
        self.knowledge_base = LematZiumKnowledgeBase()
        self.backend = GeminiChatBackend(self.settings, self.knowledge_base)
        self.conversation_store = ConversationStore()
        self.current_conversation: ConversationRecord | None = None
        self.history: list[ChatTurn] = []
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.request_in_progress = False
        self.last_assistant_response = ""
        self.audio_controller = LiveAudioController(self.settings, self._queue_audio_event, self.knowledge_base)
        self._conversation_ids: list[str] = []
        self._message_labels: list[tk.Label] = []
        self._chat_window_id: int | None = None

        if self.embedded:
            if master is None:
                raise ValueError("El modo embebido requiere un contenedor maestro.")
            try:
                master.grid_rowconfigure(0, weight=1)
                master.grid_columnconfigure(0, weight=1)
            except Exception:
                pass
            self.root = tk.Frame(master, bg=self.theme["bg"])
            self.root.grid(row=0, column=0, sticky="nsew")
        else:
            self.root = tk.Tk()
            self.root.title(f"Módulo 3 - {self.settings.assistant_name}")
            self.root.geometry("1320x860")
            self.root.minsize(1060, 700)
            self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.configure(bg=self.theme["bg"])

        self.style = ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass
        self._configure_style()

        self.status_var = tk.StringVar(
            value=f"Listo. Base de conocimiento: {self.knowledge_base.stats.display()}."
        )
        self.subtitle_var = tk.StringVar(value=self._subtitle_text())
        self.conversation_info_var = tk.StringVar(value="Nueva conversación · sin guardar hasta el primer mensaje")

        self._build_ui()
        self._refresh_conversation_list()
        self.start_new_conversation(initial=True)
        self.root.after(120, self._poll_events)

    # ------------------------------------------------------------------
    # Configuración visual
    # ------------------------------------------------------------------
    def _subtitle_text(self) -> str:
        return (
            f"Escritura: {self.settings.text_model_label} · Gemma: {self.settings.gemma_thinking_mode} · "
            f"Modo: {self.settings.response_mode} · Audio: {self.settings.audio_model_label} · "
            f"Voz: {self.settings.audio_voice_name} · Timbre: {self.settings.audio_voice_filter_label} · "
            f"Conocimiento: {self.knowledge_base.stats.display()}"
        )

    @staticmethod
    def _voice_display_value(voice_name: str) -> str:
        style = AUDIO_VOICE_STYLES.get(str(voice_name or "").strip(), "")
        return f"{voice_name} · {style}" if style else str(voice_name or "")

    @classmethod
    def _voice_display_values(cls) -> tuple[str, ...]:
        return tuple(cls._voice_display_value(name) for name in AUDIO_VOICE_NAMES)

    @staticmethod
    def _voice_name_from_display(display_value: str) -> str:
        return str(display_value or "").split(" · ", 1)[0].strip()

    @staticmethod
    def _voice_filter_display_value(filter_label: str) -> str:
        config = AUDIO_VOICE_FILTER_PRESETS.get(str(filter_label or "").strip(), {})
        description = str(config.get("description", "") or "").strip()
        return f"{filter_label} · {description}" if description else str(filter_label or "")

    @classmethod
    def _voice_filter_display_values(cls) -> tuple[str, ...]:
        return tuple(cls._voice_filter_display_value(label) for label in AUDIO_VOICE_FILTER_LABELS)

    @staticmethod
    def _voice_filter_label_from_display(display_value: str) -> str:
        return str(display_value or "").split(" · ", 1)[0].strip()

    def _on_voice_selected(self, _event: tk.Event | None = None) -> None:
        selected = self._voice_name_from_display(self.voice_var.get())
        if selected not in AUDIO_VOICE_NAMES:
            self.voice_var.set(self._voice_display_value(self.settings.audio_voice_name))
            return
        if self.audio_controller.is_running:
            self.voice_var.set(self._voice_display_value(self.settings.audio_voice_name))
            self.status_var.set("Detén la sesión de audio antes de cambiar la voz.")
            self._append_system_message("Para cambiar la voz de LEMATRÓN, primero detén la sesión de audio activa.")
            return
        if selected == self.settings.audio_voice_name:
            return
        self.settings = replace(self.settings, audio_voice_name=selected)
        self.audio_controller = LiveAudioController(self.settings, self._queue_audio_event, self.knowledge_base)
        save_assistant_preference("assistant_audio_voice", selected)
        navigation_host = getattr(self, "lematzium_navigation_host", None)
        try:
            if navigation_host is not None and hasattr(navigation_host, "assistant_audio_voice"):
                navigation_host.assistant_audio_voice.set(selected)
        except Exception:
            pass
        self.subtitle_var.set(self._subtitle_text())
        self.voice_status_var.set(f"Voz activa: {self._voice_display_value(selected)}")
        self.status_var.set(f"Voz de LEMATRÓN actualizada a {selected}.")
        self._append_system_message(f"Voz de LEMATRÓN seleccionada: {self._voice_display_value(selected)}.")

    def _on_voice_filter_selected(self, _event: tk.Event | None = None) -> None:
        selected = self._voice_filter_label_from_display(self.voice_filter_var.get())
        if selected not in AUDIO_VOICE_FILTER_LABELS:
            self.voice_filter_var.set(self._voice_filter_display_value(self.settings.audio_voice_filter_label))
            return
        if self.audio_controller.is_running:
            self.voice_filter_var.set(self._voice_filter_display_value(self.settings.audio_voice_filter_label))
            self.status_var.set("Detén la sesión de audio antes de cambiar el timbre de salida.")
            self._append_system_message("Para cambiar el filtro vocal de LEMATRÓN, primero detén la sesión de audio activa.")
            return
        if selected == self.settings.audio_voice_filter_label:
            return
        self.settings = replace(self.settings, audio_voice_filter_label=selected)
        self.audio_controller = LiveAudioController(self.settings, self._queue_audio_event, self.knowledge_base)
        save_assistant_preference("assistant_audio_voice_filter", selected)
        navigation_host = getattr(self, "lematzium_navigation_host", None)
        try:
            if navigation_host is not None and hasattr(navigation_host, "assistant_audio_voice_filter"):
                navigation_host.assistant_audio_voice_filter.set(selected)
        except Exception:
            pass
        self.subtitle_var.set(self._subtitle_text())
        self.voice_filter_status_var.set(f"Timbre activo: {self._voice_filter_display_value(selected)}")
        self.status_var.set(f"Filtro vocal de LEMATRÓN actualizado: {selected}.")
        self._append_system_message(f"Filtro vocal de LEMATRÓN seleccionado: {self._voice_filter_display_value(selected)}.")

    def _configure_style(self) -> None:
        self.style.configure(
            "AI.TButton",
            background=self.theme["accent"],
            foreground="#00111e",
            borderwidth=0,
            focusthickness=0,
            padding=(14, 9),
            font=("Segoe UI Semibold", 10),
        )
        self.style.map(
            "AI.TButton",
            background=[("active", self.theme["accent_soft"]), ("disabled", self.theme["panel"])],
            foreground=[("disabled", self.theme["text_soft"])],
        )
        self.style.configure(
            "AI.Secondary.TButton",
            background=self.theme["panel"],
            foreground=self.theme["text"],
            borderwidth=1,
            focusthickness=0,
            padding=(12, 8),
            font=("Segoe UI", 10),
        )
        self.style.map(
            "AI.Secondary.TButton",
            background=[("active", self.theme["field_bg"]), ("disabled", self.theme["panel"])],
            foreground=[("disabled", self.theme["text_soft"])],
        )
        self.style.configure(
            "AI.Audio.TButton",
            background=self.theme["accent_soft"],
            foreground="#00111e",
            borderwidth=0,
            focusthickness=0,
            padding=(12, 8),
            font=("Segoe UI Semibold", 10),
        )
        self.style.map(
            "AI.Audio.TButton",
            background=[("active", self.theme["accent"]), ("disabled", self.theme["panel"])],
            foreground=[("disabled", self.theme["text_soft"])],
        )
        self.style.configure(
            "AI.Danger.TButton",
            background="#381722",
            foreground="#ffd8de",
            borderwidth=1,
            focusthickness=0,
            padding=(12, 8),
            font=("Segoe UI", 10),
        )
        self.style.map(
            "AI.Danger.TButton",
            background=[("active", "#542130")],
        )
        self.style.configure(
            "AI.Voice.TCombobox",
            fieldbackground=self.theme["field_bg"],
            background=self.theme["field_bg"],
            foreground=self.theme["field_text"],
            arrowcolor=self.theme["accent_soft"],
            bordercolor=self.theme["accent"],
            lightcolor=self.theme["accent"],
            darkcolor=self.theme["accent"],
            padding=5,
        )
        self.style.map(
            "AI.Voice.TCombobox",
            fieldbackground=[("readonly", self.theme["field_bg"])],
            foreground=[("readonly", self.theme["field_text"])],
            selectbackground=[("readonly", self.theme["panel"])],
            selectforeground=[("readonly", self.theme["field_text"])],
        )

    def _build_ui(self) -> None:
        outer = tk.Frame(self.root, bg=self.theme["bg"], padx=20, pady=18)
        outer.pack(fill="both", expand=True)
        outer.grid_columnconfigure(0, weight=1)
        outer.grid_rowconfigure(1, weight=1)

        # Encabezado superior.
        header = tk.Frame(outer, bg=self.theme["bg"])
        header.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        title = tk.Label(
            header,
            text=f"{self.settings.assistant_name} · Asistente experto LEMATZIUM",
            bg=self.theme["bg"],
            fg=self.theme["text"],
            font=("Segoe UI Semibold", 22),
            anchor="w",
        )
        title.pack(fill="x")
        subtitle = tk.Label(
            header,
            textvariable=self.subtitle_var,
            bg=self.theme["bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 10),
            anchor="w",
        )
        subtitle.pack(fill="x", pady=(5, 0))

        # Cuerpo: historial lateral + panel de chat.
        body = tk.Frame(outer, bg=self.theme["bg"])
        body.grid(row=1, column=0, sticky="nsew")
        body.grid_columnconfigure(0, minsize=self.SIDEBAR_WIDTH, weight=0)
        body.grid_columnconfigure(1, weight=1)
        body.grid_rowconfigure(0, weight=1)

        self._build_sidebar(body)
        self._build_main_chat_area(body)

    def _build_sidebar(self, body: tk.Frame) -> None:
        sidebar = tk.Frame(
            body,
            bg=self.theme["panel"],
            width=self.SIDEBAR_WIDTH,
            highlightthickness=1,
            highlightbackground=self.theme["accent"],
            padx=14,
            pady=14,
        )
        sidebar.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        sidebar.grid_propagate(False)
        sidebar.grid_columnconfigure(0, weight=1)
        sidebar.grid_rowconfigure(4, weight=1)

        label = tk.Label(
            sidebar,
            text="Conversaciones",
            bg=self.theme["panel"],
            fg=self.theme["text"],
            font=("Segoe UI Semibold", 14),
            anchor="w",
        )
        label.grid(row=0, column=0, sticky="ew")

        description = tk.Label(
            sidebar,
            text="Memoria persistente por sesión. Abre una conversación previa para continuarla.",
            bg=self.theme["panel"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 9),
            justify="left",
            wraplength=self.SIDEBAR_WIDTH - 34,
            anchor="w",
        )
        description.grid(row=1, column=0, sticky="ew", pady=(6, 12))

        self.new_chat_button = ttk.Button(
            sidebar,
            text="＋ Nueva conversación",
            command=self.start_new_conversation,
            style="AI.TButton",
        )
        self.new_chat_button.grid(row=2, column=0, sticky="ew", pady=(0, 10))

        conversation_caption = tk.Label(
            sidebar,
            text="Historial guardado",
            bg=self.theme["panel"],
            fg=self.theme["text_soft"],
            font=("Segoe UI Semibold", 9),
            anchor="w",
        )
        conversation_caption.grid(row=3, column=0, sticky="ew", pady=(0, 5))

        list_frame = tk.Frame(sidebar, bg=self.theme["panel"])
        list_frame.grid(row=4, column=0, sticky="nsew")
        list_frame.grid_columnconfigure(0, weight=1)
        list_frame.grid_rowconfigure(0, weight=1)

        self.conversation_listbox = tk.Listbox(
            list_frame,
            bg=self.theme["field_bg"],
            fg=self.theme["field_text"],
            selectbackground=self.theme["accent"],
            selectforeground="#00111e",
            bd=0,
            highlightthickness=1,
            highlightbackground=self.theme["accent"],
            activestyle="none",
            font=("Segoe UI", 10),
            exportselection=False,
        )
        self.conversation_listbox.grid(row=0, column=0, sticky="nsew")
        self.conversation_listbox.bind("<<ListboxSelect>>", self._on_conversation_selected)
        conv_scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.conversation_listbox.yview)
        conv_scroll.grid(row=0, column=1, sticky="ns")
        self.conversation_listbox.configure(yscrollcommand=conv_scroll.set)

        actions = tk.Frame(sidebar, bg=self.theme["panel"])
        actions.grid(row=5, column=0, sticky="ew", pady=(10, 0))
        actions.grid_columnconfigure(0, weight=1)
        actions.grid_columnconfigure(1, weight=1)
        self.delete_chat_button = ttk.Button(
            actions,
            text="Eliminar",
            command=self.delete_selected_conversation,
            style="AI.Danger.TButton",
        )
        self.delete_chat_button.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.copy_button = ttk.Button(
            actions,
            text="Copiar última",
            command=self.copy_last_response,
            style="AI.Secondary.TButton",
        )
        self.copy_button.grid(row=0, column=1, sticky="ew", padx=(6, 0))

    def _build_main_chat_area(self, body: tk.Frame) -> None:
        main = tk.Frame(body, bg=self.theme["bg"])
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)

        info_bar = tk.Frame(main, bg=self.theme["panel"], highlightthickness=1, highlightbackground=self.theme["accent"])
        info_bar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        info_bar.grid_columnconfigure(0, weight=1)
        info_label = tk.Label(
            info_bar,
            textvariable=self.conversation_info_var,
            bg=self.theme["panel"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 10),
            padx=12,
            pady=8,
            anchor="w",
        )
        info_label.grid(row=0, column=0, sticky="ew")

        chat_panel = tk.Frame(main, bg=self.theme["panel"], highlightthickness=1, highlightbackground=self.theme["accent"])
        chat_panel.grid(row=1, column=0, sticky="nsew")
        chat_panel.grid_columnconfigure(0, weight=1)
        chat_panel.grid_rowconfigure(0, weight=1)

        self.chat_canvas = tk.Canvas(
            chat_panel,
            bg="#0b141a",
            highlightthickness=0,
            bd=0,
        )
        self.chat_canvas.grid(row=0, column=0, sticky="nsew")
        chat_scroll = ttk.Scrollbar(chat_panel, orient="vertical", command=self.chat_canvas.yview)
        chat_scroll.grid(row=0, column=1, sticky="ns")
        self.chat_canvas.configure(yscrollcommand=chat_scroll.set)

        self.chat_inner = tk.Frame(self.chat_canvas, bg="#0b141a", padx=18, pady=18)
        self._chat_window_id = self.chat_canvas.create_window((0, 0), window=self.chat_inner, anchor="nw")
        self.chat_inner.bind("<Configure>", self._on_chat_inner_configure)
        self.chat_canvas.bind("<Configure>", self._on_chat_canvas_configure)
        self.chat_canvas.bind_all("<MouseWheel>", self._on_mousewheel)

        self._build_composer(main)
        self._build_status(main)

    def _build_composer(self, main: tk.Frame) -> None:
        composer = tk.Frame(
            main,
            bg=self.theme["bg"],
            pady=12,
        )
        composer.grid(row=2, column=0, sticky="ew")
        composer.grid_columnconfigure(0, weight=1)

        input_frame = tk.Frame(
            composer,
            bg=self.theme["field_bg"],
            highlightthickness=1,
            highlightbackground=self.theme["accent"],
            padx=12,
            pady=10,
        )
        input_frame.grid(row=0, column=0, sticky="ew")
        input_frame.grid_columnconfigure(0, weight=1)
        input_frame.grid_rowconfigure(0, weight=1)

        self.input_text = tk.Text(
            input_frame,
            height=4,
            wrap="word",
            bg=self.theme["field_bg"],
            fg=self.theme["field_text"],
            insertbackground=self.theme["field_text"],
            bd=0,
            relief="flat",
            padx=2,
            pady=2,
            font=("Segoe UI", 11),
            undo=True,
        )
        self.input_text.grid(row=0, column=0, sticky="ew")
        self.input_text.bind("<Return>", self._send_on_enter)
        self.input_text.bind("<Shift-Return>", lambda _e: None)
        self.input_text.bind("<Control-Return>", lambda _e: self.send_message())

        toolbar = tk.Frame(input_frame, bg=self.theme["field_bg"])
        toolbar.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        toolbar.grid_columnconfigure(5, weight=1)

        self.mic_button = ttk.Button(
            toolbar,
            text="🎙 Iniciar audio",
            command=self.toggle_audio_chat,
            style="AI.Audio.TButton",
        )
        self.mic_button.grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.mic_mute_button = ttk.Button(
            toolbar,
            text="🔇 Silenciar micrófono",
            command=self.toggle_microphone_mute,
            style="AI.Secondary.TButton",
            state="disabled",
        )
        self.mic_mute_button.grid(row=0, column=1, sticky="w", padx=(0, 8))
        self.refresh_knowledge_button = ttk.Button(
            toolbar,
            text="Actualizar conocimiento",
            command=self.refresh_knowledge,
            style="AI.Secondary.TButton",
        )
        self.refresh_knowledge_button.grid(row=0, column=2, sticky="w", padx=(0, 8))
        self.copy_toolbar_button = ttk.Button(
            toolbar,
            text="Copiar última respuesta",
            command=self.copy_last_response,
            style="AI.Secondary.TButton",
        )
        self.copy_toolbar_button.grid(row=0, column=3, sticky="w", padx=(0, 8))

        shortcut = tk.Label(
            toolbar,
            text="Enter: enviar · Shift + Enter: salto de línea",
            bg=self.theme["field_bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 9),
            anchor="w",
        )
        shortcut.grid(row=0, column=5, sticky="w")

        self.send_button = ttk.Button(toolbar, text="Enviar", command=self.send_message, style="AI.TButton")
        self.send_button.grid(row=0, column=6, sticky="e")

        voice_row = tk.Frame(input_frame, bg=self.theme["field_bg"])
        voice_row.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        voice_row.grid_columnconfigure(2, weight=1)
        tk.Label(
            voice_row,
            text="Voz de LEMATRÓN:",
            bg=self.theme["field_bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI Semibold", 9),
            anchor="w",
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.voice_var = tk.StringVar(value=self._voice_display_value(self.settings.audio_voice_name))
        self.voice_combo = ttk.Combobox(
            voice_row,
            values=self._voice_display_values(),
            textvariable=self.voice_var,
            state="readonly",
            width=32,
            style="AI.Voice.TCombobox",
        )
        self.voice_combo.grid(row=0, column=1, sticky="w", padx=(0, 12))
        self.voice_combo.bind("<<ComboboxSelected>>", self._on_voice_selected)
        self.voice_status_var = tk.StringVar(value=f"Voz activa: {self._voice_display_value(self.settings.audio_voice_name)}")
        tk.Label(
            voice_row,
            textvariable=self.voice_status_var,
            bg=self.theme["field_bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 9),
            anchor="w",
        ).grid(row=0, column=2, sticky="ew")

        filter_row = tk.Frame(input_frame, bg=self.theme["field_bg"])
        filter_row.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        filter_row.grid_columnconfigure(2, weight=1)
        tk.Label(
            filter_row,
            text="Timbre LEMATRÓN:",
            bg=self.theme["field_bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI Semibold", 9),
            anchor="w",
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.voice_filter_var = tk.StringVar(value=self._voice_filter_display_value(self.settings.audio_voice_filter_label))
        self.voice_filter_combo = ttk.Combobox(
            filter_row,
            values=self._voice_filter_display_values(),
            textvariable=self.voice_filter_var,
            state="readonly",
            width=42,
            style="AI.Voice.TCombobox",
        )
        self.voice_filter_combo.grid(row=0, column=1, sticky="w", padx=(0, 12))
        self.voice_filter_combo.bind("<<ComboboxSelected>>", self._on_voice_filter_selected)
        self.voice_filter_status_var = tk.StringVar(value=f"Timbre activo: {self._voice_filter_display_value(self.settings.audio_voice_filter_label)}")
        tk.Label(
            filter_row,
            textvariable=self.voice_filter_status_var,
            bg=self.theme["field_bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 9),
            anchor="w",
        ).grid(row=0, column=2, sticky="ew")

    def _send_on_enter(self, event: tk.Event) -> str | None:
        """Comportamiento tipo mensajería: Enter envía, Shift+Enter conserva salto de línea."""
        if event.state & 0x0001:  # Shift presionado
            return None
        return self.send_message()

    def _build_status(self, main: tk.Frame) -> None:
        footer = tk.Frame(main, bg=self.theme["bg"])
        footer.grid(row=3, column=0, sticky="ew")
        status = tk.Label(
            footer,
            textvariable=self.status_var,
            bg=self.theme["bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 10),
            anchor="w",
        )
        status.pack(fill="x")
        hint = tk.Label(
            footer,
            text=(
                "El asistente consulta manual, documentación y código. En modo auditoría prioriza trazabilidad; "
                "en capacitación guía al usuario paso a paso."
            ),
            bg=self.theme["bg"],
            fg=self.theme["text_soft"],
            font=("Segoe UI", 9),
            anchor="w",
        )
        hint.pack(fill="x", pady=(4, 0))

    # ------------------------------------------------------------------
    # Chat visual
    # ------------------------------------------------------------------
    @staticmethod
    def _display_text(text: str) -> str:
        """Limpieza visual ligera de Markdown cuando la UI no lo renderiza."""
        visible = str(text or "").strip()
        visible = re.sub(r"(?m)^\s{0,3}#{1,6}\s+", "", visible)
        visible = visible.replace("**", "").replace("__", "")
        return visible

    def _message_wraplength(self) -> int:
        canvas_width = max(self.chat_canvas.winfo_width(), 720)
        return max(420, min(canvas_width - 160, 900))

    def _append_card(
        self,
        role: str,
        header: str,
        body: str,
        *,
        modality: str = "text",
        turn_index: int | None = None,
        source_labels: tuple[str, ...] | None = None,
    ) -> None:
        body = self._display_text(body) or "(sin contenido)"
        row = tk.Frame(self.chat_inner, bg="#0b141a")
        row.pack(fill="x", pady=(0, 10))

        if role == "user":
            side = "right"
            bubble_bg = "#005c4b"
            border = "#1a8f78"
            header_fg = "#d9fdd3"
            body_fg = "#f2fff9"
            max_width_pad = (170, 6)
        elif role == "assistant":
            side = "left"
            bubble_bg = "#202c33"
            border = "#31424d"
            header_fg = self.theme["accent_soft"]
            body_fg = "#eef5f7"
            max_width_pad = (6, 170)
        elif role == "error":
            side = "left"
            bubble_bg = "#401c24"
            border = "#ffb1b1"
            header_fg = "#ffb1b1"
            body_fg = "#ffd8de"
            max_width_pad = (6, 170)
        else:
            side = "left"
            bubble_bg = "#182229"
            border = "#31424d"
            header_fg = self.theme["text_soft"]
            body_fg = self.theme["text_soft"]
            max_width_pad = (6, 170)

        spacer_left = tk.Frame(row, bg="#0b141a", width=max_width_pad[0])
        spacer_right = tk.Frame(row, bg="#0b141a", width=max_width_pad[1])
        if side == "right":
            spacer_left.pack(side="left", fill="x", expand=True)
        bubble = tk.Frame(
            row,
            bg=bubble_bg,
            highlightthickness=1,
            highlightbackground=border,
            padx=12,
            pady=9,
        )
        bubble.pack(side=side, fill="x", expand=False)
        if side == "left":
            spacer_right.pack(side="left", fill="x", expand=True)

        suffix = " · audio" if modality == "audio" else ""
        header_label = tk.Label(
            bubble,
            text=f"{header}{suffix}",
            bg=bubble_bg,
            fg=header_fg,
            font=("Segoe UI Semibold", 9),
            anchor="w",
            justify="left",
        )
        header_label.pack(fill="x", pady=(0, 4))

        body_label = tk.Label(
            bubble,
            text=body,
            bg=bubble_bg,
            fg=body_fg,
            font=("Segoe UI", 11 if role in {"user", "assistant"} else 10),
            justify="left",
            anchor="w",
            wraplength=self._message_wraplength(),
        )
        body_label.pack(fill="x")
        self._message_labels.append(body_label)

        actions = tk.Frame(bubble, bg=bubble_bg)
        actions.pack(fill="x", pady=(6, 0))
        copy_btn = tk.Button(
            actions,
            text="Copiar",
            command=lambda text=body: self.copy_message_text(text),
            bg=bubble_bg,
            fg=header_fg,
            activebackground=bubble_bg,
            activeforeground=body_fg,
            relief="flat",
            bd=0,
            padx=0,
            pady=0,
            cursor="hand2",
            font=("Segoe UI", 8, "underline"),
        )
        copy_btn.pack(side="left")
        if role == "user" and turn_index is not None:
            edit_btn = tk.Button(
                actions,
                text="Editar",
                command=lambda idx=turn_index: self.edit_user_message(idx),
                bg=bubble_bg,
                fg=header_fg,
                activebackground=bubble_bg,
                activeforeground=body_fg,
                relief="flat",
                bd=0,
                padx=10,
                pady=0,
                cursor="hand2",
                font=("Segoe UI", 8, "underline"),
            )
            edit_btn.pack(side="left")
        if source_labels:
            sources_btn = tk.Button(
                actions,
                text="Ver fuentes",
                command=lambda labels=tuple(source_labels): self.show_sources_dialog(labels),
                bg=bubble_bg,
                fg=header_fg,
                activebackground=bubble_bg,
                activeforeground=body_fg,
                relief="flat",
                bd=0,
                padx=10,
                pady=0,
                cursor="hand2",
                font=("Segoe UI", 8, "underline"),
            )
            sources_btn.pack(side="left")

        self._scroll_chat_to_bottom()

    def _append_system_message(self, message: str) -> None:
        self._append_card("system", "Sistema", message)

    def _append_sources_message(self, source_labels: tuple[str, ...]) -> None:
        count = len(source_labels)
        preview = "\n".join(source_labels[:2])
        if count > 2:
            preview += f"\n\n... y {count - 2} fuente(s) adicional(es)."
        message = (
            f"Fuentes consultadas: {count}.\n"
            "Pulsa ‘Ver fuentes’ para visualizar rutas, líneas y extractos, o para abrir el archivo fuente cuando exista localmente.\n\n"
            f"{preview}"
        )
        self._append_card("system", "Fuentes", message, source_labels=tuple(source_labels))

    def _append_user_message(self, message: str, *, modality: str = "text", turn_index: int | None = None) -> None:
        self._append_card("user", "Usuario", message, modality=modality, turn_index=turn_index)

    def _append_assistant_message(self, message: str, *, modality: str = "text", turn_index: int | None = None) -> None:
        self._append_card("assistant", self.settings.assistant_name, message, modality=modality, turn_index=turn_index)

    def _append_error(self, message: str) -> None:
        self._append_card("error", "Error", message)

    def _clear_rendered_messages(self) -> None:
        for child in self.chat_inner.winfo_children():
            child.destroy()
        self._message_labels.clear()
        self.chat_canvas.yview_moveto(0.0)

    def _scroll_chat_to_bottom(self) -> None:
        self.root.after_idle(lambda: self.chat_canvas.yview_moveto(1.0))

    def _on_chat_inner_configure(self, _event: tk.Event) -> None:
        self.chat_canvas.configure(scrollregion=self.chat_canvas.bbox("all"))

    def _on_chat_canvas_configure(self, event: tk.Event) -> None:
        if self._chat_window_id is not None:
            self.chat_canvas.itemconfigure(self._chat_window_id, width=max(1, event.width))
        wrap = self._message_wraplength()
        for label in self._message_labels:
            try:
                label.configure(wraplength=wrap)
            except tk.TclError:
                continue

    def _on_mousewheel(self, event: tk.Event) -> None:
        try:
            self.chat_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            return

    # ------------------------------------------------------------------
    # Conversaciones persistentes
    # ------------------------------------------------------------------
    def _refresh_conversation_list(self, selected_id: str | None = None) -> None:
        records = self.conversation_store.list_records()
        self._conversation_ids = [record.conversation_id for record in records]
        self.conversation_listbox.delete(0, "end")
        selected_index: int | None = None
        for idx, record in enumerate(records):
            title = record.title or "Nueva conversación"
            turns_label = f"{len(record.turns)} mensajes"
            self.conversation_listbox.insert("end", f"{title}  ·  {turns_label}")
            if record.conversation_id == selected_id:
                selected_index = idx
        if selected_index is not None:
            self.conversation_listbox.selection_clear(0, "end")
            self.conversation_listbox.selection_set(selected_index)
            self.conversation_listbox.activate(selected_index)
            self.conversation_listbox.see(selected_index)

    def _on_conversation_selected(self, _event: tk.Event) -> None:
        selection = self.conversation_listbox.curselection()
        if not selection:
            return
        idx = int(selection[0])
        if idx < 0 or idx >= len(self._conversation_ids):
            return
        conversation_id = self._conversation_ids[idx]
        if self.current_conversation and self.current_conversation.conversation_id == conversation_id:
            return
        if self.request_in_progress:
            messagebox.showinfo(
                "Consulta en curso",
                "Espera a que termine la respuesta actual antes de cambiar de conversación.",
                parent=self.root,
            )
            self._refresh_conversation_list(self.current_conversation.conversation_id if self.current_conversation else None)
            return
        record = self.conversation_store.get(conversation_id)
        if record is not None:
            self._load_conversation(record)

    def _load_conversation(self, record: ConversationRecord) -> None:
        self.current_conversation = record
        self.history = [ChatTurn(role=turn.role, text=turn.text) for turn in record.turns]
        self.last_assistant_response = ""
        for turn in reversed(record.turns):
            if turn.role == "assistant" and turn.text.strip():
                self.last_assistant_response = turn.text
                break
        self._clear_rendered_messages()
        if not record.turns:
            self._append_system_message("Conversación seleccionada. Escribe una pregunta para comenzar.")
        else:
            for idx, turn in enumerate(record.turns):
                if turn.role == "assistant":
                    self._append_assistant_message(turn.text, modality=turn.modality, turn_index=idx)
                else:
                    self._append_user_message(turn.text, modality=turn.modality, turn_index=idx)
        self.conversation_info_var.set(f"{record.title} · {len(record.turns)} mensajes guardados")
        self.status_var.set("Conversación cargada desde memoria local.")
        self._refresh_conversation_list(record.conversation_id)

    def start_new_conversation(self, initial: bool = False) -> None:
        if self.request_in_progress:
            messagebox.showinfo(
                "Consulta en curso",
                "Espera a que termine la respuesta antes de iniciar otra conversación.",
                parent=self.root,
            )
            return
        self.current_conversation = None
        self.history.clear()
        self.last_assistant_response = ""
        self._clear_rendered_messages()
        self.conversation_listbox.selection_clear(0, "end")
        if initial:
            self._append_system_message(
                "Asistente experto LEMATZIUM activo. Pregunta sobre uso, código, auditoría o capacitación. "
                "Las conversaciones se guardan automáticamente desde el primer mensaje."
            )
        else:
            self._append_system_message("Nueva conversación iniciada. El historial anterior permanece disponible en la columna izquierda.")
        self.conversation_info_var.set("Nueva conversación · sin guardar hasta el primer mensaje")
        self.status_var.set("Nueva conversación lista.")

    def _ensure_current_conversation(self) -> ConversationRecord:
        if self.current_conversation is None:
            self.current_conversation = self.conversation_store.create()
            self.conversation_info_var.set("Nueva conversación · guardando historial")
        return self.current_conversation

    def _persist_turn(self, role: str, text: str, *, modality: str = "text") -> None:
        record = self._ensure_current_conversation()
        record.append_turn(role, text, modality=modality)
        self.conversation_store.upsert(record)
        self.conversation_info_var.set(f"{record.title} · {len(record.turns)} mensajes guardados")
        self._refresh_conversation_list(record.conversation_id)

    def delete_selected_conversation(self) -> None:
        selection = self.conversation_listbox.curselection()
        if not selection:
            self.status_var.set("Selecciona una conversación guardada para eliminarla.")
            return
        idx = int(selection[0])
        if idx < 0 or idx >= len(self._conversation_ids):
            return
        conversation_id = self._conversation_ids[idx]
        record = self.conversation_store.get(conversation_id)
        title = record.title if record is not None else "esta conversación"
        if not messagebox.askyesno(
            "Eliminar conversación",
            f"¿Eliminar la conversación guardada «{title}»?",
            parent=self.root,
        ):
            return
        removed = self.conversation_store.delete(conversation_id)
        if removed:
            if self.current_conversation and self.current_conversation.conversation_id == conversation_id:
                self.start_new_conversation()
            self._refresh_conversation_list()
            self.status_var.set("Conversación eliminada.")

    # ------------------------------------------------------------------
    # Mensajes de texto
    # ------------------------------------------------------------------
    def send_message(self) -> str:
        if self.request_in_progress:
            self.status_var.set("Espera a que termine la respuesta actual.")
            return "break"
        message = self.input_text.get("1.0", "end").strip()
        if not message:
            self.status_var.set("Escribe un mensaje antes de enviarlo.")
            return "break"

        pending_user_index = len(self.history)
        self._append_user_message(message, turn_index=pending_user_index)
        self.input_text.delete("1.0", "end")
        self.request_in_progress = True
        self.send_button.configure(state="disabled")
        active_model = self.backend.active_text_model_label or self.settings.text_model_label
        self.status_var.set(f"Consultando {active_model} y la base de conocimiento...")

        history_snapshot = list(self.history)
        self.history.append(ChatTurn(role="user", text=message))
        self._persist_turn("user", message)
        thread = threading.Thread(
            target=self._generate_in_background,
            args=(history_snapshot, message),
            daemon=True,
        )
        thread.start()
        return "break"

    def _generate_in_background(self, history_snapshot: list[ChatTurn], message: str) -> None:
        try:
            reply = self.backend.generate_reply(history_snapshot, message)
            self.events.put(("assistant", reply))
        except GeminiApiError as exc:
            self.events.put(("error", str(exc)))
        except Exception as exc:  # pragma: no cover - defensivo
            self.events.put(("error", f"Error inesperado: {exc}"))

    # ------------------------------------------------------------------
    # Conocimiento y audio
    # ------------------------------------------------------------------
    def refresh_knowledge(self) -> None:
        if self.request_in_progress:
            self.status_var.set("Espera a que termine la respuesta actual antes de recargar el conocimiento.")
            return
        self.refresh_knowledge_button.configure(state="disabled")
        self.status_var.set("Actualizando base de conocimiento de manual, documentación y código...")
        thread = threading.Thread(target=self._refresh_knowledge_background, daemon=True)
        thread.start()

    def _refresh_knowledge_background(self) -> None:
        try:
            stats = self.knowledge_base.rebuild()
            self.events.put(("knowledge_refreshed", stats.display()))
        except Exception as exc:
            self.events.put(("knowledge_error", f"No se pudo actualizar la base de conocimiento: {exc}"))

    def toggle_audio_chat(self) -> None:
        if self.audio_controller.is_running:
            self.status_var.set("Deteniendo sesión de audio...")
            self.mic_button.configure(text="⏹ Deteniendo audio...")
            self.audio_controller.stop()
            return
        self.status_var.set(f"Conectando audio en vivo con {self.settings.audio_model_label}...")
        self.mic_button.configure(text="🎙 Conectando...")
        self.audio_controller.start()
        if not self.audio_controller.is_running:
            self.mic_button.configure(text="🎙 Iniciar audio")
            self.mic_mute_button.configure(text="🔇 Silenciar micrófono", state="disabled")

    def toggle_microphone_mute(self) -> None:
        if not self.audio_controller.is_running:
            self.mic_mute_button.configure(text="🔇 Silenciar micrófono", state="disabled")
            self.status_var.set("Inicia primero la sesión de audio.")
            return
        should_mute = not self.audio_controller.is_microphone_muted
        self.audio_controller.set_microphone_muted(should_mute)
        if should_mute:
            self.mic_mute_button.configure(text="🔊 Reactivar micrófono")
            self.status_var.set("Micrófono silenciado. La IA no recibirá ruido ambiente hasta que lo reactives.")
            self._append_system_message("Micrófono silenciado durante la sesión de audio.")
        else:
            self.mic_mute_button.configure(text="🔇 Silenciar micrófono")
            self.status_var.set("Micrófono reactivado. Puedes hablar nuevamente.")
            self._append_system_message("Micrófono reactivado durante la sesión de audio.")

    def _queue_audio_event(self, event: AudioUiEvent) -> None:
        self.events.put((event.kind, event.payload))

    # ------------------------------------------------------------------
    # Bucle de eventos
    # ------------------------------------------------------------------
    def _poll_events(self) -> None:
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "assistant":
                    self._handle_text_reply(payload)
                elif kind == "error":
                    self._handle_text_error(str(payload))
                elif kind == "knowledge_refreshed":
                    self.refresh_knowledge_button.configure(state="normal")
                    self.subtitle_var.set(self._subtitle_text())
                    self._append_system_message(f"Base de conocimiento actualizada: {payload}.")
                    self.status_var.set(f"Base de conocimiento actualizada: {payload}.")
                elif kind == "knowledge_error":
                    self.refresh_knowledge_button.configure(state="normal")
                    self._append_error(str(payload))
                    self.status_var.set("No se pudo actualizar la base de conocimiento.")
                elif kind == "audio_started":
                    self.mic_button.configure(text="⏹ Detener audio")
                    self.mic_mute_button.configure(text="🔇 Silenciar micrófono", state="normal")
                    self._append_system_message(str(payload))
                    self.status_var.set(str(payload))
                elif kind == "audio_stopped":
                    self.mic_button.configure(text="🎙 Iniciar audio")
                    self.mic_mute_button.configure(text="🔇 Silenciar micrófono", state="disabled")
                    self._append_system_message(str(payload))
                    self.status_var.set(str(payload))
                elif kind == "audio_status":
                    self._append_system_message(str(payload))
                    self.status_var.set(str(payload))
                elif kind == "audio_user":
                    text = str(payload)
                    pending_audio_user_index = len(self.history)
                    self._append_user_message(text, modality="audio", turn_index=pending_audio_user_index)
                    self.history.append(ChatTurn(role="user", text=text))
                    self._persist_turn("user", text, modality="audio")
                    self.status_var.set("Audio del usuario transcrito y guardado en la conversación.")
                elif kind == "audio_assistant":
                    text = str(payload)
                    pending_audio_assistant_index = len(self.history)
                    self._append_assistant_message(text, modality="audio", turn_index=pending_audio_assistant_index)
                    self.history.append(ChatTurn(role="assistant", text=text))
                    self._persist_turn("assistant", text, modality="audio")
                    self.last_assistant_response = text
                    self.status_var.set("Respuesta de audio recibida y guardada.")
                elif kind == "audio_error":
                    self.mic_button.configure(text="🎙 Iniciar audio")
                    self.mic_mute_button.configure(text="🔇 Silenciar micrófono", state="disabled")
                    self._append_error(f"Audio: {payload}")
                    self.status_var.set("No se pudo iniciar o sostener el audio en vivo.")
        except queue.Empty:
            pass
        try:
            self.root.after(120, self._poll_events)
        except tk.TclError:
            return

    def _handle_text_reply(self, payload: Any) -> None:
        if not isinstance(payload, ChatReply):
            self._handle_text_error("La respuesta del módulo no llegó en el formato esperado.")
            return
        if payload.notice:
            self._append_system_message(payload.notice)
        self.subtitle_var.set(self._subtitle_text())
        self.history.append(ChatTurn(role="assistant", text=payload.text))
        assistant_turn_index = len(self.history) - 1
        self._persist_turn("assistant", payload.text)
        self.last_assistant_response = payload.text
        self._append_assistant_message(payload.text, turn_index=assistant_turn_index)
        if payload.knowledge_sources:
            visible_sources = "Fuentes consultadas visibles:\n" + "\n\n".join(payload.knowledge_sources[:8])
            if len(payload.knowledge_sources) > 8:
                visible_sources += f"\n\n... {len(payload.knowledge_sources) - 8} fuente(s) adicional(es) omitida(s) en pantalla."
            visible_sources += "\n\nPuedes usar el botón Copiar de esta burbuja para conservar rutas, líneas y extractos."
            self._append_system_message(visible_sources)
        self.status_var.set(f"Respuesta recibida con {payload.model_label}.")
        self.request_in_progress = False
        self.send_button.configure(state="normal")

    def _handle_text_error(self, message: str) -> None:
        self._append_error(message)
        self.status_var.set("No se pudo completar la consulta.")
        self.request_in_progress = False
        self.send_button.configure(state="normal")

    # ------------------------------------------------------------------
    # Acciones auxiliares
    # ------------------------------------------------------------------
    @staticmethod
    def _parse_source_label(label: str) -> dict[str, str]:
        match = re.search(r"^Fuente\s+(?P<num>\d+):\s*(?P<kind>[^|]+)\|\s*(?P<path>[^|]+)\|\s*líneas\s*(?P<lines>\d+\s*-\s*\d+)", str(label or ""), re.M)
        if not match:
            return {"num": "", "kind": "Fuente", "path": "", "lines": "", "label": str(label or "")}
        data = match.groupdict()
        data["label"] = str(label or "")
        data["kind"] = data["kind"].strip()
        data["path"] = data["path"].strip()
        data["lines"] = data["lines"].replace(" ", "")
        return data

    def _source_path(self, source_data: dict[str, str]) -> Path | None:
        rel = str(source_data.get("path") or "").strip()
        if not rel:
            return None
        candidate = (self.knowledge_base.suite_root / rel).resolve()
        try:
            candidate.relative_to(self.knowledge_base.suite_root.resolve())
        except Exception:
            return None
        return candidate

    def _open_local_source_file(self, source_data: dict[str, str]) -> None:
        path = self._source_path(source_data)
        if path is None or not path.exists():
            messagebox.showwarning(
                "Fuente no disponible",
                "No se encontró el archivo fuente local asociado a esta referencia.",
                parent=self.root,
            )
            return
        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
            self.status_var.set(f"Fuente abierta: {path.name}")
        except Exception as exc:
            messagebox.showerror("No se pudo abrir la fuente", f"Detalle: {exc}", parent=self.root)

    def show_sources_dialog(self, source_labels: tuple[str, ...]) -> None:
        labels = tuple(str(label or "").strip() for label in source_labels if str(label or "").strip())
        if not labels:
            self.status_var.set("No hay fuentes visibles asociadas a este mensaje.")
            return
        sources = [self._parse_source_label(label) for label in labels]
        dialog = tk.Toplevel(self.root)
        dialog.title("Fuentes consultadas")
        dialog.configure(bg=self.theme["bg"])
        dialog.transient(self.root.winfo_toplevel())
        dialog.geometry("1080x620")
        dialog.minsize(820, 460)
        dialog.grid_columnconfigure(1, weight=1)
        dialog.grid_rowconfigure(1, weight=1)

        title = tk.Label(
            dialog,
            text="Fuentes consultadas por el asistente",
            bg=self.theme["bg"],
            fg=self.theme["text"],
            font=("Segoe UI Semibold", 16),
            anchor="w",
            padx=18,
            pady=14,
        )
        title.grid(row=0, column=0, columnspan=2, sticky="ew")

        left = tk.Frame(dialog, bg=self.theme["panel"], padx=12, pady=12, highlightthickness=1, highlightbackground=self.theme["accent"])
        left.grid(row=1, column=0, sticky="nsew", padx=(18, 10), pady=(0, 14))
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)
        left_title = tk.Label(left, text="Listado", bg=self.theme["panel"], fg=self.theme["text"], font=("Segoe UI Semibold", 11), anchor="w")
        left_title.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        listbox = tk.Listbox(
            left,
            bg=self.theme["field_bg"],
            fg=self.theme["field_text"],
            selectbackground=self.theme["accent"],
            selectforeground="#00111e",
            bd=0,
            highlightthickness=1,
            highlightbackground=self.theme["accent"],
            activestyle="none",
            font=("Segoe UI", 10),
            exportselection=False,
            width=44,
        )
        listbox.grid(row=1, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(left, orient="vertical", command=listbox.yview)
        scroll.grid(row=1, column=1, sticky="ns")
        listbox.configure(yscrollcommand=scroll.set)

        right = tk.Frame(dialog, bg=self.theme["panel"], padx=12, pady=12, highlightthickness=1, highlightbackground=self.theme["accent"])
        right.grid(row=1, column=1, sticky="nsew", padx=(0, 18), pady=(0, 14))
        right.grid_rowconfigure(1, weight=1)
        right.grid_columnconfigure(0, weight=1)
        detail_title_var = tk.StringVar(value="Seleccione una fuente")
        detail_title = tk.Label(right, textvariable=detail_title_var, bg=self.theme["panel"], fg=self.theme["text"], font=("Segoe UI Semibold", 11), anchor="w")
        detail_title.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        detail = tk.Text(
            right,
            wrap="word",
            bg=self.theme["field_bg"],
            fg=self.theme["field_text"],
            insertbackground=self.theme["field_text"],
            bd=0,
            relief="flat",
            padx=12,
            pady=12,
            font=("Consolas", 10),
            state="disabled",
        )
        detail.grid(row=1, column=0, sticky="nsew")
        detail_scroll = ttk.Scrollbar(right, orient="vertical", command=detail.yview)
        detail_scroll.grid(row=1, column=1, sticky="ns")
        detail.configure(yscrollcommand=detail_scroll.set)

        actions = tk.Frame(right, bg=self.theme["panel"])
        actions.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        selected_index = {"value": 0}

        def _copy_selected() -> None:
            idx = selected_index["value"]
            if idx < 0 or idx >= len(sources):
                return
            self.copy_message_text(sources[idx]["label"])

        def _open_selected() -> None:
            idx = selected_index["value"]
            if idx < 0 or idx >= len(sources):
                return
            self._open_local_source_file(sources[idx])

        copy_btn = ttk.Button(actions, text="Copiar fuente", command=_copy_selected, style="AI.Secondary.TButton")
        copy_btn.pack(side="left", padx=(0, 8))
        open_btn = ttk.Button(actions, text="Abrir archivo fuente", command=_open_selected, style="AI.TButton")
        open_btn.pack(side="left", padx=(0, 8))
        close_btn = ttk.Button(actions, text="Cerrar", command=dialog.destroy, style="AI.Secondary.TButton")
        close_btn.pack(side="right")

        def _render_selected(idx: int) -> None:
            selected_index["value"] = idx
            source = sources[idx]
            title_text = f"Fuente {source.get('num') or idx + 1}: {source.get('path') or 'sin ruta'}"
            if source.get("lines"):
                title_text += f" · líneas {source['lines']}"
            detail_title_var.set(title_text)
            text = source.get("label") or "(fuente sin detalle)"
            path = self._source_path(source)
            if path is not None:
                state = "Disponible localmente" if path.exists() else "No encontrado localmente"
                text += f"\n\nArchivo local: {path}\nEstado: {state}"
            detail.configure(state="normal")
            detail.delete("1.0", "end")
            detail.insert("1.0", text)
            detail.configure(state="disabled")

        for idx, source in enumerate(sources):
            path = source.get("path") or "sin ruta"
            lines = source.get("lines") or "sin líneas"
            listbox.insert("end", f"Fuente {source.get('num') or idx + 1} · {path} · {lines}")

        def _on_select(_event=None):
            selection = listbox.curselection()
            if not selection:
                return
            _render_selected(int(selection[0]))

        listbox.bind("<<ListboxSelect>>", _on_select)
        listbox.selection_set(0)
        listbox.activate(0)
        _render_selected(0)
        try:
            dialog.lift()
            dialog.focus_force()
        except Exception:
            pass

    def copy_message_text(self, text: str) -> None:
        clean = str(text or "").strip()
        if not clean:
            self.status_var.set("El mensaje no tiene texto copiable.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(clean)
        self.root.update_idletasks()
        self.status_var.set("Mensaje copiado al portapapeles.")

    def edit_user_message(self, turn_index: int) -> None:
        if self.request_in_progress:
            self.status_var.set("Espera a que termine la respuesta actual antes de editar un mensaje.")
            return
        record = self.current_conversation
        if record is None or turn_index < 0 or turn_index >= len(record.turns):
            self.status_var.set("No se encontró el mensaje para editar.")
            return
        turn = record.turns[turn_index]
        if turn.role != "user":
            self.status_var.set("Solo se pueden editar mensajes del usuario.")
            return

        dialog = tk.Toplevel(self.root)
        dialog.title("Editar mensaje")
        dialog.configure(bg=self.theme["bg"])
        dialog.transient(self.root.winfo_toplevel())
        dialog.grab_set()
        dialog.geometry("720x360")
        dialog.minsize(560, 280)
        dialog.grid_columnconfigure(0, weight=1)
        dialog.grid_rowconfigure(1, weight=1)

        title = tk.Label(
            dialog,
            text="Editar mensaje del usuario",
            bg=self.theme["bg"],
            fg=self.theme["text"],
            font=("Segoe UI Semibold", 14),
            anchor="w",
            padx=18,
            pady=14,
        )
        title.grid(row=0, column=0, sticky="ew")

        editor_frame = tk.Frame(
            dialog,
            bg=self.theme["field_bg"],
            highlightthickness=1,
            highlightbackground=self.theme["accent"],
            padx=12,
            pady=12,
        )
        editor_frame.grid(row=1, column=0, sticky="nsew", padx=18, pady=(0, 12))
        editor_frame.grid_columnconfigure(0, weight=1)
        editor_frame.grid_rowconfigure(0, weight=1)

        editor = tk.Text(
            editor_frame,
            wrap="word",
            bg=self.theme["field_bg"],
            fg=self.theme["field_text"],
            insertbackground=self.theme["field_text"],
            bd=0,
            relief="flat",
            font=("Segoe UI", 11),
            undo=True,
        )
        editor.grid(row=0, column=0, sticky="nsew")
        editor.insert("1.0", turn.text)
        editor.focus_set()

        action_bar = tk.Frame(dialog, bg=self.theme["bg"], padx=18, pady=12)
        action_bar.grid(row=2, column=0, sticky="ew")
        action_bar.grid_columnconfigure(0, weight=1)

        def save_edit() -> None:
            new_text = editor.get("1.0", "end").strip()
            if not new_text:
                messagebox.showwarning("Mensaje vacío", "El mensaje no puede quedar vacío.", parent=dialog)
                return
            if not record.edit_turn(turn_index, new_text):
                messagebox.showerror("No se pudo editar", "No se pudo guardar la edición del mensaje.", parent=dialog)
                return
            self.conversation_store.upsert(record)
            self.history = [ChatTurn(role=item.role, text=item.text) for item in record.turns]
            self._load_conversation(record)
            self.status_var.set("Mensaje editado y conversación actualizada.")
            dialog.destroy()

        cancel_btn = ttk.Button(action_bar, text="Cancelar", command=dialog.destroy, style="AI.Secondary.TButton")
        cancel_btn.grid(row=0, column=1, sticky="e", padx=(8, 0))
        save_btn = ttk.Button(action_bar, text="Guardar edición", command=save_edit, style="AI.TButton")
        save_btn.grid(row=0, column=2, sticky="e", padx=(8, 0))

        dialog.bind("<Escape>", lambda _e: dialog.destroy())
        dialog.bind("<Control-Return>", lambda _e: save_edit())

    def copy_last_response(self) -> None:
        if not self.last_assistant_response.strip():
            self.status_var.set("Aún no hay una respuesta para copiar.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(self.last_assistant_response)
        self.root.update_idletasks()
        self.status_var.set("Última respuesta copiada al portapapeles.")

    def on_hide(self) -> None:
        """Libera el audio al navegar fuera del módulo embebido."""
        try:
            if self.audio_controller.is_running:
                self.audio_controller.stop()
        except Exception:
            pass

    def on_app_close(self) -> None:
        self.on_hide()

    def _on_close(self) -> None:
        self.audio_controller.stop()
        try:
            self.root.destroy()
        except Exception:
            pass

    def run(self) -> None:
        if self.embedded:
            return
        self.root.mainloop()


def main() -> int:
    app = AssistantWindow()
    app.run()
    return 0


__all__ = ["AssistantWindow", "main"]
