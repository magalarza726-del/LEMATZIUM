from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
from typing import Any

# Modelos de escritura habilitados desde Google AI Studio / Gemini API.
TEXT_MODEL_IDS: dict[str, str] = {
    "Gemini 3.1 Flash Lite": "gemini-3.1-flash-lite",
    "Gemma 4 31B": "gemma-4-31b-it",
}

# Alias para no romper preferencias guardadas en versiones previas del módulo.
TEXT_MODEL_ALIASES: dict[str, str] = {
    "Gemini 3 Flash": "Gemini 3.1 Flash Lite",
    "Gemini 3.1 Flash": "Gemini 3.1 Flash Lite",
    "Gemini 3.1 Flash-Lite": "Gemini 3.1 Flash Lite",
}

AUDIO_MODEL_IDS: dict[str, str] = {
    "Gemini 3.1 Flash Live": "gemini-3.1-flash-live-preview",
    "Gemini 2.5 Flash Native Audio Dialog": "gemini-2.5-flash-native-audio-preview-12-2025",
}

# Voces oficiales disponibles para Gemini Live / Native Audio.
# La selección por defecto conserva la identidad LEMATRÓN con Algenib.
AUDIO_VOICE_STYLES: dict[str, str] = {
    "Zephyr": "Bright",
    "Puck": "Upbeat",
    "Charon": "Informative",
    "Kore": "Firm",
    "Fenrir": "Excitable",
    "Leda": "Youthful",
    "Orus": "Firm",
    "Aoede": "Breezy",
    "Callirrhoe": "Easy-going",
    "Autonoe": "Bright",
    "Enceladus": "Breathy",
    "Iapetus": "Clear",
    "Umbriel": "Easy-going",
    "Algieba": "Smooth",
    "Despina": "Smooth",
    "Erinome": "Clear",
    "Algenib": "Gravelly",
    "Rasalgethi": "Informative",
    "Laomedeia": "Upbeat",
    "Achernar": "Soft",
    "Alnilam": "Firm",
    "Schedar": "Even",
    "Gacrux": "Mature",
    "Pulcherrima": "Forward",
    "Achird": "Friendly",
    "Zubenelgenubi": "Casual",
    "Vindemiatrix": "Gentle",
    "Sadachbia": "Lively",
    "Sadaltager": "Knowledgeable",
    "Sulafat": "Warm",
}
AUDIO_VOICE_NAMES: tuple[str, ...] = tuple(AUDIO_VOICE_STYLES.keys())

# Presets DSP de salida. No alteran la voz elegida por la API; ecualizan el audio
# recibido para volver el timbre más grave y perceptible sin forzar pitch-shift.
# El procesamiento usa shelf grave, recorte suave de presencia y protección de picos.
AUDIO_VOICE_FILTER_PRESETS: dict[str, dict[str, Any]] = {
    "Sin filtro": {
        "enabled": False,
        "low_shelf_hz": 0.0,
        "low_shelf_db": 0.0,
        "presence_hz": 0.0,
        "presence_db": 0.0,
        "presence_q": 0.85,
        "output_gain": 1.0,
        "description": "audio original",
    },
    "LEMATRÓN grave limpio": {
        "enabled": True,
        "low_shelf_hz": 260.0,
        "low_shelf_db": 4.0,
        "presence_hz": 3200.0,
        "presence_db": -1.6,
        "presence_q": 0.90,
        "output_gain": 0.82,
        "description": "grave perceptible · cuerpo +4.0 dB · dicción limpia",
    },
    "LEMATRÓN grave marcado": {
        "enabled": True,
        "low_shelf_hz": 300.0,
        "low_shelf_db": 6.0,
        "presence_hz": 3000.0,
        "presence_db": -2.6,
        "presence_q": 0.85,
        "output_gain": 0.72,
        "description": "grave profundo · cuerpo +6.0 dB · control de brillo",
    },
}
AUDIO_VOICE_FILTER_LABELS: tuple[str, ...] = tuple(AUDIO_VOICE_FILTER_PRESETS.keys())

ASSISTANT_RESPONSE_MODES: tuple[str, ...] = (
    "Auditoría estricta",
    "Capacitación",
    "Soporte técnico",
)

GEMMA_THINKING_MODES: tuple[str, ...] = (
    "Thinking",
    "No thinking",
)

DEFAULT_ASSISTANT_NAME = "LEMATZIUM IA"
DEFAULT_TEXT_MODEL_LABEL = "Gemini 3.1 Flash Lite"
DEFAULT_AUDIO_MODEL_LABEL = "Gemini 3.1 Flash Live"
DEFAULT_AUDIO_VOICE_NAME = "Gacrux"
DEFAULT_AUDIO_VOICE_FILTER_LABEL = "LEMATRÓN grave limpio"
DEFAULT_ASSISTANT_RESPONSE_MODE = "Auditoría estricta"
DEFAULT_GEMMA_THINKING_MODE = "Thinking"
PREFS_FILENAME = "lematzium_suite_launcher_prefs.json"


@dataclass(frozen=True)
class AssistantSettings:
    assistant_name: str = DEFAULT_ASSISTANT_NAME
    api_key: str = ""
    text_model_label: str = DEFAULT_TEXT_MODEL_LABEL
    audio_model_label: str = DEFAULT_AUDIO_MODEL_LABEL
    audio_voice_name: str = DEFAULT_AUDIO_VOICE_NAME
    audio_voice_filter_label: str = DEFAULT_AUDIO_VOICE_FILTER_LABEL
    response_mode: str = DEFAULT_ASSISTANT_RESPONSE_MODE
    gemma_thinking_mode: str = DEFAULT_GEMMA_THINKING_MODE
    prefs_path: Path | None = None

    @property
    def text_model_id(self) -> str:
        return TEXT_MODEL_IDS.get(self.text_model_label, TEXT_MODEL_IDS[DEFAULT_TEXT_MODEL_LABEL])

    @property
    def audio_model_id(self) -> str:
        return AUDIO_MODEL_IDS.get(self.audio_model_label, AUDIO_MODEL_IDS[DEFAULT_AUDIO_MODEL_LABEL])

    @property
    def has_api_key(self) -> bool:
        return bool(self.api_key.strip())

    @property
    def gemma_thinking_enabled(self) -> bool:
        return self.gemma_thinking_mode == "Thinking"



def _safe_text(value: Any, default: str) -> str:
    text = str(value or "").strip()
    return text or default



def _resolve_label(value: Any, allowed: dict[str, str] | tuple[str, ...], default: str, *, aliases: dict[str, str] | None = None) -> str:
    candidate = str(value or default).strip()
    if aliases:
        candidate = aliases.get(candidate, candidate)
    allowed_values = allowed.keys() if isinstance(allowed, dict) else allowed
    return candidate if candidate in allowed_values else default



def candidate_prefs_paths() -> list[Path]:
    candidates: list[Path] = []
    env_path = os.getenv("LEMATZIUM_THEME_FILE", "").strip()
    if env_path:
        candidates.append(Path(env_path))

    here = Path(__file__).resolve()
    # settings.py -> lematzium_ai_assistant -> module_3_ai_assistant -> modules -> suite root
    try:
        suite_root = here.parents[3]
        candidates.append(suite_root / "launcher" / PREFS_FILENAME)
    except IndexError:
        pass

    local_app = os.getenv("LOCALAPPDATA", "").strip()
    if local_app:
        candidates.append(Path(local_app) / "LEMATZIUM" / PREFS_FILENAME)

    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        try:
            key = str(candidate.expanduser().resolve()).lower()
        except Exception:
            key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(candidate)
    return unique



def read_prefs() -> tuple[dict[str, Any], Path | None]:
    for path in candidate_prefs_paths():
        if not path.exists():
            continue
        try:
            return json.loads(path.read_text(encoding="utf-8")), path
        except Exception:
            continue
    return {}, None



def save_assistant_preference(key: str, value: Any) -> Path | None:
    """Guarda una preferencia puntual del asistente en el archivo del launcher.

    Se usa desde el propio Módulo 3 para que la voz seleccionada se conserve
    entre sesiones aunque el usuario no abra Configuración del HUB.
    """
    prefs, existing_path = read_prefs()
    target = existing_path
    if target is None:
        candidates = candidate_prefs_paths()
        target = candidates[0] if candidates else None
    if target is None:
        return None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        data = dict(prefs or {})
        data[str(key)] = value
        target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return target
    except Exception:
        return None


def load_assistant_settings() -> AssistantSettings:
    prefs, prefs_path = read_prefs()
    api_key_env = os.getenv("GOOGLE_API_KEY", "").strip() or os.getenv("GEMINI_API_KEY", "").strip()
    api_key_prefs = str(prefs.get("gemini_api_key", "")).strip()
    return AssistantSettings(
        assistant_name=_safe_text(prefs.get("assistant_name"), DEFAULT_ASSISTANT_NAME),
        api_key=api_key_env or api_key_prefs,
        text_model_label=_resolve_label(
            prefs.get("assistant_text_model"),
            TEXT_MODEL_IDS,
            DEFAULT_TEXT_MODEL_LABEL,
            aliases=TEXT_MODEL_ALIASES,
        ),
        audio_model_label=_resolve_label(
            prefs.get("assistant_audio_model"),
            AUDIO_MODEL_IDS,
            DEFAULT_AUDIO_MODEL_LABEL,
        ),
        audio_voice_name=_resolve_label(
            prefs.get("assistant_audio_voice"),
            AUDIO_VOICE_NAMES,
            DEFAULT_AUDIO_VOICE_NAME,
        ),
        audio_voice_filter_label=_resolve_label(
            prefs.get("assistant_audio_voice_filter"),
            AUDIO_VOICE_FILTER_LABELS,
            DEFAULT_AUDIO_VOICE_FILTER_LABEL,
        ),
        response_mode=_resolve_label(
            prefs.get("assistant_response_mode"),
            ASSISTANT_RESPONSE_MODES,
            DEFAULT_ASSISTANT_RESPONSE_MODE,
        ),
        gemma_thinking_mode=_resolve_label(
            prefs.get("assistant_gemma_thinking_mode"),
            GEMMA_THINKING_MODES,
            DEFAULT_GEMMA_THINKING_MODE,
        ),
        prefs_path=prefs_path,
    )


__all__ = [
    "AUDIO_MODEL_IDS",
    "AUDIO_VOICE_FILTER_LABELS",
    "AUDIO_VOICE_FILTER_PRESETS",
    "AUDIO_VOICE_NAMES",
    "AUDIO_VOICE_STYLES",
    "ASSISTANT_RESPONSE_MODES",
    "AssistantSettings",
    "DEFAULT_ASSISTANT_NAME",
    "DEFAULT_ASSISTANT_RESPONSE_MODE",
    "DEFAULT_AUDIO_MODEL_LABEL",
    "DEFAULT_AUDIO_VOICE_FILTER_LABEL",
    "DEFAULT_AUDIO_VOICE_NAME",
    "DEFAULT_GEMMA_THINKING_MODE",
    "DEFAULT_TEXT_MODEL_LABEL",
    "GEMMA_THINKING_MODES",
    "PREFS_FILENAME",
    "TEXT_MODEL_ALIASES",
    "TEXT_MODEL_IDS",
    "candidate_prefs_paths",
    "load_assistant_settings",
    "read_prefs",
    "save_assistant_preference",
]
