from __future__ import annotations

import asyncio
import base64
import math

import numpy as np
from dataclasses import dataclass
import threading
import time
from typing import Callable, Any

from .knowledge import LematZiumKnowledgeBase
from .settings import AUDIO_VOICE_FILTER_PRESETS, AssistantSettings

SEND_SAMPLE_RATE = 16000
RECEIVE_SAMPLE_RATE = 24000
INPUT_BLOCKSIZE = 1024
OUTPUT_BLOCKSIZE = 2048


@dataclass(frozen=True)
class AudioUiEvent:
    kind: str
    payload: str


class LiveAudioError(RuntimeError):
    """Error normalizado para el chat de audio en vivo."""


class _BiquadFilter:
    """Biquad IIR en forma directa transpuesta, estable para procesamiento por bloques."""

    def __init__(self, b0: float, b1: float, b2: float, a1: float, a2: float) -> None:
        self.b0 = float(b0)
        self.b1 = float(b1)
        self.b2 = float(b2)
        self.a1 = float(a1)
        self.a2 = float(a2)
        self.z1 = 0.0
        self.z2 = 0.0

    def process(self, samples: np.ndarray) -> np.ndarray:
        if samples.size == 0:
            return samples
        output = np.empty_like(samples)
        z1 = float(self.z1)
        z2 = float(self.z2)
        b0 = float(self.b0)
        b1 = float(self.b1)
        b2 = float(self.b2)
        a1 = float(self.a1)
        a2 = float(self.a2)
        for index, sample in enumerate(samples):
            x = float(sample)
            y = (b0 * x) + z1
            z1 = (b1 * x) - (a1 * y) + z2
            z2 = (b2 * x) - (a2 * y)
            output[index] = y
        self.z1 = z1
        self.z2 = z2
        return output


class LiveOutputVoiceFilter:
    """Filtro de timbre de salida para LEMATRÓN.

    La versión previa únicamente aplicaba una inclinación tonal muy sutil; en la
    práctica podía percibirse casi igual que "Sin filtro". Esta versión procesa
    la salida PCM con una ecualización vocal más clara y audible:

    - shelf grave: aporta cuerpo masculino en bajas frecuencias;
    - recorte suave de presencia: reduce brillo agresivo sin apagar la dicción;
    - control automático de picos: evita clipping y distorsión por sobrecarga.

    No pretende clonar voces ni bajar el pitch real. El objetivo es modificar el
    timbre de manera perceptible, limpia y estable en tiempo real.
    """

    def __init__(self, preset_label: str) -> None:
        config = AUDIO_VOICE_FILTER_PRESETS.get(str(preset_label or "").strip(), {})
        self.label = str(preset_label or "Sin filtro").strip() or "Sin filtro"
        self.enabled = bool(config.get("enabled", False))
        self.low_shelf_hz = float(config.get("low_shelf_hz", 0.0) or 0.0)
        self.low_shelf_db = float(config.get("low_shelf_db", 0.0) or 0.0)
        self.presence_hz = float(config.get("presence_hz", 0.0) or 0.0)
        self.presence_db = float(config.get("presence_db", 0.0) or 0.0)
        self.presence_q = max(0.10, float(config.get("presence_q", 0.85) or 0.85))
        self.output_gain = max(0.05, float(config.get("output_gain", 1.0) or 1.0))
        self._filters: list[_BiquadFilter] = []
        if self.enabled:
            if self.low_shelf_hz > 0.0 and abs(self.low_shelf_db) > 1e-6:
                self._filters.append(self._make_low_shelf(self.low_shelf_hz, self.low_shelf_db))
            if self.presence_hz > 0.0 and abs(self.presence_db) > 1e-6:
                self._filters.append(self._make_peaking(self.presence_hz, self.presence_db, self.presence_q))

    @staticmethod
    def _normalize_coefficients(b0: float, b1: float, b2: float, a0: float, a1: float, a2: float) -> _BiquadFilter:
        if abs(a0) < 1e-12:
            return _BiquadFilter(1.0, 0.0, 0.0, 0.0, 0.0)
        return _BiquadFilter(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)

    @classmethod
    def _make_low_shelf(cls, frequency_hz: float, gain_db: float) -> _BiquadFilter:
        fs = float(RECEIVE_SAMPLE_RATE)
        frequency_hz = min(max(20.0, float(frequency_hz)), fs * 0.45)
        amplitude = 10.0 ** (float(gain_db) / 40.0)
        omega = 2.0 * math.pi * frequency_hz / fs
        cosine = math.cos(omega)
        sine = math.sin(omega)
        sqrt_a = math.sqrt(amplitude)
        shelf_slope = 1.0
        alpha = (sine / 2.0) * math.sqrt(max(0.0, (amplitude + (1.0 / amplitude)) * ((1.0 / shelf_slope) - 1.0) + 2.0))
        b0 = amplitude * ((amplitude + 1.0) - (amplitude - 1.0) * cosine + 2.0 * sqrt_a * alpha)
        b1 = 2.0 * amplitude * ((amplitude - 1.0) - (amplitude + 1.0) * cosine)
        b2 = amplitude * ((amplitude + 1.0) - (amplitude - 1.0) * cosine - 2.0 * sqrt_a * alpha)
        a0 = (amplitude + 1.0) + (amplitude - 1.0) * cosine + 2.0 * sqrt_a * alpha
        a1 = -2.0 * ((amplitude - 1.0) + (amplitude + 1.0) * cosine)
        a2 = (amplitude + 1.0) + (amplitude - 1.0) * cosine - 2.0 * sqrt_a * alpha
        return cls._normalize_coefficients(b0, b1, b2, a0, a1, a2)

    @classmethod
    def _make_peaking(cls, frequency_hz: float, gain_db: float, q: float) -> _BiquadFilter:
        fs = float(RECEIVE_SAMPLE_RATE)
        frequency_hz = min(max(20.0, float(frequency_hz)), fs * 0.45)
        q = max(0.10, float(q))
        amplitude = 10.0 ** (float(gain_db) / 40.0)
        omega = 2.0 * math.pi * frequency_hz / fs
        cosine = math.cos(omega)
        alpha = math.sin(omega) / (2.0 * q)
        b0 = 1.0 + alpha * amplitude
        b1 = -2.0 * cosine
        b2 = 1.0 - alpha * amplitude
        a0 = 1.0 + (alpha / amplitude)
        a1 = -2.0 * cosine
        a2 = 1.0 - (alpha / amplitude)
        return cls._normalize_coefficients(b0, b1, b2, a0, a1, a2)

    def process(self, audio_data: bytes) -> bytes:
        if not self.enabled or not audio_data or len(audio_data) % 2:
            return audio_data
        samples_i16 = np.frombuffer(audio_data, dtype=np.int16)
        if samples_i16.size == 0:
            return audio_data
        samples = samples_i16.astype(np.float32) / 32768.0
        samples *= float(self.output_gain)
        for filter_stage in self._filters:
            samples = filter_stage.process(samples)

        # Protección limpia contra picos. Se normaliza el bloque solo si el DSP
        # podría exceder el rango PCM, evitando clipping duro sin introducir un
        # saturador audible.
        peak = float(np.max(np.abs(samples))) if samples.size else 0.0
        if peak > 0.985:
            samples *= (0.985 / peak)
        samples = np.clip(samples, -1.0, 0.9999695)
        return (samples * 32768.0).astype(np.int16).tobytes()


class LiveAudioController:
    """Controlador de sesión Live API, ejecutado fuera del hilo de Tkinter.

    El botón de micrófono abre una sesión de conversación por voz sin bloquear la UI.
    Para preguntas sobre LEMATZIUM, el modelo Live puede invocar una herramienta local
    que recupera evidencia desde el manual, la documentación y el código base.
    """

    def __init__(
        self,
        settings: AssistantSettings,
        emit: Callable[[AudioUiEvent], None],
        knowledge_base: LematZiumKnowledgeBase | None = None,
    ) -> None:
        self.settings = settings
        self._emit = emit
        self.knowledge_base = knowledge_base or LematZiumKnowledgeBase()
        self._thread: threading.Thread | None = None
        self._stop_flag = threading.Event()
        self._running_lock = threading.Lock()
        self._running = False
        self._playback_lock = threading.Lock()
        self._playback_hold_until = 0.0
        self._microphone_muted = threading.Event()
        self._mute_state_lock = threading.Lock()
        self._microphone_muted_since: float | None = None
        self._audio_stream_end_sent_for_mute = False
        self._sent_audio_since_last_stream_end = False

    @property
    def is_running(self) -> bool:
        with self._running_lock:
            return self._running

    def _set_running(self, value: bool) -> None:
        with self._running_lock:
            self._running = value

    @property
    def is_microphone_muted(self) -> bool:
        return self._microphone_muted.is_set()

    def set_microphone_muted(self, muted: bool) -> None:
        """Silencia o reactiva el envío del micrófono sin reiniciar la sesión Live.

        El stream físico de sounddevice permanece abierto, pero mientras el micrófono
        está silenciado no se encolan ni se transmiten chunks. La Live API recomienda
        enviar `audio_stream_end=True` únicamente cuando la pausa de entrada supera
        aproximadamente 1 segundo; por ello el cierre del tramo se programa de forma
        diferida en el bucle emisor, evitando cierres prematuros que pueden provocar
        desconexiones 1006 en algunas sesiones.
        """
        should_mute = bool(muted)
        if should_mute:
            if not self._microphone_muted.is_set():
                self._microphone_muted.set()
                with self._mute_state_lock:
                    self._microphone_muted_since = time.monotonic()
                    self._audio_stream_end_sent_for_mute = False
        else:
            self._microphone_muted.clear()
            with self._mute_state_lock:
                self._microphone_muted_since = None
                self._audio_stream_end_sent_for_mute = False

    def start(self) -> None:
        if self.is_running:
            return
        if not self.settings.has_api_key:
            self._emit(
                AudioUiEvent(
                    "audio_error",
                    "No hay API key configurada. Ingresa la API en Configuración del HUB antes de iniciar el audio.",
                )
            )
            return
        self._stop_flag.clear()
        self._microphone_muted.clear()
        with self._mute_state_lock:
            self._microphone_muted_since = None
            self._audio_stream_end_sent_for_mute = False
            self._sent_audio_since_last_stream_end = False
        with self._playback_lock:
            self._playback_hold_until = 0.0
        self._set_running(True)
        self._thread = threading.Thread(target=self._run_in_thread, name="lematzium-live-audio", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_flag.set()

    def _run_in_thread(self) -> None:
        try:
            asyncio.run(self._run_live_session())
        except LiveAudioError as exc:
            self._emit(AudioUiEvent("audio_error", str(exc)))
        except Exception as exc:  # pragma: no cover - defensivo, depende de SDK/dispositivos
            self._emit(AudioUiEvent("audio_error", f"No se pudo sostener la sesión de audio: {exc}"))
        finally:
            self._set_running(False)
            self._emit(AudioUiEvent("audio_stopped", "Sesión de audio finalizada."))

    async def _run_live_session(self) -> None:
        try:
            from google import genai
            from google.genai import types
        except Exception as exc:  # pragma: no cover - depende del entorno del usuario
            raise LiveAudioError(
                "No se pudo importar google-genai. Abre el módulo desde el HUB para instalar dependencias o ejecuta: pip install google-genai."
            ) from exc

        try:
            import sounddevice as sd
        except Exception as exc:  # pragma: no cover - depende del entorno del usuario
            raise LiveAudioError(
                "El chat por audio requiere sounddevice. Instala la dependencia con: pip install sounddevice."
            ) from exc

        try:
            client = genai.Client(api_key=self.settings.api_key)
        except Exception as exc:  # pragma: no cover - depende del SDK
            raise LiveAudioError(f"No se pudo inicializar el cliente de audio Gemini API: {exc}") from exc

        assistant_name = self.settings.assistant_name.strip() or "LEMATZIUM IA"
        knowledge_tool = {
            "name": "buscar_conocimiento_lematzium",
            "description": (
                "Busca evidencia interna de LEMATZIUM en el manual de uso, la documentación y el código fuente. "
                "Debe utilizarse antes de responder preguntas sobre funcionamiento, auditoría, clases, módulos, "
                "algoritmos, configuración, reportes o rutas del programa."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "consulta": {
                        "type": "string",
                        "description": "Pregunta o tema concreto que debe buscarse en la base de conocimiento de LEMATZIUM.",
                    }
                },
                "required": ["consulta"],
            },
        }
        config: dict[str, Any] = {
            "response_modalities": ["AUDIO"],
            "input_audio_transcription": {},
            "output_audio_transcription": {},
            "speech_config": {
                "voice_config": {
                    "prebuilt_voice_config": {
                        "voice_name": self.settings.audio_voice_name,
                    }
                }
            },
            "realtime_input_config": {
                "automatic_activity_detection": {
                    "disabled": False,
                    "start_of_speech_sensitivity": types.StartSensitivity.START_SENSITIVITY_LOW,
                    "end_of_speech_sensitivity": types.EndSensitivity.END_SENSITIVITY_LOW,
                    # Espera suficiente para no cortar frases naturales ni reaccionar
                    # con tanta facilidad a pausas breves o ruido ambiente.
                    "prefix_padding_ms": 20,
                    "silence_duration_ms": 700,
                }
            },
            "tools": [{"function_declarations": [knowledge_tool]}],
            "system_instruction": {
                "parts": [
                    {
                        "text": (
                            f"Tu nombre visible es {assistant_name}. Eres el asistente experto de LEMATZIUM. "
                            "Responde en español, con claridad técnica, de forma profesional y sin inventar información. "
                            "Cuando te pregunten por LEMATZIUM, su uso, auditoría, capacitación, módulos, reportes, "
                            "algoritmos o código, llama primero a la función buscar_conocimiento_lematzium. "
                            "Usa la evidencia devuelta para responder. Si no hay evidencia suficiente, delimita exactamente qué parte no se confirma. "
                            "No respondas de forma meramente declarativa: guía al usuario con pasos, rutas dentro del programa, verificaciones y advertencias cuando la pregunta sea operativa. "
                            "En conversación por audio, cuando el usuario pida explicar, orientar o capacitar, entrega una respuesta completa y autosuficiente: desarrolla la idea central, los pasos esenciales y el cierre útil antes de terminar; no reduzcas la respuesta a una introducción breve salvo que el usuario pida expresamente concisión. "
                            "Si la pregunta pide cómo se calcula, cómo funciona internamente o solicita un paso a paso algorítmico, desarrolla el cálculo real con datos de entrada, funciones, variables, parámetros, umbrales, fallback, salida del sistema y validación operativa cuando la evidencia recuperada lo permita. "
                            "No digas que el detalle no está documentado si la evidencia de código o la guía técnica lo contiene. "
                            "Si la pregunta es de auditoría, explica la afirmación, la evidencia y su límite. Si es de capacitación, actúa como instructor interno. "
                            f"Modo de respuesta activo: {self.settings.response_mode}."
                        )
                    }
                ]
            },
        }

        loop = asyncio.get_running_loop()
        audio_queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=64)
        output_voice_filter = LiveOutputVoiceFilter(self.settings.audio_voice_filter_label)
        if output_voice_filter.enabled:
            self._emit(AudioUiEvent("audio_status", f"Timbre de salida activo: {output_voice_filter.label}."))
        else:
            self._emit(AudioUiEvent("audio_status", "Timbre de salida activo: Sin filtro."))
        audio_status_once = {"shown": False}

        def input_callback(indata, frames, time_info, status) -> None:  # noqa: ANN001 - callback de sounddevice
            if self._stop_flag.is_set() or self._microphone_muted.is_set() or self._assistant_audio_is_playing():
                return
            if status and not audio_status_once["shown"]:
                audio_status_once["shown"] = True
                self._emit(AudioUiEvent("audio_status", f"Advertencia del micrófono: {status}"))
            chunk = bytes(indata)
            try:
                loop.call_soon_threadsafe(self._queue_audio_chunk, audio_queue, chunk)
            except RuntimeError:
                return

        try:
            async with client.aio.live.connect(model=self.settings.audio_model_id, config=config) as session:
                self._emit(
                    AudioUiEvent(
                        "audio_started",
                        f"Micrófono activo con {self.settings.audio_model_label} · voz {self.settings.audio_voice_name} · timbre {self.settings.audio_voice_filter_label}. Habla para conversar en vivo.",
                    )
                )
                try:
                    with sd.RawInputStream(
                        samplerate=SEND_SAMPLE_RATE,
                        channels=1,
                        dtype="int16",
                        blocksize=INPUT_BLOCKSIZE,
                        callback=input_callback,
                    ) as _input_stream, sd.RawOutputStream(
                        samplerate=RECEIVE_SAMPLE_RATE,
                        channels=1,
                        dtype="int16",
                        blocksize=OUTPUT_BLOCKSIZE,
                    ) as output_stream:
                        sender = asyncio.create_task(self._send_microphone_audio(session, audio_queue, types))
                        receiver = asyncio.create_task(self._receive_live_responses(session, output_stream, types, output_voice_filter))
                        stopper = asyncio.create_task(self._watch_stop())
                        done, pending = await asyncio.wait(
                            {sender, receiver, stopper},
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                        for task in pending:
                            task.cancel()
                        await asyncio.gather(*pending, return_exceptions=True)
                        for task in done:
                            exc = task.exception()
                            if exc is not None:
                                raise exc
                except LiveAudioError:
                    raise
                except Exception as exc:
                    raise LiveAudioError(f"No se pudo capturar o reproducir audio en el equipo: {exc}") from exc
        except LiveAudioError:
            raise
        except Exception as exc:  # pragma: no cover - depende de red/API externa
            raise LiveAudioError(
                f"No se pudo abrir la sesión Live API con {self.settings.audio_model_label}: {exc}"
            ) from exc

    @staticmethod
    def _queue_audio_chunk(queue: asyncio.Queue[bytes], chunk: bytes) -> None:
        try:
            queue.put_nowait(chunk)
        except asyncio.QueueFull:
            try:
                queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
            try:
                queue.put_nowait(chunk)
            except asyncio.QueueFull:
                pass

    async def _watch_stop(self) -> None:
        while not self._stop_flag.is_set():
            await asyncio.sleep(0.15)

    async def _send_microphone_audio(self, session, audio_queue: asyncio.Queue[bytes], types) -> None:  # noqa: ANN001
        while not self._stop_flag.is_set():
            if self._microphone_muted.is_set():
                # Elimina audio residual para que un ruido capturado justo antes del
                # silencio no llegue tarde a la sesión cuando el usuario reactiva el micrófono.
                while True:
                    try:
                        audio_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        break

                should_flush = False
                with self._mute_state_lock:
                    muted_since = self._microphone_muted_since
                    if muted_since is None:
                        self._microphone_muted_since = time.monotonic()
                        muted_since = self._microphone_muted_since
                    muted_long_enough = (time.monotonic() - muted_since) >= 1.05
                    should_flush = (
                        muted_long_enough
                        and not self._audio_stream_end_sent_for_mute
                        and self._sent_audio_since_last_stream_end
                    )
                    if should_flush:
                        self._audio_stream_end_sent_for_mute = True

                if should_flush:
                    try:
                        await session.send_realtime_input(audio_stream_end=True)
                    except Exception as exc:
                        raise LiveAudioError(
                            f"No se pudo marcar el fin del tramo de micrófono silenciado: {exc}"
                        ) from exc
                    with self._mute_state_lock:
                        self._sent_audio_since_last_stream_end = False
                await asyncio.sleep(0.10)
                continue

            try:
                chunk = await asyncio.wait_for(audio_queue.get(), timeout=0.25)
            except TimeoutError:
                continue
            if not chunk or self._microphone_muted.is_set() or self._assistant_audio_is_playing():
                continue
            await session.send_realtime_input(
                audio=types.Blob(data=chunk, mime_type=f"audio/pcm;rate={SEND_SAMPLE_RATE}")
            )
            with self._mute_state_lock:
                self._sent_audio_since_last_stream_end = True
                self._audio_stream_end_sent_for_mute = False

    async def _receive_live_responses(self, session, output_stream, types, output_voice_filter: LiveOutputVoiceFilter) -> None:  # noqa: ANN001
        # `session.receive()` del SDK entrega un único turno completo y luego finaliza
        # su iterador. Por eso se mantiene un bucle externo: de lo contrario la sesión
        # Live se cerraría al terminar la primera respuesta del asistente.
        while not self._stop_flag.is_set():
            user_transcript = ""
            assistant_transcript = ""
            received_any_message = False

            async for response in session.receive():
                received_any_message = True
                if self._stop_flag.is_set():
                    return

                direct_audio = getattr(response, "data", None)
                audio_already_played = bool(direct_audio)
                if direct_audio:
                    # El SDK expone `response.data` como acceso directo al audio de la respuesta.
                    # No se vuelve a escribir la misma carga desde `model_turn.parts`, porque eso
                    # duplica la reproducción y produce un efecto de eco.
                    playback_audio = output_voice_filter.process(direct_audio)
                    self._mark_assistant_audio_playback(playback_audio)
                    try:
                        output_stream.write(playback_audio)
                    except Exception as exc:
                        raise LiveAudioError(f"No se pudo reproducir el audio recibido: {exc}") from exc

                tool_call = getattr(response, "tool_call", None)
                if tool_call is not None:
                    await self._handle_tool_call(session, tool_call, types)
                    continue

                content = getattr(response, "server_content", None)
                if content is None:
                    continue

                if bool(getattr(content, "interrupted", False)):
                    self._emit(
                        AudioUiEvent(
                            "audio_status",
                            "La respuesta de audio fue interrumpida por actividad detectada en el micrófono. Puedes usar Silenciar micrófono mientras escuchas.",
                        )
                    )

                input_transcription = getattr(content, "input_transcription", None)
                user_transcript = self._merge_transcript_fragment(
                    user_transcript,
                    getattr(input_transcription, "text", ""),
                )

                output_transcription = getattr(content, "output_transcription", None)
                assistant_transcript = self._merge_transcript_fragment(
                    assistant_transcript,
                    getattr(output_transcription, "text", ""),
                )

                model_turn = getattr(content, "model_turn", None)
                if not audio_already_played:
                    # Compatibilidad defensiva: si la versión del SDK no llena `response.data`,
                    # se reproduce el audio desde la estructura cruda `model_turn.parts`.
                    for part in getattr(model_turn, "parts", []) or []:
                        inline_data = getattr(part, "inline_data", None)
                        audio_data = getattr(inline_data, "data", b"") if inline_data is not None else b""
                        if isinstance(audio_data, str):
                            try:
                                audio_data = base64.b64decode(audio_data)
                            except Exception:
                                audio_data = b""
                        if audio_data:
                            playback_audio = output_voice_filter.process(audio_data)
                            self._mark_assistant_audio_playback(playback_audio)
                            try:
                                output_stream.write(playback_audio)
                            except Exception as exc:
                                raise LiveAudioError(f"No se pudo reproducir el audio recibido: {exc}") from exc

            # Se muestran una sola burbuja de usuario y una sola del asistente por turno,
            # evitando que las transcripciones parciales aparezcan como mensajes separados.
            self._emit_transcript("audio_user", user_transcript)
            self._emit_transcript("audio_assistant", assistant_transcript)

            # Si el SDK termina el iterador sin entregar ningún mensaje, la sesión ya no
            # tiene contenido útil que procesar y se deja salir para que el controlador
            # informe el cierre real.
            if not received_any_message:
                return

    async def _handle_tool_call(self, session, tool_call, types) -> None:  # noqa: ANN001
        function_responses = []
        for fc in getattr(tool_call, "function_calls", []) or []:
            name = str(getattr(fc, "name", "") or "")
            args = getattr(fc, "args", {}) or {}
            query = str(args.get("consulta") or args.get("query") or args.get("pregunta") or "").strip()
            if name == "buscar_conocimiento_lematzium":
                if not query:
                    query = "LEMATZIUM funcionamiento general"
                self._emit(AudioUiEvent("audio_status", f"Consultando base de conocimiento: {query}"))
                payload = self.knowledge_base.tool_payload(query)
            else:
                payload = {"resultado": "herramienta_no_soportada", "detalle": f"No existe la herramienta {name}."}
            function_responses.append(
                types.FunctionResponse(
                    id=getattr(fc, "id", None),
                    name=name,
                    response=payload,
                )
            )
        if function_responses:
            await session.send_tool_response(function_responses=function_responses)

    @staticmethod
    def _merge_transcript_fragment(current: str, fragment: str) -> str:
        existing = " ".join(str(current or "").split()).strip()
        piece = " ".join(str(fragment or "").split()).strip()
        if not piece:
            return existing
        if not existing:
            return piece
        if piece == existing or existing.endswith(piece):
            return existing
        if piece.startswith(existing):
            return piece

        # El SDK puede enviar fragmentos sucesivos o acumulativos. Si existe solape,
        # se conserva únicamente el texto nuevo; si no, se concatena como continuación.
        max_overlap = min(len(existing), len(piece))
        for size in range(max_overlap, 0, -1):
            if existing[-size:].lower() == piece[:size].lower():
                merged = existing + piece[size:]
                return " ".join(merged.split()).strip()
        return f"{existing} {piece}".strip()

    def _mark_assistant_audio_playback(self, audio_data: bytes) -> None:
        # PCM 16-bit mono a 24 kHz: 2 bytes por muestra. Se añade una cola breve para
        # evitar que el micrófono capture el final reproducido por los parlantes.
        duration = len(audio_data) / float(2 * RECEIVE_SAMPLE_RATE)
        hold_seconds = max(0.18, duration + 0.22)
        now = time.monotonic()
        with self._playback_lock:
            self._playback_hold_until = max(self._playback_hold_until, now + hold_seconds)

    def _assistant_audio_is_playing(self) -> bool:
        with self._playback_lock:
            return time.monotonic() < self._playback_hold_until

    def _emit_transcript(self, kind: str, text: str) -> None:
        clean = " ".join(str(text or "").split()).strip()
        if not clean:
            return
        self._emit(AudioUiEvent(kind, clean))


__all__ = [
    "AudioUiEvent",
    "INPUT_BLOCKSIZE",
    "LiveAudioController",
    "LiveAudioError",
    "LiveOutputVoiceFilter",
    "OUTPUT_BLOCKSIZE",
    "RECEIVE_SAMPLE_RATE",
    "SEND_SAMPLE_RATE",
]
