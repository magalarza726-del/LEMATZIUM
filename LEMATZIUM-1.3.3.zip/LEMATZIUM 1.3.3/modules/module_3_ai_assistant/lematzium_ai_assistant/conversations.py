from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Iterable, Mapping, Any
from uuid import uuid4

CONVERSATIONS_FILENAME = "assistant_conversations.json"
MAX_STORED_TURNS_PER_CONVERSATION = 400


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _safe_str(value: Any, default: str = "") -> str:
    text = str(value or "").strip()
    return text or default


def _suite_root_from_package() -> Path:
    # conversations.py -> lematzium_ai_assistant -> module_3_ai_assistant -> modules -> suite root
    return Path(__file__).resolve().parents[3]


def _conversation_store_path(suite_root: Path | None = None) -> Path:
    root = (suite_root or _suite_root_from_package()).resolve()
    return root / "config" / CONVERSATIONS_FILENAME


def make_title_from_message(message: str, *, limit: int = 54) -> str:
    compact = " ".join(str(message or "").replace("\r", "\n").split()).strip()
    if not compact:
        return "Nueva conversación"
    compact = compact.rstrip("?.!,:;")
    if len(compact) <= limit:
        return compact
    return compact[: limit - 1].rstrip() + "…"


@dataclass
class ConversationTurn:
    role: str
    text: str
    modality: str = "text"
    created_at: str = field(default_factory=_now_iso)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "ConversationTurn":
        role = _safe_str(payload.get("role"), "assistant").lower()
        role = "assistant" if role in {"assistant", "ia", "model"} else "user"
        modality = _safe_str(payload.get("modality"), "text").lower()
        if modality not in {"text", "audio"}:
            modality = "text"
        return cls(
            role=role,
            text=_safe_str(payload.get("text")),
            modality=modality,
            created_at=_safe_str(payload.get("created_at"), _now_iso()),
        )

    def to_mapping(self) -> dict[str, str]:
        return {
            "role": self.role,
            "text": self.text,
            "modality": self.modality,
            "created_at": self.created_at,
        }


@dataclass
class ConversationRecord:
    conversation_id: str
    title: str = "Nueva conversación"
    created_at: str = field(default_factory=_now_iso)
    updated_at: str = field(default_factory=_now_iso)
    turns: list[ConversationTurn] = field(default_factory=list)

    @classmethod
    def empty(cls) -> "ConversationRecord":
        now = _now_iso()
        return cls(conversation_id=uuid4().hex, title="Nueva conversación", created_at=now, updated_at=now)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "ConversationRecord":
        turns_payload = payload.get("turns", [])
        turns: list[ConversationTurn] = []
        if isinstance(turns_payload, list):
            for item in turns_payload:
                if isinstance(item, Mapping):
                    turn = ConversationTurn.from_mapping(item)
                    if turn.text.strip():
                        turns.append(turn)
        now = _now_iso()
        return cls(
            conversation_id=_safe_str(payload.get("conversation_id"), uuid4().hex),
            title=_safe_str(payload.get("title"), "Nueva conversación"),
            created_at=_safe_str(payload.get("created_at"), now),
            updated_at=_safe_str(payload.get("updated_at"), now),
            turns=turns[-MAX_STORED_TURNS_PER_CONVERSATION:],
        )

    def to_mapping(self) -> dict[str, Any]:
        return {
            "conversation_id": self.conversation_id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "turns": [turn.to_mapping() for turn in self.turns[-MAX_STORED_TURNS_PER_CONVERSATION:]],
        }

    def touch(self) -> None:
        self.updated_at = _now_iso()

    def append_turn(self, role: str, text: str, *, modality: str = "text") -> None:
        clean = _safe_str(text)
        if not clean:
            return
        normalized_role = "assistant" if str(role).lower().strip() in {"assistant", "ia", "model"} else "user"
        normalized_modality = "audio" if str(modality).lower().strip() == "audio" else "text"
        self.turns.append(ConversationTurn(role=normalized_role, text=clean, modality=normalized_modality))
        self.turns = self.turns[-MAX_STORED_TURNS_PER_CONVERSATION:]
        if self.title == "Nueva conversación" and normalized_role == "user":
            self.title = make_title_from_message(clean)
        self.touch()

    def edit_turn(self, index: int, new_text: str) -> bool:
        """Edita un turno ya guardado.

        Se admite principalmente para mensajes del usuario, de modo similar a una app de mensajería.
        El método es conservador: conserva rol, modalidad y fecha original, pero actualiza el texto y la marca de modificación del registro.
        """
        if index < 0 or index >= len(self.turns):
            return False
        clean = _safe_str(new_text)
        if not clean:
            return False
        turn = self.turns[index]
        turn.text = clean
        first_user_idx = next((i for i, item in enumerate(self.turns) if item.role == "user"), None)
        if first_user_idx == index:
            self.title = make_title_from_message(clean)
        self.touch()
        return True


class ConversationStore:
    def __init__(self, suite_root: Path | None = None) -> None:
        self.path = _conversation_store_path(suite_root)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._records: dict[str, ConversationRecord] = {}
        self.load()

    def load(self) -> list[ConversationRecord]:
        self._records.clear()
        if not self.path.exists():
            return []
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return []
        rows = payload.get("conversations", []) if isinstance(payload, Mapping) else []
        if not isinstance(rows, list):
            return []
        for item in rows:
            if not isinstance(item, Mapping):
                continue
            record = ConversationRecord.from_mapping(item)
            self._records[record.conversation_id] = record
        return self.list_records()

    def save(self) -> None:
        payload = {
            "schema_version": 1,
            "saved_at": _now_iso(),
            "conversations": [record.to_mapping() for record in self.list_records()],
        }
        temp_path = self.path.with_suffix(self.path.suffix + ".tmp")
        temp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temp_path.replace(self.path)

    def list_records(self) -> list[ConversationRecord]:
        return sorted(self._records.values(), key=lambda record: record.updated_at, reverse=True)

    def get(self, conversation_id: str | None) -> ConversationRecord | None:
        if not conversation_id:
            return None
        return self._records.get(conversation_id)

    def create(self) -> ConversationRecord:
        record = ConversationRecord.empty()
        self._records[record.conversation_id] = record
        self.save()
        return record

    def upsert(self, record: ConversationRecord) -> None:
        self._records[record.conversation_id] = record
        self.save()

    def delete(self, conversation_id: str | None) -> bool:
        if not conversation_id or conversation_id not in self._records:
            return False
        del self._records[conversation_id]
        self.save()
        return True


__all__ = [
    "CONVERSATIONS_FILENAME",
    "ConversationRecord",
    "ConversationStore",
    "ConversationTurn",
    "MAX_STORED_TURNS_PER_CONVERSATION",
    "make_title_from_message",
]
