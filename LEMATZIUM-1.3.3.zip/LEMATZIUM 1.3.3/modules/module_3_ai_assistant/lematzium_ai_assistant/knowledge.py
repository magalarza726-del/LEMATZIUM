from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import unicodedata
import zipfile
from xml.etree import ElementTree as ET
from typing import Iterable

MAX_CONTEXT_CHARS = 42000
MAX_RESULTS = 18

STOPWORDS = {
    "a", "al", "algo", "ante", "así", "bajo", "cada", "como", "con", "contra", "cual", "cuando", "de", "del", "desde", "donde", "dos", "el", "ella", "ellas", "ello", "ellos", "en", "entre", "era", "es", "esa", "esas", "ese", "eso", "esos", "esta", "está", "estas", "este", "esto", "estos", "fue", "ha", "hay", "la", "las", "le", "les", "lo", "los", "más", "me", "mi", "mis", "muy", "no", "o", "para", "pero", "por", "porque", "que", "qué", "se", "ser", "si", "sí", "sin", "sobre", "son", "su", "sus", "te", "tiene", "tienen", "todo", "todos", "tu", "un", "una", "unas", "uno", "unos", "y", "ya",
}

CODE_EXTENSIONS = {".py", ".json"}
DOC_EXTENSIONS = {".md", ".txt", ".docx"}


@dataclass(frozen=True)
class KnowledgeChunk:
    source_id: str
    path: str
    kind: str
    title: str
    start_line: int
    end_line: int
    text: str
    tokens: frozenset[str]


@dataclass(frozen=True)
class KnowledgeHit:
    chunk: KnowledgeChunk
    score: float

    def formatted_header(self, index: int) -> str:
        return (
            f"[Fuente {index} | {self.chunk.kind} | {self.chunk.path} | "
            f"líneas {self.chunk.start_line}-{self.chunk.end_line}]"
        )


@dataclass(frozen=True)
class KnowledgeStats:
    files_indexed: int
    chunks_indexed: int
    last_build_label: str

    def display(self) -> str:
        return f"{self.files_indexed} archivos · {self.chunks_indexed} fragmentos"


ALGORITHM_HINTS = {
    "calculo", "calcular", "cálculo", "algoritmo", "formula", "fórmula", "paso", "pasos",
    "interno", "internamente", "codigo", "código", "funcion", "función", "deteccion", "detección",
    "criterio", "umbral", "fluencia", "offset", "modulo", "módulo", "maximo", "máximo",
}


def _query_tokens_raw(value: str) -> set[str]:
    return set(tokenize(value))


def is_algorithmic_query(query: str) -> bool:
    tokens = _query_tokens_raw(query)
    normalized = normalize(query)
    return bool(tokens & {normalize(token) for token in ALGORITHM_HINTS}) or any(
        phrase in normalized for phrase in (
            "paso a paso", "como se calcula", "cómo se calcula", "como funciona internamente",
            "cómo funciona internamente", "explica el algoritmo", "detalle del calculo", "detalle del cálculo",
        )
    )


def expand_query(query: str) -> str:
    """Expande consultas del usuario con sinónimos y rutas internas relevantes.

    La expansión mejora la recuperación cuando el usuario pregunta con lenguaje natural
    y el código usa nombres de funciones o módulos en inglés.
    """
    base = str(query or "").strip()
    normalized = normalize(base)
    additions: list[str] = []

    if any(term in normalized for term in ("fluencia", "yield", "yp")) and any(term in normalized for term in ("metal", "metales", "modulo 1", "módulo 1")):
        additions.extend([
            "GUIA_EXPLICACION_CLARA_Y_DEFENDIBLE_LEMATZIUM",
            "GUIA_ASTME8_E8M_21_PARA_LEMATZIUM",
            "GUIA_TECNICA_CALCULO_FLUENCIA_METALES",
            "tensile_drop_1mpa detection.py contracts.py controller.py",
            "detect_upper_yield_by_drop _detect_first_peak_with_drop _detect_upper_yield_fallback",
            "DetectionSettings upper_yield_drop_mpa min_required_drop_mpa smoothing_window snap_window_points",
            "first_peak_min_consecutive_drop_points min_candidate_fraction_of_global_max min_candidate_rise_mpa",
            "fallback_smoothing_window fallback_min_required_drop_fraction_of_max fallback_min_work_hardening_gain_mpa",
            "plateau_ratio nonpositive_ratio sustained_drop hardening_gain score",
            "curve.auto_yield curve.manual_yield chosen_yield SelectedPoint",
        ])
    if "offset" in normalized or "rp" in normalized or "r2p" in normalized:
        additions.extend([
            "tensile_offset02_calculator.py Rp offset recta elástica intersección",
            "A B R2P elastic line offset strain stress",
        ])
    if "ejes" in normalized or "grafica" in normalized or "gráfica" in normalized:
        additions.extend([
            "autoajustar gráfica X max Y max X space Y space Home zoom pan",
            "main_window graph axis scale plot",
        ])
    if "reporte" in normalized or "word" in normalized or "export" in normalized:
        additions.extend([
            "exportar Word reportador plantillas fecha emisión OT PDF grupos autoexportación",
            "exporter.py export_dialog.py",
        ])
    if any(term in normalized for term in ("puntos", "ventana", "suavizado", "ruido", "defendible", "auditor", "auditoria", "auditoría", "fuentes", "justificacion", "justificación", "trazabilidad")):
        additions.extend([
            "GUIA_EXPLICACION_CLARA_Y_DEFENDIBLE_LEMATZIUM puntos ventana suavizado ruido defendible fuentes visibles",
            "GUIA_ASTME8_E8M_21_PARA_LEMATZIUM fluencia discontinua ruido datos digitales",
            "GUIA_RESPUESTAS_AUDITORIA_SIN_SOBREAFIRMAR justificar trazabilidad no garantizar base de datos reporte automático manual",
        ])
    if "audio" in normalized or "microfono" in normalized or "micrófono" in normalized:
        additions.extend([
            "audio_live.py LiveAudioController Gemini Live transcripción function calling",
        ])

    if not additions:
        return base
    return base + "\n" + "\n".join(additions)


def _preferred_path_bonus(chunk: "KnowledgeChunk", query: str) -> float:
    normalized_query = normalize(query)
    rel = normalize(chunk.path)
    bonus = 0.0
    assistant_terms = {"asistente", "ia", "gemini", "gemma", "audio", "microfono", "micrófono", "chat", "modelo", "api", "conversacion", "conversación"}
    if "module_3_ai_assistant" in rel and not any(term in normalized_query for term in assistant_terms):
        bonus -= 9.0
    if any(term in normalized_query for term in ("fluencia", "yield", "yp")) and any(term in normalized_query for term in ("metal", "metales", "modulo 1", "módulo 1")):
        if "module_3_ai_assistant" in rel:
            # Evita que el motor de recuperación se cite a sí mismo cuando el usuario
            # pregunta por el algoritmo real del módulo de metales.
            bonus -= 36.0
        if "guia_explicacion_clara_y_defendible_lematzium" in rel:
            bonus += 16.0
        if "guia_astme8_e8m_21_para_lematzium" in rel:
            bonus += 10.0
        if "guia_respuestas_auditoria_sin_sobreafirmar" in rel:
            bonus += 11.0
        if "guia_tecnica_calculo_fluencia_metales" in rel:
            bonus += 14.0
        if "tensile_drop_1mpa/detection.py" in rel:
            bonus += 15.0
        if "tensile_drop_1mpa/contracts.py" in rel:
            bonus += 6.5
        if "tensile_drop_1mpa/controller.py" in rel:
            bonus += 4.5
    if ("offset" in normalized_query or "rp" in normalized_query or "r2p" in normalized_query) and "tensile_offset02" in rel:
        bonus += 5.0
    if is_algorithmic_query(query) and chunk.kind == "Código":
        bonus += 2.25
    if is_algorithmic_query(query) and "docs/knowledge/" in rel:
        bonus += 1.75
    return bonus


def _strip_accents(value: str) -> str:
    return "".join(
        char for char in unicodedata.normalize("NFKD", str(value or ""))
        if not unicodedata.combining(char)
    )


def normalize(value: str) -> str:
    return _strip_accents(str(value or "")).lower().replace("σ", " sigma ").replace("ε", " epsilon ")


def tokenize(value: str) -> list[str]:
    raw = re.findall(r"[a-z0-9_]+", normalize(value))
    return [token for token in raw if len(token) > 1 and token not in STOPWORDS]


def _extract_docx_text(path: Path) -> str:
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    lines: list[str] = []
    with zipfile.ZipFile(path) as zf:
        xml = zf.read("word/document.xml")
    root = ET.fromstring(xml)
    for paragraph in root.findall(".//w:p", ns):
        parts = [node.text or "" for node in paragraph.findall(".//w:t", ns)]
        text = "".join(parts).strip()
        if text:
            lines.append(text)
    return "\n".join(lines)


def _safe_read_text(path: Path) -> str:
    try:
        if path.suffix.lower() == ".docx":
            return _extract_docx_text(path)
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def _chunk_lines(text: str, *, source_id: str, rel_path: str, kind: str, title: str) -> list[KnowledgeChunk]:
    lines = text.splitlines()
    if not lines:
        return []
    chunks: list[KnowledgeChunk] = []
    window = 46 if kind != "Código" else 72
    overlap = 8 if kind != "Código" else 14
    step = max(1, window - overlap)
    for start in range(0, len(lines), step):
        slice_lines = lines[start : start + window]
        if not slice_lines:
            continue
        body = "\n".join(slice_lines).strip()
        if not body:
            continue
        body = body[:4200]
        tokens = frozenset(tokenize(f"{rel_path}\n{title}\n{body}"))
        if not tokens:
            continue
        chunk = KnowledgeChunk(
            source_id=f"{source_id}:{start+1}-{start+len(slice_lines)}",
            path=rel_path,
            kind=kind,
            title=title,
            start_line=start + 1,
            end_line=start + len(slice_lines),
            text=body,
            tokens=tokens,
        )
        chunks.append(chunk)
        if start + window >= len(lines):
            break
    return chunks


def _is_eligible_file(path: Path, root: Path) -> bool:
    suffix = path.suffix.lower()
    if suffix not in CODE_EXTENSIONS | DOC_EXTENSIONS:
        return False
    parts = {part.lower() for part in path.parts}
    if "__pycache__" in parts or ".venv" in parts or "runtime" in parts or "tests" in parts:
        return False
    rel = path.relative_to(root).as_posix().lower()
    if rel.endswith(".pyc") or "/templates/" in rel:
        return False
    if suffix == ".docx" and "docs/knowledge/" not in rel:
        return False
    if suffix == ".txt" and path.with_suffix(".docx").exists():
        # Evita duplicar exactamente el mismo manual cuando se conserva una copia TXT de apoyo.
        return False
    if suffix == ".json" and not (
        rel.startswith("config/")
        or rel.startswith("launcher/")
        or "module_3_ai_assistant" in rel
    ):
        return False
    if suffix in {".md", ".txt"} and not (
        rel.startswith("docs/")
        or "module_3_ai_assistant" in rel
        or rel.endswith("readme.md")
    ):
        return False
    return True


def _kind_for_path(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".py":
        return "Código"
    if suffix == ".json":
        return "Configuración"
    if suffix == ".docx":
        return "Manual DOCX"
    if "manual" in path.name.lower():
        return "Manual"
    return "Documentación"


def _title_from_path(path: Path) -> str:
    return path.stem.replace("_", " ").replace("-", " ").strip() or path.name


def _suite_root_from_package() -> Path:
    # knowledge.py -> lematzium_ai_assistant -> module_3_ai_assistant -> modules -> suite root
    return Path(__file__).resolve().parents[3]


class LematZiumKnowledgeBase:
    def __init__(self, suite_root: Path | None = None) -> None:
        self.suite_root = (suite_root or _suite_root_from_package()).resolve()
        self._chunks: list[KnowledgeChunk] = []
        self._files_indexed = 0
        self._build_counter = 0
        self.rebuild()

    @property
    def stats(self) -> KnowledgeStats:
        label = f"recarga {self._build_counter}" if self._build_counter else "sin construir"
        return KnowledgeStats(
            files_indexed=self._files_indexed,
            chunks_indexed=len(self._chunks),
            last_build_label=label,
        )

    def rebuild(self) -> KnowledgeStats:
        chunks: list[KnowledgeChunk] = []
        files_indexed = 0
        for path in sorted(self.suite_root.rglob("*")):
            if not path.is_file() or not _is_eligible_file(path, self.suite_root):
                continue
            text = _safe_read_text(path)
            if not text.strip():
                continue
            rel = path.relative_to(self.suite_root).as_posix()
            kind = _kind_for_path(path)
            title = _title_from_path(path)
            source_id = re.sub(r"[^a-zA-Z0-9_.-]+", "_", rel)
            file_chunks = _chunk_lines(text, source_id=source_id, rel_path=rel, kind=kind, title=title)
            if file_chunks:
                files_indexed += 1
                chunks.extend(file_chunks)
        self._chunks = chunks
        self._files_indexed = files_indexed
        self._build_counter += 1
        return self.stats

    def search(self, query: str, *, max_results: int = MAX_RESULTS) -> list[KnowledgeHit]:
        expanded_query = expand_query(query)
        query_tokens = tokenize(expanded_query)
        if not query_tokens:
            return []
        qset = set(query_tokens)
        phrase = normalize(query).strip()
        hits: list[KnowledgeHit] = []
        algorithmic = is_algorithmic_query(query)
        for chunk in self._chunks:
            overlap = qset & set(chunk.tokens)
            if not overlap:
                continue
            score = float(len(overlap))
            score += 0.35 * sum(1 for token in overlap if token in normalize(chunk.path))
            score += 0.25 * sum(1 for token in overlap if token in normalize(chunk.title))
            low_text = normalize(chunk.text)
            if phrase and len(phrase) > 5 and phrase in low_text:
                score += 4.0
            if "manual" in normalize(chunk.kind) and any(token in qset for token in {"usar", "uso", "boton", "exportar", "instalar", "operar"}):
                score += 0.75
            if chunk.kind == "Código" and any(token in qset for token in {"codigo", "funcion", "archivo", "clase", "metodo", "calculo", "algoritmo", "deteccion"}):
                score += 1.35 if algorithmic else 0.75
            if algorithmic and chunk.kind in {"Documentación", "Manual DOCX"}:
                score += 0.25
            score += _preferred_path_bonus(chunk, query)
            score += min(0.8, len(overlap) / max(1, len(qset)))
            hits.append(KnowledgeHit(chunk=chunk, score=score))
        hits.sort(key=lambda hit: (-hit.score, hit.chunk.path, hit.chunk.start_line))
        return hits[: max(1, int(max_results))]

    def context_for_prompt(self, query: str, *, max_results: int = MAX_RESULTS, max_chars: int = MAX_CONTEXT_CHARS) -> tuple[str, list[KnowledgeHit]]:
        algorithmic = is_algorithmic_query(query)
        effective_results = max(max_results, 18) if algorithmic else max_results
        effective_chars = max(max_chars, 42000) if algorithmic else max_chars
        hits = self.search(query, max_results=effective_results)
        if not hits:
            return "No se recuperó evidencia interna suficiente para esta consulta.", []
        blocks: list[str] = []
        used = 0
        selected: list[KnowledgeHit] = []
        for idx, hit in enumerate(hits, start=1):
            block = f"{hit.formatted_header(idx)}\n{hit.chunk.text.strip()}"
            if used + len(block) > effective_chars and selected:
                break
            blocks.append(block)
            selected.append(hit)
            used += len(block)
        return "\n\n".join(blocks), selected

    def tool_payload(self, query: str, *, max_results: int = 6) -> dict[str, object]:
        context, hits = self.context_for_prompt(query, max_results=max_results, max_chars=9000)
        return {
            "consulta": query,
            "evidencia": context,
            "fuentes": [
                {
                    "ruta": hit.chunk.path,
                    "tipo": hit.chunk.kind,
                    "lineas": f"{hit.chunk.start_line}-{hit.chunk.end_line}",
                    "puntaje": round(hit.score, 3),
                }
                for hit in hits
            ],
            "resultado": "ok" if hits else "sin_evidencia",
        }


__all__ = [
    "KnowledgeChunk",
    "KnowledgeHit",
    "KnowledgeStats",
    "LematZiumKnowledgeBase",
    "MAX_CONTEXT_CHARS",
    "MAX_RESULTS",
    "expand_query",
    "is_algorithmic_query",
    "normalize",
    "tokenize",
]
