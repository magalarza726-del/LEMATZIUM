from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .knowledge import LematZiumKnowledgeBase, KnowledgeHit, is_algorithmic_query
from .settings import AssistantSettings, TEXT_MODEL_IDS

MAX_HISTORY_TURNS = 16
MAX_CHARS_PER_TURN = 3200


@dataclass(frozen=True)
class ChatTurn:
    role: str
    text: str

    def normalized_role(self) -> str:
        return "assistant" if self.role.lower().strip() in {"assistant", "model", "ia"} else "user"


@dataclass(frozen=True)
class ChatReply:
    text: str
    model_label: str
    model_id: str
    fallback_from: str | None = None
    notice: str | None = None
    knowledge_sources: tuple[str, ...] = ()



def _clean_text(text: str, *, limit: int = MAX_CHARS_PER_TURN) -> str:
    compact = " ".join(str(text or "").replace("\r", "\n").split())
    if len(compact) <= limit:
        return compact
    return compact[: limit - 1].rstrip() + "…"



def _mode_instructions(settings: AssistantSettings) -> list[str]:
    """Instrucciones de estilo según el modo elegido en configuración.

    Todos los modos deben ser útiles para el usuario: una respuesta técnicamente correcta
    que no guía la acción práctica no cumple el objetivo del asistente interno.
    """
    mode = settings.response_mode
    if mode == "Capacitación":
        return [
            "Modo activo: Capacitación.",
            "Actúa como instructor interno de LEMATZIUM. Explica paso a paso, anticipa errores frecuentes y guía al usuario hasta completar la tarea.",
            "Cuando la pregunta sea operativa, responde con: objetivo, ruta dentro del programa, pasos numerados, qué verificar y errores comunes.",
            "Cuando la pregunta sea conceptual o de cálculo, explica el principio, cómo lo aplica LEMATZIUM y cómo el analista debe validarlo.",
            "Incluye una mini comprobación práctica o pregunta de autoevaluación solo cuando aporte valor.",
        ]
    if mode == "Soporte técnico":
        return [
            "Modo activo: Soporte técnico.",
            "Prioriza diagnóstico práctico, rutas de verificación y acciones concretas para resolver dudas del programa.",
            "Cuando exista un problema, ordena la respuesta como: causa probable, verificación en pantalla/código y acción recomendada.",
            "Distingue entre funcionamiento observado en el código, procedimiento descrito en el manual y recomendaciones operativas.",
        ]
    return [
        "Modo activo: Auditoría estricta.",
        "Responde sobre LEMATZIUM solo con base en evidencia interna recuperada del manual, documentación o código.",
        "No exageres la incertidumbre: si la evidencia permite confirmar una idea, exprésala con claridad; si no alcanza, di exactamente qué parte no quedó confirmada.",
        "Distingue explícitamente lo confirmado por manual, lo confirmado por código y lo no documentado cuando la pregunta lo requiera.",
        "Aunque el modo sea de auditoría, guía al auditor o analista: explica cómo verificarlo en la interfaz, qué evidencia inspeccionar y qué límites tiene la afirmación.",
        "Si la consulta es un saludo, agradecimiento o conversación general sin afirmaciones sobre la app, responde de forma cordial y breve sin mencionar falta de evidencia.",
    ]


def _knowledge_source_labels(hits: Sequence[KnowledgeHit]) -> tuple[str, ...]:
    labels: list[str] = []
    for idx, hit in enumerate(hits, start=1):
        snippet = " ".join(hit.chunk.text.strip().split())[:360]
        label = (
            f"Fuente {idx}: {hit.chunk.kind} | {hit.chunk.path} | "
            f"líneas {hit.chunk.start_line}-{hit.chunk.end_line}\n"
            f"Extracto: {snippet}{'…' if len(snippet) >= 360 else ''}"
        )
        if label not in labels:
            labels.append(label)
    return tuple(labels)




def _deep_answer_instructions(user_message: str) -> list[str]:
    """Instrucciones adicionales para preguntas que exigen profundidad algorítmica."""
    if not is_algorithmic_query(user_message):
        return []
    return [
        "La consulta actual exige una respuesta algorítmica profunda, clara y defendible, no un resumen superficial.",
        "Empieza con una explicación simple: qué intenta encontrar el programa y por qué. Usa analogías breves cuando ayuden.",
        "Después desarrolla el cálculo interno paso a paso y nombra funciones, variables, umbrales y decisiones de flujo que aparezcan en la evidencia.",
        "Si aparecen valores como 7 puntos, 3 puntos o 18 puntos, explica siempre que un punto es una fila/medición del CSV, no una unidad fija de longitud o tiempo; depende de cómo la máquina registró los datos.",
        "Si el código muestra suavizado, explica por qué existe, qué riesgo evita, si modifica o no el CSV, y si el valor final vuelve o no a la señal bruta.",
        "Si el código muestra dos fases o fallback, explícalas por separado y en orden de ejecución, aclarando cuándo entra cada una.",
        "Si el código contiene fórmulas o ecuaciones, escríbelas en texto claro y explica qué representa cada variable.",
        "Si el resultado final se almacena en atributos o diagnósticos, indícalo, pero no exageres la trazabilidad si el código no guarda una traza completa.",
        "Si existe prioridad de punto manual sobre automático, explícalo y diferencia cálculo automático vs decisión del analista.",
        "Anticipa dudas de auditoría aunque el usuario no las formule: justificación del criterio, límites, validación necesaria y cómo comprobarlo en pantalla.",
        "Cuando el usuario pida una justificación, no te limites al algoritmo: explica también si el criterio es heurístico, qué riesgo controla y qué evidencia faltaría para blindarlo en auditoría.",
        "Si el usuario comparte una justificación escrita, detecta sobreafirmaciones y corrígelas con lenguaje defendible.",
        "No digas que el detalle algorítmico no está desglosado si el código o la guía técnica recuperada sí lo detallan.",
        "Estructura preferida: 1) en simple, 2) qué significa cada número/umbral, 3) algoritmo real paso a paso, 4) por qué es defendible, 5) qué debe validar el usuario, 6) límite o mejora recomendada.",
    ]


def build_prompt(
    history: Sequence[ChatTurn],
    user_message: str,
    settings: AssistantSettings,
    knowledge_context: str,
    knowledge_hits: Sequence[KnowledgeHit],
) -> str:
    assistant_name = settings.assistant_name.strip() or "LEMATZIUM IA"
    lines = [
        f"Tu nombre visible es {assistant_name}.",
        "Eres el asistente experto de LEMATZIUM.",
        "Responde en español, con claridad técnica, precisión documental y orientación práctica.",
        "Tu estilo debe ser parecido a un buen instructor: primero fácil de entender, luego técnico y defendible.",
        "No des por entendido un término interno: si hablas de suavizado, puntos, ventana, umbral, fallback, offset, trazabilidad o fuente, explícalo en lenguaje sencillo.",
        "Cuando una acción del programa pueda parecer cuestionable en auditoría, justifica por qué existe, qué evita, qué no modifica y qué debe validarse.",
        "Anticipa dudas razonables aunque el usuario no las formule: explica por qué una decisión del programa es defendible, qué límite tiene y cómo se comprobaría.",
        "Cuando aparezcan cantidades como 7 puntos, 3 puntos o 18 puntos, aclara siempre que son mediciones consecutivas del CSV, no unidades fijas de tiempo, distancia o esfuerzo.",
        "No conviertas objetos internos, diagnósticos o archivos de configuración en una 'base de datos' si la fuente no lo confirma.",
        "No digas que el reporte imprime o conserva una traza completa automático/manual salvo que la evidencia del exportador o la plantilla lo demuestre.",
        "Tu prioridad es responder sobre el uso, la arquitectura, el código, la trazabilidad, la auditoría y la capacitación de LEMATZIUM.",
        "Cita dentro de tu respuesta las referencias [Fuente 1], [Fuente 2], etc., únicamente cuando uses la evidencia recuperada.",
        "No afirmes haber modificado archivos, enviado correos o ejecutado acciones fuera de esta conversación.",
        "No inventes botones, rutas, algoritmos ni resultados. Cuando algo no esté probado por la evidencia, delimítalo.",
        *_mode_instructions(settings),
        *_deep_answer_instructions(user_message),
        "",
        "Evidencia interna recuperada:",
        knowledge_context,
        "",
        "Reglas para usar la evidencia:",
        "- No conviertas una recomendación documental en una afirmación de código si no está implementada.",
        "- No conviertas una función de código en un procedimiento operativo si el manual no lo respalda.",
        "- Si la pregunta es operativa, guía al usuario como si estuviera frente a la pantalla: ruta, pasos, verificación y advertencias.",
        "- Si la pregunta es sobre cálculo o algoritmo, explica el cálculo interno real con secuencia de funciones, variables, criterios numéricos, fallback, salida guardada y validación; evita limitarte al principio general.",
        "- Si la pregunta es de auditoría, responde de forma defendible: afirmación, evidencia, alcance y límite.",
        "- Si la evidencia recuperada es parcial, aprovecha lo que sí está confirmado y declara con precisión la porción no documentada.",
        "",
        "Formato de respuesta recomendado:",
        "- Evita Markdown pesado porque la interfaz prioriza lectura limpia. No uses ###, ** ni bloques de código extensos salvo que el usuario los solicite.",
        "- Usa títulos simples seguidos de dos puntos, párrafos breves y listas numeradas cuando haya pasos.",
        "- En preguntas de uso, incluye normalmente: 'Qué hace', 'Cómo hacerlo', 'Qué verificar' y 'Errores o límites'.",
        "- En preguntas de auditoría o código, incluye normalmente: 'En simple', 'Qué significan los números', 'Algoritmo interno paso a paso', 'Por qué es defendible', 'Qué debe validar el usuario' y 'Límite de evidencia'.",
        "- La profundidad debe ser suficiente para que un analista nuevo ejecute la acción o un auditor entienda el razonamiento sin pedir una aclaración básica.",
        "- Cuando cites fuentes, no dependas solo de [Fuente X]; al final la interfaz mostrará las fuentes visibles. Tu respuesta debe ser comprensible incluso sin abrirlas.",
        "",
        "Conversación previa:",
    ]
    recent = list(history[-MAX_HISTORY_TURNS:])
    if not recent:
        lines.append("(sin mensajes previos)")
    else:
        for turn in recent:
            role = "Usuario" if turn.normalized_role() == "user" else assistant_name
            lines.append(f"{role}: {_clean_text(turn.text)}")
    lines.extend(
        [
            "",
            f"Usuario: {_clean_text(user_message)}",
            f"{assistant_name}:",
        ]
    )
    return "\n".join(lines)


class GeminiApiError(RuntimeError):
    """Error de integración normalizado para la UI."""



def _extract_response_text(response) -> str:
    text = str(getattr(response, "text", "") or "").strip()
    if text:
        return text

    # Fallback defensivo para respuestas del SDK que no exponen .text.
    try:
        chunks: list[str] = []
        for candidate in getattr(response, "candidates", []) or []:
            content = getattr(candidate, "content", None)
            for part in getattr(content, "parts", []) or []:
                part_text = getattr(part, "text", "")
                if part_text and not getattr(part, "thought", False):
                    chunks.append(str(part_text))
        joined = "\n".join(chunks).strip()
        if joined:
            return joined
    except Exception:
        pass
    return ""



def _is_quota_or_availability_error(exc: Exception) -> bool:
    """Detecta agotamiento de cuota/rate limit o indisponibilidad transitoria."""
    raw = " ".join(
        [
            str(exc or ""),
            str(getattr(exc, "message", "") or ""),
            str(getattr(exc, "status_code", "") or ""),
            str(getattr(exc, "code", "") or ""),
        ]
    ).lower()
    markers = (
        "429",
        "503",
        "resource_exhausted",
        "resource exhausted",
        "quota",
        "rate limit",
        "rate_limit",
        "too many requests",
        "requests per minute",
        "requests per day",
        "tokens per minute",
        "temporarily unavailable",
        "service unavailable",
        "model is overloaded",
        "overloaded",
        "capacity",
    )
    return any(marker in raw for marker in markers)


class GeminiChatBackend:
    def __init__(self, settings: AssistantSettings, knowledge_base: LematZiumKnowledgeBase | None = None) -> None:
        self.settings = settings
        self.active_text_model_label = settings.text_model_label
        self.knowledge_base = knowledge_base or LematZiumKnowledgeBase()

    def _client(self):
        if not self.settings.has_api_key:
            raise GeminiApiError(
                "No hay API key configurada. Ingresa la API en Configuración del HUB o define GOOGLE_API_KEY/GEMINI_API_KEY."
            )
        try:
            from google import genai
        except Exception as exc:  # pragma: no cover - depende del entorno del usuario
            raise GeminiApiError(
                "No se pudo importar google-genai. Instala la dependencia o vuelve a abrir el módulo desde el HUB para permitir la instalación automática."
            ) from exc
        try:
            return genai.Client(api_key=self.settings.api_key)
        except Exception as exc:  # pragma: no cover - depende del SDK
            raise GeminiApiError(f"No se pudo inicializar el cliente Gemini API: {exc}") from exc

    def _generation_config(self, model_label: str):
        if model_label != "Gemma 4 31B" or not self.settings.gemma_thinking_enabled:
            return None
        try:
            from google.genai import types
        except Exception as exc:  # pragma: no cover - depende del entorno del usuario
            raise GeminiApiError(
                "Gemma 4 Thinking requiere google-genai actualizado. Reinstala con: pip install -U google-genai."
            ) from exc
        return types.GenerateContentConfig(
            thinking_config=types.ThinkingConfig(thinking_level="high")
        )

    def _candidate_labels(self) -> list[str]:
        active = self.active_text_model_label if self.active_text_model_label in TEXT_MODEL_IDS else self.settings.text_model_label
        labels = [active]
        labels.extend(label for label in TEXT_MODEL_IDS if label != active)
        return labels

    def generate_reply(self, history: Sequence[ChatTurn], user_message: str) -> ChatReply:
        user_message = str(user_message or "").strip()
        if not user_message:
            raise GeminiApiError("Escribe un mensaje antes de enviarlo.")

        knowledge_context, knowledge_hits = self.knowledge_base.context_for_prompt(user_message)
        prompt = build_prompt(history, user_message, self.settings, knowledge_context, knowledge_hits)
        client = self._client()
        fallback_error: Exception | None = None
        fallback_from: str | None = None

        for attempt, model_label in enumerate(self._candidate_labels(), start=1):
            model_id = TEXT_MODEL_IDS[model_label]
            try:
                generation_config = self._generation_config(model_label)
                if generation_config is None:
                    response = client.models.generate_content(model=model_id, contents=prompt)
                else:
                    response = client.models.generate_content(model=model_id, contents=prompt, config=generation_config)
                text = _extract_response_text(response)
                if not text:
                    raise GeminiApiError("El modelo respondió sin texto utilizable.")

                notice = None
                if fallback_from and model_label != fallback_from:
                    self.active_text_model_label = model_label
                    notice = (
                        f"Aviso: {fallback_from} no estuvo disponible por cuota, límite de uso o saturación temporal. "
                        f"LEMATZIUM cambió automáticamente a {model_label} para continuar la conversación."
                    )
                return ChatReply(
                    text=text,
                    model_label=model_label,
                    model_id=model_id,
                    fallback_from=fallback_from,
                    notice=notice,
                    knowledge_sources=_knowledge_source_labels(knowledge_hits),
                )
            except GeminiApiError:
                raise
            except Exception as exc:  # pragma: no cover - red/API externa
                if attempt == 1 and _is_quota_or_availability_error(exc):
                    fallback_error = exc
                    fallback_from = model_label
                    continue
                if fallback_from:
                    raise GeminiApiError(
                        f"{fallback_from} no estuvo disponible y el modelo alternativo {model_label} tampoco respondió. "
                        f"Detalle del último intento: {exc}"
                    ) from exc
                raise GeminiApiError(
                    f"La solicitud al modelo {model_label} no se completó: {exc}"
                ) from exc

        if fallback_from and fallback_error is not None:
            raise GeminiApiError(
                f"{fallback_from} no estuvo disponible y no se encontró un modelo alternativo operativo. Detalle: {fallback_error}"
            )
        raise GeminiApiError("No se pudo generar una respuesta con los modelos configurados.")


__all__ = [
    "ChatReply",
    "ChatTurn",
    "GeminiApiError",
    "GeminiChatBackend",
    "MAX_CHARS_PER_TURN",
    "MAX_HISTORY_TURNS",
    "build_prompt",
]
