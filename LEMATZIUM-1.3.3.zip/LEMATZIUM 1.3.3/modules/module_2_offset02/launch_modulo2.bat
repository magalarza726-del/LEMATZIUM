@echo off
setlocal
cd /d "%~dp0"
python launch_modulo2.py
endlocal
