Set WshShell = CreateObject("WScript.Shell")
DesktopPath = WshShell.SpecialFolders("Desktop")
Set Shortcut = WshShell.CreateShortcut(DesktopPath & "\LEMATZIUM Módulo 2 v1.1.1.lnk")
Shortcut.TargetPath = WshShell.CurrentDirectory & "\launch_modulo2.bat"
Shortcut.WorkingDirectory = WshShell.CurrentDirectory
Shortcut.Description = "LEMATZIUM Módulo 2 v1.1.1"
Shortcut.Save
