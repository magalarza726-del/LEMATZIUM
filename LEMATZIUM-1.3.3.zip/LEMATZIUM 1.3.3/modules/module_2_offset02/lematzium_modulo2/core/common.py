from __future__ import annotations

import csv
import math
import re
from pathlib import Path
from typing import Any, Sequence

import numpy as np


def as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and math.isnan(value):
        return ""
    return str(value).replace("﻿", "").strip()


def as_float(value: Any, default: float = np.nan) -> float:
    if value is None:
        return default
    if isinstance(value, (int, float, np.integer, np.floating)):
        try:
            return float(value)
        except Exception:
            return default
    text = as_text(value)
    if not text:
        return default
    text = text.replace(" ", "").replace(",", ".")
    text = re.sub(r"(?i)(mm|mpa|kn|seg|s|%)$", "", text).strip()
    try:
        return float(text)
    except Exception:
        return default


def is_blank_row(row: Sequence[Any]) -> bool:
    return all(as_text(x) == "" for x in row)


def normalize_row(row: Sequence[Any]) -> list[str]:
    return [as_text(x) for x in row]


def detect_delimiter_from_bytes(content: bytes) -> str:
    sample = content[:10000].decode("latin1", errors="ignore")
    for delim in [",", ";", "	", "|"]:
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=[delim])
            return dialect.delimiter
        except Exception:
            pass
    counts = {d: sample.count(d) for d in [",", ";", "	", "|"]}
    return max(counts, key=counts.get)


def make_unique_name(base: str, seen: dict[str, int]) -> str:
    base = as_text(base) or "Specimen"
    count = seen.get(base, 0) + 1
    seen[base] = count
    return base if count == 1 else f"{base}_R{count}"


def sanitize_filename(name: str) -> str:
    return re.sub(r"[^\w\-. ]+", "_", as_text(name)).strip().replace(" ", "_")


def rolling_mean(values, window: int):
    import pandas as pd
    if window <= 1:
        return np.asarray(values, dtype=float)
    return pd.Series(np.asarray(values, dtype=float)).rolling(window, center=True, min_periods=1).mean().to_numpy()


def first_nonempty_index(rows: list[list[str]], predicate, start: int = 0):
    for i in range(start, len(rows)):
        if predicate(rows[i]):
            return i
    return None
