from __future__ import annotations


def main() -> int:
    from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_ui import launch_tensile_offset02_app
    launch_tensile_offset02_app()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
