"""Reservado para integración futura con plantillas Word institucionales."""
