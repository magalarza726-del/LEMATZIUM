"""Reservado para exportación futura dentro de LEMATZIUM."""
