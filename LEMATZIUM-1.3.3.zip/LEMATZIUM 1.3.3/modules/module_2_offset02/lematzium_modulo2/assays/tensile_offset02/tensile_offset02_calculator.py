from __future__ import annotations

from typing import Optional

import numpy as np

from lematzium_modulo2.core.common import rolling_mean
from .tensile_offset02_models import (
    TensileOffset02CurveData,
    TensileOffset02LineHandles,
    TensileOffset02Point,
    normalize_shape,
)


DEFAULT_OFFSET_PERCENT = 0.2


def normalize_offset_percent(value: Optional[float], default: float = DEFAULT_OFFSET_PERCENT) -> float:
    """Normaliza el offset Rp expresado en porcentaje de L0.

    Mantiene Rp0.2 como valor predeterminado histórico. Si el valor es
    inválido, nulo o no positivo, vuelve a 0.2 para no romper el flujo actual.
    """
    try:
        offset = float(value)
    except (TypeError, ValueError):
        offset = float(default)
    if not np.isfinite(offset) or offset <= 0:
        offset = float(default)
    return offset


def format_rp_label(offset_percent: Optional[float]) -> str:
    """Devuelve la etiqueta visible del método Rp: Rp0.2, Rp0.5, Rp1, etc."""
    offset = normalize_offset_percent(offset_percent)
    text = f"{offset:.6g}"
    return f"Rp{text}"


def get_curve_offset_percent(curve: TensileOffset02CurveData) -> float:
    return normalize_offset_percent(getattr(curve, "offset_percent", DEFAULT_OFFSET_PERCENT))


def set_tensile_offset02_offset_percent(curve: TensileOffset02CurveData, offset_percent: Optional[float]) -> float:
    """Actualiza el offset de una curva y devuelve el valor normalizado."""
    normalized = normalize_offset_percent(offset_percent)
    curve.offset_percent = normalized
    curve.diagnostics["offset_percent"] = normalized
    curve.diagnostics["rp_label"] = format_rp_label(normalized)
    return normalized


def create_point_from_index(curve: TensileOffset02CurveData, index: int, source: str, note: str = "") -> TensileOffset02Point:
    df = curve.df
    index = int(max(0, min(index, len(df) - 1)))
    row = df.iloc[index]
    return TensileOffset02Point(index=index, x_mm=float(row["elongation_mm"]), y_mpa=float(row["stress_MPa"]), source=source, note=note)


def _safe_gradient(y: np.ndarray, x: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    if len(y) < 2 or len(x) < 2:
        return np.zeros_like(y)
    dx = np.diff(x)
    dy = np.diff(y)
    core = np.divide(dy, dx, out=np.zeros_like(dy, dtype=float), where=np.abs(dx) > 1e-12)
    if len(core) == 1:
        return np.full_like(y, core[0], dtype=float)
    g = np.empty_like(y, dtype=float)
    g[1:-1] = (core[:-1] + core[1:]) / 2.0
    g[0] = core[0]
    g[-1] = core[-1]
    return np.nan_to_num(g, nan=0.0, posinf=0.0, neginf=0.0)


def _weighted_linear_fit(xs: np.ndarray, ys: np.ndarray, weights: np.ndarray):
    xs = np.asarray(xs, dtype=float)
    ys = np.asarray(ys, dtype=float)
    weights = np.asarray(weights, dtype=float)
    if len(xs) < 2:
        return None
    W = np.sqrt(np.clip(weights, 1e-12, None))
    A = np.vstack([xs, np.ones(len(xs))]).T
    Aw = A * W[:, None]
    yw = ys * W
    m, b = np.linalg.lstsq(Aw, yw, rcond=None)[0]
    y_pred = m * xs + b
    w_mean = float(np.average(ys, weights=weights))
    ss_res = float(np.sum(weights * (ys - y_pred) ** 2))
    ss_tot = float(np.sum(weights * (ys - w_mean) ** 2))
    r2 = 1.0 if ss_tot <= 1e-12 else 1.0 - ss_res / ss_tot
    return float(m), float(b), float(r2), y_pred


def _find_bend_onset_index(x: np.ndarray, grad: np.ndarray, peak_grad_idx: int, peak_grad: float) -> int:
    search_start = min(len(x) - 3, peak_grad_idx + 12)
    if search_start >= len(x) - 3:
        return min(len(x) - 2, peak_grad_idx + 20)
    drop_threshold = 0.62 * peak_grad
    hard_drop_threshold = 0.48 * peak_grad
    for i in range(search_start, len(x) - 8):
        local = grad[i:i + 8]
        if len(local) < 4:
            break
        if np.nanmedian(local) <= hard_drop_threshold:
            return i
        if np.nanmedian(local) <= drop_threshold and np.nanmedian(grad[i + 4:i + 12]) <= drop_threshold:
            return i
    return min(len(x) - 2, search_start + 40)


def detect_tensile_offset02_maximum(curve: TensileOffset02CurveData) -> TensileOffset02Point:
    df = curve.df
    if df.empty or "stress_MPa" not in df.columns:
        return TensileOffset02Point(note="Sin esfuerzo para máximo.")
    idx = int(df["stress_MPa"].astype(float).idxmax())
    return create_point_from_index(curve, idx, source="auto", note="Máximo automático")


def detect_tensile_offset02_auto_line_handles(curve: TensileOffset02CurveData) -> TensileOffset02LineHandles:
    """
    Busca una recta automática que priorice la coincidencia en la zona alta del tramo lineal,
    justo antes de que la curva empiece a torcerse. Visualmente esto hace que la recta se vea
    más coincidente arriba que abajo, como suele hacer el analista.
    """
    df = curve.df
    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)
    if len(x) < 20:
        a_idx = 0
        b_idx = min(len(x) - 1, max(1, len(x) // 4))
        return TensileOffset02LineHandles(
            point_a=create_point_from_index(curve, a_idx, "auto", "A auto"),
            point_b=create_point_from_index(curve, b_idx, "auto", "B auto"),
            source="auto",
        )

    y_smooth = rolling_mean(y, 7)
    grad = rolling_mean(_safe_gradient(y_smooth, x), 9)
    max_y_idx = int(np.nanargmax(y_smooth))
    x_at_max_y = float(x[max_y_idx]) if max_y_idx < len(x) else float(np.nanmax(x))
    early_limit_x = max(x_at_max_y * 0.35, float(np.nanmax(x)) * 0.12)
    early_idxs = np.where((x <= early_limit_x) & np.isfinite(grad))[0]
    if len(early_idxs) < 15:
        early_idxs = np.arange(min(len(x), max(18, len(x) // 5)))

    peak_grad_idx = int(early_idxs[np.argmax(grad[early_idxs])])
    peak_grad = float(grad[peak_grad_idx]) if np.isfinite(grad[peak_grad_idx]) else 0.0
    if peak_grad <= 0:
        a_idx = int(max(0, peak_grad_idx - 8))
        b_idx = int(min(len(x) - 1, peak_grad_idx + 18))
        return TensileOffset02LineHandles(
            point_a=create_point_from_index(curve, a_idx, "auto", "A auto"),
            point_b=create_point_from_index(curve, b_idx, "auto", "B auto"),
            source="auto",
        )

    bend_idx = _find_bend_onset_index(x, grad, peak_grad_idx, peak_grad)
    search_end_min = max(peak_grad_idx + 16, bend_idx - 30)
    search_end_max = min(len(x) - 2, bend_idx + 18)

    best = None
    best_score = -1e18
    min_points = 14
    max_points = min(120, search_end_max)
    for end in range(search_end_min, search_end_max + 1, 2):
        for win in range(min_points, max_points + 1, 4):
            start = end - win + 1
            if start < 0:
                continue
            xs = x[start:end + 1]
            ys = y[start:end + 1]
            gs = grad[start:end + 1]
            if len(xs) < 6 or np.any(np.diff(xs) <= 0):
                continue
            mean_grad = float(np.nanmedian(gs))
            top_grad = float(np.nanmedian(gs[max(0, len(gs) * 2 // 3):]))
            if mean_grad < 0.45 * peak_grad or top_grad < 0.32 * peak_grad:
                continue
            # Ponderar más la zona alta del segmento para que la coincidencia arriba mande.
            weights = np.linspace(0.35, 2.75, len(xs)) ** 1.35
            fit = _weighted_linear_fit(xs, ys, weights)
            if fit is None:
                continue
            m, b, r2, y_pred = fit
            if not np.isfinite(m) or m <= 0:
                continue
            upper_slice = slice(max(0, int(len(xs) * 0.60)), len(xs))
            upper_rmse = float(np.sqrt(np.mean((ys[upper_slice] - y_pred[upper_slice]) ** 2)))
            all_rmse = float(np.sqrt(np.mean((ys - y_pred) ** 2)))
            upper_bias = float(np.mean(np.abs((ys[upper_slice] - y_pred[upper_slice]))))
            end_penalty = abs(end - bend_idx)
            start_penalty = max(0, peak_grad_idx - start)
            score = (
                r2 * 9000.0
                + (m / max(peak_grad, 1e-9)) * 900.0
                + len(xs) * 5.0
                - upper_rmse * 220.0
                - all_rmse * 60.0
                - upper_bias * 110.0
                - end_penalty * 8.0
                - start_penalty * 1.2
            )
            if score > best_score:
                best_score = score
                best = (int(start), int(end), float(m), float(b), float(r2), float(upper_rmse), float(all_rmse), int(bend_idx), int(peak_grad_idx), float(peak_grad))

    if best is None:
        a_idx = int(max(0, peak_grad_idx - 10))
        b_idx = int(min(len(x) - 1, bend_idx))
        curve.diagnostics["auto_line_fit"] = {
            "start_idx": a_idx,
            "end_idx": b_idx,
            "peak_grad_idx": int(peak_grad_idx),
            "peak_grad": float(peak_grad),
            "bend_idx": int(bend_idx),
        }
    else:
        a_idx, b_idx, m, b, r2, upper_rmse, all_rmse, bend_idx, peak_grad_idx, peak_grad = best
        curve.diagnostics["auto_line_fit"] = {
            "start_idx": a_idx,
            "end_idx": b_idx,
            "peak_grad_idx": int(peak_grad_idx),
            "peak_grad": float(peak_grad),
            "bend_idx": int(bend_idx),
            "slope": float(m),
            "intercept": float(b),
            "r2": float(r2),
            "upper_rmse": float(upper_rmse),
            "all_rmse": float(all_rmse),
            "fit_mode": "weighted_upper_priority",
        }

    return TensileOffset02LineHandles(
        point_a=create_point_from_index(curve, int(a_idx), source="auto", note="A auto"),
        point_b=create_point_from_index(curve, int(b_idx), source="auto", note="B auto"),
        source="auto",
    )


def line_parameters_from_handles(curve: TensileOffset02CurveData, handles: TensileOffset02LineHandles):
    if handles.point_a.index is None or handles.point_b.index is None:
        return None
    df = curve.df
    a_idx = int(handles.point_a.index)
    b_idx = int(handles.point_b.index)
    if a_idx == b_idx:
        return None
    if a_idx > b_idx:
        a_idx, b_idx = b_idx, a_idx
    xs = df.iloc[a_idx:b_idx + 1]["elongation_mm"].to_numpy(dtype=float)
    ys = df.iloc[a_idx:b_idx + 1]["stress_MPa"].to_numpy(dtype=float)
    if len(xs) < 2:
        return None

    # La recta activa debe estar definida estrictamente por los puntos A y B
    # visibles/editables. En versiones anteriores el modo automático podía usar
    # la pendiente/intercepto de un ajuste ponderado del tramo, por lo que la
    # recta dibujada y la recta usada para Rp podían no pasar por B. Para que el
    # punto B realmente guíe la recta, el cálculo usa siempre la secante A-B.
    ax_mm = float(xs[0])
    ay_mpa = float(ys[0])
    bx_mm = float(xs[-1])
    by_mpa = float(ys[-1])
    dx = bx_mm - ax_mm
    if abs(dx) < 1e-12:
        return None
    m = (by_mpa - ay_mpa) / dx
    b = ay_mpa - m * ax_mm
    return float(m), float(b), a_idx, b_idx



def calculate_elastic_modulus(curve: TensileOffset02CurveData) -> Optional[float]:
    """
    Calcula el módulo elástico a partir de la recta activa A-B de Rp0.2.

    La gráfica trabaja en MPa contra alargamiento en mm. Por tanto, si la
    pendiente de la recta es MPa/mm y L0 es la longitud calibrada en mm:

        E_MPa = pendiente_MPa_por_mm * L0_mm
        E_GPa = E_MPa / 1000

    El resultado se guarda en curve.diagnostics para que interfaz y reporte
    consuman una única fuente de verdad. Devuelve E en GPa o None si no es
    calculable.
    """
    diagnostics = curve.diagnostics
    diagnostics["elastic_modulus_mpa"] = None
    diagnostics["elastic_modulus_gpa"] = None
    diagnostics["elastic_modulus_note"] = "No disponible"

    handles = curve.visual_state.chosen_line_handles
    params = line_parameters_from_handles(curve, handles)
    if params is None:
        diagnostics["elastic_modulus_note"] = "No disponible: puntos A/B inválidos."
        return None

    slope_mpa_per_mm, intercept_mpa, a_idx, b_idx = params
    if a_idx == b_idx or not np.isfinite(slope_mpa_per_mm) or slope_mpa_per_mm <= 0:
        diagnostics["elastic_modulus_note"] = "No disponible: pendiente A/B inválida."
        return None

    gauge = curve.geometry.gauge_length_mm
    if gauge is None or not np.isfinite(gauge) or float(gauge) <= 0:
        diagnostics["elastic_modulus_note"] = "No disponible: longitud calibrada inválida."
        return None

    e_mpa = float(slope_mpa_per_mm) * float(gauge)
    if not np.isfinite(e_mpa) or e_mpa <= 0:
        diagnostics["elastic_modulus_note"] = "No disponible: resultado inválido."
        return None

    e_gpa = e_mpa / 1000.0
    diagnostics["elastic_modulus_mpa"] = e_mpa
    diagnostics["elastic_modulus_gpa"] = e_gpa
    diagnostics["elastic_modulus_slope_mpa_per_mm"] = float(slope_mpa_per_mm)
    diagnostics["elastic_line_intercept_mpa"] = float(intercept_mpa)
    diagnostics["elastic_modulus_gauge_length_mm"] = float(gauge)
    diagnostics["elastic_modulus_line_indices"] = {"a": int(a_idx), "b": int(b_idx)}
    diagnostics["elastic_modulus_line_source"] = handles.source
    diagnostics["elastic_modulus_note"] = f"Calculado desde recta A-B de {format_rp_label(get_curve_offset_percent(curve))}."
    return e_gpa


def format_elastic_modulus_gpa(curve: TensileOffset02CurveData, ndigits: int = 2) -> str:
    """Devuelve el módulo elástico en GPa para mostrar en UI/reporte."""
    value = curve.diagnostics.get("elastic_modulus_gpa")
    try:
        if value is None or not np.isfinite(float(value)):
            return "No disponible"
        return f"{float(value):.{ndigits}f}"
    except Exception:
        return "No disponible"

def calculate_tensile_offset02_yield(
    curve: TensileOffset02CurveData,
    handles: TensileOffset02LineHandles,
    offset_percent: Optional[float] = None,
) -> TensileOffset02Point:
    offset = set_tensile_offset02_offset_percent(curve, offset_percent if offset_percent is not None else get_curve_offset_percent(curve))
    rp_label = format_rp_label(offset)
    params = line_parameters_from_handles(curve, handles)
    if params is None:
        curve.diagnostics["offset_mm"] = None
        return TensileOffset02Point(note=f"No se pudo calcular {rp_label}.")
    m, b, a_idx, b_idx = params
    df = curve.df
    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)
    gauge = curve.geometry.gauge_length_mm if curve.geometry.gauge_length_mm and np.isfinite(curve.geometry.gauge_length_mm) else None
    if not gauge or gauge <= 0:
        curve.diagnostics["offset_mm"] = None
        return TensileOffset02Point(note=f"No hay longitud calibrada para {offset:g}% offset.")

    shift_mm = float(gauge) * offset / 100.0
    curve.diagnostics["offset_percent"] = offset
    curve.diagnostics["offset_mm"] = float(shift_mm)
    curve.diagnostics["rp_label"] = rp_label
    hidden_offset_y = m * (x - shift_mm) + b
    diff = y - hidden_offset_y

    # En el método Rp la línea offset queda por debajo de la recta elástica al
    # inicio. Por ello, en la zona elástica la curva suele estar ARRIBA de la
    # línea offset (diff > 0). El punto Rp corresponde a la primera intersección
    # posterior a la zona proporcional, normalmente cuando diff cambia de
    # positivo a negativo. Buscar el cruce inverso hace que se seleccione un
    # punto prematuro cercano a B o un punto aproximado inestable.
    start_search = min(len(x) - 2, max(b_idx, 1))
    hit_idx = None
    for i in range(start_search, len(x) - 1):
        if np.isnan(diff[i]) or np.isnan(diff[i + 1]):
            continue
        if diff[i] >= 0 >= diff[i + 1]:
            hit_idx = i
            break
    if hit_idx is None:
        for i in range(max(1, a_idx), len(x) - 1):
            if np.isnan(diff[i]) or np.isnan(diff[i + 1]):
                continue
            if diff[i] >= 0 >= diff[i + 1]:
                hit_idx = i
                break
    if hit_idx is None:
        finite = np.isfinite(diff)
        search_from = max(start_search, 0)
        candidate_mask = finite.copy()
        candidate_mask[:search_from] = False
        if not candidate_mask.any():
            candidate_mask = finite
        idxs = np.where(candidate_mask)[0]
        if len(idxs) == 0:
            return TensileOffset02Point(note=f"No se pudo calcular {rp_label}.")
        idx = int(idxs[np.argmin(np.abs(diff[idxs]))])
        point = create_point_from_index(curve, idx, source=handles.source, note=f"{rp_label} aproximado")
        curve.diagnostics["rp_intersection_mode"] = "nearest_abs_diff_no_sign_crossing"
        return point

    x1, x2 = x[hit_idx], x[hit_idx + 1]
    y1, y2 = y[hit_idx], y[hit_idx + 1]
    d1, d2 = diff[hit_idx], diff[hit_idx + 1]
    if d2 == d1:
        xi = x1
        yi = y1
    else:
        t = (0 - d1) / (d2 - d1)
        xi = x1 + t * (x2 - x1)
        yi = y1 + t * (y2 - y1)
    curve.diagnostics["rp_intersection_mode"] = "positive_to_negative_crossing"
    curve.diagnostics["rp_intersection_indices"] = {"left": int(hit_idx), "right": int(hit_idx + 1)}
    return TensileOffset02Point(index=hit_idx, x_mm=float(xi), y_mpa=float(yi), source=handles.source, note=rp_label)


def recalculate_tensile_offset02_curve(curve: TensileOffset02CurveData) -> None:
    visual = curve.visual_state
    visual.auto_max = detect_tensile_offset02_maximum(curve)
    visual.auto_line_handles = detect_tensile_offset02_auto_line_handles(curve)
    visual.auto_yield = calculate_tensile_offset02_yield(curve, visual.chosen_line_handles)
    if visual.manual_line_handles.point_a.index is not None and visual.manual_line_handles.point_b.index is not None:
        visual.auto_yield = calculate_tensile_offset02_yield(curve, visual.manual_line_handles)
    calculate_elastic_modulus(curve)


def _ensure_manual_handles_seeded(curve: TensileOffset02CurveData) -> None:
    visual = curve.visual_state
    if visual.manual_line_handles.point_a.index is None:
        auto_a = visual.auto_line_handles.point_a
        visual.manual_line_handles.point_a = TensileOffset02Point(
            index=auto_a.index,
            x_mm=auto_a.x_mm,
            y_mpa=auto_a.y_mpa,
            source="manual",
            note="A manual",
        )
    if visual.manual_line_handles.point_b.index is None:
        auto_b = visual.auto_line_handles.point_b
        visual.manual_line_handles.point_b = TensileOffset02Point(
            index=auto_b.index,
            x_mm=auto_b.x_mm,
            y_mpa=auto_b.y_mpa,
            source="manual",
            note="B manual",
        )
    visual.manual_line_handles.source = "manual"


def set_tensile_offset02_manual_handle(curve: TensileOffset02CurveData, which: str, index: int) -> None:
    point = create_point_from_index(curve, index, source="manual", note=f"{which} manual")
    visual = curve.visual_state
    if which == "a":
        _ensure_manual_handles_seeded(curve)
        visual.manual_line_handles.point_a = point
    elif which == "b":
        _ensure_manual_handles_seeded(curve)
        visual.manual_line_handles.point_b = point
    elif which == "max":
        visual.manual_max = point
        return
    else:
        raise ValueError("which debe ser a, b o max")
    if visual.manual_line_handles.point_a.index is not None and visual.manual_line_handles.point_b.index is not None:
        if visual.manual_line_handles.point_a.index > visual.manual_line_handles.point_b.index:
            visual.manual_line_handles.point_a, visual.manual_line_handles.point_b = visual.manual_line_handles.point_b, visual.manual_line_handles.point_a
        visual.manual_line_handles.source = "manual"
        visual.auto_yield = calculate_tensile_offset02_yield(curve, visual.manual_line_handles)
        calculate_elastic_modulus(curve)


def clear_tensile_offset02_manuals(curve: TensileOffset02CurveData) -> None:
    visual = curve.visual_state
    visual.manual_line_handles = TensileOffset02LineHandles(source="manual")
    visual.manual_max = TensileOffset02Point()
    visual.selected_target = "none"
    visual.auto_yield = calculate_tensile_offset02_yield(curve, visual.auto_line_handles)
    calculate_elastic_modulus(curve)


def update_tensile_offset02_geometry(curve: TensileOffset02CurveData, shape, side1_mm, side2_mm, diameter_mm, gauge_length_mm, area_mm2_manual=None) -> None:
    curve.geometry.shape = normalize_shape(shape)
    curve.geometry.side1_mm = side1_mm
    curve.geometry.side2_mm = side2_mm
    curve.geometry.diameter_mm = diameter_mm
    curve.geometry.gauge_length_mm = gauge_length_mm
    curve.geometry.area_mm2_manual = area_mm2_manual
    if hasattr(curve.geometry, "validate"):
        curve.diagnostics["geometry_validation_errors"] = curve.geometry.validate(require_gauge=True)
    clear_tensile_offset02_manuals(curve)
    recalculate_tensile_offset02_curve(curve)
