from __future__ import annotations

from pathlib import Path
import os
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import numpy as np

from .tensile_offset02_controller import TensileOffset02Controller
from .tensile_offset02_plots import draw_tensile_offset02_curve, configure_tensile_offset02_decimal_formatters, adapt_tensile_offset02_zoom_precision
from .tensile_offset02_models import SHAPE_CIRCULAR, SHAPE_IRREGULAR, SHAPE_OPTIONS, SHAPE_RECTANGULAR, normalize_shape
from .tensile_offset02_calculator import format_rp_label, get_curve_offset_percent, normalize_offset_percent
from ...ui.runtime_theme import load_runtime_theme
from shared.tk_window_restore import install_window_restore_guard, set_windows_app_user_model_id
from shared.tk_ui_standard import (
    TEXT_ACTIONS_SECTION,
    TEXT_APPLY_VIEW,
    TEXT_AUTO_ADJUST,
    TEXT_EXPORT_PNG,
    TEXT_EXPORT_WORD,
    TEXT_GEOMETRY_SECTION,
    TEXT_IMPORT_CSV,
    TEXT_INTERACTIVE_GRAPH,
    TEXT_NO_FILE,
    TEXT_READY,
    TEXT_RECALCULATE,
    TEXT_RELOAD,
    TEXT_RESULTS_SECTION,
    TEXT_SPECIMEN,
    SUPPORTED_FILETYPES,
    configure_standard_style,
    set_loaded_status,
    show_error,
    show_import_error,
    show_warning,
    warning_summary,
)

APP_TITLE = "LEMATZIUM - Módulo 2 v1.1.8"
_RUNTIME_THEME = load_runtime_theme()
BG = "#f7f7f7"
PANEL = "#ffffff"
ACCENT = _RUNTIME_THEME["accent"]
ACCENT_SOFT = "#dff1ff" if _RUNTIME_THEME["name"] == "Blanco moderno" else _RUNTIME_THEME["accent_soft"]


class ScrollablePanel(ttk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0, bg=master.winfo_toplevel().cget("bg"))
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.bind("<MouseWheel>", self._on_mousewheel, add="+")
        self.inner.bind("<MouseWheel>", self._on_mousewheel, add="+")

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


class CollapsibleSection(ttk.Frame):
    def __init__(self, master, title: str, start_collapsed: bool = True, **kwargs):
        super().__init__(master, **kwargs)
        self.title = title
        self.is_expanded = not start_collapsed
        self.button = ttk.Button(self, command=self.toggle)
        self.button.pack(fill="x")
        self.content = ttk.Frame(self)
        if self.is_expanded:
            self.content.pack(fill="both", expand=True, pady=(6, 0))
        self._refresh_header()

    def _refresh_header(self):
        symbol = "▼" if self.is_expanded else "▶"
        self.button.configure(text=f"{symbol} {self.title}")

    def toggle(self):
        self.is_expanded = not self.is_expanded
        if self.is_expanded:
            self.content.pack(fill="both", expand=True, pady=(6, 0))
        else:
            self.content.pack_forget()
        self._refresh_header()


class TensileOffset02App:

    def _build_root_scaffold(self):
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.root_canvas = tk.Canvas(self.root, bg=BG, highlightthickness=0, bd=0)
        self.root_vscroll = ttk.Scrollbar(self.root, orient="vertical", command=self.root_canvas.yview)
        self.root_hscroll = ttk.Scrollbar(self.root, orient="horizontal", command=self.root_canvas.xview)
        self.root_canvas.configure(yscrollcommand=self.root_vscroll.set, xscrollcommand=self.root_hscroll.set)
        self.root_canvas.grid(row=0, column=0, sticky="nsew")
        self.root_vscroll.grid(row=0, column=1, sticky="ns")
        self.root_hscroll.grid(row=1, column=0, sticky="ew")
        self.root_host = ttk.Frame(self.root_canvas)
        self.root_canvas_window = self.root_canvas.create_window((0, 0), window=self.root_host, anchor="nw")
        self.root_host.bind("<Configure>", lambda _e: self.root_canvas.configure(scrollregion=self.root_canvas.bbox("all")))
        self.root_canvas.bind("<Configure>", self._on_root_canvas_configure)
        self.root.bind_all("<Shift-MouseWheel>", self._on_root_shift_mousewheel, add="+")

    def _on_root_canvas_configure(self, event=None):
        if event is not None:
            self.root_canvas.itemconfigure(self.root_canvas_window, height=max(event.height, self.root_host.winfo_reqheight()))

    def _on_root_shift_mousewheel(self, event):
        self.root_canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")
    def __init__(self):
        set_windows_app_user_model_id("LEMATZIUM.Modulo2.Offset02")
        self.root = tk.Tk()
        install_window_restore_guard(self.root, app_id="LEMATZIUM.Modulo2.Offset02")
        self.root.title(APP_TITLE)
        self.root.geometry("1500x930")
        self.root.minsize(1180, 760)
        self.root.configure(bg=BG)
        try:
            level = max(35, min(100, int(os.getenv("LEMATZIUM_BRIGHTNESS", "85"))))
            self.root.attributes("-alpha", 0.55 + (level / 100.0) * 0.45)
        except Exception:
            pass

        self.style = ttk.Style(self.root)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass
        self._build_root_scaffold()
        self.root.configure(bg=BG)
        configure_standard_style(self.style, bg=BG, accent=ACCENT, accent_soft=ACCENT_SOFT)

        self.controller = TensileOffset02Controller()
        self.current_file_label_var = tk.StringVar(value=TEXT_NO_FILE)
        self.current_point_var = tk.StringVar(value="Punto actual: —")
        self.specimen_var = tk.StringVar(value="")
        self.selection_var = tk.StringVar(value="auto")
        self.scroll_factor_var = tk.StringVar(value="1.25")
        self.status_var = tk.StringVar(value=TEXT_READY)

        self.axis_mode_var = tk.StringVar(value="auto")
        self.grid_x_var = tk.StringVar(value="")
        self.grid_y_var = tk.StringVar(value="")
        self.x_max_var = tk.StringVar(value="")
        self.y_max_var = tk.StringVar(value="")

        self.meta_lock_var = tk.BooleanVar(value=True)
        self.geometry_lock_var = tk.BooleanVar(value=True)
        self.results_lock_var = tk.BooleanVar(value=True)
        self.apply_geometry_all_var = tk.BooleanVar(value=False)
        self.apply_offset_all_var = tk.BooleanVar(value=False)
        self.offset_percent_var = tk.StringVar(value="0.2")
        self.rp_label_var = tk.StringVar(value="Rp0.2")
        self._geometry_after_id = None
        self._suspend_geometry_trace = False

        self.meta_vars = {k: tk.StringVar(value="") for k in [
            "procedure", "standard", "machine", "material", "speed", "humidity", "temp", "control"
        ]}
        self.geometry_vars = {k: tk.StringVar(value="") for k in ["shape", "side1", "side2", "diameter", "area", "gauge"]}
        self.result_vars = {k: tk.StringVar(value="") for k in ["elastic", "yield", "max", "elong"]}
        self.order_var = tk.StringVar(value="")
        self.geometry_vars["shape"].set(SHAPE_RECTANGULAR)

        self.comment_text = None
        self.summary_tree = None
        self.dragging_target: str | None = None
        self.drag_active = False
        self.primary_label_var = tk.StringVar(value="Espesor (mm)")
        self.secondary_label_var = tk.StringVar(value="Anchura (mm)")
        self.area_label_var = tk.StringVar(value="Área calculada (mm²)")

        self.graph_config = {
            "axis_mode": "auto",
            "grid_x": None,
            "grid_y": None,
            "x_max": None,
            "y_max": None,
        }
        self._create_widgets()
        for _k in ("shape", "side1", "side2", "diameter", "area", "gauge"):
            self.geometry_vars[_k].trace_add("write", self._on_geometry_var_changed)
        self.root.bind("<Left>", self._on_key_prev)
        self.root.bind("<Right>", self._on_key_next)

    def _create_widgets(self):
        container = ttk.Frame(self.root_host, padding=10)
        container.pack(fill="both", expand=True)

        header = ttk.Frame(container)
        header.pack(fill="x")
        ttk.Label(header, text="LEMATZIUM - Módulo 2", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Rp configurable, módulo elástico y reporte Word editable",
            style="SubHeader.TLabel",
        ).pack(anchor="w", pady=(0, 8))

        body = ttk.Panedwindow(container, orient="horizontal")
        body.pack(fill="both", expand=True)
        left = ttk.Frame(body)
        right = ttk.Frame(body)
        body.add(left, weight=3)
        body.add(right, weight=2)

        self._build_left(left)
        self._build_right(right)
        ttk.Label(container, textvariable=self.status_var, relief="groove", anchor="w").pack(fill="x", pady=(8, 0))

    def _build_left(self, parent):
        top = ttk.Frame(parent)
        top.pack(fill="x", pady=(0, 6))
        ttk.Button(top, text=TEXT_IMPORT_CSV, style="Accent.TButton", command=self.open_file).pack(side="left")
        ttk.Button(top, text=TEXT_RELOAD, command=self.reload_file).pack(side="left", padx=(6, 0))
        ttk.Button(top, text=TEXT_RECALCULATE, command=self.recalculate_all).pack(side="left", padx=(6, 0))
        ttk.Button(top, text=TEXT_EXPORT_WORD, command=self.open_export_dialog).pack(side="left", padx=(6, 0))
        ttk.Label(top, textvariable=self.current_file_label_var).pack(side="left", padx=(12, 0))

        mid = ttk.Frame(parent)
        mid.pack(fill="x", pady=(0, 6))
        ttk.Label(mid, text=TEXT_SPECIMEN).pack(side="left")
        self.specimen_combo = ttk.Combobox(mid, textvariable=self.specimen_var, state="readonly", width=22)
        self.specimen_combo.pack(side="left", padx=(6, 10))
        self.specimen_combo.bind("<<ComboboxSelected>>", self._on_specimen_change)
        ttk.Label(mid, textvariable=self.current_point_var).pack(side="left")

        plot_frame = ttk.LabelFrame(parent, text=TEXT_INTERACTIVE_GRAPH, padding=8)
        plot_frame.pack(fill="both", expand=True)
        self.fig = Figure(figsize=(9.5, 6.4), dpi=100, facecolor=PANEL)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor("#ffffff")
        self.ax.grid(True, color="#d8d8d8", linestyle="--", linewidth=0.6)
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        self.toolbar = NavigationToolbar2Tk(self.canvas, plot_frame, pack_toolbar=False)
        self.toolbar.update()
        self.toolbar.pack(fill="x")
        self.canvas.mpl_connect("scroll_event", self._on_scroll_zoom)
        self.canvas.mpl_connect("motion_notify_event", self._on_mouse_move)
        self.canvas.mpl_connect("button_press_event", self._on_plot_press)
        self.canvas.mpl_connect("button_release_event", self._on_plot_release)

    def _build_right(self, parent):
        panel = ScrollablePanel(parent)
        panel.pack(fill="both", expand=True)
        box = panel.inner

        sec = CollapsibleSection(box, title="A. Factor de scroll", start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        ttk.Label(sec.content, text="Factor").grid(row=0, column=0, sticky="w")
        ttk.Entry(sec.content, textvariable=self.scroll_factor_var, width=10).grid(row=0, column=1, sticky="w", padx=(6, 0))

        sec = CollapsibleSection(box, title="B. Punto de fluencia y máximo", start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        for i, (text, value) in enumerate([("Auto", "auto"), ("Manual", "manual")]):
            ttk.Radiobutton(sec.content, text=text, value=value, variable=self.selection_var, command=self._on_selection_mode_change).grid(row=0, column=i, sticky="w", padx=(0, 8))
        ttk.Label(sec.content, text="Offset Rp (%)").grid(row=1, column=0, sticky="w", pady=(8, 2))
        self.offset_entry = ttk.Entry(sec.content, textvariable=self.offset_percent_var, width=10)
        self.offset_entry.grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(8, 2))
        ttk.Label(sec.content, textvariable=self.rp_label_var).grid(row=1, column=2, sticky="w", padx=(8, 0), pady=(8, 2))
        ttk.Checkbutton(sec.content, text="Aplicar offset a todas", variable=self.apply_offset_all_var).grid(row=2, column=0, columnspan=2, sticky="w", pady=2)
        ttk.Button(sec.content, text="Aplicar offset", command=self.apply_offset_percent).grid(row=2, column=2, sticky="w", padx=(8, 0), pady=2)

        self.point_labels = {k: tk.StringVar(value="—") for k in ["a", "b", "yield", "max"]}
        labels = [("Punto A", "a"), ("Punto B", "b"), (self.rp_label_var, "yield"), ("Máximo", "max")]
        for r, (lab, key) in enumerate(labels, start=3):
            if isinstance(lab, tk.StringVar):
                ttk.Label(sec.content, textvariable=lab).grid(row=r, column=0, sticky="w", pady=2)
            else:
                ttk.Label(sec.content, text=lab).grid(row=r, column=0, sticky="w", pady=2)
            ttk.Label(sec.content, textvariable=self.point_labels[key]).grid(row=r, column=1, columnspan=3, sticky="w", pady=2)
        ttk.Button(sec.content, text="Color curva", command=self.pick_curve_color).grid(row=7, column=0, sticky="w", pady=(8, 0))
        ttk.Button(sec.content, text="Color recta coincidente", command=self.pick_line_color).grid(row=7, column=1, sticky="w", padx=(8, 0), pady=(8, 0))
        ttk.Button(sec.content, text="Color recta paralela", command=self.pick_offset_color).grid(row=7, column=2, sticky="w", padx=(8, 0), pady=(8, 0))

        sec = CollapsibleSection(box, title="C. Configuración de la gráfica", start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        ttk.Radiobutton(sec.content, text="Auto", value="auto", variable=self.axis_mode_var).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(sec.content, text="Manual", value="manual", variable=self.axis_mode_var).grid(row=0, column=1, sticky="w")
        entries = [
            ("Espaciado X", self.grid_x_var), ("Espaciado Y", self.grid_y_var),
            ("X máx", self.x_max_var), ("Y máx", self.y_max_var),
        ]
        for i, (lab, var) in enumerate(entries, start=1):
            ttk.Label(sec.content, text=lab).grid(row=i, column=0, sticky="w", pady=1)
            ttk.Entry(sec.content, textvariable=var, width=12).grid(row=i, column=1, sticky="w", padx=(6, 0), pady=1)
        ttk.Label(sec.content, text="La vista previa siempre inicia en 0,0 y coincide con la exportación PNG.").grid(row=5, column=0, columnspan=2, sticky="w", pady=(6, 2))
        ttk.Button(sec.content, text=TEXT_APPLY_VIEW, command=self.apply_graph_config).grid(row=6, column=0, sticky="w", pady=(8, 0))
        ttk.Button(sec.content, text=TEXT_AUTO_ADJUST, command=self.auto_adjust).grid(row=6, column=1, sticky="w", padx=(8, 0), pady=(8, 0))

        sec = CollapsibleSection(box, title="D. Datos del ensayo", start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        meta_box = sec.content
        ttk.Checkbutton(meta_box, text="Bloquear edición", variable=self.meta_lock_var, command=self._apply_lock_states).grid(row=0, column=0, columnspan=2, sticky="w")
        fields = [
            ("Procedimiento", "procedure"), ("Norma", "standard"), ("Equipo", "machine"), ("Material", "material"),
            ("Velocidad", "speed"), ("Humedad", "humidity"), ("Temperatura", "temp"), ("Control", "control"),
        ]
        self.meta_entries = {}
        for i, (lab, key) in enumerate(fields, start=1):
            ttk.Label(meta_box, text=lab).grid(row=i, column=0, sticky="w", pady=1)
            ent = ttk.Entry(meta_box, textvariable=self.meta_vars[key], width=28)
            ent.grid(row=i, column=1, sticky="w", padx=(6, 0), pady=1)
            self.meta_entries[key] = ent

        sec = CollapsibleSection(box, title=TEXT_GEOMETRY_SECTION, start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        geo_box = sec.content
        ttk.Checkbutton(geo_box, text="Bloquear edición", variable=self.geometry_lock_var, command=self._apply_lock_states).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(geo_box, text="Forma").grid(row=1, column=0, sticky="w", pady=1)
        self.shape_combo = ttk.Combobox(geo_box, textvariable=self.geometry_vars["shape"], state="readonly", width=18, values=SHAPE_OPTIONS)
        self.shape_combo.grid(row=1, column=1, sticky="w", padx=(6, 0), pady=1)
        self.shape_combo.bind("<<ComboboxSelected>>", self._on_shape_change)

        self.primary_label = ttk.Label(geo_box, textvariable=self.primary_label_var)
        self.primary_label.grid(row=2, column=0, sticky="w", pady=1)
        self.primary_entry = ttk.Entry(geo_box, textvariable=self.geometry_vars["side1"], width=18)
        self.primary_entry.grid(row=2, column=1, sticky="w", padx=(6, 0), pady=1)

        self.secondary_label = ttk.Label(geo_box, textvariable=self.secondary_label_var)
        self.secondary_label.grid(row=3, column=0, sticky="w", pady=1)
        self.secondary_entry = ttk.Entry(geo_box, textvariable=self.geometry_vars["side2"], width=18)
        self.secondary_entry.grid(row=3, column=1, sticky="w", padx=(6, 0), pady=1)

        self.diameter_label = ttk.Label(geo_box, text="Diámetro (mm)")
        self.diameter_label.grid(row=4, column=0, sticky="w", pady=1)
        self.diameter_entry = ttk.Entry(geo_box, textvariable=self.geometry_vars["diameter"], width=18)
        self.diameter_entry.grid(row=4, column=1, sticky="w", padx=(6, 0), pady=1)

        self.area_label = ttk.Label(geo_box, textvariable=self.area_label_var)
        self.area_label.grid(row=5, column=0, sticky="w", pady=1)
        self.area_entry = ttk.Entry(geo_box, textvariable=self.geometry_vars["area"], width=18)
        self.area_entry.grid(row=5, column=1, sticky="w", padx=(6, 0), pady=1)
        ttk.Label(geo_box, text="Longitud calibrada (mm)").grid(row=6, column=0, sticky="w", pady=1)
        self.gauge_entry = ttk.Entry(geo_box, textvariable=self.geometry_vars["gauge"], width=18)
        self.gauge_entry.grid(row=6, column=1, sticky="w", padx=(6, 0), pady=1)
        self.apply_geometry_all_check = ttk.Checkbutton(
            geo_box,
            text="Aplicar esta geometría a todas las probetas",
            variable=self.apply_geometry_all_var,
        )
        self.apply_geometry_all_check.grid(row=7, column=0, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Button(geo_box, text="Aplicar geometría", command=self.apply_geometry).grid(row=8, column=0, sticky="w", pady=(8, 0))

        sec = CollapsibleSection(box, title=TEXT_RESULTS_SECTION, start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        res_box = sec.content
        ttk.Checkbutton(res_box, text="Bloquear edición", variable=self.results_lock_var, command=self._apply_lock_states).grid(row=0, column=0, columnspan=2, sticky="w")
        res_fields = [("Módulo elástico (GPa)", "elastic"), ("Fluencia Rp (MPa)", "yield"), ("Máximo (MPa)", "max"), ("Elongación (%)", "elong")]
        self.result_entries = {}
        for i, (lab, key) in enumerate(res_fields, start=1):
            ttk.Label(res_box, text=lab).grid(row=i, column=0, sticky="w", pady=1)
            ent = ttk.Entry(res_box, textvariable=self.result_vars[key], width=18)
            ent.grid(row=i, column=1, sticky="w", padx=(6, 0), pady=1)
            self.result_entries[key] = ent
        ttk.Label(res_box, text="N° orden").grid(row=5, column=0, sticky="w", pady=(6,1))
        self.order_entry = ttk.Entry(res_box, textvariable=self.order_var, width=18)
        self.order_entry.grid(row=5, column=1, sticky="w", padx=(6, 0), pady=(6,1))

        sec = CollapsibleSection(box, title="G. Comentario", start_collapsed=True)
        sec.pack(fill="both", expand=True, pady=(0, 8))
        self.comment_text = tk.Text(sec.content, height=8, wrap="word")
        self.comment_text.pack(fill="both", expand=True)

        sec = CollapsibleSection(box, title="H. Resumen por probeta", start_collapsed=True)
        sec.pack(fill="both", expand=True, pady=(0, 8))
        cols = ("specimen", "elastic", "yield", "max")
        tree = ttk.Treeview(sec.content, columns=cols, show="headings", height=8)
        tree.heading("specimen", text="Probeta")
        tree.heading("elastic", text="E (GPa)")
        tree.heading("yield", text="Fluencia")
        tree.heading("max", text="Máximo")
        tree.column("specimen", width=120)
        tree.column("elastic", width=85)
        tree.column("yield", width=90)
        tree.column("max", width=90)
        tree.pack(fill="both", expand=True)
        self.summary_tree = tree

        sec = CollapsibleSection(box, title=TEXT_ACTIONS_SECTION, start_collapsed=True)
        sec.pack(fill="x", pady=(0, 8))
        ttk.Button(sec.content, text=TEXT_EXPORT_PNG, command=self.export_png).pack(anchor="w")
        ttk.Button(sec.content, text=TEXT_EXPORT_WORD, command=self.open_export_dialog).pack(anchor="w", pady=(6, 0))

        self._apply_lock_states()
        self._apply_shape_state()

    def open_file(self):
        path = filedialog.askopenfilename(title="Importar CSV de ensayo", filetypes=SUPPORTED_FILETYPES)
        if not path:
            return
        self.open_file_from_path(path)

    def reload_file(self):
        if not self.controller.current_file:
            show_warning("Sin archivo", "No hay archivo cargado para recargar.")
            return
        self.open_file_from_path(self.controller.current_file)

    def recalculate_all(self):
        if self.controller.dataset is None:
            show_warning("Sin datos", "Primero importa un CSV para recalcular.")
            return
        active = self.specimen_var.get().strip()
        try:
            self.controller.recalculate_all()
            if active:
                self.controller.set_specimen(active)
            self._refresh_current_curve(reset_view=False)
            self._refresh_summary()
            self.status_var.set("Curvas recalculadas con la configuración actual.")
        except Exception as exc:
            show_error("Recalcular", exc)

    def open_file_from_path(self, path):
        try:
            dataset = self.controller.load_file(path)
        except Exception as exc:
            show_import_error(exc)
            return
        self.current_file_label_var.set(Path(path).name)
        ids = dataset.specimen_ids()
        self.specimen_combo["values"] = ids
        try:
            self.apply_geometry_all_check.configure(state=("normal" if len(ids) > 1 else "disabled"))
        except Exception:
            pass
        if len(ids) <= 1:
            self.apply_geometry_all_var.set(False)
        if ids:
            self.specimen_var.set(ids[0])
        self.comment_text.delete("1.0", "end")
        self.comment_text.insert("1.0", dataset.default_comment or "")
        self._load_meta()
        self._refresh_current_curve(reset_view=True)
        set_loaded_status(self.status_var, path, extra=warning_summary(dataset))

    def _load_meta(self):
        ds = self.controller.dataset
        if not ds:
            return
        meta = ds.meta or {}
        self.meta_vars["procedure"].set(meta.get("Procedimiento", meta.get("Procedure", "")))
        self.meta_vars["standard"].set(meta.get("Norma de referencia", meta.get("Reference Standard", "")))
        self.meta_vars["machine"].set(meta.get("Equipo Utilizado", meta.get("Used Device", "")))
        self.meta_vars["material"].set(meta.get("Material", ""))
        self.meta_vars["speed"].set(meta.get("Velocidad de ensayo", meta.get("Test Speed", "")))
        self.meta_vars["humidity"].set(meta.get("Humedad Máx/Mín", meta.get("Humidity Max/Min", "")))
        self.meta_vars["temp"].set(meta.get("Temperatura Máx/Mín", meta.get("Temperature Max/Min", "")))
        self.meta_vars["control"].set(meta.get("Control de Velocidad", meta.get("Speed Control", "")))
        self.order_var.set(meta.get("Número de Orden", meta.get("Order No", meta.get("N° orden", ""))))

    def _on_specimen_change(self, _event=None):
        if not self.specimen_var.get():
            return
        self.controller.set_specimen(self.specimen_var.get())
        self.dragging_target = None
        self.drag_active = False
        self._refresh_current_curve(reset_view=True)

    def _refresh_current_curve(self, reset_view=False):
        curve = self.controller.get_curve()
        if curve is None:
            return
        self._suspend_geometry_trace = True
        try:
            self.geometry_vars["shape"].set(normalize_shape(curve.geometry.shape))
            self.geometry_vars["side1"].set(self._fmt(curve.geometry.side1_mm))
            self.geometry_vars["side2"].set(self._fmt(curve.geometry.side2_mm))
            self.geometry_vars["diameter"].set(self._fmt(curve.geometry.diameter_mm))
            self.geometry_vars["area"].set(self._fmt(curve.geometry.area_mm2_manual if normalize_shape(curve.geometry.shape) == SHAPE_IRREGULAR else curve.geometry.area_mm2))
            self.geometry_vars["gauge"].set(self._fmt(curve.geometry.gauge_length_mm))
        finally:
            self._suspend_geometry_trace = False
        self._apply_shape_state()
        offset_percent = get_curve_offset_percent(curve)
        self.offset_percent_var.set(f"{offset_percent:g}")
        self.rp_label_var.set(format_rp_label(offset_percent))
        elastic_value = curve.diagnostics.get("elastic_modulus_gpa")
        self.result_vars["elastic"].set(self._fmt(elastic_value, 2) if elastic_value is not None else "No disponible")
        self.result_vars["yield"].set(self._fmt(curve.visual_state.auto_yield.y_mpa, 3) or "No disponible")
        self.result_vars["max"].set(self._fmt(curve.visual_state.chosen_max.y_mpa, 3))
        self.result_vars["elong"].set(self._fmt(curve.reported_elong_after_fracture_pct, 3))
        self._update_point_labels(curve)
        if reset_view:
            self.graph_config["axis_mode"] = self.axis_mode_var.get()
            current_limits = None
        else:
            current_limits = (self.ax.get_xlim(), self.ax.get_ylim())
        draw_tensile_offset02_curve(self.ax, curve, self.graph_config, visible_limits=current_limits)
        self.canvas.draw_idle()
        self._refresh_summary()

    def _refresh_summary(self):
        for item in self.summary_tree.get_children():
            self.summary_tree.delete(item)
        for row in self.controller.build_summary_rows():
            self.summary_tree.insert("", "end", values=(row["specimen"], row.get("elastic_gpa_text", "No disponible"), self._fmt(row["yield_mpa"], 2), self._fmt(row["max_mpa"], 2)))

    def _update_point_labels(self, curve):
        vs = curve.visual_state
        self.point_labels["a"].set(self._point_text(vs.chosen_line_handles.point_a))
        self.point_labels["b"].set(self._point_text(vs.chosen_line_handles.point_b))
        self.point_labels["yield"].set(self._point_text(vs.auto_yield))
        self.point_labels["max"].set(self._point_text(vs.chosen_max))

    def _point_text(self, point):
        if point.index is None or point.x_mm is None or point.y_mpa is None:
            return "—"
        return f"idx={point.index} | x={point.x_mm:.4f} mm | y={point.y_mpa:.4f} MPa"

    def _on_selection_mode_change(self):
        curve = self.controller.get_curve()
        if curve is None:
            return
        mode = self.selection_var.get()
        if mode == "auto":
            self.controller.clear_manuals()
            curve.visual_state.selected_target = "none"
            self.dragging_target = None
            self.drag_active = False
        self._refresh_current_curve(reset_view=False)

    def _on_mouse_move(self, event):
        curve = self.controller.get_curve()
        if curve is None or event.inaxes != self.ax or event.xdata is None or event.ydata is None:
            self.current_point_var.set("Punto actual: —")
            return
        idx = self._nearest_index_by_x(event.xdata)
        row = curve.df.iloc[idx]
        self.current_point_var.set(f"Punto actual: X={row['elongation_mm']:.4f} mm | Y={row['stress_MPa']:.4f} MPa | idx={idx}")
        if self.selection_var.get() == "manual" and self.drag_active and self.dragging_target is not None:
            self.controller.set_manual_target_by_index(self.dragging_target, idx)
            curve.visual_state.selected_target = self.dragging_target
            self._refresh_current_curve(reset_view=False)

    def _point_distance_px(self, point, event) -> float:
        if point.index is None or point.x_mm is None or point.y_mpa is None or event.x is None or event.y is None:
            return float("inf")
        px, py = self.ax.transData.transform((point.x_mm, point.y_mpa))
        return float(np.hypot(px - event.x, py - event.y))

    def _find_pick_target(self, event) -> str | None:
        curve = self.controller.get_curve()
        if curve is None:
            return None
        vs = curve.visual_state
        candidates = {
            "a": vs.chosen_line_handles.point_a,
            "b": vs.chosen_line_handles.point_b,
            "max": vs.chosen_max,
        }
        distances = {name: self._point_distance_px(point, event) for name, point in candidates.items()}
        best_name = min(distances, key=distances.get)
        return best_name if distances[best_name] <= 14.0 else None

    def _on_plot_press(self, event):
        curve = self.controller.get_curve()
        if curve is None or event.inaxes != self.ax or event.xdata is None:
            return
        if self.selection_var.get() != "manual":
            return
        picked = self._find_pick_target(event)
        if picked is None:
            self.dragging_target = None
            self.drag_active = False
            return
        self.dragging_target = picked
        self.drag_active = True
        curve.visual_state.selected_target = picked
        idx = self._nearest_index_by_x(event.xdata)
        self.controller.set_manual_target_by_index(picked, idx)
        self._refresh_current_curve(reset_view=False)

    def _on_plot_release(self, _event):
        self.drag_active = False

    def _nearest_index_by_x(self, x_value):
        curve = self.controller.get_curve()
        df = curve.df
        dx = np.abs(df["elongation_mm"].to_numpy(dtype=float) - float(x_value))
        return int(np.argmin(dx))

    def _on_scroll_zoom(self, event):
        if event.inaxes != self.ax:
            return
        try:
            scale = float(self.scroll_factor_var.get())
            if scale <= 1:
                scale = 1.25
        except Exception:
            scale = 1.25
        factor = 1.0 / scale if event.button == "up" else scale
        cur_xlim = self.ax.get_xlim()
        cur_ylim = self.ax.get_ylim()
        xdata = event.xdata if event.xdata is not None else (cur_xlim[0] + cur_xlim[1]) / 2.0
        ydata = event.ydata if event.ydata is not None else (cur_ylim[0] + cur_ylim[1]) / 2.0
        new_width = (cur_xlim[1] - cur_xlim[0]) * factor
        new_height = (cur_ylim[1] - cur_ylim[0]) * factor
        relx = (cur_xlim[1] - xdata) / (cur_xlim[1] - cur_xlim[0]) if (cur_xlim[1] - cur_xlim[0]) else 0.5
        rely = (cur_ylim[1] - ydata) / (cur_ylim[1] - cur_ylim[0]) if (cur_ylim[1] - cur_ylim[0]) else 0.5
        x0 = max(0.0, xdata - new_width * (1 - relx))
        y0 = max(0.0, ydata - new_height * (1 - rely))
        self.ax.set_xlim([x0, xdata + new_width * relx])
        self.ax.set_ylim([y0, ydata + new_height * rely])
        adapt_tensile_offset02_zoom_precision(self.ax)
        self.canvas.draw_idle()

    def apply_graph_config(self):
        self.graph_config = {
            "axis_mode": self.axis_mode_var.get(),
            "grid_x": self._parse_float(self.grid_x_var.get()),
            "grid_y": self._parse_float(self.grid_y_var.get()),
            "x_max": self._parse_float(self.x_max_var.get()),
            "y_max": self._parse_float(self.y_max_var.get()),
        }
        self._refresh_current_curve(reset_view=True)

    def auto_adjust(self):
        self.axis_mode_var.set("auto")
        self._refresh_current_curve(reset_view=True)

    def apply_offset_percent(self, reset_view=False):
        if self.controller.dataset is None:
            show_warning("Sin datos", "Primero importa un CSV para configurar el offset Rp.")
            return
        try:
            offset = normalize_offset_percent(self.offset_percent_var.get())
            active = self.specimen_var.get().strip()
            if self.apply_offset_all_var.get() and len(self.controller.dataset.curves) > 1:
                self.controller.update_offset_percent_all(offset)
                if active:
                    self.controller.set_specimen(active)
                message = f"Offset {format_rp_label(offset)} aplicado a todas las probetas."
            else:
                self.controller.update_offset_percent(offset)
                message = f"Offset {format_rp_label(offset)} aplicado a la probeta actual."
        except Exception as exc:
            self.status_var.set(f"No se pudo actualizar offset Rp: {exc}")
            return
        self._refresh_current_curve(reset_view=reset_view)
        self.status_var.set(message)

    def apply_geometry(self):
        self._apply_geometry_change(reset_view=True)

    def _on_shape_change(self, _event=None):
        self._apply_shape_state()
        self._on_geometry_var_changed()

    def _on_geometry_var_changed(self, *_args):
        if self._suspend_geometry_trace:
            return
        self._update_area_preview()
        if self.geometry_lock_var.get():
            return
        if self._geometry_after_id is not None:
            self.root.after_cancel(self._geometry_after_id)
        self._geometry_after_id = self.root.after(180, self._apply_geometry_change)

    def _apply_geometry_change(self, reset_view=False):
        self._geometry_after_id = None
        shape = normalize_shape(self.geometry_vars["shape"].get())
        side1 = self._parse_float(self.geometry_vars["side1"].get())
        side2 = self._parse_float(self.geometry_vars["side2"].get())
        diameter = self._parse_float(self.geometry_vars["diameter"].get())
        gauge = self._parse_float(self.geometry_vars["gauge"].get())
        area = self._parse_float(self.geometry_vars["area"].get()) if shape == SHAPE_IRREGULAR else None
        try:
            if self.apply_geometry_all_var.get() and self.controller.dataset and len(self.controller.dataset.curves) > 1:
                self.controller.update_geometry_all(shape, side1, side2, diameter, gauge, area)
                message = "Geometría aplicada a todas las probetas y curvas recalculadas."
            else:
                self.controller.update_geometry(shape, side1, side2, diameter, gauge, area)
                message = "Geometría actualizada y curva recalculada."
        except Exception as exc:
            self.status_var.set(f"No se pudo actualizar geometría: {exc}")
            return
        self._refresh_current_curve(reset_view=reset_view)
        self.status_var.set(message)

    def _apply_shape_state(self):
        shape = normalize_shape(self.geometry_vars["shape"].get())
        is_circular = shape == SHAPE_CIRCULAR
        is_irregular = shape == SHAPE_IRREGULAR
        self.primary_label_var.set("Espesor (mm)" if not is_circular and not is_irregular else "")
        self.secondary_label_var.set("Anchura (mm)" if not is_circular and not is_irregular else "")
        self.area_label_var.set("Área (mm²)" if is_irregular else "Área calculada (mm²)")
        if is_circular:
            self.primary_label.grid_remove()
            self.primary_entry.grid_remove()
            self.secondary_label.grid_remove()
            self.secondary_entry.grid_remove()
            self.diameter_label.grid()
            self.diameter_entry.grid()
        elif is_irregular:
            self.primary_label.grid_remove()
            self.primary_entry.grid_remove()
            self.secondary_label.grid_remove()
            self.secondary_entry.grid_remove()
            self.diameter_label.grid_remove()
            self.diameter_entry.grid_remove()
        else:
            self.primary_label.grid()
            self.primary_entry.grid()
            self.secondary_label.grid()
            self.secondary_entry.grid()
            self.diameter_label.grid_remove()
            self.diameter_entry.grid_remove()
        self._apply_lock_states()

    def export_png(self):
        curve = self.controller.get_curve()
        if curve is None:
            show_warning("Sin datos", "Primero importa un CSV y selecciona una probeta.")
            return
        initial = f"{curve.specimen_id}_modulo2_v1_1_6.png"
        path = filedialog.asksaveasfilename(title="Exportar PNG", defaultextension=".png", initialfile=initial, filetypes=[("PNG", "*.png")])
        if not path:
            return
        try:
            self.canvas.draw()
            self.fig.savefig(path, dpi=220, facecolor=self.fig.get_facecolor())
            self.status_var.set(f"PNG exportado: {Path(path).name}")
        except Exception as exc:
            show_error("Exportar PNG", exc)

    def pick_curve_color(self):
        curve = self.controller.get_curve()
        if curve is None:
            return
        color = colorchooser.askcolor(color=curve.visual_state.curve_color)[1]
        if color:
            curve.visual_state.curve_color = color
            self._refresh_current_curve(reset_view=False)

    def pick_line_color(self):
        curve = self.controller.get_curve()
        if curve is None:
            return
        color = colorchooser.askcolor(color=curve.visual_state.line_color)[1]
        if color:
            curve.visual_state.line_color = color
            self._refresh_current_curve(reset_view=False)

    def pick_offset_color(self):
        curve = self.controller.get_curve()
        if curve is None:
            return
        color = colorchooser.askcolor(color=curve.visual_state.offset_line_color)[1]
        if color:
            curve.visual_state.offset_line_color = color
            self._refresh_current_curve(reset_view=False)

    def _apply_lock_states(self):
        meta_state = "readonly" if self.meta_lock_var.get() else "normal"
        for ent in self.meta_entries.values():
            ent.configure(state=meta_state)

        geo_state = "readonly" if self.geometry_lock_var.get() else "normal"
        self.shape_combo.configure(state="disabled" if self.geometry_lock_var.get() else "readonly")
        shape = normalize_shape(self.geometry_vars["shape"].get())
        is_circular = shape == SHAPE_CIRCULAR
        is_irregular = shape == SHAPE_IRREGULAR
        if is_circular:
            self.diameter_entry.configure(state=geo_state)
            self.primary_entry.configure(state="readonly")
            self.secondary_entry.configure(state="readonly")
        elif is_irregular:
            self.diameter_entry.configure(state="readonly")
            self.primary_entry.configure(state="readonly")
            self.secondary_entry.configure(state="readonly")
        else:
            self.diameter_entry.configure(state="readonly")
            self.primary_entry.configure(state=geo_state)
            self.secondary_entry.configure(state=geo_state)
        self.area_entry.configure(state=geo_state if is_irregular else "readonly")
        self.gauge_entry.configure(state=geo_state)

        res_state = "readonly" if self.results_lock_var.get() else "normal"
        for ent in self.result_entries.values():
            ent.configure(state=res_state)


    def _update_area_preview(self, *_args):
        shape = normalize_shape(self.geometry_vars["shape"].get())
        side1 = self._parse_float(self.geometry_vars["side1"].get())
        side2 = self._parse_float(self.geometry_vars["side2"].get())
        diameter = self._parse_float(self.geometry_vars["diameter"].get())
        area = None
        if shape == SHAPE_CIRCULAR and diameter and diameter > 0:
            area = np.pi * (diameter ** 2) / 4.0
        elif shape == SHAPE_RECTANGULAR and side1 and side2 and side1 > 0 and side2 > 0:
            area = side1 * side2
        if shape != SHAPE_IRREGULAR:
            self._suspend_geometry_trace = True
            try:
                self.geometry_vars["area"].set(self._fmt(area, 4) if area is not None else "")
            finally:
                self._suspend_geometry_trace = False
        self._apply_shape_state()

    def _on_key_prev(self, _event=None):
        self._nudge_selected(-1)

    def _on_key_next(self, _event=None):
        self._nudge_selected(1)

    def _nudge_selected(self, delta: int):
        curve = self.controller.get_curve()
        if curve is None or self.selection_var.get() != "manual":
            return
        target = curve.visual_state.selected_target
        if target not in {"a", "b", "max"}:
            return
        vs = curve.visual_state
        if target == "a":
            base_idx = vs.chosen_line_handles.point_a.index if vs.chosen_line_handles.point_a.index is not None else 0
        elif target == "b":
            base_idx = vs.chosen_line_handles.point_b.index if vs.chosen_line_handles.point_b.index is not None else 0
        else:
            base_idx = vs.chosen_max.index if vs.chosen_max.index is not None else 0
        new_idx = max(0, min(len(curve.df) - 1, int(base_idx) + int(delta)))
        self.controller.set_manual_target_by_index(target, new_idx)
        curve.visual_state.selected_target = target
        self._refresh_current_curve(reset_view=False)

    @staticmethod
    def _parse_float(text):
        text = (text or "").strip().replace(",", ".")
        if not text:
            return None
        try:
            return float(text)
        except Exception:
            return None

    @staticmethod
    def _fmt(value, ndigits=2):
        if value is None:
            return ""
        try:
            return f"{float(value):.{ndigits}f}"
        except Exception:
            return ""

    def _save_export_metadata(self) -> None:
        dataset = self.controller.dataset
        if dataset is None:
            return
        dataset.meta.update({
            "Procedimiento": self.meta_vars["procedure"].get().strip(),
            "Norma de referencia": self.meta_vars["standard"].get().strip(),
            "Equipo Utilizado": self.meta_vars["machine"].get().strip(),
            "Material": self.meta_vars["material"].get().strip(),
            "Velocidad de ensayo": self.meta_vars["speed"].get().strip(),
            "Humedad Máx/Mín": self.meta_vars["humidity"].get().strip(),
            "Temperatura Máx/Mín": self.meta_vars["temp"].get().strip(),
            "Control de Velocidad": self.meta_vars["control"].get().strip(),
            "Número de Orden": self.order_var.get().strip(),
            "Comment": self.comment_text.get("1.0", "end").strip(),
        })
        dataset.default_comment = self.comment_text.get("1.0", "end").strip() or dataset.default_comment

    def open_export_dialog(self):
        dataset = self.controller.dataset
        if dataset is None:
            show_warning("Sin datos", "Primero importa un CSV antes de preparar el informe.")
            return
        from lematzium_modulo2.ui.export_dialog import ReportExportDialog

        self._save_export_metadata()
        ReportExportDialog(
            self.root,
            dataset=dataset,
            default_order_number=self.order_var.get().strip(),
            default_comment=self.comment_text.get("1.0", "end").strip() or dataset.default_comment,
        )

    def run(self):
        self.root.mainloop()


def launch_tensile_offset02_app():
    app = TensileOffset02App()
    app.run()
