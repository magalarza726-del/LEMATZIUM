ASSAY_CODE = "tensile_offset02"
ASSAY_NAME = "Ensayo de tracción - fluencia por 0.2% offset"
ASSAY_FAMILY = "curve_based"
SOURCE_POLICY = "CSV_ONLY"
REQUIRED_INPUTS = [
    "curve_points",
    "original_area_mm2 or dimensions",
    "gauge_length_mm",
]
EXPECTED_OUTPUTS = [
    "scalar_results",
    "table_results",
    "plot_results",
    "warnings",
    "audit_data",
]
REPORT_MODE = "future_word_template"
EXPORT_FORMATS = ["json"]
UI_MODE = "tkinter_desktop"
