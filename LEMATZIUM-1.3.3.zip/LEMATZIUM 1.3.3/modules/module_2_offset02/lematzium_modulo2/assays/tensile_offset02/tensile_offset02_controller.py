from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from .tensile_offset02_calculator import (
    clear_tensile_offset02_manuals,
    format_elastic_modulus_gpa,
    recalculate_tensile_offset02_curve,
    set_tensile_offset02_manual_handle,
    set_tensile_offset02_offset_percent,
    update_tensile_offset02_geometry,
)
from .tensile_offset02_reader import load_tensile_offset02_dataset

try:
    from shared.tensile_unified.compat import apply_unified_analysis_for_module2
except Exception:  # pragma: no cover - compatibilidad si shared no esta disponible
    apply_unified_analysis_for_module2 = None


class TensileOffset02Controller:
    def __init__(self):
        self.dataset = None
        self.current_file = None
        self.current_specimen_id = None

    def _apply_unified_analysis(self, curve):
        """Registra analisis del motor comun sin alterar el flujo historico."""
        if apply_unified_analysis_for_module2 is None:
            return
        try:
            apply_unified_analysis_for_module2(curve)
        except Exception as exc:
            if hasattr(curve, "diagnostics") and isinstance(curve.diagnostics, dict):
                curve.diagnostics["unified_bridge_error"] = f"{type(exc).__name__}: {exc}"

    def load_file(self, path: str):
        self.dataset = load_tensile_offset02_dataset(path)
        self.current_file = path
        for curve in self.dataset.curves:
            recalculate_tensile_offset02_curve(curve)
        self._apply_unified_analysis(curve)
        ids = self.dataset.specimen_ids()
        self.current_specimen_id = ids[0] if ids else None
        return self.dataset

    def get_curve(self):
        if not self.dataset or not self.current_specimen_id:
            return None
        return self.dataset.get_curve(self.current_specimen_id)

    def set_specimen(self, specimen_id: str):
        self.current_specimen_id = specimen_id

    def set_manual_target_by_index(self, target: str, index: int):
        curve = self.get_curve()
        if curve is None:
            return
        set_tensile_offset02_manual_handle(curve, target, index)
        self._apply_unified_analysis(curve)

    def clear_manuals(self):
        curve = self.get_curve()
        if curve is None:
            return
        clear_tensile_offset02_manuals(curve)
        self._apply_unified_analysis(curve)

    def recalculate_all(self):
        """Recalcula todas las curvas sin recargar el archivo fuente."""
        if self.dataset is None:
            raise RuntimeError("No hay dataset cargado.")
        current_id = self.current_specimen_id
        for curve in self.dataset.curves:
            recalculate_tensile_offset02_curve(curve)
        self._apply_unified_analysis(curve)
        self.current_specimen_id = current_id


    def update_offset_percent(self, offset_percent):
        curve = self.get_curve()
        if curve is None:
            return
        set_tensile_offset02_offset_percent(curve, offset_percent)
        recalculate_tensile_offset02_curve(curve)
        self._apply_unified_analysis(curve)

    def update_offset_percent_all(self, offset_percent):
        if self.dataset is None:
            return
        current_id = self.current_specimen_id
        for curve in self.dataset.curves:
            set_tensile_offset02_offset_percent(curve, offset_percent)
            recalculate_tensile_offset02_curve(curve)
            self._apply_unified_analysis(curve)
        self.current_specimen_id = current_id

    def update_geometry(self, shape, side1_mm, side2_mm, diameter_mm, gauge_length_mm, area_mm2_manual=None):
        curve = self.get_curve()
        if curve is None:
            return
        update_tensile_offset02_geometry(curve, shape, side1_mm, side2_mm, diameter_mm, gauge_length_mm, area_mm2_manual)
        self._apply_unified_analysis(curve)

    def update_geometry_all(self, shape, side1_mm, side2_mm, diameter_mm, gauge_length_mm, area_mm2_manual=None):
        if self.dataset is None:
            return
        current_id = self.current_specimen_id
        for curve in self.dataset.curves:
            update_tensile_offset02_geometry(curve, shape, side1_mm, side2_mm, diameter_mm, gauge_length_mm, area_mm2_manual)
            self._apply_unified_analysis(curve)
        self.current_specimen_id = current_id

    def build_summary_rows(self):
        rows = []
        if not self.dataset:
            return rows
        for curve in self.dataset.curves:
            rows.append({
                "specimen": curve.specimen_id,
                "elastic_gpa": curve.diagnostics.get("elastic_modulus_gpa"),
                "elastic_gpa_text": format_elastic_modulus_gpa(curve),
                "yield_mpa": curve.visual_state.auto_yield.y_mpa,
                "max_mpa": curve.visual_state.chosen_max.y_mpa,
            })
        return rows
