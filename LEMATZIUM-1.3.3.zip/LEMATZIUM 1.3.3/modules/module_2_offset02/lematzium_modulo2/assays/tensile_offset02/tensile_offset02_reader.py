from __future__ import annotations

import re
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import pandas as pd

from lematzium_modulo2.core.common import (
    as_float,
    as_text,
    detect_delimiter_from_bytes,
    first_nonempty_index,
    is_blank_row,
    make_unique_name,
    normalize_row,
)
from .tensile_offset02_models import (
    SHAPE_CIRCULAR,
    SHAPE_IRREGULAR,
    SHAPE_RECTANGULAR,
    TensileOffset02CurveData,
    TensileOffset02Dataset,
    TensileOffset02Geometry,
    normalize_shape,
)
try:
    from shared.tensile_geometry import shape_from_headers
except ModuleNotFoundError:
    def shape_from_headers(headers, export_shape=None):
        return normalize_shape(export_shape)


class TensileOffset02FileReadError(RuntimeError):
    pass


class TensileOffset02ParseError(RuntimeError):
    pass


SUPPORTED_TEXT_EXTENSIONS = {".csv", ".txt", ".tsv", ".dat", ".prn"}
SUPPORTED_EXCEL_EXTENSIONS = {".xlsx", ".xlsm", ".xltx", ".xltm", ".xls", ".xlsb"}
SUPPORTED_INPUT_EXTENSIONS = SUPPORTED_TEXT_EXTENSIONS | SUPPORTED_EXCEL_EXTENSIONS


DEFAULT_COMMENT = (
    "El área corresponde al área nominal de la muestra.\n"
    "El esfuerzo de fluencia corresponde al valor Rp0,2 calculado sobre una recta base del tramo lineal inicial.\n"
    "La visualización de la recta es una guía para el analista y no reemplaza la revisión técnica.\n"
)


def _looks_like_specimen_name(text: str) -> bool:
    value = as_text(text)
    if not value:
        return False
    lower = value.lower()
    forbidden = {"titulo", "forma:", "nombre", "nombre:", "parametro", "unidades", "unidad de longitud", "tiempo", "seg"}
    if lower in forbidden:
        return False
    block_match = re.match(r"^(\d+)\s*-\s*(\d+)$", value)
    if block_match:
        left, right = block_match.groups()
        if len(left) <= 2 and len(right) <= 2:
            return False
    return True


def _header_index(headers: list[str], *needles: str) -> Optional[int]:
    normalized = [as_text(h).lower().replace(":", "").strip() for h in headers]
    for idx, cell in enumerate(normalized):
        if any(needle in cell for needle in needles):
            return idx
    return None


def _export_shape_before_geometry(rows: list[list[str]], geometry_header_idx: int) -> Optional[str]:
    start = max(0, geometry_header_idx - 8)
    for idx in range(start, geometry_header_idx):
        row = rows[idx]
        first = as_text(row[0]).lower().replace(":", "") if row else ""
        if first == "forma":
            if idx + 1 < geometry_header_idx and rows[idx + 1]:
                return as_text(rows[idx + 1][0])
        if idx > 0:
            prev = rows[idx - 1]
            prev_first = as_text(prev[0]).lower().replace(":", "") if prev else ""
            if prev_first == "forma":
                return as_text(row[0])
    return None


def _geometry_from_row(row: list[str], headers: list[str], export_shape: Optional[str]) -> TensileOffset02Geometry:
    thickness_idx = _header_index(headers, "espesor", "thickness", "lado 1")
    width_idx = _header_index(headers, "anchura", "ancho", "width", "lado 2")
    diameter_idx = _header_index(headers, "diámetro", "diametro", "diameter")
    area_idx = _header_index(headers, "área", "area")
    gauge_idx = _header_index(headers, "longitud", "calibrada", "gauge")

    gauge = as_float(row[gauge_idx]) if gauge_idx is not None and len(row) > gauge_idx else np.nan
    shape = shape_from_headers(headers, export_shape)

    if diameter_idx is not None:
        diameter = as_float(row[diameter_idx]) if len(row) > diameter_idx else np.nan
        return TensileOffset02Geometry(
            shape=SHAPE_CIRCULAR,
            diameter_mm=diameter if np.isfinite(diameter) else None,
            gauge_length_mm=gauge if np.isfinite(gauge) else None,
        )
    if thickness_idx is not None and width_idx is not None:
        side1 = as_float(row[thickness_idx]) if len(row) > thickness_idx else np.nan
        side2 = as_float(row[width_idx]) if len(row) > width_idx else np.nan
        return TensileOffset02Geometry(
            shape=SHAPE_RECTANGULAR,
            side1_mm=side1 if np.isfinite(side1) else None,
            side2_mm=side2 if np.isfinite(side2) else None,
            gauge_length_mm=gauge if np.isfinite(gauge) else None,
        )
    if area_idx is not None:
        area = as_float(row[area_idx]) if len(row) > area_idx else np.nan
        return TensileOffset02Geometry(
            shape=SHAPE_IRREGULAR,
            area_mm2_manual=area if np.isfinite(area) else None,
            gauge_length_mm=gauge if np.isfinite(gauge) else None,
        )
    return TensileOffset02Geometry(shape=normalize_shape(shape), gauge_length_mm=gauge if np.isfinite(gauge) else None)


def read_tensile_offset02_table(path: str | Path, sheet_name: Optional[str] = None) -> pd.DataFrame:
    path = Path(path)
    ext = path.suffix.lower()
    if ext not in SUPPORTED_INPUT_EXTENSIONS:
        raise TensileOffset02FileReadError(f"Extensión no soportada: {ext}")
    if ext in SUPPORTED_TEXT_EXTENSIONS:
        raw = path.read_bytes()
        delimiter = detect_delimiter_from_bytes(raw)
        last_error = None
        for encoding in ["utf-8-sig", "utf-8", "cp1252", "latin1"]:
            try:
                return pd.read_csv(path, sep=delimiter, header=None, dtype=str, encoding=encoding, engine="python", keep_default_na=False)
            except Exception as exc:
                last_error = exc
        raise TensileOffset02FileReadError(str(last_error))
    engine_candidates: list[Tuple[str, dict]] = []
    if ext == ".xlsb":
        engine_candidates = [("pyxlsb", {})]
    elif ext == ".xls":
        engine_candidates = [("xlrd", {})]
    else:
        engine_candidates = [("openpyxl", {"read_only": True, "data_only": True})]
    last_error = None
    for engine, kwargs in engine_candidates:
        try:
            excel_file = pd.ExcelFile(path, engine=engine, engine_kwargs=kwargs if kwargs else None)
            sheet = sheet_name or excel_file.sheet_names[0]
            return pd.read_excel(excel_file, sheet_name=sheet, header=None, dtype=str, keep_default_na=False)
        except Exception as exc:
            last_error = exc
    raise TensileOffset02FileReadError(str(last_error))


def dataframe_to_rows(df: pd.DataFrame) -> list[list[str]]:
    rows: list[list[str]] = []
    for _, row in df.iterrows():
        rows.append(normalize_row(row.tolist()))
    return rows


def parse_tensile_offset02_machine_export(rows: list[list[str]], source_path: str) -> TensileOffset02Dataset:
    meta: dict[str, str] = {}
    header_idx = first_nonempty_index(rows, lambda r: len(r) >= 2 and r[0].lower() == "titulo")
    if header_idx is None or header_idx + 1 >= len(rows):
        raise TensileOffset02ParseError("No se encontró la cabecera general de exportación.")
    meta_keys = rows[header_idx]
    meta_values = rows[header_idx + 1]
    for key, value in zip(meta_keys, meta_values):
        key = as_text(key)
        if key:
            meta[key] = as_text(value)
    default_comment = meta.get("Comment", "") or DEFAULT_COMMENT

    geometry_header_idx = first_nonempty_index(
        rows,
        lambda r: len(r) >= 3 and as_text(r[0]).lower().startswith("nombre") and (
            any("espesor" in as_text(c).lower() for c in r)
            or any("anchura" in as_text(c).lower() for c in r)
            or any("diámetro" in as_text(c).lower() or "diametro" in as_text(c).lower() for c in r)
            or any("área" in as_text(c).lower() or "area" in as_text(c).lower() for c in r)
        ),
        start=header_idx + 1,
    )
    if geometry_header_idx is None:
        raise TensileOffset02ParseError("No se encontró la tabla de geometría.")

    geometry_rows: dict[str, TensileOffset02Geometry] = {}
    geometry_sequence: list[str] = []
    seen_names: dict[str, int] = {}
    geometry_headers = rows[geometry_header_idx]
    export_shape = _export_shape_before_geometry(rows, geometry_header_idx)
    i = geometry_header_idx + 1
    if i < len(rows) and rows[i] and as_text(rows[i][0]).lower().startswith("unidad"):
        i += 1
    while i < len(rows):
        row = rows[i]
        specimen_raw = as_text(row[0]) if len(row) > 0 else ""
        if not _looks_like_specimen_name(specimen_raw):
            break
        specimen_id = make_unique_name(specimen_raw.strip(), seen_names)
        geometry = _geometry_from_row(row, geometry_headers, export_shape)
        geometry_rows[specimen_id] = geometry
        geometry_sequence.append(specimen_id)
        i += 1

    result_map: dict[str, dict[str, float | None]] = {}
    result_header_idx = first_nonempty_index(
        rows,
        lambda r: len(r) >= 3 and r[0].lower() == "nombre" and ("máximo" in r[1].lower() or "fluencia" in r[1].lower()),
        start=i,
    )
    if result_header_idx is not None:
        j = result_header_idx + 3
        seen_result_names: dict[str, int] = {}
        while j < len(rows):
            row = rows[j]
            specimen_raw = as_text(row[0]) if len(row) > 0 else ""
            if not _looks_like_specimen_name(specimen_raw):
                break
            specimen_id = make_unique_name(specimen_raw, seen_result_names)
            header = [c.lower() for c in rows[result_header_idx]]
            max_idx = 1 if len(header) > 1 and "máximo" in header[1] else (2 if len(header) > 2 and "máximo" in header[2] else None)
            yield_idx = 1 if len(header) > 1 and "fluencia" in header[1] else (2 if len(header) > 2 and "fluencia" in header[2] else None)
            elong_idx = 2 if len(header) > 2 and "elong" in header[2] else (3 if len(header) > 3 and "elong" in header[3] else None)
            result_map[specimen_id] = {
                "yield_mpa": nan_to_none(as_float(row[yield_idx]) if yield_idx is not None and len(row) > yield_idx else np.nan),
                "max_mpa": nan_to_none(as_float(row[max_idx]) if max_idx is not None and len(row) > max_idx else np.nan),
                "elong_pct": nan_to_none(as_float(row[elong_idx]) if elong_idx is not None and len(row) > elong_idx else np.nan),
            }
            j += 1

    block_starts: list[tuple[int, str]] = []
    for idx, row in enumerate(rows):
        tag = as_text(row[0]) if row else ""
        if not re.match(r"^\d+\s*-\s*\d+$", tag):
            continue
        next_row = rows[idx + 1] if idx + 1 < len(rows) else []
        if len(next_row) >= 3 and next_row[0].lower() == "tiempo" and "carga" in next_row[1].lower() and "alarg" in next_row[2].lower():
            block_starts.append((idx, re.sub(r"\s+", "", tag)))
    if not block_starts:
        raise TensileOffset02ParseError("No se encontraron bloques de puntos.")

    curves: list[TensileOffset02CurveData] = []
    for ordinal, (start_idx, block_id) in enumerate(block_starts):
        specimen_id = geometry_sequence[ordinal] if ordinal < len(geometry_sequence) else f"Specimen_{ordinal+1:02d}"
        geometry = geometry_rows.get(specimen_id, TensileOffset02Geometry())
        results = result_map.get(specimen_id, {})
        data_start = start_idx + 3
        data_rows: list[list[str]] = []
        k = data_start
        while k < len(rows):
            current = rows[k]
            first = as_text(current[0]) if current else ""
            if re.match(r"^\d+\s*-\s*\d+$", first):
                break
            if not current or is_blank_row(current):
                k += 1
                continue
            if not re.match(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$", first.replace(",", ".")):
                k += 1
                continue
            data_rows.append(current)
            k += 1
        df_curve = pd.DataFrame({
            "time_s": [as_float(r[0]) for r in data_rows],
            "load_kN": [as_float(r[1]) if len(r) > 1 else np.nan for r in data_rows],
            "elongation_mm": [as_float(r[2]) if len(r) > 2 else np.nan for r in data_rows],
        }).dropna(subset=["time_s", "load_kN", "elongation_mm"]).reset_index(drop=True)
        curves.append(TensileOffset02CurveData(
            specimen_id=specimen_id,
            block_id=block_id,
            geometry=geometry,
            raw_df=df_curve,
            reported_yield_mpa=results.get("yield_mpa"),
            reported_max_mpa=results.get("max_mpa"),
            reported_elong_after_fracture_pct=results.get("elong_pct"),
        ))
    return TensileOffset02Dataset(source_path=str(source_path), source_kind="machine_export", meta=meta, curves=curves, default_comment=default_comment)


def parse_tensile_offset02_generic_numeric_table(df: pd.DataFrame, source_path: str) -> TensileOffset02Dataset:
    lowered = [as_text(x).lower() for x in df.iloc[0].tolist()]
    def find_col(possible_names):
        for idx, col_name in enumerate(lowered):
            if any(name in col_name for name in possible_names):
                return idx
        return None
    time_idx = find_col(["time", "tiempo", "seg"])
    load_idx = find_col(["load", "carga", "kn"])
    elong_idx = find_col(["elong", "alarg", "disp", "mm"])
    stress_idx = find_col(["stress", "esfuerzo", "mpa"])
    if elong_idx is None:
        raise TensileOffset02ParseError("No se encontró columna de alargamiento.")
    if load_idx is None and stress_idx is None:
        raise TensileOffset02ParseError("No se encontró carga o esfuerzo.")
    table = df.iloc[1:].copy().reset_index(drop=True)
    out = pd.DataFrame()
    out["time_s"] = table.iloc[:, time_idx].map(as_float) if time_idx is not None else np.arange(len(table), dtype=float)
    out["elongation_mm"] = table.iloc[:, elong_idx].map(as_float)
    if load_idx is not None:
        out["load_kN"] = table.iloc[:, load_idx].map(as_float)
    if stress_idx is not None:
        out["stress_MPa"] = table.iloc[:, stress_idx].map(as_float)
    out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=["elongation_mm"]).reset_index(drop=True)
    curve = TensileOffset02CurveData(
        specimen_id=Path(source_path).stem,
        block_id="1-1",
        geometry=TensileOffset02Geometry(),
        raw_df=out,
    )
    return TensileOffset02Dataset(source_path=str(source_path), source_kind="generic_table", meta={}, curves=[curve], default_comment=DEFAULT_COMMENT)


def load_tensile_offset02_dataset(path: str | Path, sheet_name: Optional[str] = None) -> TensileOffset02Dataset:
    table = read_tensile_offset02_table(path, sheet_name=sheet_name)
    rows = dataframe_to_rows(table)
    try:
        return parse_tensile_offset02_machine_export(rows, str(path))
    except Exception:
        return parse_tensile_offset02_generic_numeric_table(table, str(path))


def nan_to_none(value):
    try:
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return None
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return None
