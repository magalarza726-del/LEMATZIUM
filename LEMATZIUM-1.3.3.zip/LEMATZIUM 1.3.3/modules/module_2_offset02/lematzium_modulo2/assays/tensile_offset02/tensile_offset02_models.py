from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np
import pandas as pd

try:
    from shared.tensile_geometry import (
        SHAPE_CIRCULAR,
        SHAPE_IRREGULAR,
        SHAPE_OPTIONS,
        SHAPE_RECTANGULAR,
        TensileGeometry,
        normalize_shape,
    )
except ModuleNotFoundError:  # ejecución directa del módulo sin launcher
    import sys
    from pathlib import Path

    _modules_dir = Path(__file__).resolve().parents[4]
    if str(_modules_dir) not in sys.path:
        sys.path.insert(0, str(_modules_dir))
    from shared.tensile_geometry import (
        SHAPE_CIRCULAR,
        SHAPE_IRREGULAR,
        SHAPE_OPTIONS,
        SHAPE_RECTANGULAR,
        TensileGeometry,
        normalize_shape,
    )


class TensileOffset02Geometry(TensileGeometry):
    pass


@dataclass
class TensileOffset02Point:
    index: Optional[int] = None
    x_mm: Optional[float] = None
    y_mpa: Optional[float] = None
    source: str = "auto"
    note: str = ""


@dataclass
class TensileOffset02LineHandles:
    point_a: TensileOffset02Point = field(default_factory=TensileOffset02Point)
    point_b: TensileOffset02Point = field(default_factory=TensileOffset02Point)
    source: str = "auto"


@dataclass
class TensileOffset02VisualState:
    auto_line_handles: TensileOffset02LineHandles = field(default_factory=TensileOffset02LineHandles)
    manual_line_handles: TensileOffset02LineHandles = field(default_factory=TensileOffset02LineHandles)
    auto_yield: TensileOffset02Point = field(default_factory=TensileOffset02Point)
    auto_max: TensileOffset02Point = field(default_factory=TensileOffset02Point)
    manual_max: TensileOffset02Point = field(default_factory=TensileOffset02Point)
    selected_target: str = "none"
    curve_color: str = "#0b69a3"
    line_color: str = "#d97706"
    offset_line_color: str = "#7c3aed"

    @property
    def chosen_line_handles(self) -> TensileOffset02LineHandles:
        if self.manual_line_handles.point_a.index is not None and self.manual_line_handles.point_b.index is not None:
            return self.manual_line_handles
        return self.auto_line_handles

    @property
    def chosen_yield(self) -> TensileOffset02Point:
        return self.auto_yield

    @property
    def chosen_max(self) -> TensileOffset02Point:
        if self.manual_max.index is not None:
            return self.manual_max
        return self.auto_max


@dataclass
class TensileOffset02CurveData:
    specimen_id: str
    block_id: str
    geometry: TensileOffset02Geometry
    raw_df: pd.DataFrame
    offset_percent: float = 0.2
    reported_yield_mpa: Optional[float] = None
    reported_max_mpa: Optional[float] = None
    reported_elong_after_fracture_pct: Optional[float] = None
    diagnostics: dict[str, Any] = field(default_factory=dict)
    visual_state: TensileOffset02VisualState = field(default_factory=TensileOffset02VisualState)

    @property
    def df(self) -> pd.DataFrame:
        df = self.raw_df.copy()
        area = self.geometry.area_mm2
        if area and "load_kN" in df.columns:
            df["stress_MPa"] = (df["load_kN"].astype(float) * 1000.0) / float(area)
        elif "stress_MPa" in df.columns:
            df["stress_MPa"] = df["stress_MPa"].astype(float)
        if "elongation_mm" in df.columns:
            df["elongation_mm"] = df["elongation_mm"].astype(float)
        if self.geometry.gauge_length_mm and np.isfinite(self.geometry.gauge_length_mm):
            df["strain_mm_mm"] = df["elongation_mm"] / float(self.geometry.gauge_length_mm)
        else:
            df["strain_mm_mm"] = np.nan
        return df


@dataclass
class TensileOffset02Dataset:
    source_path: str
    source_kind: str
    meta: dict[str, Any]
    curves: list[TensileOffset02CurveData] = field(default_factory=list)
    default_comment: str = ""

    def specimen_ids(self) -> list[str]:
        return [c.specimen_id for c in self.curves]

    def get_curve(self, specimen_id: str) -> TensileOffset02CurveData:
        for curve in self.curves:
            if curve.specimen_id == specimen_id:
                return curve
        raise KeyError(f"No existe la probeta '{specimen_id}'.")
