from __future__ import annotations

import math

from matplotlib.ticker import AutoMinorLocator, FuncFormatter, MultipleLocator
import numpy as np

from .tensile_offset02_calculator import (
    format_rp_label,
    get_curve_offset_percent,
    line_parameters_from_handles,
)



def _graph_bool(value, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "si", "sí", "on", "y"}

def configure_tensile_offset02_decimal_formatters(ax):
    def smart_fmt(value, _pos=None):
        x0, x1 = ax.get_xlim()
        span = abs(x1 - x0)
        if span <= 0.01:
            return f"{value:.5f}"
        if span <= 0.10:
            return f"{value:.4f}"
        if span <= 1.0:
            return f"{value:.3f}"
        if span <= 10.0:
            return f"{value:.2f}"
        return f"{value:.1f}"

    def smart_fmt_y(value, _pos=None):
        y0, y1 = ax.get_ylim()
        span = abs(y1 - y0)
        if span <= 1.0:
            return f"{value:.4f}"
        if span <= 10.0:
            return f"{value:.3f}"
        if span <= 100.0:
            return f"{value:.2f}"
        return f"{value:.1f}"

    ax.xaxis.set_major_formatter(FuncFormatter(smart_fmt))
    ax.yaxis.set_major_formatter(FuncFormatter(smart_fmt_y))
    ax.format_coord = lambda x, y: f"x={x:.4f} mm | y={y:.4f} MPa"


def adapt_tensile_offset02_zoom_precision(ax, target_ticks: int = 8) -> None:
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    x_span = max(abs(x1 - x0), 1e-9)
    y_span = max(abs(y1 - y0), 1e-9)
    x_step = _nice_step(x_span, target_ticks)
    y_step = _nice_step(y_span, target_ticks)
    if x_step > 0:
        ax.xaxis.set_major_locator(MultipleLocator(x_step))
    if y_step > 0:
        ax.yaxis.set_major_locator(MultipleLocator(y_step))
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    configure_tensile_offset02_decimal_formatters(ax)


def _nice_step(max_value: float, target_steps: int = 8) -> float:
    max_value = max(float(max_value), 1e-9)
    raw = max_value / max(target_steps, 1)
    exponent = math.floor(math.log10(raw)) if raw > 0 else 0
    fraction = raw / (10 ** exponent)
    if fraction <= 1:
        nice = 1
    elif fraction <= 2:
        nice = 2
    elif fraction <= 2.5:
        nice = 2.5
    elif fraction <= 5:
        nice = 5
    else:
        nice = 10
    return nice * (10 ** exponent)


def _ceil_to_step(value: float, step: float) -> float:
    if step <= 0:
        return value
    return math.ceil(value / step) * step



def _line_points_for_visible_box(m: float, b: float, xlim, ylim, overscan: float = 0.20):
    x0, x1 = float(xlim[0]), float(xlim[1])
    y0, y1 = float(ylim[0]), float(ylim[1])
    dx = max(abs(x1 - x0), 1e-9)
    dy = max(abs(y1 - y0), 1e-9)

    # Se expande la caja visible para que la línea siga viéndose completa
    # incluso cuando el analista use configuración manual agresiva.
    x0e, x1e = x0 - dx * overscan, x1 + dx * overscan
    y0e, y1e = y0 - dy * overscan, y1 + dy * overscan

    pts = []

    # Intersecciones con bordes verticales
    y_at_x0 = m * x0e + b
    y_at_x1 = m * x1e + b
    if y0e <= y_at_x0 <= y1e:
        pts.append((x0e, y_at_x0))
    if y0e <= y_at_x1 <= y1e:
        pts.append((x1e, y_at_x1))

    # Intersecciones con bordes horizontales
    if abs(m) < 1e-12:
        if y0e <= b <= y1e:
            pts.extend([(x0e, b), (x1e, b)])
    else:
        x_at_y0 = (y0e - b) / m
        x_at_y1 = (y1e - b) / m
        if x0e <= x_at_y0 <= x1e:
            pts.append((x_at_y0, y0e))
        if x0e <= x_at_y1 <= x1e:
            pts.append((x_at_y1, y1e))

    # Quitar duplicados por tolerancia
    uniq = []
    for px, py in pts:
        if not any(abs(px - ux) < 1e-9 and abs(py - uy) < 1e-9 for ux, uy in uniq):
            uniq.append((px, py))

    if len(uniq) >= 2:
        # Elegir el par más separado para garantizar línea larga completa
        best = None
        best_d2 = -1.0
        for i in range(len(uniq)):
            for j in range(i + 1, len(uniq)):
                d2 = (uniq[i][0] - uniq[j][0]) ** 2 + (uniq[i][1] - uniq[j][1]) ** 2
                if d2 > best_d2:
                    best_d2 = d2
                    best = (uniq[i], uniq[j])
        return best

    # Fallback robusto: usar un rango en x más largo que la vista actual.
    xline = np.array([x0e, x1e], dtype=float)
    yline = m * xline + b
    return (xline[0], yline[0]), (xline[1], yline[1])

def _apply_grid_and_decimals(ax, x_grid: float, y_grid: float) -> None:
    if x_grid and x_grid > 0:
        ax.xaxis.set_major_locator(MultipleLocator(x_grid))
    if y_grid and y_grid > 0:
        ax.yaxis.set_major_locator(MultipleLocator(y_grid))
    ax.xaxis.set_minor_locator(AutoMinorLocator(2))
    ax.yaxis.set_minor_locator(AutoMinorLocator(2))
    configure_tensile_offset02_decimal_formatters(ax)


def apply_tensile_offset02_axes_config(ax, config: dict, x_data, y_data):
    axis_mode = config.get("axis_mode", "auto")
    x_data_max = max(float(np.nanmax(x_data)) if len(x_data) else 1.0, 1e-6)
    y_data_max = max(float(np.nanmax(y_data)) if len(y_data) else 1.0, 1e-6)

    if axis_mode == "manual":
        x_grid = config.get("grid_x") or _nice_step(config.get("x_max") or x_data_max)
        y_grid = config.get("grid_y") or _nice_step(config.get("y_max") or y_data_max)
        x_max = config.get("x_max") if config.get("x_max") and config.get("x_max") > 0 else _ceil_to_step(x_data_max, x_grid)
        y_max = config.get("y_max") if config.get("y_max") and config.get("y_max") > 0 else _ceil_to_step(y_data_max, y_grid)
        ax.set_xlim(0.0, float(x_max))
        ax.set_ylim(0.0, float(y_max))
        _apply_grid_and_decimals(ax, float(x_grid), float(y_grid))
        return

    x_grid = config.get("grid_x") or _nice_step(x_data_max)
    y_grid = config.get("grid_y") or _nice_step(y_data_max)
    x_max = _ceil_to_step(x_data_max, x_grid)
    y_max = _ceil_to_step(y_data_max, y_grid)
    if x_max <= 0:
        x_max = x_grid
    if y_max <= 0:
        y_max = y_grid
    ax.set_xlim(0.0, float(x_max))
    ax.set_ylim(0.0, float(y_max))
    _apply_grid_and_decimals(ax, float(x_grid), float(y_grid))




def _dedupe_legend_entries(handles, labels):
    """Devuelve entradas de leyenda únicas, ignorando etiquetas internas de Matplotlib."""
    unique_handles = []
    unique_labels = []
    seen = set()
    for handle, label in zip(handles, labels):
        if not label or label.startswith("_") or label in seen:
            continue
        seen.add(label)
        unique_handles.append(handle)
        unique_labels.append(label)
    return unique_handles, unique_labels


def _apply_tensile_offset02_legend(ax, graph_config: dict | None = None) -> None:
    """Ubica una única leyenda de forma segura para pantalla o reporte.

    Para el reporte Word se usa leyenda interna. Esto evita el recorte producido por
    leyendas externas con ``bbox_to_anchor`` cuando el PNG se inserta en una celda
    de ancho fijo. En pantalla se conserva el modo externo por compatibilidad visual.
    """
    config = graph_config or {}
    mode = str(config.get("legend_mode", "outside")).lower().strip()
    handles, labels = _dedupe_legend_entries(*ax.get_legend_handles_labels())

    existing = ax.get_legend()
    if existing is not None:
        existing.remove()

    if not handles or not labels or mode in {"none", "hidden", "off"}:
        return

    if mode in {"inside", "inside_report", "report"}:
        ax.legend(
            handles,
            labels,
            loc="best",
            fontsize=7,
            frameon=True,
            framealpha=0.90,
            borderpad=0.35,
            labelspacing=0.30,
            handlelength=1.8,
        )
        if getattr(ax, "figure", None) is not None:
            ax.figure.subplots_adjust(left=0.10, right=0.98, bottom=0.13, top=0.90)
        return

    # Modo pantalla: se deja la leyenda externa, pero reservando margen derecho.
    if getattr(ax, "figure", None) is not None:
        ax.figure.subplots_adjust(right=0.82)
    ax.legend(
        handles,
        labels,
        loc="upper left",
        bbox_to_anchor=(1.01, 1.0),
        borderaxespad=0.0,
        fontsize=8,
        frameon=True,
        framealpha=0.90,
    )

def draw_tensile_offset02_curve(ax, curve, graph_config: dict, visible_limits=None):
    ax.clear()
    df = curve.df
    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)
    visual = curve.visual_state
    report_clean = _graph_bool((graph_config or {}).get("report_clean"), default=False)

    ax.set_facecolor("#fbfcfd")
    ax.set_xlabel("Alargamiento (mm)")
    ax.set_ylabel("Esfuerzo (MPa)")
    ax.plot(x, y, color=visual.curve_color, linewidth=1.2, label=curve.specimen_id)

    # Primero se fijan límites y localizadores mayores/menores; luego se activa la grilla.
    # Antes, la grilla se configuraba solo como major antes de definir los minor locators,
    # por lo que las líneas secundarias punteadas no llegaban al PNG del reporte.
    apply_tensile_offset02_axes_config(ax, graph_config, x, y)
    if visible_limits is not None:
        ax.set_xlim(*visible_limits[0])
        ax.set_ylim(*visible_limits[1])
        configure_tensile_offset02_decimal_formatters(ax)

    if report_clean:
        # Reporte: líneas principales continuas y líneas secundarias punteadas,
        # reforzadas para conservarse visibles tras la exportación a Word/PDF.
        ax.set_axisbelow(True)
        ax.grid(True, which="major", color="#777777", linestyle="-", linewidth=0.82, alpha=0.98)
        ax.grid(True, which="minor", color="#737373", linestyle=(0, (1.35, 2.15)), linewidth=0.82, alpha=1.0)
        tick_size = int((graph_config or {}).get("report_tick_label_size") or 7)
        ax.tick_params(axis="both", which="major", labelsize=tick_size)
        ax.tick_params(axis="both", which="minor", labelsize=max(5, tick_size - 1))
    else:
        # Interfaz: conserva el estilo de vista previa.
        ax.grid(True, which="major", color="#d0d7df", linestyle="--", linewidth=0.6)
        ax.grid(True, which="minor", color="#e3e8ee", linestyle=":", linewidth=0.45, alpha=0.78)

    handles = visual.chosen_line_handles
    params = line_parameters_from_handles(curve, handles)
    if params is not None:
        m, b, a_idx, b_idx = params
        line_p1, line_p2 = _line_points_for_visible_box(m, b, ax.get_xlim(), ax.get_ylim(), overscan=0.35)
        xline = np.array([line_p1[0], line_p2[0]], dtype=float)
        yline = np.array([line_p1[1], line_p2[1]], dtype=float)
        ax.plot(xline, yline, color=visual.line_color, linewidth=1.8, linestyle='-', label='_nolegend_')

        gauge = curve.geometry.gauge_length_mm if curve.geometry.gauge_length_mm and np.isfinite(curve.geometry.gauge_length_mm) else None
        if gauge and gauge > 0:
            offset_percent = get_curve_offset_percent(curve)
            shift_mm = float(gauge) * offset_percent / 100.0
            b_offset = b - m * shift_mm
            off_p1, off_p2 = _line_points_for_visible_box(m, b_offset, ax.get_xlim(), ax.get_ylim(), overscan=0.35)
            xline_offset = np.array([off_p1[0], off_p2[0]], dtype=float)
            yline_offset = np.array([off_p1[1], off_p2[1]], dtype=float)
            ax.plot(xline_offset, yline_offset, color=visual.offset_line_color, linewidth=1.8, linestyle='--', label='_nolegend_')

    rp_label = format_rp_label(get_curve_offset_percent(curve))
    for label, point, color in [
        ("A", handles.point_a, "#b91c1c"),
        ("B", handles.point_b, "#15803d"),
        ("MÁX", visual.chosen_max, "#111827"),
        (rp_label, visual.auto_yield, "#7c3aed"),
    ]:
        if point.index is None or point.x_mm is None or point.y_mpa is None:
            continue
        aliases = {label.lower()}
        if label == 'A':
            aliases.add('a')
        elif label == 'B':
            aliases.add('b')
        elif label.startswith('M'):
            aliases.add('max')
        marker_size = 70 if visual.selected_target.lower() in aliases else 36
        ax.scatter([point.x_mm], [point.y_mpa], s=marker_size, zorder=6, color=color, edgecolors='white', linewidths=0.8)
        ax.annotate(label, (point.x_mm, point.y_mpa), textcoords="offset points", xytext=(5, -7), fontsize=9, color=color)

    ax.set_title(f"Curva esfuerzo-alargamiento: {curve.specimen_id}", fontsize=12)
    _apply_tensile_offset02_legend(ax, graph_config)
