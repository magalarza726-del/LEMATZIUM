from __future__ import annotations

import io
import math
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Sequence

import matplotlib
matplotlib.use("Agg")
from matplotlib.figure import Figure
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_models import TensileOffset02CurveData, TensileOffset02Dataset
from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_calculator import (
    format_rp_label,
    get_curve_offset_percent,
)
from lematzium_modulo2.assays.tensile_offset02.tensile_offset02_plots import draw_tensile_offset02_curve
from .ot_pdf_reader import OTContext
from .templates import ACCREDITATION_ACCREDITED, ACCREDITATION_NON_ACCREDITED, get_report_template_path
from shared.tensile_report_tables import build_geometry_table
from shared.word_report_utils import (
    add_inline_picture as _add_inline_picture,
    cleanup_editable_report as _cleanup_editable_report,
    prepare_editable_document as _prepare_editable_document,
    remove_document_protection as _shared_remove_document_protection,
)

ARIAL = "Arial"
HEADER_FONT = "Calibri"
SECTION_FILL = "C0C0C0"
REPORT_LAYOUT_PATCH_VERSION = "v7_fecha_ensayo_borde_final_plus_4pt_real_header_calibri_body"
# Equivalente aproximado a mover un borde de tabla 1 punto en Word.
WORD_POINT_CM = 2.54 / 72
SAMPLE_TABLE_WIDTHS_CM = [
    1.75,
    4.05 - 3 * WORD_POINT_CM,  # descripción: borde hacia fecha de recepción 3 puntos a la izquierda
    1.75 + 3 * WORD_POINT_CM,  # fecha recepción gana esos 3 puntos
    2.05,
    2.20,
    3.10 + WORD_POINT_CM,  # línea condición/fecha de ensayo: 1 punto a la derecha
    1.60 + 8 * WORD_POINT_CM,  # v7: borde final derecho 2 puntos MAS que v6; movimiento real +2 puntos
]
SAMPLE_TABLE_WIDTH_CM = sum(SAMPLE_TABLE_WIDTHS_CM)
REPORT_TABLE_WIDTH_CM = SAMPLE_TABLE_WIDTH_CM


@dataclass
class ReportExportGroup:
    report_number: str
    order_number: str
    specimen_ids: List[str]
    observations: str = ""
    title: str = "ENSAYO DE TENSIÓN"


@dataclass
class ReportExportPayload:
    accreditation_mode: str
    issue_date: str = ""
    client_name: str = ""
    client_phone: str = ""
    client_address: str = ""
    client_email: str = ""
    client_contact: str = ""
    default_comment: str = ""
    source_path: str = ""
    ot_pdf_path: str = ""
    ot_context: Optional[OTContext] = None
    groups: List[ReportExportGroup] = field(default_factory=list)


def _safe(value: Any) -> str:
    if value is None:
        return ""
    return str(value).replace("\ufeff", "").strip()


_SPANISH_MONTHS = {
    "enero": 1,
    "febrero": 2,
    "marzo": 3,
    "abril": 4,
    "mayo": 5,
    "junio": 6,
    "julio": 7,
    "agosto": 8,
    "septiembre": 9,
    "setiembre": 9,
    "octubre": 10,
    "noviembre": 11,
    "diciembre": 12,
}


def _flatten_spaces(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _client_line(value: Any) -> str:
    """Normaliza campos del encabezado provenientes del PDF de OT a una sola línea."""
    return _flatten_spaces(_safe(value))


def _to_iso_date(value: Any) -> str:
    normalized = _flatten_spaces(_safe(value))
    if not normalized:
        return ""
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
        return normalized
    match = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})", normalized)
    if match:
        day, month, year = match.groups()
        if len(year) == 2:
            year = f"20{year}"
        return f"{int(year):04d}-{int(month):02d}-{int(day):02d}"
    match = re.search(r"(\d{1,2})\s+de\s+([A-Za-zÁÉÍÓÚáéíóúñÑ]+)\s+del?\s+(\d{4})", normalized, re.IGNORECASE)
    if match:
        day, month_text, year = match.groups()
        month = _SPANISH_MONTHS.get(month_text.lower())
        if month:
            return f"{int(year):04d}-{month:02d}-{int(day):02d}"
    return normalized


def _meta_first(meta: Any, *keys: str, default: str = "") -> Any:
    if not isinstance(meta, dict):
        return default
    for key in keys:
        value = meta.get(key)
        if value not in (None, ""):
            return value
    return default


def _f2(value: Optional[float], ndigits: int = 2) -> str:
    try:
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return ""
        return f"{float(value):.{ndigits}f}"
    except Exception:
        return ""


def _elastic_mpa_text(curve: TensileOffset02CurveData, ndigits: int = 1) -> str:
    try:
        value = curve.diagnostics.get("elastic_modulus_gpa")
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return "No disponible"
        return f"{float(value) * 1000.0:.{ndigits}f}"
    except Exception:
        return "No disponible"


def _f0(value: Optional[float]) -> str:
    try:
        if value is None or (isinstance(value, float) and math.isnan(value)):
            return ""
        return f"{float(value):.0f}"
    except Exception:
        return ""


def _set_cell_text(cell, text: str, *, bold: bool = False, align: int = WD_ALIGN_PARAGRAPH.LEFT, font_size: int = 9) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = align
    run = paragraph.add_run(_safe(text))
    run.bold = bold
    run.font.name = ARIAL
    run.font.size = Pt(font_size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def _set_table_borders(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "000000")


def _set_table_outer_borders_only(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "000000")
    for edge in ("insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "nil")


def _set_table_border_nil(table) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "nil")


def _set_row_cant_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def _set_paragraph_keep_together(paragraph, keep_with_next: bool = False) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    keep_lines = OxmlElement("w:keepLines")
    p_pr.append(keep_lines)
    if keep_with_next:
        keep_next = OxmlElement("w:keepNext")
        p_pr.append(keep_next)


def _cm_to_dxa(width_cm: float) -> int:
    """Convert centimeters to Word twips (dxa)."""
    return max(1, int(round(width_cm * 1440 / 2.54)))


def _set_table_fixed_widths(table, widths_cm: Sequence[float]) -> None:
    """Force Word to use the exact column grid instead of recalculating AutoFit.

    Setting only ``cell.width`` is not always enough: Word can rewrite the
    table grid when opening the document. This writes the table width, the
    fixed layout flag, the ``tblGrid`` columns, and each cell ``tcW`` value.
    """
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    tbl = table._tbl
    tbl_pr = tbl.tblPr

    # Center at XML level and remove any inherited indentation from the template.
    tbl_jc = tbl_pr.find(qn("w:jc"))
    if tbl_jc is None:
        tbl_jc = OxmlElement("w:jc")
        tbl_pr.append(tbl_jc)
    tbl_jc.set(qn("w:val"), "center")
    for tbl_ind in list(tbl_pr.findall(qn("w:tblInd"))):
        tbl_pr.remove(tbl_ind)

    tbl_layout = tbl_pr.find(qn("w:tblLayout"))
    if tbl_layout is None:
        tbl_layout = OxmlElement("w:tblLayout")
        tbl_pr.append(tbl_layout)
    tbl_layout.set(qn("w:type"), "fixed")

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), str(_cm_to_dxa(sum(widths_cm))))

    existing_grid = tbl.find(qn("w:tblGrid"))
    if existing_grid is not None:
        tbl.remove(existing_grid)
    tbl_grid = OxmlElement("w:tblGrid")
    for width in widths_cm:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(_cm_to_dxa(width)))
        tbl_grid.append(grid_col)
    tbl.insert(1, tbl_grid)

    for row in table.rows:
        for column_index, width in enumerate(widths_cm):
            cell = row.cells[column_index]
            cell.width = Cm(width)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:type"), "dxa")
            tc_w.set(qn("w:w"), str(_cm_to_dxa(width)))


def _make_table(document: Document, rows: int, cols: int, widths_cm: Sequence[float]):
    table = document.add_table(rows=rows, cols=cols)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    _set_table_fixed_widths(table, widths_cm)
    _set_table_borders(table)
    return table


def _add_simple_field(paragraph, field_code: str, placeholder: str = "1") -> None:
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), field_code)
    run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    _set_rpr_font_name(r_pr, HEADER_FONT)
    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), "22")  # 11 pt = 22 half-points
    r_pr.append(sz)
    sz_cs = OxmlElement("w:szCs")
    sz_cs.set(qn("w:val"), "22")
    r_pr.append(sz_cs)
    run.append(r_pr)
    text_el = OxmlElement("w:t")
    text_el.text = placeholder
    run.append(text_el)
    fld.append(run)
    paragraph._p.append(fld)


def _remove_document_protection(document: Document) -> None:
    _shared_remove_document_protection(document)


def _remove_leading_empty_paragraphs(document: Document) -> None:
    for paragraph in list(document.paragraphs):
        if paragraph.text.strip():
            break
        paragraph._element.getparent().remove(paragraph._element)



def _set_rpr_font_name(r_pr, font_name: str = HEADER_FONT) -> None:
    """Set run fonts explicitly to Calibri and tag them as Word body-theme text."""
    r_fonts = r_pr.find(qn("w:rFonts"))
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.insert(0, r_fonts)
    for attr in ("ascii", "hAnsi", "eastAsia", "cs"):
        r_fonts.set(qn(f"w:{attr}"), font_name)
    # These theme attributes make Word show/use the body font family when applicable.
    r_fonts.set(qn("w:asciiTheme"), "minorHAnsi")
    r_fonts.set(qn("w:hAnsiTheme"), "minorHAnsi")
    r_fonts.set(qn("w:eastAsiaTheme"), "minorEastAsia")
    r_fonts.set(qn("w:cstheme"), "minorBidi")


def _force_header_font_calibri_body(header) -> None:
    """Force every run in the Word header to Calibri (Body) at 11 pt.

    This includes runs created inside PAGE/NUMPAGES fields and paragraph breaks,
    so Word does not fall back to the template's previous 10 pt value when the
    user places the cursor in the header.
    """
    for run_el in header._element.xpath(".//w:r"):
        r_pr = run_el.find(qn("w:rPr"))
        if r_pr is None:
            r_pr = OxmlElement("w:rPr")
            run_el.insert(0, r_pr)
        _set_rpr_font_name(r_pr, HEADER_FONT)
        for tag in ("w:sz", "w:szCs"):
            existing = r_pr.find(qn(tag))
            if existing is None:
                existing = OxmlElement(tag)
                r_pr.append(existing)
            existing.set(qn("w:val"), "22")  # 11 pt = 22 half-points

def _set_header_content(document: Document, report_number: str, order_number: str, issue_date: str, total_pages: int) -> None:
    for section in document.sections:
        section.different_first_page_header_footer = False
        header = section.header
        if not header.tables:
            _force_header_font_calibri_body(header)
            continue
        header_table = header.tables[0]
        while len(header_table.rows) > 1:
            header_table._tbl.remove(header_table.rows[-1]._tr)
        metadata_row = header_table.add_row()
        if len(metadata_row.cells) == 3:
            left_cell, middle_cell, right_cell = metadata_row.cells
            middle_cell.text = ""
        else:
            left_cell, right_cell = metadata_row.cells
        left_p = left_cell.paragraphs[0]
        left_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        r = left_p.add_run("Hoja: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        _add_simple_field(left_p, "PAGE", "1")
        r = left_p.add_run(" de ")
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        _add_simple_field(left_p, "NUMPAGES", str(total_pages))
        left_p.add_run("\n")
        r = left_p.add_run("N° de informe: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        r = left_p.add_run(report_number)
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)

        right_p = right_cell.paragraphs[0]
        right_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        r = right_p.add_run("Fecha de emisión: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        r = right_p.add_run(issue_date)
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        right_p.add_run("\n")
        r = right_p.add_run("Número de Orden: ")
        r.bold = True
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        r = right_p.add_run(order_number)
        r.font.name = HEADER_FONT
        r.font.size = Pt(11)
        _set_table_border_nil(header_table)
        _force_header_font_calibri_body(header)


def _add_signature_block(document: Document) -> None:
    spacer = document.add_paragraph()
    spacer.paragraph_format.space_before = Pt(8)
    spacer.paragraph_format.space_after = Pt(4)
    table = document.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    row = table.rows[0]
    row.height = Cm(1.7)
    row.height_rule = WD_ROW_HEIGHT_RULE.EXACTLY
    row.cells[0].width = Cm(8.3)
    row.cells[1].width = Cm(8.3)
    _set_table_borders(table)
    _set_cell_text(table.cell(0, 0), "Departamento técnico", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=11)
    _set_cell_text(table.cell(0, 1), "", align=WD_ALIGN_PARAGRAPH.CENTER, font_size=11)


def _build_title_block(document: Document, report_number: str, order_number: str, issue_date: str) -> None:
    return


def _build_client_block(document: Document, payload: ReportExportPayload) -> None:
    title_table = _make_table(document, 1, 1, [REPORT_TABLE_WIDTH_CM])
    _set_cell_text(title_table.cell(0, 0), "DATOS GENERALES DEL CLIENTE", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=10)
    _set_cell_shading(title_table.cell(0, 0), SECTION_FILL)
    table = _make_table(document, 5, 1, [REPORT_TABLE_WIDTH_CM])
    _set_table_outer_borders_only(table)
    labels = ["DATOS DEL CLIENTE:", "TELÉFONO:", "DIRECCIÓN:", "CORREO ELECTRÓNICO:", "CONTACTO:"]
    values = [
        payload.client_name or (payload.ot_context.client_name if payload.ot_context else ""),
        payload.client_phone or (payload.ot_context.phone if payload.ot_context else ""),
        payload.client_address or (payload.ot_context.address if payload.ot_context else ""),
        payload.client_email or (payload.ot_context.email if payload.ot_context else ""),
        payload.client_contact or (payload.ot_context.contact if payload.ot_context else ""),
    ]
    for row_index, (label, value) in enumerate(zip(labels, values)):
        cell = table.cell(row_index, 0)
        cell.text = ""
        paragraph = cell.paragraphs[0]
        run_label = paragraph.add_run(label)
        run_label.bold = True
        run_label.font.name = ARIAL
        run_label.font.size = Pt(9)
        run_value = paragraph.add_run(f" {_client_line(value)}")
        run_value.font.name = ARIAL
        run_value.font.size = Pt(9)


def _sample_row_for_curve(dataset: TensileOffset02Dataset, curve: TensileOffset02CurveData, payload: ReportExportPayload) -> List[str]:
    meta = dataset.meta or {}
    ot_row = payload.ot_context.sample_rows.get(curve.specimen_id) if payload.ot_context else None
    description = (ot_row.description if ot_row else "") or curve.raw_df.attrs.get("description", "") or meta.get(f"description_{curve.specimen_id}", "")
    received = (ot_row.received_date if ot_row else "") or _meta_first(meta, "Fecha Recepción", "Fecha de Recepción")
    tested = _meta_first(meta, "Fecha Ensayo", "Fecha de Ensayo") or received
    return [
        curve.specimen_id,
        _safe(description),
        _to_iso_date(received),
        "☒ Cliente  \n☐ Otros  \n☐ No aplica",
        "☐ Cliente  \n☒ LEMAT  \n☐ No aplica",
        "☒ Acorde a norma  \n☐ No acorde a norma  \n☐ No aplica",
        _to_iso_date(tested),
    ]


def _set_checkbox_option_row(cell, label: str, selected: bool) -> None:
    _set_cell_text(
        cell,
        ("☒ " if selected else "☐ ") + label,
        align=WD_ALIGN_PARAGRAPH.LEFT,
        font_size=8,
    )
    for paragraph in cell.paragraphs:
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _build_sample_block(document: Document, dataset, payload: ReportExportPayload, group: ReportExportGroup) -> None:
    title_table = _make_table(document, 1, 1, [SAMPLE_TABLE_WIDTH_CM])
    _set_cell_text(title_table.cell(0, 0), "DATOS DE LA MUESTRA", bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=10)
    _set_cell_shading(title_table.cell(0, 0), SECTION_FILL)

    specimen_count = len(group.specimen_ids)
    table = _make_table(document, 1 + specimen_count * 3, 7, SAMPLE_TABLE_WIDTHS_CM)
    headers = [
        "Código de Muestra LEMAT",
        "Descripción de la muestra proporcionada por el cliente",
        "Fecha de\nRecepción",
        "Muestreo\nrealizado por",
        "Preparación de\nmuestra\nrealizada por",
        "Condición de\nentrega de la\nmuestra previo al\nensayo",
        "Fecha de\nEnsayo",
    ]
    for col_index, header in enumerate(headers):
        _set_cell_text(table.cell(0, col_index), header, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)

    for specimen_index, specimen_id in enumerate(group.specimen_ids):
        curve = dataset.get_curve(specimen_id)
        row_values = _sample_row_for_curve(dataset, curve, payload)
        start_row = 1 + specimen_index * 3
        end_row = start_row + 2

        for col_index in (0, 1, 2, 6):
            merged = table.cell(start_row, col_index).merge(table.cell(end_row, col_index))
            align = WD_ALIGN_PARAGRAPH.CENTER
            _set_cell_text(merged, row_values[col_index], align=align, font_size=8)
            merged.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

        _set_checkbox_option_row(table.cell(start_row + 0, 3), "Cliente", True)
        _set_checkbox_option_row(table.cell(start_row + 1, 3), "Otros", False)
        _set_checkbox_option_row(table.cell(start_row + 2, 3), "No aplica", False)

        _set_checkbox_option_row(table.cell(start_row + 0, 4), "Cliente", False)
        _set_checkbox_option_row(table.cell(start_row + 1, 4), "LEMAT", True)
        _set_checkbox_option_row(table.cell(start_row + 2, 4), "No aplica", False)

        _set_checkbox_option_row(table.cell(start_row + 0, 5), "Acorde a norma", True)
        _set_checkbox_option_row(table.cell(start_row + 1, 5), "No acorde a norma", False)
        _set_checkbox_option_row(table.cell(start_row + 2, 5), "No aplica", False)

    for row in table.rows[1:]:
        row.height = Cm(0.60)
        row.height_rule = WD_ROW_HEIGHT_RULE.EXACTLY

    # Reapply exact grid after vertical merges because Word/python-docx may rewrite tcW.
    _set_table_fixed_widths(table, SAMPLE_TABLE_WIDTHS_CM)


def _build_observations_block(document: Document, observations: str) -> None:
    # Separación equivalente a un Shift+Enter entre la tabla DATOS DE LA MUESTRA
    # y el rótulo Observaciones, manteniendo el flujo del reporte editable.
    cover_spacer = document.add_paragraph()
    cover_spacer.paragraph_format.space_before = Pt(0)
    cover_spacer.paragraph_format.space_after = Pt(0)
    cover_spacer.add_run().add_break(WD_BREAK.LINE)

    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(0)
    run = paragraph.add_run("Observaciones")
    run.bold = True
    run.font.name = ARIAL
    run.font.size = Pt(10)
    body = document.add_paragraph(_safe(observations))
    for run in body.runs:
        run.font.name = ARIAL
        run.font.size = Pt(9)


def _build_auto_graph_config(curve: TensileOffset02CurveData) -> dict:
    df = curve.df
    x = df["elongation_mm"].to_numpy(dtype=float)
    y = df["stress_MPa"].to_numpy(dtype=float)
    return {"axis_mode": "auto", "grid_x": None, "grid_y": None, "x_max": float(x.max()) if len(x) else None, "y_max": float(y.max()) if len(y) else None}


def render_curve_png(curve: TensileOffset02CurveData, *, width_inches: float = 7.2, height_inches: float = 4.35, dpi: int = 220) -> bytes:
    """Renderiza la curva para Word sin recortar la leyenda.

    La leyenda del reporte se coloca dentro del eje para evitar que Word la corte
    al insertar el PNG en una celda de ancho fijo. Se evita una segunda llamada a
    ``ax.legend`` porque la función de dibujo ya ubica una única leyenda.
    """
    figure = Figure(figsize=(width_inches, height_inches), dpi=dpi, facecolor="none")
    ax = figure.add_subplot(111)
    graph_config = _build_auto_graph_config(curve)
    graph_config["legend_mode"] = "inside_report"
    # El renderador de Offset 0.2 usa un motor propio; se activa explícitamente
    # el modo de reporte para que aplique líneas principales continuas y
    # secundarias punteadas, en lugar del estilo de pantalla.
    graph_config["report_clean"] = True
    graph_config["report_tick_label_size"] = 7
    draw_tensile_offset02_curve(ax, curve, graph_config)
    output = io.BytesIO()
    figure.tight_layout(pad=1.05)
    figure.savefig(output, format="png", dpi=dpi, transparent=True, bbox_inches=None)
    return output.getvalue()


def _build_tension_section(document: Document, dataset: TensileOffset02Dataset, group: ReportExportGroup, curve: TensileOffset02CurveData, comment_text: str) -> None:
    document.add_page_break()
    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(10)
    title_text = str(group.title or "ENSAYO DE TENSIÓN").upper()
    title_run = title.add_run(title_text)
    title_run.bold = True
    title_run.font.name = "Calibri"
    title_run.font.size = Pt(11)

    meta_table = _make_table(document, 4, 4, [3.2, 4.2, 3.6, 5.2])
    _set_table_border_nil(meta_table)
    left_pairs = [
        ("Procedimiento", _meta_first(dataset.meta, "Procedimiento", "Procedure", default="PEE/LEMAT/03")),
        ("Temperatura Máx/Mín", _meta_first(dataset.meta, "Temperatura Máx/Mín", "Temperatura Max/Min", "Temperature Max/Min")),
        ("Equipo utilizado", _meta_first(dataset.meta, "Equipo Utilizado", "Used Device", default="MUE 600KN")),
        ("Velocidad de ensayo", _meta_first(dataset.meta, "Velocidad de Ensayo", "Velocidad de ensayo", "Test Speed")),
    ]
    right_pairs = [
        ("Norma de Referencia", _meta_first(dataset.meta, "Norma de Referencia", "Norma de referencia", "Reference Standard", default="ISO 6892-1:2016")),
        ("Humedad Máx/Mín", _meta_first(dataset.meta, "Humedad Máx/Mín", "Humidity Max/Min")),
        ("Material", _meta_first(dataset.meta, "Material", default="Acero")),
        ("Control de Velocidad", _meta_first(dataset.meta, "Control de Velocidad", "Speed Control", default="Mediante tasa de esfuerzo")),
    ]
    for row_index, (label, value) in enumerate(left_pairs):
        _set_cell_text(meta_table.cell(row_index, 0), f"{label}:", bold=True, font_size=8)
        _set_cell_text(meta_table.cell(row_index, 1), _safe(value), font_size=8)
    for row_index, (label, value) in enumerate(right_pairs):
        _set_cell_text(meta_table.cell(row_index, 2), f"{label}:", bold=True, font_size=8)
        _set_cell_text(meta_table.cell(row_index, 3), _safe(value), font_size=8)

    build_geometry_table(document, curve.geometry, curve.specimen_id, result_widths_cm=[2.4, 3.6, 3.2, 3.6, 3.0])

    yield_point = curve.visual_state.chosen_yield
    max_point = curve.visual_state.chosen_max
    result_table = _make_table(document, 4, 5, [2.4, 3.6, 3.2, 3.6, 3.0])
    rp_percent = get_curve_offset_percent(curve)
    headers = ["Nombre", "Esfuerzo de Fluencia", "Esfuerzo Máximo", "Elongación luego de\nRotura", "M . Elástico"]
    for col_index, header in enumerate(headers):
        _set_cell_text(result_table.cell(0, col_index), header, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    parameter_labels = ["Parametro", f"{float(rp_percent):g} %", "", "", ""]
    unit_labels = ["Unidades", "MPa", "MPa", "%", "MPa"]
    yield_text = _f0(yield_point.y_mpa) or "No disponible"
    value_labels = [curve.specimen_id, yield_text, _f0(max_point.y_mpa), _f2(curve.reported_elong_after_fracture_pct, 1), _elastic_mpa_text(curve)]
    for col_index, value in enumerate(parameter_labels):
        _set_cell_text(result_table.cell(1, col_index), value, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    for col_index, value in enumerate(unit_labels):
        _set_cell_text(result_table.cell(2, col_index), value, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)
    for col_index, value in enumerate(value_labels):
        _set_cell_text(result_table.cell(3, col_index), value, align=WD_ALIGN_PARAGRAPH.CENTER, font_size=8)

    image_bytes = render_curve_png(curve, width_inches=7.2, height_inches=4.35, dpi=220)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp:
        tmp.write(image_bytes)
        temp_path = Path(tmp.name)

    figure_table = document.add_table(rows=1, cols=1)
    figure_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    figure_table.autofit = False
    _set_table_border_nil(figure_table)
    figure_row = figure_table.rows[0]
    _set_row_cant_split(figure_row)
    figure_cell = figure_row.cells[0]
    figure_cell.width = Cm(16.9)
    figure_cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

    picture_paragraph = figure_cell.paragraphs[0]
    picture_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_paragraph_keep_together(picture_paragraph, keep_with_next=True)
    picture_run = picture_paragraph.add_run()
    # La imagen no debe superar el ancho útil de la celda; si se inserta más
    # ancha, Word recorta visualmente la leyenda o fuerza un reescalado inestable.
    _add_inline_picture(picture_paragraph, temp_path, width_cm=16.4)

    comment_title = figure_cell.add_paragraph()
    comment_title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    _set_paragraph_keep_together(comment_title, keep_with_next=True)
    comment_run = comment_title.add_run("Comentarios")
    comment_run.bold = True
    comment_run.font.name = ARIAL
    comment_run.font.size = Pt(9)

    comment_lines = [line for line in _safe(comment_text).splitlines() if line.strip()] or [""]
    for index, line in enumerate(comment_lines):
        paragraph = figure_cell.add_paragraph()
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.space_before = Pt(0)
        if index < len(comment_lines) - 1:
            _set_paragraph_keep_together(paragraph, keep_with_next=True)
        else:
            _set_paragraph_keep_together(paragraph, keep_with_next=False)
        run = paragraph.add_run(line)
        run.font.name = ARIAL
        run.font.size = Pt(8)

    temp_path.unlink(missing_ok=True)


def create_report_document_from_template(template_path: str | Path) -> Document:
    document = Document(str(template_path))
    _prepare_editable_document(document)
    return document


def export_group_to_docx(dataset: TensileOffset02Dataset, payload: ReportExportPayload, group: ReportExportGroup, output_path: str | Path) -> Path:
    template_path = get_report_template_path(payload.accreditation_mode)
    document = create_report_document_from_template(template_path)
    total_pages = 1 + len(group.specimen_ids)
    _set_header_content(document, group.report_number, group.order_number, payload.issue_date, total_pages)
    _build_title_block(document, group.report_number, group.order_number, payload.issue_date)
    _build_client_block(document, payload)
    _build_sample_block(document, dataset, payload, group)
    _build_observations_block(document, group.observations)
    comment_text = payload.default_comment
    for specimen_id in group.specimen_ids:
        curve = dataset.get_curve(specimen_id)
        _build_tension_section(document, dataset, group, curve, comment_text)
    _add_signature_block(document)
    _cleanup_editable_report(document, max_table_width_cm=REPORT_TABLE_WIDTH_CM)
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    document.save(output)
    return output


def export_report_groups_to_docx(dataset: TensileOffset02Dataset, payload: ReportExportPayload, output_dir: str | Path) -> List[Path]:
    output_directory = Path(output_dir)
    output_directory.mkdir(parents=True, exist_ok=True)
    exported_files: List[Path] = []
    for group in payload.groups:
        client_name = payload.client_name or (payload.ot_context.client_name if payload.ot_context else "")
        filename = f"INFORME N°{group.report_number} {client_name} {group.order_number}.docx"
        filename = re.sub(r'[\\/:*?"<>|]', '_', filename).strip()
        exported_files.append(export_group_to_docx(dataset, payload, group, output_directory / filename))
    return exported_files


__all__ = [
    "ACCREDITATION_ACCREDITED",
    "ACCREDITATION_NON_ACCREDITED",
    "ReportExportGroup",
    "ReportExportPayload",
    "create_report_document_from_template",
    "export_group_to_docx",
    "export_report_groups_to_docx",
]
