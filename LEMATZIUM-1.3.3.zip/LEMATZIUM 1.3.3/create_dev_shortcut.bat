@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PY_CMD="

if exist ".venv\Scripts\python.exe" set "PY_CMD=.venv\Scripts\python.exe"
if not defined PY_CMD if exist "venv\Scripts\python.exe" set "PY_CMD=venv\Scripts\python.exe"

if not defined PY_CMD (
    where python >nul 2>&1
    if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
    where py >nul 2>&1
    if not errorlevel 1 set "PY_CMD=py"
)

if not defined PY_CMD (
    echo No se encontro Python en PATH ni en .venv/venv.
    echo Crea un entorno virtual .venv o instala Python y agregalo al PATH.
    pause
    exit /b 1
)

"%PY_CMD%" "launcher\dev_shortcut_sync.py"
if errorlevel 1 (
    echo No se pudo crear o actualizar el acceso directo de desarrollador.
    pause
    exit /b 1
)

echo Acceso directo de desarrollador creado o actualizado correctamente.
pause
