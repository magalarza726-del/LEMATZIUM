# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['launcher\\lematzium_suite_launcher.py'],
    pathex=[],
    binaries=[],
    datas=[('1-removebg-preview.png', '.'), ('2-removebg-preview.png', '.'), ('3-removebg-preview.png', '.'), ('4-removebg-preview.png', '.'), ('5-removebg-preview.png', '.'), ('6-removebg-preview.png', '.'), ('assets', 'assets'), ('SECRETO_LEMATZIUM', 'SECRETO_LEMATZIUM'), ('docs', 'docs')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LEMATZIUM',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['build_assets\\icons\\lematzium_default.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='LEMATZIUM',
)
