@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo === LEMATZIUM: compilacion de EXE con PyInstaller ===

set "PY_CMD=python"
set "LAUNCHER_TARGET=launcher\lematzium_suite_launcher.py"
set "ICON_FILE=build_assets\icons\lematzium_default.ico"
set "ISCC_CMD="

where %PY_CMD% >nul 2>&1
if errorlevel 1 (
  echo No se encontro Python en PATH. Instala Python y marca "Add Python to PATH".
  pause
  exit /b 1
)

%PY_CMD% --version
if errorlevel 1 (
  echo No se pudo ejecutar Python.
  pause
  exit /b 1
)

echo.
echo [0/6] Se usara el launcher actual: "%LAUNCHER_TARGET%".

%PY_CMD% -m pip install --upgrade pip
if errorlevel 1 goto :build_failed

%PY_CMD% -m pip install pyinstaller matplotlib numpy pandas python-docx openpyxl pillow pypdf PyPDF2 pyxlsb xlrd
if errorlevel 1 goto :build_failed

if exist build rd /s /q build
if exist dist rd /s /q dist
if exist release rd /s /q release
if exist modules\module_tensile_unified\build rd /s /q modules\module_tensile_unified\build
if exist modules\module_tensile_unified\dist rd /s /q modules\module_tensile_unified\dist
if exist modules\module_4_traccion_plasticos\build rd /s /q modules\module_4_traccion_plasticos\build
if exist modules\module_4_traccion_plasticos\dist rd /s /q modules\module_4_traccion_plasticos\dist
mkdir release
mkdir release\logs

where ISCC.exe >nul 2>&1
if not errorlevel 1 set "ISCC_CMD=ISCC.exe"
if not defined ISCC_CMD if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" set "ISCC_CMD=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if not defined ISCC_CMD if exist "C:\Program Files\Inno Setup 6\ISCC.exe" set "ISCC_CMD=C:\Program Files\Inno Setup 6\ISCC.exe"

echo.
echo [1/6] Validando codigo fuente...
%PY_CMD% tools\validate_refactor.py > release\logs\validate_refactor.log 2>&1
if errorlevel 1 goto :build_failed

echo.
echo [2/6] Compilando launcher principal...
%PY_CMD% -m PyInstaller --noconfirm --clean --windowed --onedir --name LEMATZIUM ^
  --icon "%ICON_FILE%" ^
  --add-data "1-removebg-preview.png;." ^
  --add-data "2-removebg-preview.png;." ^
  --add-data "3-removebg-preview.png;." ^
  --add-data "4-removebg-preview.png;." ^
  --add-data "5-removebg-preview.png;." ^
  --add-data "6-removebg-preview.png;." ^
  --add-data "docs;docs" ^
  --add-data "SECRETO_LEMATZIUM;SECRETO_LEMATZIUM" ^
  launcher\lematzium_suite_launcher.py > release\logs\build_launcher.log 2>&1
if errorlevel 1 goto :build_failed

echo.
echo [3/6] Compilando modulo de metales...
pushd modules\module_tensile_unified
%PY_CMD% -m PyInstaller --noconfirm --clean --windowed --onedir --name LEMATZIUM_Tension_Unificada ^
  --icon "..\..\build_assets\icons\lematzium_default.ico" ^
  --paths . ^
  --paths .. ^
  --paths ..\shared ^
  --paths ..\module_1_drop1mpa ^
  --paths ..\module_2_offset02 ^
  --add-data "lematzium_tensile_unified;lematzium_tensile_unified" ^
  launch_tensile_unified.py > ..\..\release\logs\build_metales.log 2>&1
if errorlevel 1 (
  popd
  goto :build_failed
)
popd

echo.
echo [4/6] Compilando modulo de traccion plasticos...
pushd modules\module_4_traccion_plasticos
%PY_CMD% -m PyInstaller --noconfirm --clean --windowed --onedir --name LEMATZIUM_Traccion_Plasticos ^
  --icon "..\..\build_assets\icons\lematzium_default.ico" ^
  --paths . ^
  --paths .. ^
  --paths ..\shared ^
  --paths ..\module_1_drop1mpa ^
  --paths ..\module_2_offset02 ^
  --add-data "lematzium_traccion_plasticos;lematzium_traccion_plasticos" ^
  --add-data "resources;resources" ^
  launch_traccion_plasticos.py > ..\..\release\logs\build_traccion_plasticos.log 2>&1
if errorlevel 1 (
  popd
  goto :build_failed
)
popd

echo.
echo [5/6] Armando estructura final...
mkdir release\app
mkdir release\app\modules
mkdir release\app\modules\module_tensile_unified
mkdir release\app\modules\module_4_traccion_plasticos
xcopy /e /i /y dist\LEMATZIUM\* release\app\ >nul
if errorlevel 1 goto :build_failed_copy
xcopy /e /i /y modules\module_tensile_unified\dist\LEMATZIUM_Tension_Unificada\* release\app\modules\module_tensile_unified\ >nul
if errorlevel 1 goto :build_failed_copy
xcopy /e /i /y modules\module_4_traccion_plasticos\dist\LEMATZIUM_Traccion_Plasticos\* release\app\modules\module_4_traccion_plasticos\ >nul
if errorlevel 1 goto :build_failed_copy
copy /y "%ICON_FILE%" release\app\lematzium_default.ico >nul

rem Reflejar ambos modulos dentro del dist del launcher para pruebas directas.
if not exist dist\LEMATZIUM\modules mkdir dist\LEMATZIUM\modules
if not exist dist\LEMATZIUM\modules\module_tensile_unified mkdir dist\LEMATZIUM\modules\module_tensile_unified
if not exist dist\LEMATZIUM\modules\module_4_traccion_plasticos mkdir dist\LEMATZIUM\modules\module_4_traccion_plasticos
xcopy /e /i /y modules\module_tensile_unified\dist\LEMATZIUM_Tension_Unificada\* dist\LEMATZIUM\modules\module_tensile_unified\ >nul
if errorlevel 1 goto :build_failed_copy
xcopy /e /i /y modules\module_4_traccion_plasticos\dist\LEMATZIUM_Traccion_Plasticos\* dist\LEMATZIUM\modules\module_4_traccion_plasticos\ >nul
if errorlevel 1 goto :build_failed_copy
copy /y "%ICON_FILE%" dist\LEMATZIUM\lematzium_default.ico >nul

echo.
echo [6/6] Finalizado.
echo Lanzador, modulo de metales y modulo de plasticos ensamblados.
echo Prueba rapida local: %CD%\dist\LEMATZIUM\LEMATZIUM.exe
echo Carpeta preparada para Inno Setup: %CD%\release\app
echo Script Inno: %CD%\installer\LEMATZIUM_Suite.iss

if defined ISCC_CMD (
  echo.
  echo Compilando instalador con Inno Setup...
  pushd installer
  "%ISCC_CMD%" "LEMATZIUM_Suite.iss" > ..\release\logs\build_installer.log 2>&1
  set "ISCC_ERROR=!ERRORLEVEL!"
  popd
  if not "!ISCC_ERROR!"=="0" goto :build_failed
  echo Instalador generado correctamente en la carpeta installer.
) else (
  echo.
  echo AVISO: no se encontro ISCC.exe. El setup no se genero automaticamente.
  echo Instala Inno Setup 6 o ejecuta installer\compilar_inno.bat.
)

pause
exit /b 0

:build_failed_copy
echo.
echo ERROR: fallo el copiado de archivos al paquete final.
echo Revisa release\app, dist\LEMATZIUM y release\logs\
pause
exit /b 1

:build_failed
echo.
echo ERROR: fallo la compilacion. Revisa los archivos en release\logs\
pause
exit /b 1
