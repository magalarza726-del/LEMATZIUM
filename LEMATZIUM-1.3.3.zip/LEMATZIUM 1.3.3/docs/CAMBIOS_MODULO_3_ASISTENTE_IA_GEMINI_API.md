# Cambios incorporados · Módulo 3 - Asistente virtual IA

## 1. Objetivo

Se actualizó el **Módulo 3 - Asistente virtual IA** de LEMATZIUM 1.3.3 para:

- Usar como modelo de escritura principal **Gemini 3.1 Flash Lite**, en lugar de Gemini 3 Flash.
- Mantener **Gemma 4 31B** como alternativa de escritura.
- Incorporar un mecanismo de **cambio automático de modelo** cuando el modelo activo agota cuota, supera límites de uso o presenta indisponibilidad temporal.
- Añadir un **botón de micrófono** para iniciar una sesión de **chat por audio en vivo** mediante Live API.

## 2. Integración en el HUB

El launcher principal mantiene la tarjeta:

- **Módulo 3 - Asistente virtual IA**

Desde esta tarjeta se abre una ventana independiente de chat textual y de audio.

## 3. Configuración disponible

En **Configuración > Asistente virtual IA** se mantienen los campos:

1. **Nombre del asistente virtual**.
2. **Modelo de escritura**:
   - Gemini 3.1 Flash Lite.
   - Gemma 4 31B.
3. **API key Google AI**.
4. **Modelo de audio**:
   - Gemini 3.1 Flash Live.
   - Gemini 2.5 Flash Native Audio Dialog.

Los valores se guardan en:

- `launcher/lematzium_suite_launcher_prefs.json`

También se conserva compatibilidad con preferencias antiguas que tenían guardado `Gemini 3 Flash`, migrándolas internamente a `Gemini 3.1 Flash Lite`.

## 4. Mapeo de modelos

| Etiqueta de interfaz | ID usado internamente |
| --- | --- |
| Gemini 3.1 Flash Lite | `gemini-3.1-flash-lite` |
| Gemma 4 31B | `gemma-4-31b-it` |
| Gemini 3.1 Flash Live | `gemini-3.1-flash-live-preview` |
| Gemini 2.5 Flash Native Audio Dialog | `gemini-2.5-flash-native-audio-preview-12-2025` |

## 5. Cambio automático de modelo de escritura

El módulo monitorea errores compatibles con:

- Agotamiento de cuota.
- Rate limit.
- Exceso de solicitudes por minuto/día.
- Saturación o indisponibilidad temporal.

Cuando ocurre uno de estos escenarios:

1. El módulo intenta la respuesta con el **modelo alternativo**.
2. Si la respuesta se obtiene, muestra un **aviso visible en la conversación**.
3. El modelo alternativo queda como **modelo activo temporal de la sesión**, evitando insistir repetidamente en el modelo agotado.
4. La preferencia del usuario en Configuración no se altera automáticamente.

## 6. Funcionalidad del módulo conversacional

El módulo incluye:

- Chat textual multi-turno durante la sesión abierta.
- Mensajes en segundo plano para no bloquear la interfaz.
- Botón **Nueva conversación**.
- Botón **Copiar última respuesta**.
- Aviso visible cuando se activa el fallback de modelo.
- Lectura automática del nombre del asistente, modelo de escritura, API y modelo de audio configurados en el HUB.
- Mensaje explícito cuando la API key no está configurada.
- Gestión defensiva ante errores del SDK o fallos de la API.

## 7. Botón de micrófono y chat por audio

Se añadió el botón:

- **🎙 Iniciar audio**

Al activarlo:

- Se abre una sesión Live API con el modelo de audio seleccionado en Configuración.
- Se captura el micrófono en PCM 16-bit, 16 kHz.
- Se recibe audio de respuesta del modelo y se reproduce a 24 kHz.
- Se muestran transcripciones de:
  - Audio del usuario.
  - Respuesta por audio del asistente.
- El botón cambia a:
  - **⏹ Detener audio**

Si la librería de audio o el dispositivo no están disponibles, el módulo informa el error sin afectar el chat textual.

## 8. Dependencias técnicas

Dependencias del módulo:

- `google-genai`
- `sounddevice`

El HUB instala `google-genai` y `sounddevice` cuando detecta que falta la dependencia principal requerida para abrir el módulo. Si `google-genai` ya existe, pero `sounddevice` no, el botón de audio muestra una instrucción clara para instalarlo:

- `pip install sounddevice`

## 9. API key

La clave se almacena localmente en el archivo de preferencias del launcher cuando se ingresa desde Configuración. Como alternativa, el módulo reconoce:

- `GOOGLE_API_KEY`
- `GEMINI_API_KEY`

Cuando existe una variable de entorno, esta tiene prioridad sobre el valor guardado en preferencias.


## 10. Asistente experto con base de conocimiento interna

Se añadió una capa de recuperación contextual local para responder preguntas sobre LEMATZIUM con mayor trazabilidad. El módulo indexa:

- Manual de uso incluido en `docs/knowledge/`.
- Documentos `.md` y `.txt` de soporte.
- Código fuente Python del launcher y módulos.
- Configuraciones JSON relevantes.

El chat textual recupera fragmentos antes de generar la respuesta y muestra en pantalla las fuentes internas consultadas. El objetivo es que el asistente pueda apoyar consultas de auditoría, soporte técnico y capacitación sin depender únicamente de la memoria del modelo.

## 11. Modos expertos de respuesta

En Configuración se agregó el campo **Modo experto**:

- **Auditoría estricta**: exige evidencia interna suficiente y declara vacíos cuando no puede confirmarlos.
- **Capacitación**: explica como instructor interno, con pasos y criterios operativos.
- **Soporte técnico**: orienta diagnóstico, relación entre configuración y código, y ubicación de componentes.

## 12. Gemma 4: Thinking / No thinking

En Configuración se agregó el campo **Gemma 4** con dos opciones:

- **Thinking**: usa `thinking_level="high"` al consultar `gemma-4-31b-it`.
- **No thinking**: no envía la configuración de thinking de Gemma 4.

La selección solo afecta a **Gemma 4 31B**; no modifica la configuración de Gemini 3.1 Flash Lite.

## 13. Audio con consulta de conocimiento

La sesión Live API se amplió con una herramienta local llamada:

- `buscar_conocimiento_lematzium`

El modelo de audio puede invocarla para recuperar evidencia del manual, documentación y código antes de responder preguntas sobre la aplicación. Esto permite que la experiencia de voz también funcione como asistente de auditoría y capacitación.

## 14. Botón de actualización de conocimiento

El Módulo 3 incorpora el botón **Actualizar conocimiento**, que vuelve a escanear el paquete local sin reiniciar la interfaz.

## 15. Rediseño de interfaz y memoria de conversaciones

Se rediseñó la interfaz del Módulo 3 para mejorar su uso diario:

- Distribución tipo chat moderno, evitando el desbordamiento inferior de botones y controles.
- Mensajes visualmente diferenciados entre usuario, asistente, audio, sistema y errores.
- Compositor inferior fijo, con botones de audio, actualización de conocimiento, copia de respuesta y envío en una sola franja ordenada.
- Panel lateral para revisar, reabrir y eliminar conversaciones guardadas.
- Persistencia automática del historial en `config/assistant_conversations.json`.
- Conservación de transcripciones de audio dentro de la conversación activa.
- Mejora del estilo de respuesta para que el asistente no solo informe, sino que guíe al usuario con rutas de uso, pasos, verificaciones y límites de evidencia.


## Actualización: profundidad algorítmica y chat tipo mensajería
- Se amplió la recuperación de conocimiento para preguntas de cálculo, código y auditoría.
- Se agregó expansión de consultas con términos internos, rutas y nombres de funciones relevantes.
- Se incorporó una guía técnica interna para el cálculo de fluencia superior del Módulo 1 - Metales.
- El prompt exige respuestas algorítmicas paso a paso, con variables, parámetros, umbrales, fallback y salidas del sistema cuando la evidencia lo permite.
- La interfaz del chat se rediseñó con burbujas estilo mensajería, distinción visual de roles, opción de copiar mensajes y edición de mensajes del usuario.
- Se añadió envío por Enter y salto de línea con Shift+Enter.
