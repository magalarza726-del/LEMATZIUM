# Corrección rápida Easter Egg - LEMATZIUM 1.3.2

Corrección aplicada:

- Se restauró la carpeta del minijuego como `SECRETO_LEMATZIUM`.
- Se corrigió el launcher para buscar el easter egg en rutas de código fuente, ejecutable y `_MEIPASS` de PyInstaller.
- Se agregó compatibilidad de respaldo con el nombre accidental `sl` para evitar fallos de importación en copias previas.
- Se verificó la importación de `lematzium_minijuego_retro.app.RetroMinigame`.

Activación: mantener presionada la tecla Espacio y hacer 5 clics consecutivos sobre la ruedita del personaje clásico.
