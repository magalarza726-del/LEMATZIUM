# Asistente experto LEMATZIUM: auditoría, capacitación y soporte

## Propósito

El Módulo 3 ya no funciona como un chatbot genérico: opera como asistente experto del programa. Su base de conocimiento se construye a partir de:

1. Manual de uso incorporado en `docs/knowledge/`.
2. Documentación técnica del proyecto.
3. Código fuente Python del launcher y módulos.
4. Configuraciones JSON relevantes.

## Estrategia de precisión

La arquitectura usa recuperación contextual local antes de consultar el modelo. Esto evita depender únicamente de la memoria probabilística del LLM y permite responder con mayor trazabilidad sobre:

- Uso operativo de la aplicación.
- Reportadores y autoexportación.
- Configuraciones del HUB.
- Algoritmos y archivos de código.
- Evidencias para auditoría.
- Explicaciones pedagógicas para analistas nuevos.

## Perfiles

### Auditoría estricta
- Responde solo con evidencia interna recuperada.
- Si falta sustento, declara explícitamente que no encontró evidencia suficiente.
- Distingue manual, código y documentación.

### Capacitación
- Explica por pasos, como instructor interno.
- Puede convertir el material recuperado en clases, recorridos o preguntas de evaluación.

### Soporte técnico
- Prioriza diagnóstico de problemas, ubicación de funciones y relación entre configuración y comportamiento.

## Texto y audio

- **Texto:** se construye un prompt con los fragmentos recuperados de la base de conocimiento.
- **Audio:** Live API recibe una herramienta local `buscar_conocimiento_lematzium`. La sesión de voz puede solicitar evidencia antes de contestar preguntas sobre la app.

## Nota de alcance

Este mecanismo no reentrena los pesos del modelo. Implementa una base de conocimiento consultable y controlada, adecuada para mantener actualizadas las respuestas cuando cambia el código o el manual.
