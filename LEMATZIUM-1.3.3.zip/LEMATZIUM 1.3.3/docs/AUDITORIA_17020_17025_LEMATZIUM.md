# AUDITORÍA 17020-17025 · LEMATZIUM

Documento de lectura rápida para revisión funcional del programa. Aplica a:

- Módulo 1 - Tracción Metales 1.3.0
- Módulo 2 - Tracción plásticos 1.0.0

Este documento explica el flujo informático de lectura CSV, graficación, cálculo, ubicación de puntos, edición controlada y exportación de informes. No reemplaza procedimientos del laboratorio, métodos normalizados ni registros primarios.

## 1. Flujo general

1. El usuario abre el módulo desde el launcher.
2. Importa un CSV de ensayo.
3. El sistema interpreta columnas de fuerza, desplazamiento, deformación, esfuerzo, tiempo o identificación de probeta, según estén disponibles.
4. Se separan curvas por probeta o serie.
5. El usuario revisa geometría, parámetros del método, identificación y observaciones.
6. El programa grafica la curva y calcula resultados.
7. Los puntos característicos se reflejan en tabla y en gráfica.
8. El reportador agrupa probetas, selecciona plantilla y exporta Word editable.

## 2. Lectura del CSV

LEMATZIUM no modifica el CSV original. El archivo se lee como dato externo y se convierte en vectores internos. Las filas vacías, encabezados repetidos o valores no numéricos se omiten cuando no son útiles para la curva. Si no existen datos numéricos suficientes, el módulo no debe calcular resultados automáticamente.

## 3. Graficación

La curva se genera con los vectores del CSV y la geometría ingresada. Cuando hay fuerza y área inicial, se calcula esfuerzo ingenieril. Cuando hay desplazamiento/deformación y longitud de referencia, se calcula deformación ingenieril. Al cambiar de curva o importar otro CSV, la escala debe reiniciarse para evitar arrastrar zoom o límites anteriores.

## 4. Cálculos básicos

- Esfuerzo ingenieril: σ = F / A.
- Deformación ingenieril: ε = ΔL / L0.
- Resistencia máxima: mayor esfuerzo válido de la curva.
- Punto final o rotura: último tramo útil, caída de esfuerzo/carga o último dato válido según configuración.

## 5. Módulo 1 - Tracción Metales 1.3.0

Procesa curvas de tracción en metales. Identifica resistencia máxima, fluencia cuando sea detectable, offset cuando aplica, rotura y resultados asociados. El usuario puede revisar la tabla, la gráfica y exportar informes con plantilla acreditada, no acreditada o plantillas agregadas.

## 6. Módulo 2 - Tracción plásticos 1.0.0

Procesa curvas de tracción en plásticos bajo enfoque ISO 527. El sistema reconoce comportamientos tipo A, B, C y D para ubicar los puntos relevantes. Los parámetros editables permiten ajustar deformaciones de módulo, deformación auxiliar, umbrales de caída/final y criterios auxiliares de detección.

Los puntos del módulo de plásticos se muestran con nombres técnicos legibles. El usuario puede cambiar esos nombres desde la tabla y guardarlos como predeterminados para evitar códigos ambiguos en futuras sesiones.

## 7. Ubicación de puntos

Los puntos se calculan a partir de la curva activa. En curvas sin fluencia se prioriza máximo y rotura/final. En curvas con fluencia se identifican puntos de fluencia o equivalentes técnicos. Para el módulo de plásticos, el módulo se calcula con dos deformaciones de referencia configurables y sus esfuerzos asociados.

## 8. Reportador y plantillas

El reportador incluye las plantillas base:

- Acreditado (MC2202-08)
- No acreditado (MC2201-06)

El botón **Agregar plantilla** permite seleccionar un archivo `.docx` adicional. El programa copia esa plantilla a una carpeta persistente y la registra en un manifiesto JSON. Desde ese momento aparece como opción permanente, aun después de cerrar y volver a abrir LEMATZIUM.

## 9. Exportación

Cada grupo creado en el reportador genera un informe Word independiente. El programa abre la plantilla seleccionada, inserta encabezado, datos de cliente, muestra, observaciones, resultados, tablas/gráficas disponibles y bloque de firma. No altera el CSV original ni la plantilla original seleccionada.

## 10. Verificación sugerida para auditoría

- El launcher debe mostrar solo los dos módulos aprobados.
- El botón AUDITORÍA 17020-17025 debe abrir este documento.
- El CSV debe importarse sin modificarse.
- La gráfica debe corresponder a los datos importados.
- La tabla y los puntos de la gráfica deben coincidir.
- Los parámetros editables solo deben afectar el análisis interno.
- Los nombres de puntos personalizados deben conservarse al reiniciar.
- Una plantilla agregada debe quedar disponible como opción permanente.
- Los informes exportados deben ser Word editables y trazables al CSV y a los datos ingresados.
