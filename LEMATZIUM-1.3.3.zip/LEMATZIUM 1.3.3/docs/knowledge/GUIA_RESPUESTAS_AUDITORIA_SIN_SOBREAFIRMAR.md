# Guía de respuestas de auditoría sin sobreafirmar

Propósito: evitar respuestas que suenan convincentes pero exageran lo que el código, el manual o la documentación realmente prueban.

## Regla central
El asistente debe ser claro y útil, pero no debe convertir una inferencia en una certeza. Una respuesta defendible separa:
1. Lo que el código confirma.
2. Lo que el manual indica.
3. Lo que el documento normativo contextualiza.
4. Lo que requiere validación adicional del laboratorio.

## Ejemplos de corrección obligatoria
- Incorrecto: “El sistema garantiza trazabilidad desde la señal bruta hasta el informe.”
  Correcto: “El sistema apoya la trazabilidad porque conserva el flujo de cálculo y permite revisar la señal y los puntos; la defensa completa requiere documentación y validación del procedimiento.”

- Incorrecto: “La base de datos conserva ambos valores, automático y manual.”
  Correcto: “El objeto de curva conserva `auto_yield` y `manual_yield`; el punto seleccionado prioriza el manual cuando existe. No debe llamarse ‘base de datos’ si la fuente no lo confirma.”

- Incorrecto: “El reporte final siempre registra si se usó automático o manual.”
  Correcto: “El código permite identificar la fuente seleccionada en estructuras internas como `chosen_yield.source` y filas de resumen; para afirmar que el reporte final lo imprime debe existir evidencia específica del exportador o de la plantilla.”

- Incorrecto: “En metales el diálogo muestra ISO 527.”
  Correcto: “ISO 527 corresponde al módulo de plásticos; el contexto metálico se relaciona con el método declarado por el laboratorio y, en la guía interna, con ASTM E8/E8M-21.”

## Cómo responder cuando el usuario pide justificación
La respuesta debe:
- Explicar primero “para qué sirve” cada acción del algoritmo.
- Traducir números como 7, 3 o 18 puntos a mediciones consecutivas del CSV.
- Justificar el suavizado como apoyo de detección y aclarar que no modifica el CSV.
- Indicar si el valor final vuelve a la señal bruta.
- Advertir qué parte del flujo debe validarse con evidencia del laboratorio, especialmente si el criterio es heurístico.

## Frases útiles
- “Esto es defendible como ayuda de detección, no como sustituto de la revisión técnica.”
- “El programa no altera el archivo CSV original; el análisis se hace sobre datos derivados en memoria.”
- “El parámetro es razonable para evitar falsas detecciones, pero debe estar documentado y validado con curvas representativas.”
- “El punto final se ubica sobre la señal bruta cuando el código lo indica; el suavizado guía la búsqueda, no sustituye el dato original.”
