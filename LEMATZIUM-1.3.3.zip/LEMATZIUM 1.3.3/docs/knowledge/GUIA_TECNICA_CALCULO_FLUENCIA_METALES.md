# Guía técnica interna: cálculo de la fluencia superior en el Módulo 1 - Tracción Metales

## Propósito
Este documento resume el algoritmo implementado en el código del Módulo 1 para calcular el punto de fluencia superior. Su función es ayudar al asistente LEMATZIUM IA a responder con profundidad, y servir como evidencia explicativa para capacitación y auditoría técnica.

## Archivos de código relacionados
- `modules/module_1_drop1mpa/lematzium_modulo1/assays/tensile_drop_1mpa/contracts.py`
- `modules/module_1_drop1mpa/lematzium_modulo1/assays/tensile_drop_1mpa/detection.py`
- `modules/module_1_drop1mpa/lematzium_modulo1/assays/tensile_drop_1mpa/controller.py`

## 1. Entrada de datos y conversión a esfuerzo
La detección de fluencia trabaja sobre dos vectores:
- `x = elongation_mm`
- `y = stress_MPa`

El vector `stress_MPa` se obtiene en `CurveState.df` de dos formas:
1. Si el CSV contiene `load_kN` y la geometría dispone de área `area_mm2`, el esfuerzo se calcula como:
   `stress_MPa = load_kN * 1000 / area_mm2`
   La unidad resultante es MPa porque `1 N/mm² = 1 MPa`.
2. Si el CSV ya contiene `stress_MPa`, el valor se convierte a numérico y se usa directamente.

El punto de fluencia que se reporta proviene de `curve.chosen_yield`:
- Si el usuario no ajustó manualmente el punto, se usa `curve.auto_yield`.
- Si existe un punto manual, se prioriza `curve.manual_yield`.

## 2. Parámetros por defecto del detector de fluencia superior
La clase `DetectionSettings` define los parámetros principales:
- `upper_yield_drop_mpa = 1.0` MPa. Es el criterio de caída mínima por defecto.
- `smoothing_window = 7` puntos para el detector principal.
- `min_candidate_fraction_of_global_max = 0.65`.
- `min_candidate_rise_mpa = 8.0` MPa.
- `min_x_fraction_before_search = 0.02`.
- `max_x_fraction_for_search = 0.70`.
- `snap_window_points = 18`.
- `first_peak_min_consecutive_drop_points = 3`.

El valor `upper_yield_drop_mpa` se sincroniza internamente con `min_required_drop_mpa` para mantener compatibilidad con versiones previas.

## 3. Flujo general del cálculo automático
La función `run_auto_detection(curve, settings)` ejecuta:
1. `curve.auto_max = detect_global_maximum(curve)`.
2. `curve.auto_yield = detect_upper_yield_by_drop(curve, settings=settings)`.
3. Guarda diagnósticos en `curve.diagnostics`, incluyendo:
   - configuración usada,
   - `upper_yield_drop_mpa`,
   - `upper_yield_stress_mpa`,
   - mensaje de detección.

La detección de fluencia superior sigue dos fases:
1. Intento principal: `_detect_first_peak_with_drop`.
2. Si no confirma un candidato, intento de respaldo: `_detect_upper_yield_fallback`.

## 4. Fase 1: detección por primer máximo con caída sostenida
La función `_detect_first_peak_with_drop` busca el primer máximo real de la curva seguido por una caída sostenida.

### Paso 4.1. Validación mínima
Si la curva tiene menos de 8 puntos, el algoritmo no intenta detectar fluencia.

### Paso 4.2. Suavizado del esfuerzo
Sobre el vector de esfuerzo bruto `y` se aplica:
1. Mediana móvil: `y_med = rolling_median(y, smoothing_window)`.
2. Media móvil: `y_smooth = rolling_mean(y_med, smoothing_window)`.

La secuencia mediana + media reduce picos espurios y hace más estable la búsqueda del primer máximo.

### Paso 4.3. Definición de la zona de búsqueda
Se calculan:
- `x_min = min(x)`.
- `x_max = max(x)`.
- `x_span = x_max - x_min`.
- `global_max = max(y_smooth)`.

Luego se define:
- `min_x_allowed = x_min + 0.02 * x_span`.
- `max_x_allowed = x_min + 0.70 * x_span`.
- `min_y_allowed = 0.65 * global_max`.

Interpretación:
- El algoritmo evita buscar demasiado cerca del origen.
- También evita buscar fluencia muy avanzada en la curva.
- Un candidato a fluencia debe tener una altura suficientemente relevante frente al máximo global suavizado.

### Paso 4.4. Línea base y seguimiento del máximo acumulado
El índice inicial se calcula con `searchsorted(x, min_x_allowed)`.
La línea base corresponde al mínimo de `y_smooth` hasta ese punto.

A partir de allí, el algoritmo recorre la curva y mantiene:
- `peak_idx`: índice del máximo acumulado actual.
- `peak_val`: valor del máximo acumulado actual.
- `consecutive_drop_points`: contador de puntos consecutivos que confirman una caída.

Si un nuevo punto tiene `current_y >= peak_val`, se reemplaza el máximo acumulado y el contador de caída vuelve a cero.

### Paso 4.5. Requisitos para aceptar el máximo como candidato de fluencia
Antes de contar una caída, el máximo acumulado debe cumplir simultáneamente:
1. `peak_val >= min_y_allowed`.
2. `peak_val - baseline >= min_candidate_rise_mpa`, cuyo valor por defecto es `8.0 MPa`.

Si no se cumple, el algoritmo sigue recorriendo la curva sin aceptar ese máximo como candidato.

### Paso 4.6. Confirmación de la caída sostenida
Se evalúa la diferencia:
`drop = peak_val - current_y`.

Si:
`drop >= min_required_drop_mpa`,
el contador `consecutive_drop_points` aumenta en 1.

Si la caída no alcanza el umbral, el contador vuelve a cero.

La fluencia se confirma cuando:
`consecutive_drop_points >= first_peak_min_consecutive_drop_points`.

Con los valores por defecto:
- Caída mínima: `1.0 MPa`.
- Persistencia mínima: `3 puntos consecutivos`.

### Paso 4.7. Ajuste del candidato a un máximo de la curva bruta
El algoritmo no reporta directamente el índice del máximo suavizado. Primero aplica:
`raw_idx = _snap_candidate_to_raw_peak(y, peak_idx, snap_window_points)`.

Esto busca el máximo real de la señal bruta `y` dentro de una ventana local de ±18 puntos alrededor del candidato suavizado.

El punto devuelto es:
- `index = raw_idx`
- `x = elongation_mm[raw_idx]`
- `y = stress_MPa[raw_idx]`
- `source = "auto"`
- nota: fluencia superior automática por primer máximo con caída sostenida.

## 5. Fase 2: fallback mecánico si la fase principal no confirma fluencia
Si `_detect_first_peak_with_drop` no devuelve índice, el sistema usa `_detect_upper_yield_fallback`.

### Paso 5.1. Nuevo suavizado y gradiente
Se calcula:
- `y_med = rolling_median(y, fallback_smoothing_window)`.
- `y_smooth = rolling_mean(y_med, fallback_smoothing_window)`.
- `grad = safe_gradient(y_smooth, x)`.

Por defecto, `fallback_smoothing_window = 9`.

### Paso 5.2. Localización de la región temprana de análisis
Se identifica el máximo global suavizado:
- `gmax_idx = argmax(y_smooth)`.
- `gmax_y = y_smooth[gmax_idx]`.
- `x_at_max = x[gmax_idx]`.

El límite temprano se define como:
`early_limit_x = max(x_at_max * 0.40, max(x) * 0.22)`.

Solo se consideran máximos locales de `y_smooth` cuya posición `x` esté dentro de esa región temprana.

### Paso 5.3. Umbral mínimo de altura del candidato
Para cada máximo local candidato, el valor debe cumplir:
`current_y >= max(min_required_drop_mpa * 5.0, 0.55 * gmax_y)`.

Así se descartan máximos locales demasiado pequeños para representar una fluencia superior.

### Paso 5.4. Gradiente previo positivo
Se calcula la mediana del gradiente antes del candidato:
`pre_grad = median(grad[left:idx])`.

Debe cumplirse:
`pre_grad > 0`.

Esto confirma que el candidato proviene de un tramo ascendente de la curva.

### Paso 5.5. Caída sostenida posterior
Se revisa una ventana posterior `future_window`.
Se calcula:
- `local_min_after = min(future_window)`.
- `sustained_drop = current_y - local_min_after`.
- `required_drop = max(min_required_drop_mpa, 0.0025 * gmax_y)`.

Debe cumplirse:
`sustained_drop >= required_drop`.

### Paso 5.6. Endurecimiento posterior
Se calcula:
`hardening_gain = max(future_far) - current_y`.

Debe cumplirse:
`hardening_gain >= 8.0 MPa`.

Este criterio evita aceptar como fluencia una caída final o un máximo aislado que no derive luego en endurecimiento del material.

### Paso 5.7. Comprobación de meseta o pendiente no positiva
El algoritmo calcula dos indicadores:
- `nonpositive_ratio = proporción de gradientes posteriores <= 0`.
- `plateau_ratio = proporción de puntos posteriores próximos al nivel del candidato`.

Se exige al menos una de estas condiciones:
- `nonpositive_ratio >= 0.35`, o
- `plateau_ratio >= 0.35`.

### Paso 5.8. Puntuación de candidatos y selección del mejor
Cada candidato válido recibe una puntuación:
`score = 800/(idx+5) + sustained_drop*12 + hardening_gain*2 + pre_grad*0.1 + plateau_ratio*20 + nonpositive_ratio*20`.

La puntuación prioriza:
- candidatos tempranos,
- mayor caída sostenida,
- endurecimiento posterior,
- gradiente previo positivo,
- evidencia de meseta o pendiente no positiva.

Se conserva el candidato con mayor `score`.

### Paso 5.9. Ajuste final a la señal bruta
Al igual que en la fase 1, el índice escogido se ajusta a un máximo de la señal bruta en una ventana local de ±18 puntos.

Si se encuentra candidato, se devuelve un `SelectedPoint` automático con la nota:
- “Fluencia automática por fallback mecánico”.

Si no se encuentra candidato, el sistema devuelve un punto sin índice y la nota:
- “No se pudo detectar automáticamente una fluencia superior confiable.”

## 6. Ajuste manual del punto de fluencia
Si el analista mueve manualmente el punto YP/fluencia en la interfaz:
1. El sistema calcula el índice de la curva más cercano a la coordenada seleccionada mediante `nearest_index`.
2. La distancia se normaliza con los rangos totales de X e Y:
   - `dx = (x - x_manual) / x_span`
   - `dy = (y - y_manual) / y_span`
3. Se minimiza `dx² + dy²` cuando se dispone de X e Y; si solo se dispone de X, se minimiza `dx²`.
4. El punto seleccionado se almacena en `curve.manual_yield`.
5. `curve.chosen_yield` prioriza el punto manual sobre el automático.

## 7. Cómo debería explicarse en auditoría o capacitación
Una respuesta técnica completa debe dejar claro que:
- El Módulo 1 calcula esfuerzo antes de detectar fluencia.
- La detección automática de fluencia superior no es una “lectura visual simple”; combina suavizado, ventana de búsqueda, criterio de altura, criterio de caída sostenida y ajuste al máximo real de la señal bruta.
- Existe un fallback mecánico más exigente cuando el primer criterio no confirma fluencia.
- El valor de caída mínima es configurable desde el controlador y conserva 1.0 MPa por defecto.
- El usuario puede corregir manualmente el punto, y el valor manual tiene prioridad sobre el automático.
- El sistema guarda diagnósticos que permiten inspeccionar el criterio usado.

## 8. Resumen sintético del algoritmo principal
1. Convertir fuerza a esfuerzo, si aplica.
2. Tomar `x = elongation_mm` y `y = stress_MPa`.
3. Suavizar `y` con mediana y media móviles.
4. Limitar búsqueda a 2%-70% del dominio X.
5. Exigir candidato con al menos 65% del máximo global suavizado y ascenso mínimo de 8 MPa desde la línea base.
6. Seguir el máximo acumulado de la curva.
7. Confirmar una caída de al menos 1 MPa durante 3 puntos consecutivos.
8. Ajustar el candidato al máximo real de la señal bruta en ±18 puntos.
9. Si falla, ejecutar fallback mecánico con criterios de gradiente, caída, endurecimiento y puntuación.
10. Guardar resultado automático y diagnósticos; permitir sustitución por punto manual.
