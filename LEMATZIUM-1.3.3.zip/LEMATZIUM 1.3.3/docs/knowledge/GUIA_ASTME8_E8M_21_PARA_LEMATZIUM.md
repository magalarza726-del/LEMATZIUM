# Guía interna ASTM E8/E8M-21 para el asistente LEMATZIUM

Propósito: dar contexto normativo al asistente cuando responda preguntas sobre ensayos de tracción de materiales metálicos en LEMATZIUM. Esta guía no sustituye la norma completa ni autoriza reproducirla; solo orienta la explicación técnica y la trazabilidad del software.

## Alcance técnico relevante
ASTM E8/E8M-21 cubre el ensayo de tracción de materiales metálicos a temperatura ambiente y trata, entre otros resultados, resistencia de fluencia, punto de fluencia, resistencia a la tracción, elongación y reducción de área.

## Términos relevantes para el módulo de metales
- Fluencia discontinua: fluctuación o hesitación de la fuerza al inicio de la deformación plástica localizada. La curva no necesariamente debe verse perfectamente discontinua.
- Límite de fluencia superior: esfuerzo correspondiente a la fuerza máxima al inicio de la fluencia discontinua. Si hay varios picos al inicio de esa fluencia, se considera el primero.
- Límite de fluencia inferior: esfuerzo mínimo observado durante la fluencia discontinua, ignorando efectos transitorios.
- Elongación de punto de fluencia: se determina desde el diagrama esfuerzo-deformación o fuerza-elongación.

## Relación con el algoritmo de LEMATZIUM
El algoritmo de fluencia superior de metales busca una primera cima relevante seguida por una caída sostenida. Esta lógica se alinea conceptualmente con la idea normativa de registrar el esfuerzo asociado al máximo al inicio de la fluencia discontinua, pero el software no reemplaza la revisión del analista ni la verificación contra el método declarado por el laboratorio.

## Ruido y datos digitales
En datos digitales pueden aparecer pequeños picos y valles causados por ruido. ASTM E8/E8M-21 reconoce que el tratamiento de datos digitales puede requerir criterios para distinguir una región real de comportamiento mecánico frente a fluctuaciones menores. Por eso, en LEMATZIUM el suavizado y los umbrales deben explicarse como herramientas de detección, no como modificación de los datos primarios.

## Reglas de respuesta para el asistente
Cuando el usuario pregunte por fluencia en metales, el asistente debe:
1. Explicar primero en lenguaje simple: primera cima importante donde el material empieza a ceder.
2. Luego explicar el algoritmo interno: suavizado, ventana de búsqueda, candidato alto, caída sostenida, ajuste a dato bruto y fallback.
3. Aclarar qué significan ventanas como 7 puntos, 3 puntos y 18 puntos.
4. Defender el uso del suavizado: ayuda a ubicar la zona; el valor final debe volver a la señal original.
5. Señalar el límite de auditoría: los parámetros deben estar documentados, validados y trazables.
6. Evitar decir que el sistema “garantiza” trazabilidad si no existe registro completo del origen automático/manual del punto final.

## Frase recomendada
“El suavizado no cambia el CSV ni debería ser el valor reportado; funciona como una regla para no confundir ruido de adquisición con una fluencia real. Lo defendible es que el algoritmo localiza la zona con ayuda del suavizado y luego coloca el punto sobre la señal bruta, siempre con revisión del analista.”


## Referencias visuales de la copia interna
La copia PDF de ASTM E8/E8M-21 conservada en `docs/knowledge/ASTM_E8_E8M_21.pdf` es de apoyo documental interno. Para preguntas sobre fluencia y propiedades de fluencia, las páginas finales del PDF son especialmente relevantes:
- Página 17: métodos de velocidad y apartado de determinación de propiedades de fluencia.
- Página 18: explicación gráfica de resistencia de fluencia por offset y diagramas de fluencia discontinua.
- Página 19: diagramas de fuerza-elongación y tratamiento de uniform elongation.
- Página 20: elongación, reducción de área y criterios de reporte asociados.

Estas referencias permiten al asistente señalar el contexto normativo sin reproducir extensamente el texto de la norma.
