# Cambios integrados — Incertidumbre en módulo de metales

## Alcance

Se integró un motor de cálculo de incertidumbre para el módulo de tracción de metales, replicando las fórmulas de las hojas Excel entregadas para:

- Plancha / rectangular.
- Circular.
- Tubería / anular.

El cálculo se ejecuta por probeta, usando la geometría y los resultados activos de cada curva.

## Archivos principales modificados/agregados

- `modules/shared/tensile_unified/uncertainty.py`: motor de cálculo y configuración editable.
- `config/uncertainty_sources.json`: valores base equivalentes a la hoja `Fuent. Incertidumbre`.
- `launcher/uncertainty_editor.py`: pantalla principal nueva `INCERTIDUMBRE`.
- `modules/shared/tensile_unified/comment_templates.py`: plantillas con placeholders dinámicos de incertidumbre.
- `modules/module_tensile_unified/.../summary_comment_flow.py`: inserta incertidumbre automática en comentarios de la UI.
- `modules/module_tensile_unified/.../export_flow.py`: inserta incertidumbre automática en exportación por probeta.
- `modules/module_tensile_unified/.../reports/group_exporter.py`: inserta incertidumbre automática en exportación por grupos.

## Validación de referencia contra hojas Excel

Valores replicados con los datos cacheados de los libros entregados:

| Geometría | Esfuerzo máximo | Fluencia | Elongación |
|---|---:|---:|---:|
| Circular | 24 MPa | 35 MPa | 3.62 % |
| Plancha / rectangular | 16 MPa | 28 MPa | 3.61 % |
| Tubería / anular | 38 MPa | 27 MPa | 3.61 % |

## Notas operativas

- Las fuentes de fuerza y área son compartidas por las geometrías.
- La repetibilidad y reproducibilidad de fluencia, máximo y elongación se editan independientemente por geometría desde `INCERTIDUMBRE`.
- Los cambios del usuario se guardan en `user_config/uncertainty_sources.local.json`.
- El archivo Excel original no se modifica; se replica su lógica dentro de LEMATZIUM.
