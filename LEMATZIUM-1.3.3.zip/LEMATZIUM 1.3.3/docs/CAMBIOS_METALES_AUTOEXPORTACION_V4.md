# Cambios - Metales incertidumbre v4

- Se corrigió el formato de A/B en reportes Rp para mostrar esfuerzos reales en MPa y no números de punto.
- Se cambió el color predeterminado de las curvas a celeste.
- Se agregó botón **Autoexportación** en la ventana de exportación.
- La autoexportación lee la OT PDF, detecta filas con **Informe por separado** como inicio de informe y agrupa las filas siguientes **No Informado** hasta el siguiente informe.
- Los números de informe se generan de forma consecutiva desde el número inicial ingresado.
- Se conserva la exportación manual existente.
- Se alineó **Forma:** con el borde izquierdo de la tabla de geometría mediante una tabla invisible de igual ancho.
- Se ajustó la tabla superior sin bordes para que empiece en el mismo borde que la tabla de resultados y para evitar salto de línea en etiquetas como **Temperatura Máx/Mín** y **Velocidad de ensayo**.
