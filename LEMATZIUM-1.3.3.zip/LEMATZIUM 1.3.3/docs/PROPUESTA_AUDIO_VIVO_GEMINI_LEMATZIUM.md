# Propuesta de mejora · Audio en vivo para el Asistente virtual IA

## 1. Estado actual

LEMATZIUM 1.3.3 ya incorpora una **primera implementación funcional de audio en vivo** dentro del Módulo 3:

- Botón **🎙 Iniciar audio / ⏹ Detener audio**.
- Conexión Live API con el modelo de audio seleccionado desde Configuración.
- Captura de micrófono.
- Reproducción de audio del modelo.
- Visualización de transcripciones de entrada y salida en el panel de conversación.
- Tool calling local a la base de conocimiento de LEMATZIUM para preguntas de auditoría, capacitación y funcionamiento.

Modelos configurables:

- `gemini-3.1-flash-live-preview` como opción principal.
- `gemini-2.5-flash-native-audio-preview-12-2025` como alternativa configurable.

## 2. Mejoras recomendadas para la siguiente iteración

### 2.1. Interfaz de audio más especializada

Agregar una pestaña o panel lateral de **Audio en vivo** con:

- Indicador visual de estado:
  - Desconectado.
  - Conectando.
  - Escuchando.
  - Respondiendo.
  - Error / reconexión.
- Medidor de nivel del micrófono.
- Selector de dispositivo de entrada y salida.
- Indicador de modelo de audio activo.
- Temporizador de duración de sesión.

### 2.2. Modos de interacción

- **Push-to-talk**: mantener presionado para hablar.
- **Manos libres**: escucha continua con detección de actividad de voz.
- **Mute temporal** del micrófono sin cerrar la sesión.

### 2.3. Control de turnos y calidad conversacional

- Detección de interrupción del usuario para cortar respuestas largas del asistente.
- Control de silencio e inicio/fin de turno.
- Mensajes de estado más claros cuando la API detecta cierre de turno.
- Posibilidad de marcar una transcripción como “final” antes de añadirla al historial.

### 2.4. Robustez técnica

- Fallback automático entre modelos de audio cuando el modelo preferido no inicia por cuota o saturación.
- Reconexión automática con máximo de intentos.
- Timeout de conexión y cierre limpio de streams.
- Mensajes diferenciados para:
  - API key inválida.
  - Modelo no disponible.
  - Micrófono no detectado.
  - Salida de audio no disponible.
  - Límite temporal de uso alcanzado.

### 2.5. Persistencia y trazabilidad

- Exportar transcript de sesión en `.txt` o `.md` bajo acción expresa del usuario.
- No guardar audio por defecto.
- Registrar en transcript:
  - modelo de audio usado,
  - fecha/hora local,
  - duración de sesión,
  - eventos de fallback o reconexión.

## 3. Mejoras específicas para LEMATZIUM

- Perfil de voz técnico-profesional para consultas del laboratorio.
- Plantillas de prompt orientadas a:
  - ensayos mecánicos,
  - incertidumbre,
  - ISO/IEC 17025,
  - uso operativo de LEMATZIUM.
- Modo **asistente operativo** para guiar al usuario dentro del programa mediante instrucciones por voz.
- Modo **auditoría por voz**: responder únicamente con evidencia recuperada cuando el perfil activo sea Auditoría estricta.
- Comandos de voz del tipo:
  - “abre el módulo de tracción de plásticos”,
  - “explícame el último resultado calculado”,
  - “resume los parámetros principales de esta curva”.

## 4. Priorización sugerida

### Fase 1 — Implementada

- Botón de micrófono.
- Sesión Live API básica.
- Captura y reproducción de audio.
- Transcripción visible en pantalla.

### Fase 2 — Recomendación inmediata

- Push-to-talk y VAD.
- Selector de dispositivos.
- Indicadores visuales de micrófono y respuesta.
- Fallback automático entre modelos de audio.
- Reconexión automática.

### Fase 3 — Evolución LEMATZIUM

- Comandos de voz propios del sistema.
- Contexto técnico del módulo abierto.
- Integración con resultados, informes y flujos internos, bajo permisos y validaciones definidas.
