# Cambios finales: asistente defendible, fuentes visibles y HUB simplificado

- Se reforzó el prompt del asistente para explicar primero en lenguaje simple y luego con fundamento técnico.
- Se añadió una guía interna de estilo para responder como instructor y como soporte de auditoría.
- Se añadió una guía interna basada en ASTM E8/E8M-21 para contexto de fluencia, fluencia discontinua y datos digitales.
- Se copió el PDF ASTM E8/E8M-21 a `docs/knowledge/ASTM_E8_E8M_21.pdf` como fuente documental visible.
- Las fuentes consultadas ahora se muestran con ruta, líneas y extracto; ya no aparecen solo como referencias no visibles.
- En el HUB se retiró el botón `AUDITORÍA 17020-17025` de las tarjetas de módulos. El conocimiento queda disponible como fuente interna del asistente.
- En el HUB se retiró la descripción de los módulos y el botón `Abrir módulo`; los módulos se abren con doble clic sobre la tarjeta.


## Refinamiento posterior
- Las fuentes ya no solo se enumeran: cada respuesta con evidencia muestra una burbuja de “Fuentes” con botón `Ver fuentes`.
- El botón `Ver fuentes` abre un panel con ruta, líneas, extracto y opción `Abrir archivo fuente` cuando el archivo existe localmente.
- Se reforzó el prompt para explicar de forma comprensible qué significan 7, 3 y 18 puntos.
- Se añadió una guía de respuestas de auditoría sin sobreafirmar, para evitar errores como llamar “base de datos” a objetos internos o afirmar trazas que el reporte no demuestra.
- Se reforzó el contexto de ASTM E8/E8M-21 mediante guía interna y referencias visuales a la copia PDF de apoyo.
